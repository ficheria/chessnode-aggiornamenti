/* Grande aggiornamento, blocco 5 (11-11): pagina Analisi, schema 22 A (anteprime/blocco22_analisi, legenda_analisi_22.txt).
   A1 intestazione «Analisi» · salvati · impostazioni
   14-11 (Kiko t1940u): A2 «Analizza una partita» scacchiera + 4 scelte · Il tuo gioco · A3 Analisi in corso · A4 Partite analizzate.
   (prima: A2 «Analizza una partita»: CTA verde + Le tue partite con i bot · Incolla PGN · Importa da Lichess / Chess.com)
   A3 «Analisi in corso»: SOLO se c'è; progresso vero (N di M, %), altrimenti attività senza percentuale
   A4 «Partite analizzate»: l'ultima in evidenza + 2 righe · Vedi tutte (storico)
   A5 «Scacchiera di analisi» (nome deciso da Kiko, L.1028): Imposta posizione →
   A6 «In arrivo»: Analisi profonda del profilo, Scouting avversari · barra con Analisi attiva.
   Storico: localStorage 'chessnodeplay-analisi-storico-v1' (scritto da analisi_commenti.js). Partite con i bot: 'chessnodeplay-partite-bot-v1'.
   Rete: SOLO quando l'utente chiede l'import → API pubbliche senza token (lichess.org/api/games/user, api.chess.com/pub). */
(function(){
  'use strict';
  var C = window.CNP, ic = C.ic, esc = C.esc, A = C.A, W = A ? window.parent : null;
  var root = document.getElementById('pg');
  var SKEY = 'chessnodeplay-analisi-storico-v1', BKEY = 'chessnodeplay-partite-bot-v1', UKEY = 'chessnodeplay-analisi-import-v1';
  var BOT = {chessnote:'Chess Node', paola:'Paola', nerd:'Luca', serena:'Nadia', maestro:'Prof'};
  var vista = 'main', timer = 0, impRis = null;
  function fenChiave(f){ var p = String(f || 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1').trim().split(/\s+/); return (p[0] || '') + ' ' + (p[1] || 'w') + ' ' + (p[2] || '-') + ' ' + (p[3] || '-'); }
  function chiaveBot(fen, sans){
    var a = 0x811c9dc5, t = fenChiave(fen) + '|' + (sans || []).join(' ');
    for (var i = 0; i < t.length; i++) a = Math.imul(a ^ t.charCodeAt(i), 16777619) >>> 0;
    return 'bot:' + a.toString(36);
  }
  function pulisciStorico(g){
    var m = {}, out = [];
    (g || []).forEach(function(x){
      if (!x) return;
      var k = (x.sans && x.sans.length) ? (fenChiave(x.fen) + '|' + x.sans.join(' ')) : ('id:' + x.id);
      if (!m[k]){ m[k] = x; out.push(x); return; }
      var y = m[k], pa = (x.fatto?4:0)+(x.prec!=null?2:0)+(x.salvata?3:0)+(x.var&&x.var.length?2:0), pb = (y.fatto?4:0)+(y.prec!=null?2:0)+(y.salvata?3:0)+(y.var&&y.var.length?2:0);
      var keep = pa > pb ? x : y, drop = keep === x ? y : x;
      if (drop.salvata) keep.salvata = true;
      if (drop.var && !keep.var) keep.var = drop.var;
      if (keep.prec == null && drop.prec != null) keep.prec = drop.prec;
      if (!keep.fatto && drop.fatto){ keep.fatto = 1; keep.pct = 100; }
      if (keep !== y){ out[out.indexOf(y)] = keep; m[k] = keep; }
    });
    return out;
  }
  function storico(){
    var o = C.rd(SKEY), g = o && Array.isArray(o.g) ? pulisciStorico(o.g) : [];
    if (o && Array.isArray(o.g) && g.length !== o.g.length){ o.g = g; try { C.wr(SKEY, o); } catch(e){} }
    return g.slice().sort(function(a, b){ return (b.agg || 0) - (a.agg || 0); });
  }
  function partiteBot(){ var a = C.rd(BKEY); return (Array.isArray(a) ? a : []).filter(function(r){ return r && r.sans && r.sans.length > 1; }).sort(function(a, b){ return (b.ts || 0) - (a.ts || 0); }); }
  function quando(ts){
    if (!ts) return ''; var d = new Date(ts), o = new Date(), h = ('0' + d.getHours()).slice(-2) + ':' + ('0' + d.getMinutes()).slice(-2);
    var g0 = new Date(o.getFullYear(), o.getMonth(), o.getDate()).getTime(), gd = new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime(), dd = Math.round((g0 - gd) / 864e5);
    if (dd === 0) return 'oggi ' + h; if (dd === 1) return 'ieri';
    return d.getDate() + ' ' + ['gen', 'feb', 'mar', 'apr', 'mag', 'giu', 'lug', 'ago', 'set', 'ott', 'nov', 'dic'][d.getMonth()];
  }
  function chev(){ return ic('chevron-right', 20).replace('class="lu"', 'class="lu ch"'); }
  function analisiAP(){ try { return W.CNAnalisiPartita; } catch(e){ return null; } }
  function inCorso(){   // la partita dello storico non finita (la più recente); se gira adesso, i numeri veri dal motore
    var g = storico().filter(function(x){ return !x.fatto && x.n > 1 && (x.pct || x.a); })[0]; if (!g) return null;
    var P = analisiAP(), s = null; try { s = P && P.stato(); } catch(e){}
    var vivo = !!(s && s.run && W.CNAnalisi && W.CNAnalisi.mode && W.CNAnalisi.mode() === 'partita' && W.CNAnalisiPartitaUI && W.CNAnalisi.state().sans.join(' ') === (g.sans || []).join(' '));
    return {g:g, vivo:vivo, pr:vivo ? s.prog : {pct:g.pct, a:g.a, b:g.b, fase:g.fase}};
  }
  function bar(pr){ return pr && pr.pct != null ? '<div class="an-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="' + pr.pct + '"><i style="width:' + pr.pct + '%"></i></div>' : '<div class="an-bar att" role="progressbar" aria-label="Analisi in corso"><i></i></div>'; }
  function testoFase(pr){ var t = ''; try { t = analisiAP().t(pr.fase || 'fase1').replace('%a', pr.a).replace('%b', pr.b); } catch(e){ t = pr.a != null ? pr.a + ' di ' + pr.b : ''; } return t; }

  /* ---------- vista principale ---------- */
  function principale(){
    var h = '<header class="an-top"><h1>Analisi</h1>' +
      '<button class="hd15-b" data-pg="salvati.html" aria-label="I miei salvati">' + ic('bookmark', 24) + '</button>' +
      '<button class="hd15-b" data-pg="impostazioni.html#analisi" aria-label="Impostazioni dell\'analisi">' + ic('settings', 24) + '</button></header>';
    /* 14-11 (Kiko t1940u/t1947u): nuovo ordine — Analizza una partita (scacchiera illustrativa + 4 scelte) · Il tuo gioco ·
       Analisi in corso · Partite analizzate. Tolti i doppioni: CTA verde (= partite con i bot), «Scacchiera di analisi» (= Posizione
       personalizzata) e la riga Scouting (resta solo in Home). */
    var nb = partiteBot().length, ult = storico()[0], fenIll = 'r1bqk1nr/pppp1ppp/2n5/2b1p3/2B1P3/5N2/PPPP1PPP/RNBQK2R w KQkq - 4 4';
    try { if (ult && ult.sans && ult.sans.length && W && W.Chess){ var gI = new W.Chess(ult.fen || undefined); ult.sans.forEach(function(m){ gI.move(m); }); fenIll = gI.fen(); } } catch(eI){}
    h += '<section class="st-card" id="anA2"><h2 class="an-h2">Analizza una partita</h2>' +
      '<div class="an2-top">' + (C.mb ? '<div class="an2-mb" aria-hidden="true">' + C.mb(fenIll, 104) + '</div>' : '') +
        '<p class="an2-tx">Scegli da dove partire: Stockfish la rivede mossa per mossa e ti mostra errori, occasioni e mosse migliori.</p></div>' +
      '<div class="an2-g">' +
        '<button class="an2-c" data-v="imp">' + ic('v2-importa', 24) + '<b>Importa</b><small>Lichess / Chess.com</small></button>' +
        '<button class="an2-c" data-v="pgn">' + ic('copy', 24) + '<b>Incolla PGN</b><small>da un file o da un sito</small></button>' +
        '<button class="an2-c" data-az="libera">' + ic('search', 24) + '<b>Posizione personalizzata</b><small>metti i pezzi o muovi tu</small></button>' +
        '<button class="an2-c" data-v="bot">' + ic('v2-bot', 24) + '<b>Le tue partite con i bot</b><small>' + (nb ? nb + (nb === 1 ? ' partita' : ' partite') : 'nessuna ancora') + '</small></button>' +
      '</div></section>';
    // Il tuo gioco (stessa sintesi della card in Home, dati veri riempiti dopo il disegno)
    h += '<section class="st-card st-sp" id="anTG"><h2 class="an-h2">Il tuo gioco<button data-pg="profilo_scacchistico.html">Vedi tutto</button></h2>' +
      '<button class="an-tg" data-pg="profilo_scacchistico.html" aria-label="Il tuo gioco: apri il profilo completo"><div class="itg-b"><div class="itg-sk"></div></div></button></section>';
    // A3 (solo se presente)
    var ic3 = inCorso();
    if (ic3){
      var pr = ic3.pr || {}, g = ic3.g;
      h += '<section class="st-card st-sp" id="anA3"><h2 class="an-h2">Analisi in corso</h2><p class="an-sub">' + esc(g.titolo || 'Partita') + ' · ' + esc(quando(g.agg)) + '</p>' + bar(pr) +
        (pr.pct != null ? '<div class="an-pl"><span>' + esc(testoFase(pr)) + '</span><b>' + pr.pct + '%</b></div>' : '') +
        '<p class="an-mu">' + (ic3.vivo ? 'Continua anche mentre giri nell\'app: qui vedi a che punto è.' : 'In pausa: riprende da qui quando la apri.') + '</p>' +
        '<button class="an-sec" data-apri="' + esc(g.id) + '" style="margin-top:10px">' + (ic3.vivo ? 'Apri' : 'Riprendi') + '</button></section>';
    }
    // A4
    var fatte = storico().filter(function(x){ return x.fatto; });
    if (fatte.length){
      var u = fatte[0];
      h += '<section class="st-card st-sp" id="anA4"><h2 class="an-h2">Partite analizzate' + (fatte.length > 3 ? '<button data-v="tutte">Vedi tutte</button>' : '') + '</h2>' +
        '<button class="an-hl" data-apri="' + esc(u.id) + '"><b>' + esc(u.titolo || 'Partita') + '</b><small>' + (u.prec != null ? 'Precisione ' + u.prec + '% · ' : '') + esc(quando(u.fattaIl || u.agg)) + '</small><span class="an-sec">Apri</span></button>' +
        fatte.slice(1, 3).map(riga).join('') + '</section>';
    }
    return h + C.bar(3);
  }
  function riga(x){ return '<button class="an-li" data-apri="' + esc(x.id) + '"><span>' + esc(x.titolo || 'Partita') + (x.prec != null ? ' · ' + x.prec + '%' : '') + ' · ' + esc(quando(x.fattaIl || x.agg)) + '</span>' + (x.salvata ? ic('bookmark', 16) : '') + '<em>Apri</em></button>'; }

  /* ---------- viste interne ---------- */
  function testa(t){ return '<header class="an-vh"><button class="pg-back" data-vback aria-label="Indietro">' + ic('chevron-left', 24) + '</button><h1>' + esc(t) + '</h1></header>'; }
  function vBot(){
    var a = partiteBot();
    return testa('Le tue partite con i bot') + (a.length ? '<section class="st-card">' + a.slice(0, 40).map(function(r){
      var es = r.esito === 'v' ? '<span class="an-res v">Vinta</span>' : r.esito === 's' ? '<span class="an-res s">Persa</span>' : '<span class="an-res">Patta</span>';
      return '<button class="an-li" data-bot="' + esc(r.id) + '"><span>Tu vs ' + esc(BOT[r.bot] || 'bot') + ' · ' + esc(quando(r.ts)) + ' · ' + Math.ceil(r.sans.length / 2) + ' mosse</span>' + es + '</button>'; }).join('') + '</section>'
      : '<p class="an-vuoto">Non hai ancora giocato partite con i bot.</p><button class="btn an-cta" data-go="tab2">Gioca una partita</button>');
  }
  function seg(nome, val){ return '<div class="seg" role="radiogroup" data-seg="' + nome + '">' + [['w', 'Bianco'], ['b', 'Nero'], ['', 'Non so']].map(function(x){ return '<button type="button" role="radio" data-val="' + x[0] + '" aria-checked="' + (val === x[0]) + '" class="' + (val === x[0] ? 'on' : '') + '">' + x[1] + '</button>'; }).join('') + '</div>'; }
  var pgnCol = '';
  function vPgn(){
    return testa('Incolla PGN') + '<textarea class="an-ta" id="anTa" spellcheck="false" autocapitalize="off" aria-label="PGN della partita" placeholder="Incolla qui la partita (PGN)…"></textarea>' +
      '<span class="an-lab">Con che colore giocavi?</span>' + seg('col', pgnCol) +
      '<p class="an-err" id="anErr" role="status"></p><button class="btn an-cta" data-az="pgnok" style="margin-top:6px">Analizza la partita</button>' +
      '<p class="an-src">Il PGN resta sul telefono: niente viene inviato.</p>';
  }
  function vImp(){
    var u = C.rd(UKEY) || {}, s = u.s || 'lichess';
    var h = testa('Importa da Lichess / Chess.com') +
      '<div class="seg" role="radiogroup" data-seg="sito">' + [['lichess', 'Lichess'], ['chesscom', 'Chess.com']].map(function(x){ return '<button type="button" role="radio" data-val="' + x[0] + '" aria-checked="' + (s === x[0]) + '" class="' + (s === x[0] ? 'on' : '') + '">' + x[1] + '</button>'; }).join('') + '</div>' +
      '<span class="an-lab">Nome utente</span><input class="an-in" id="anUser" autocomplete="off" autocapitalize="off" spellcheck="false" value="' + esc(u.u || '') + '" placeholder="es. il tuo nome su ' + (s === 'lichess' ? 'Lichess' : 'Chess.com') + '">' +
      '<p class="an-err" id="anErr" role="status"></p><button class="btn an-cta" data-az="cerca" style="margin-top:6px">Cerca le ultime partite</button>' +
      '<p class="an-src">Usa Internet solo ora: legge le partite pubbliche dal sito scelto, senza accesso al tuo account.</p>';
    if (impRis) h += '<section class="st-card st-sp">' + (impRis.length ? impRis.map(function(g, i){
      return '<button class="an-li" data-imp="' + i + '"><span>' + esc(g.titolo) + ' · ' + esc(quando(g.ts)) + '</span>' + (g.esito === 'v' ? '<span class="an-res v">Vinta</span>' : g.esito === 's' ? '<span class="an-res s">Persa</span>' : g.esito === 'p' ? '<span class="an-res">Patta</span>' : '') + '</button>'; }).join('') : '<p class="an-vuoto">Nessuna partita trovata.</p>') + '</section>';
    return h;
  }
  function vTutte(){
    var a = storico().filter(function(x){ return x.fatto; });
    return testa('Partite analizzate') + '<section class="st-card">' + (a.length ? a.map(riga).join('') : '<p class="an-vuoto">Nessuna partita analizzata.</p>') + '</section>';
  }
  function disegna(){
    var h = vista === 'bot' ? vBot() : vista === 'pgn' ? vPgn() : vista === 'imp' ? vImp() : vista === 'tutte' ? vTutte() : principale();
    root.innerHTML = h;
    var tg = document.querySelector('#anTG .itg-b');
    if (tg && window.CNTuoGioco){ if (!A) tg.innerHTML = window.CNTuoGioco.card(null, window.CNCollega && window.CNCollega.stato()); else window.CNTuoGioco.riassunto().then(function(d){ var el = document.querySelector('#anTG .itg-b'); if (el) el.innerHTML = window.CNTuoGioco.card(d, window.CNCollega && window.CNCollega.stato()); }); }
    clearInterval(timer);
    /* 15-11: si aggiorna SOLO se l'analisi gira davvero. Prima, con un'analisi in pausa (!vivo),
       il timer richiamava disegna() ogni secondo → la pagina lampeggiava e sembrava bloccata. */
    if (vista === 'main' && inCorso() && inCorso().vivo) timer = setInterval(function(){ var x = inCorso(); if (!x || !x.vivo){ clearInterval(timer); disegna(); return; } var b = document.querySelector('#anA3 .an-bar i'), l = document.querySelector('#anA3 .an-pl');
      if (b && x.pr && x.pr.pct != null){ b.style.width = x.pr.pct + '%'; b.parentNode.setAttribute('aria-valuenow', x.pr.pct); } if (l && x.pr) l.innerHTML = '<span>' + esc(testoFase(x.pr)) + '</span><b>' + x.pr.pct + '%</b>'; }, 1000);
  }
  function apriVista(v){ vista = v; disegna(); window.scrollTo(0, 0); }
  C.canBack = function(){ return vista !== 'main'; };
  C.onBack = function(){ if (vista === 'main') return false; apriVista('main'); return true; };

  /* ---------- aprire una partita / la scacchiera ---------- */
  function apriPartita(pgn, meta){
    if (!W || !C.P){ C.toast('Anteprima: l\'analisi si apre nell\'app.'); return; }
    W.__cnAnReq = {pgn:pgn, partita:meta}; C.P.go('anpartita');
    /* Analizza me: solo se il colore dell'utente è noto (tue partite, bot compresi). Non si marca «self» una partita solo studiata. */
    if (pgn && meta && meta.me && W.__cnap && typeof W.__cnap.importaMe === 'function'){
      var priv = meta.fonte === 'pgn' || meta.fonte === 'bot' || !!meta.bot;
      var opt = { private: priv, fileName: meta.fonte || 'partita' };
      if (priv && (meta.fonte === 'bot' || meta.bot) && meta.sans){ opt.source = 'interna'; opt.sourceId = chiaveBot(meta.fen, meta.sans); }
      try { W.__cnap.importaMe(pgn, opt); } catch (eImp) {}
    }
  }
  function pgnDa(fen, sans, meta){
    var g = new W.Chess(fen || undefined); meta = meta || {};
    if (fen && fen.split(' ')[0] !== 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR'){ g.setHeader('SetUp', '1'); g.setHeader('FEN', fen); }
    g.setHeader('Site', 'Chess Node');
    if (meta.titolo) g.setHeader('Event', meta.titolo);
    var d = meta.data ? new Date(meta.data) : null;
    if (d && !isNaN(d.getTime())) g.setHeader('Date', d.getFullYear() + '.' + ('0' + (d.getMonth() + 1)).slice(-2) + '.' + ('0' + d.getDate()).slice(-2));
    if (meta.me === 'w'){ g.setHeader('White', 'Tu'); if (meta.titolo) g.setHeader('Black', String(meta.titolo).replace(/^Tu vs\s+/, '') + ' (bot)'); }
    if (meta.me === 'b'){ g.setHeader('Black', 'Tu'); if (meta.titolo) g.setHeader('White', String(meta.titolo).replace(/^Tu vs\s+/, '') + ' (bot)'); }
    sans.forEach(function(m){ g.move(m); }); return g.pgn();
  }
  function apriStorico(id){
    var x = storico().filter(function(y){ return y.id === id; })[0]; if (!x || !x.sans) return;
    apriPartita(pgnDa(x.fen, x.sans, x), {titolo:x.titolo, me:x.me, esito:x.esito, fonte:x.fonte, bot:x.bot, data:x.data, fen:x.fen, sans:x.sans});
  }
  function apriBot(id){ if (!C.P){ C.toast('Anteprima: l\'analisi si apre nell\'app.'); return; } C.P.go('botanalizza', id); }
  function profiloNome(){ var p = C.rd('chessnodeplay-profilo-v1') || {}, u = C.rd(UKEY) || {}; return [p.nome, u.u].filter(Boolean).map(function(s){ return String(s).toLowerCase(); }); }
  function leggiPgn(t){
    try { var g = new W.Chess(); g.loadPgn(t); var hd = g.getHeaders ? g.getHeaders() : {}; if (hd.Variant && !/^(standard|from position)$/i.test(hd.Variant)) return {err:'Questa partita è una variante (' + hd.Variant + '): si analizzano solo gli scacchi normali.'};
      if (g.history().length < 2) return {err:'Servono almeno due mosse per analizzare una partita.'}; return {g:g, hd:hd}; }
    catch(e){ var bad = String(e && e.message || '').match(/move[^:]*:\s*(\S+)/i); return {err:'Non riesco a leggere questo PGN.' + (bad ? ' Mossa non valida: ' + bad[1] + '.' : '')}; }
  }
  function esitoDa(res, me){ if (!me || !res || res === '*') return null; if (res === '1/2-1/2') return 'p'; return (res === '1-0') === (me === 'w') ? 'v' : 's'; }
  function okPgn(){
    var t = document.getElementById('anTa').value.trim(), e = document.getElementById('anErr');
    if (!t){ e.textContent = 'Incolla prima la partita.'; return; }
    if (!W){ e.textContent = 'Anteprima: l\'analisi si apre nell\'app.'; return; }
    var r = leggiPgn(t); if (r.err){ e.textContent = r.err; return; }
    var me = pgnCol, hd = r.hd, nomi = profiloNome();
    if (!me && hd.White && nomi.indexOf(String(hd.White).toLowerCase()) >= 0) me = 'w';
    if (!me && hd.Black && nomi.indexOf(String(hd.Black).toLowerCase()) >= 0) me = 'b';
    var tit = me ? 'Tu vs ' + ((me === 'w' ? hd.Black : hd.White) || 'avversario') : ((hd.White || 'Bianco') + ' vs ' + (hd.Black || 'Nero'));
    apriPartita(t, {titolo:tit, me:me || null, esito:esitoDa(hd.Result, me), fonte:'pgn'});
  }
  function cerca(){
    var u = document.getElementById('anUser').value.trim(), e = document.getElementById('anErr'), s = (C.rd(UKEY) || {}).s || 'lichess';
    if (!/^[A-Za-z0-9_-]{2,30}$/.test(u)){ e.textContent = 'Scrivi un nome utente valido.'; return; }
    if (!W){ e.textContent = 'Anteprima: l\'import si usa nell\'app.'; return; }
    C.wr(UKEY, {s:s, u:u}); e.textContent = 'Cerco le partite…';
    var p = s === 'lichess' ? daLichess(u) : daChesscom(u);
    p.then(function(a){ impRis = a; disegna(); }, function(err){ var x = document.getElementById('anErr'); if (x) x.textContent = err && err.message === '404' ? 'Utente non trovato.' : 'Non riesco a scaricare le partite: controlla la connessione e riprova.'; });
  }
  function daLichess(u){   // API pubblica di Lichess (nessun token): ultime 10 partite in NDJSON con il PGN
    return fetch('https://lichess.org/api/games/user/' + encodeURIComponent(u) + '?max=10&pgnInJson=true&clocks=false&evals=false&opening=false', {headers:{Accept:'application/x-ndjson'}})
      .then(function(r){ if (!r.ok) throw new Error(String(r.status)); return r.text(); })
      .then(function(t){ return t.split('\n').filter(Boolean).map(function(l){ try { return JSON.parse(l); } catch(e){ return null; } }).filter(function(g){ return g && g.pgn && (!g.variant || g.variant === 'standard' || g.variant === 'fromPosition'); }).map(function(g){
        var w = ((g.players.white.user || {}).name || 'Bianco'), b = ((g.players.black.user || {}).name || 'Nero'), me = w.toLowerCase() === u.toLowerCase() ? 'w' : b.toLowerCase() === u.toLowerCase() ? 'b' : null;
        var es = me ? (!g.winner ? (/^(created|started|aborted|noStart|unknownFinish)$/.test(g.status) ? null : 'p') : (g.winner === 'white') === (me === 'w') ? 'v' : 's') : null;   // rilievo 19: annullata / non finita ≠ patta
        return {pgn:g.pgn, me:me, esito:es, ts:g.createdAt, titolo:me ? 'Tu vs ' + (me === 'w' ? b : w) : w + ' vs ' + b, fonte:'lichess'}; }); });
  }
  function daChesscom(u){   // API pubblica di Chess.com (nessun token): archivio del mese più recente
    var base = 'https://api.chess.com/pub/player/' + encodeURIComponent(u.toLowerCase()) + '/games/archives';
    return fetch(base).then(function(r){ if (!r.ok) throw new Error(String(r.status)); return r.json(); }).then(function(j){
      var ar = (j.archives || []).slice(-1)[0]; if (!ar) return [];
      return fetch(ar).then(function(r){ if (!r.ok) throw new Error(String(r.status)); return r.json(); }).then(function(m){
        return (m.games || []).filter(function(g){ return g.pgn && (!g.rules || g.rules === 'chess'); }).slice(-10).reverse().map(function(g){
          var w = g.white.username, b = g.black.username, me = w.toLowerCase() === u.toLowerCase() ? 'w' : b.toLowerCase() === u.toLowerCase() ? 'b' : null;
          var mr = me ? g[me === 'w' ? 'white' : 'black'].result : null, es = !me ? null : mr === 'win' ? 'v' : /agreed|repetition|stalemate|insufficient|50move|timevsinsufficient/.test(mr) ? 'p' : 's';
          return {pgn:g.pgn, me:me, esito:es, ts:(g.end_time || 0) * 1000, titolo:me ? 'Tu vs ' + (me === 'w' ? b : w) : w + ' vs ' + b, fonte:'chesscom'}; }); }); });
  }

  /* ---------- clic ---------- */
  root.addEventListener('click', function(ev){
    var t;
    if ((t = ev.target.closest('[data-vback]'))){ apriVista('main'); return; }
    if ((t = ev.target.closest('[data-v]'))){ if (t.dataset.v === 'imp') impRis = null; apriVista(t.dataset.v); return; }
    if ((t = ev.target.closest('[data-apri]'))){ apriStorico(t.dataset.apri); return; }
    if ((t = ev.target.closest('[data-bot]'))){ apriBot(t.dataset.bot); return; }
    if ((t = ev.target.closest('[data-imp]'))){ var g = impRis && impRis[+t.dataset.imp]; if (g) apriPartita(g.pgn, {titolo:g.titolo, me:g.me, esito:g.esito, fonte:g.fonte, data:g.ts}); return; }
    if ((t = ev.target.closest('[data-seg] [data-val]'))){
      var sg = t.parentNode.dataset.seg, v = t.dataset.val;
      if (sg === 'col') pgnCol = v; else if (sg === 'sito'){ var u = C.rd(UKEY) || {}; u.s = v; C.wr(UKEY, u); impRis = null; var keep = document.getElementById('anUser').value; disegna(); document.getElementById('anUser').value = keep; return; }
      [].forEach.call(t.parentNode.children, function(b){ var on = b === t; b.classList.toggle('on', on); b.setAttribute('aria-checked', on); }); return;
    }
    if ((t = ev.target.closest('[data-az]'))){
      var az = t.dataset.az;
      if (az === 'cta'){   // la partita più recente con un bot non ancora analizzata; senza partite: Incolla PGN
        var fatte = {}; storico().forEach(function(x){ if (x.fatto) fatte[(x.sans || []).join(' ')] = 1; });
        var r = partiteBot().filter(function(x){ return !fatte[x.sans.join(' ')]; })[0] || partiteBot()[0];
        if (r) apriBot(r.id); else apriVista('pgn');
      }
      else if (az === 'libera'){ if (C.P) C.P.go('anposizione'); else C.toast('Anteprima: la scacchiera si apre nell\'app.'); }   // 15-11: prima la scelta Editor dei pezzi / Muovi i pezzi
      else if (az === 'pgnok') okPgn();
      else if (az === 'cerca') cerca();
    }
  });
  window.addEventListener('pageshow', function(ev){ if (ev.persisted) disegna(); });
  document.addEventListener('visibilitychange', function(){ if (!document.hidden && vista === 'main') disegna(); });
  disegna();
  window.__analisiPg = {disegna:disegna, vista:function(){ return vista; }, apriVista:apriVista};
})();
