/* Progressi 23b — costruito dalle correzioni scritte (Kiko 07-11 18:12 e schema 23).
   Dati veri da chessnodeplay-stats-v1, chessnodeplay-progress-v1 e CNBotStats.
   ?demo=1 = dati di esempio solo in memoria, segnalati in pagina, niente scritture.
   Precisione e punteggio restano etichettati «provvisorio». Le notifiche non si toccano. */
(function () {
  'use strict';
  var W = window, C = W.CNP || {}, Q = new URLSearchParams(location.search), DEMO = Q.has('demo');
  var esc = C.esc || function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };
  var ic = C.ic || function () { return ''; };
  function rd(k) { try { return JSON.parse(localStorage.getItem(k)); } catch (e) { return null; } }
  function pad(n) { return ('0' + n).slice(-2); }
  function dk(t) { var d = new Date(t); return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); }
  var TODAY = dk(Date.now());
  function addD(k, n) { var p = k.split('-'); return dk(new Date(+p[0], p[1] - 1, +p[2] + n).getTime()); }
  function itNum(n, dec) { var s = dec != null ? (Math.round(n * Math.pow(10, dec)) / Math.pow(10, dec)).toFixed(dec) : String(Math.round(n)); return s.replace('.', ','); }
  var MESI = ['gen', 'feb', 'mar', 'apr', 'mag', 'giu', 'lug', 'ago', 'set', 'ott', 'nov', 'dic'];
  function itData(k) { if (!k) return ''; var p = k.split('-'); return (+p[2]) + ' ' + MESI[(+p[1] || 1) - 1]; }
  var MINT = 5; /* soglia già usata in Progressi 19c: % per tema solo con almeno 5 esercizi */
  var MIN_AN = 10; /* stessa soglia «Pochi dati» dell'analisi profonda: sotto 10 partite analizzate */
  var PERIODI = [['tutto', 'Tutte'], ['90', '90 g'], ['30', '30 g'], ['7', '7 g']];
  var periodo = 'tutto';
  var colBot = 'tutti'; /* tutti | w | b */
  var tempoBot = 'tutti'; /* tutti | bullet | blitz | rapide */
  var vediTutti = false;

  var BOOK = W.BOOK || { chapters: [], ex: [] }, CH = BOOK.chapters || [], EX = BOOK.ex || [];
  var BS = W.CNBotStats;
  var progress = rd('chessnodeplay-progress-v1') || {}, st = rd('chessnodeplay-stats-v1') || {};
  var botN = [], botS = [];

  if (DEMO) (function () {
    progress = {}; st = { diary: {}, time: { total: 0, days: {} }, rev: {}, cups: {}, p50: [], thl: {}, fo: {} };
    var done = { m1: 64, m2: 42, dbl: 35, disa: 12, pin: 18, skew: 16, promo: 8, fin: 14, defl: 2, def: 10 }, i = 0;
    EX.forEach(function (e) {
      if (done[e.c] > 0) {
        var ok = (i * 7 + e.c.length) % 10 < (e.c === 'm1' ? 9 : e.c === 'defl' ? 2 : e.c === 'pin' ? 5 : 7);
        progress[e.n] = ok ? 's' : 'e'; st.fo[e.n] = ok ? 1 : 0; done[e.c]--; i++;
      }
    });
    var R = [6, 9, 0, 12, 8, 7, 10, 0, 0, 5, 11, 9, 8, 6, 7, 10, 9, 12, 8, 6];
    for (var d = 0; d < 20; d++) {
      var k = addD(TODAY, -d), r = R[d]; if (d < 7 && !r) r = 4;
      if (r) {
        st.diary[k] = { t: r + 1, r: r, p: Math.round(r * (0.6 + (d % 4) * 0.08)), s: r * 42000, n: r, th: {} };
        st.time.days[k] = 600000 + r * 90000;
      }
    }
    if (st.diary[TODAY]) st.diary[TODAY].g = [1, 2, 3, 4, 5, 6];
    st.time.total = 26.5 * 3600000;
    st.cups = { costanza: ['2026-10-27', '2026-10-31', null], traguardi: ['2026-10-29', null, null], impegno: ['2026-10-24', '2026-10-31', null], precisione: ['2026-10-30', null, null], lacuna: [null, null, null] };
    for (var j = 0; j < 50; j++) st.p50.push(j % 3 ? 1 : 0);
    botN = (BS && BS.esempio) ? BS.esempio(TODAY) : [];
    botS = [
      { bot: 'paola', colore: 'w', orologio: '10+0', esito: 'v', motivo: 'matto', data: addD(TODAY, -4), semimosse: 40, precisione: 71, handicap: true },
      { bot: 'nerd', colore: 'b', orologio: '5', esito: 's', motivo: 'matto', data: addD(TODAY, -9), semimosse: 52, precisione: 58, handicap: true },
      { bot: 'chessnote', colore: 'w', orologio: 'no', esito: 'p', motivo: 'accordo', data: addD(TODAY, -2), semimosse: 80, precisione: 80, handicap: true }
    ];
  })();
  else {
    if (BS) { botN = BS.leggi() || []; botS = (BS.leggiSpeciali() || []).filter(function (r) { return r.handicap; }); }
  }
  ['diary', 'rev', 'cups', 'thl', 'fo'].forEach(function (k) { if (!st[k] || typeof st[k] !== 'object') st[k] = {}; });
  if (!st.time || typeof st.time !== 'object') st.time = {}; if (!st.time.days) st.time.days = {}; if (!Array.isArray(st.p50)) st.p50 = [];

  function giorniPeriodo() { return periodo === 'tutto' ? null : +periodo; }
  function inPeriodo(k) {
    if (!k || periodo === 'tutto') return true;
    var lim = addD(TODAY, -((+periodo) - 1));
    return k >= lim && k <= TODAY;
  }
  function isSolved(n) { return progress[n] === 's' || progress[n] === 'e'; }
  function studied(k) { var e = st.diary[k]; return (st.time.days[k] || 0) >= 60000 || !!(e && e.t > 0); }
  var streak = 0, best = 0;
  (function () {
    var k = studied(TODAY) ? TODAY : addD(TODAY, -1);
    while (studied(k)) { streak++; k = addD(k, -1); }
    var ks = {}; Object.keys(st.time.days).concat(Object.keys(st.diary)).forEach(function (x) { if (studied(x)) ks[x] = 1; });
    var run = 0, prev = null;
    Object.keys(ks).sort().forEach(function (x) { run = prev && addD(prev, 1) === x ? run + 1 : 1; if (run > best) best = run; prev = x; });
  })();
  function monthH() { var m = 0, mk = TODAY.slice(0, 7); Object.keys(st.time.days).forEach(function (k) { if (k.slice(0, 7) === mk) m += st.time.days[k]; }); return m / 3600000; }
  function fascia(clk) {
    if (clk === '1') return 'bullet';
    if (clk === '3' || clk === '3+2' || clk === '5' || clk === '5+2') return 'blitz';
    if (clk === '10' || clk === '10+5' || clk === '10+0' || clk === '15+10' || clk === '30') return 'rapide';
    return 'altro'; /* «no» e eventuali tempi non raggruppati: solo in Tutti i tempi */
  }
  function filtraBot(list) {
    return (list || []).filter(function (g) {
      if (!inPeriodo(g.data)) return false;
      if (colBot !== 'tutti' && g.colore !== colBot) return false;
      if (tempoBot !== 'tutti' && fascia(g.orologio) !== tempoBot) return false;
      return true;
    });
  }
  function vps(list) {
    var r = { n: list.length, v: 0, p: 0, s: 0, prec: null, np: 0, sp: 0 };
    list.forEach(function (g) { r[g.esito]++; if (typeof g.precisione === 'number') { r.sp += g.precisione; r.np++; } });
    if (r.np) r.prec = Math.round(r.sp / r.np);
    return r;
  }
  function nomeOrologio(id) {
    if (BS && BS.OROLOGI) { var x = BS.OROLOGI.filter(function (o) { return o[0] === id; })[0]; if (x) return x[1]; }
    return id === 'no' ? 'Senza orologio' : id;
  }

  function chips(name, items, sel) {
    return '<div class="ps-chips" role="radiogroup">' + items.map(function (it) {
      return '<button type="button" class="ps-chip" data-' + name + '="' + it[0] + '" role="radio" aria-checked="' + (sel === it[0] ? 'true' : 'false') + '">' + esc(it[1]) + '</button>';
    }).join('') + '</div>';
  }
  function kpi(v, l, nota) {
    return '<div class="pr-kpi"><b>' + v + '</b><span>' + esc(l) + (nota ? '<small>' + esc(nota) + '</small>' : '') + '</span></div>';
  }
  function lineChart(vals, col, labels) {
    if (!vals.length) return '';
    var w = 305, h = 48, max = 1, i, pts = [];
    vals.forEach(function (v) { if (v > max) max = v; });
    if (max <= 0) max = 1;
    for (i = 0; i < vals.length; i++) {
      var x = vals.length === 1 ? w / 2 : i * w / (vals.length - 1);
      var y = h - (vals[i] / max) * (h - 4);
      pts.push(x.toFixed(1) + ',' + y.toFixed(1));
    }
    var lab = '';
    if (labels && labels.length) {
      lab = '<div class="pr-clab"><span>' + esc(labels[0]) + '</span><span>' + esc(labels[labels.length - 1]) + '</span></div>';
    }
    return '<svg class="pr-line" viewBox="0 0 ' + w + ' ' + h + '" width="100%" height="' + h + '" aria-hidden="true"><polyline points="' + pts.join(' ') + '" fill="none" stroke="' + col + '" stroke-width="2.5" stroke-linejoin="round"/></svg>' + lab;
  }

  function radarHtml(data) {
    /* data: [{name, pct|null, n}]; pct null = pochi dati: asse tratteggiato, niente vertice né segmento */
    var n = data.length; if (!n) return '<p class="pr-vuoto">Pochi dati per la ragnatela.</p>';
    var W = 360, H = 300, cx = 180, cy = 148, R = 100, i, j, g = '', few = false;
    function pt(i, r) { var a = -Math.PI / 2 + i * 2 * Math.PI / n; return [cx + Math.cos(a) * r, cy + Math.sin(a) * r]; }
    [0.25, 0.5, 0.75, 1].forEach(function (f) {
      var pts = []; for (i = 0; i < n; i++) { var p = pt(i, R * f); pts.push(p[0].toFixed(1) + ',' + p[1].toFixed(1)); }
      g += '<polygon points="' + pts.join(' ') + '" fill="none" stroke="currentColor" class="pr-grid"/>';
    });
    for (i = 0; i < n; i++) {
      var a = pt(i, R), dash = data[i].pct == null ? ' stroke-dasharray="4 4"' : '';
      if (data[i].pct == null) few = true;
      g += '<path d="M' + cx + ' ' + cy + ' L' + a[0].toFixed(1) + ' ' + a[1].toFixed(1) + '" stroke="currentColor" class="pr-axis"' + dash + '/>';
      var L = pt(i, R + 22), cs = Math.cos(-Math.PI / 2 + i * 2 * Math.PI / n);
      var anc = Math.abs(cs) < 0.3 ? 'middle' : cs > 0 ? 'start' : 'end';
      g += '<text x="' + L[0].toFixed(1) + '" y="' + (L[1] + 4).toFixed(1) + '" text-anchor="' + anc + '" class="pr-rl">' + esc(data[i].name) + '</text>';
    }
    for (i = 0; i < n; i++) {
      j = (i + 1) % n;
      if (data[i].pct == null || data[j].pct == null) continue;
      var p1 = pt(i, R * data[i].pct / 100), p2 = pt(j, R * data[j].pct / 100);
      g += '<path d="M' + p1[0].toFixed(1) + ' ' + p1[1].toFixed(1) + ' L' + p2[0].toFixed(1) + ' ' + p2[1].toFixed(1) + '" stroke="#2D6A4F" stroke-width="2.5" fill="none"/>';
    }
    return '<div class="pr-rad">' +
      '<svg viewBox="0 0 ' + W + ' ' + H + '" width="100%" role="img" aria-label="Primo colpo per tema">' + g + '</svg>' +
      (few ? '<p class="pr-note">Assi tratteggiati: Pochi dati (meno di ' + MINT + ' esercizi). Nessuna percentuale su quegli assi.</p>' : '') +
      '</div>';
  }

  var analisiCache = null, analisiStato = 'attesa';

  function tatticaPeriodo() {
    var risolti = 0, primo = 0, days = [];
    var nGiorni = periodo === '7' ? 7 : 14;
    for (var i = nGiorni - 1; i >= 0; i--) {
      var k = addD(TODAY, -i), e = inPeriodo(k) ? (st.diary[k] || {}) : {};
      days.push({ k: k, r: e.r || 0 });
    }
    Object.keys(st.diary).forEach(function (k) {
      if (!inPeriodo(k)) return;
      var e = st.diary[k] || {};
      risolti += e.r || 0; primo += Math.min(e.p || 0, e.r || 0);
    });
    var foK = Object.keys(st.fo);
    /* primo colpo complessivo nel periodo: dai conteggi giornalieri (dato vero) */
    var pctPrimo = risolti ? Math.round(100 * primo / risolti) : null;
    /* per tema, il primo colpo è per esercizio (fo), non per giorno: si mostra sulla ragnatela solo con filtro «Tutto» */
    var temi = CH.map(function (c) {
      var tot = 0, ok = 0, f1 = 0, fn = 0;
      EX.forEach(function (e) {
        if (e.c !== c.id) return; tot++;
        if (isSolved(e.n)) ok++;
        if (st.fo[e.n] != null) { fn++; f1 += st.fo[e.n] ? 1 : 0; }
      });
      return { id: c.id, name: c.name, tot: tot, ok: ok, f1: f1, fn: fn, pct: fn >= MINT ? Math.round(100 * f1 / fn) : null };
    });
    return { risolti: risolti, pctPrimo: pctPrimo, days: days, temi: temi };
  }

  function assiRadar(t) {
    var pref = ['m1', 'm2', 'dbl', 'disa', 'disc', 'pin', 'skew', 'defl', 'fin'], assi = [];
    pref.forEach(function (id) { t.temi.forEach(function (c) { if (c.id === id && assi.length < 8 && assi.indexOf(c) < 0) assi.push(c); }); });
    t.temi.slice().sort(function (a, b) { return b.fn - a.fn; }).forEach(function (c) { if (assi.length < 8 && assi.indexOf(c) < 0 && c.fn > 0) assi.push(c); });
    return assi.slice(0, 8);
  }
  function htmlRadar(t) {
    var h = '<section class="st-card pr-card" id="prRad"><h2 class="an-h2">Primo colpo per tema</h2>';
    h += '<p class="pr-sub">0–100% · su tutti gli esercizi · la difficoltà resta distinta nel dettaglio, senza un punteggio unico</p>';
    if (periodo !== 'tutto') h += '<p class="pr-note">La ragnatela è sempre su tutti gli esercizi: il periodo scelto vale per i numeri e i grafici sotto.</p>';
    var assi = assiRadar(t);
    h += radarHtml(assi.map(function (c) { return { name: c.name, pct: c.pct, n: c.fn }; }));
    return h + '</section>';
  }

  function htmlP3(t) {
    var h = '<section class="st-card pr-card" id="prTat"><h2 class="an-h2">Tattica</h2>';
    h += '<div class="pr-kpis">' + kpi(t.risolti, 'risolti') + kpi(t.pctPrimo == null ? '—' : t.pctPrimo + '%', 'primo colpo') + kpi(streak, 'giorni di fila', 'serie attuale') + '</div>';
    h += '<h3 class="pr-h3">Risolti al giorno · ultimi ' + t.days.length + ' giorni</h3>';
    var max = 1; t.days.forEach(function (d) { if (d.r > max) max = d.r; });
    h += '<div class="pr-bars" aria-hidden="true">';
    t.days.forEach(function (d) { var ht = Math.max(d.r ? 4 : 0, Math.round(d.r / max * 48)); h += '<i style="height:' + ht + 'px" title="' + esc(itData(d.k) + ': ' + d.r) + '"></i>'; });
    h += '</div><div class="pr-clab"><span>' + esc(itData(t.days[0].k)) + '</span><span>' + esc(itData(t.days[t.days.length - 1].k)) + '</span></div>';
    var righe = (vediTutti ? t.temi : t.temi.filter(function (c) { return c.ok || c.fn; })).slice();
    if (!vediTutti) righe = righe.slice(0, 4);
    h += '<table class="pr-tab"><thead><tr><th>Tema</th><th>Risolti</th><th>1° colpo</th></tr></thead><tbody>';
    (vediTutti ? t.temi : righe).forEach(function (c) {
      var pc = periodo === 'tutto' ? (c.pct == null ? 'Pochi dati' : c.pct + '%') : '—';
      h += '<tr><td>' + esc(c.name) + '</td><td>' + c.ok + '</td><td>' + pc + '</td></tr>';
    });
    h += '</tbody></table>';
    h += '<button type="button" class="ps-lnk" id="prVediTemi">' + (vediTutti ? 'Mostra meno' : 'Vedi tutti') + '</button>';
    return h + '</section>';
  }

  function htmlP4() {
    var list = filtraBot(botN), sp = filtraBot(botS), r = vps(list);
    var h = '<section class="st-card pr-card" id="prBot"><h2 class="an-h2">Partite con i bot</h2>';
    h += chips('col', [['tutti', 'Tutti'], ['w', 'Bianco'], ['b', 'Nero']], colBot);
    h += chips('tmp', [['tutti', 'Tutti i tempi'], ['rapide', 'Rapide'], ['blitz', 'Blitz'], ['bullet', 'Bullet']], tempoBot);
    if (tempoBot === 'tutti' && list.length) {
      var clk = {}; list.forEach(function (g) { var k = g.orologio || 'no'; clk[k] = (clk[k] || 0) + 1; });
      h += '<p class="pr-note">Tempi nel filtro: ' + Object.keys(clk).sort().map(function (k) { return nomeOrologio(k) + ' ' + clk[k]; }).join(' · ') + '.</p>';
    }
    h += '<div class="pr-bots">';
    var bots = (BS && BS.BOTS) ? BS.BOTS : [];
    if (!bots.length) h += '<p class="pr-vuoto">Ancora nessuna partita: gioca con un bot e qui vedrai i risultati.</p>';
    bots.forEach(function (b) {
      var g = list.filter(function (x) { return x.bot === b[0]; }), s = vps(g);
      h += '<div class="pr-bot"><img class="pr-av" alt="" src="istruttori/tondi/' + esc(b[0]) + '.webp"><div><b>' + esc(b[1]) + '</b><span>' + esc(b[2]) + ' stimato</span></div>' +
        '<div class="pr-vps">' + (g.length ? (s.v + ' / ' + s.p + ' / ' + s.s) : '—') + '</div></div>';
    });
    h += '</div>';
    /* andamento precisione, con date, etichetta provvisorio */
    var byDay = {};
    list.forEach(function (g) {
      if (typeof g.precisione !== 'number') return;
      var d = byDay[g.data] || (byDay[g.data] = { s: 0, n: 0 }); d.s += g.precisione; d.n++;
    });
    var ks = Object.keys(byDay).sort();
    h += '<h3 class="pr-h3">Precisione <span class="pr-prov">provvisorio</span></h3>';
    if (ks.length) {
      h += lineChart(ks.map(function (k) { return byDay[k].s / byDay[k].n; }), '#2D6A4F', [itData(ks[0]), itData(ks[ks.length - 1])]);
    } else h += '<p class="pr-vuoto">Pochi dati per il grafico della precisione.</p>';
    var hs = vps(sp);
    h += '<div class="pr-hand">Con handicap <span>V/P/S: ' + (sp.length ? (hs.v + ' / ' + hs.p + ' / ' + hs.s) : '0 / 0 / 0') + '</span></div>';
    h += '<p class="pr-note">Le partite con handicap restano separate dal conteggio normale. I filtri di colore e tempo valgono solo per questa sezione.</p>';
    return h + '</section>';
  }

  function htmlP5() {
    var h = '<section class="st-card pr-card" id="prAn"><h2 class="an-h2">Analisi</h2>';
    if (analisiStato === 'attesa') return h + '<p class="pr-vuoto">Carico le partite analizzate…</p></section>';
    var d = analisiCache;
    if (!d || !d.n) {
      h += '<p class="pr-vuoto">Nessuna partita analizzata in questo periodo.</p>';
      h += '<h3 class="pr-h3">Errori medi per partita</h3><p class="pr-vuoto">Pochi dati</p>';
      h += '<h3 class="pr-h3">Blunder medi per partita</h3><p class="pr-vuoto">Pochi dati</p>';
      return h + '</section>';
    }
    h += '<p class="pr-lead">' + d.n + (d.n === 1 ? ' partita analizzata' : ' partite analizzate') + '</p>';
    if (d.n < MIN_AN || d.prec == null) h += '<p class="pr-note">Pochi dati per una precisione media affidabile.</p>';
    else h += '<p class="pr-lead2">Precisione media ' + itNum(d.prec, 0) + '% <span class="pr-prov">provvisorio</span></p>';
    h += '<h3 class="pr-h3">Errori medi per partita</h3>';
    if (d.serieErr.length) h += lineChart(d.serieErr, '#e8590c', d.serieLab);
    else h += '<p class="pr-vuoto">Pochi dati</p>';
    h += '<h3 class="pr-h3">Blunder medi per partita</h3>';
    if (d.serieBl.length) h += lineChart(d.serieBl, '#2D6A4F', d.serieLab);
    else h += '<p class="pr-vuoto">Pochi dati</p>';
    h += '<p class="pr-leg">' +
      (d.errMed != null ? 'Errori medi per partita ' + itNum(d.errMed, 1) : '') +
      (d.blMed != null ? ' · Blunder medi per partita ' + itNum(d.blMed, 1) : '') +
      ' · ' + (periodo === 'tutto' ? 'Tutte' : PERIODI.filter(function (x) { return x[0] === periodo; })[0][1]) + '</p>';
    return h + '</section>';
  }

  function htmlP6() {
    var solvedTot = 0;
    (EX || []).forEach(function (e) { if (isSolved(e.n)) solvedTot++; });
    var p50ok = st.p50.length >= 50, p50 = st.p50.length ? Math.round(st.p50.reduce(function (a, b) { return a + b; }, 0) / st.p50.length * 100) : null;
    var lac = CH.filter(function (c) { return st.thl[c.id] && st.thl[c.id].ok; }).length;
    var FAM = [
      ['costanza', 'Costanza', [3, 7, 30], streak, function (x) { return x + ' giorni di fila'; }],
      ['impegno', 'Impegno', [1, 5, 20], monthH(), function (x) { return String(Math.round(x * 10) / 10).replace('.', ',') + (x === 1 ? ' ora in un mese' : ' ore in un mese'); }],
      ['precisione', 'Precisione', [60, 70, 80], p50ok ? p50 : 0, function (x) { return x + '% al primo colpo (ultimi 50)'; }],
      ['lacuna', 'Lacuna colmata', [1, 2, 3], lac, function (x) { return x === 1 ? '1 tema recuperato' : x + ' temi recuperati'; }],
      ['traguardi', 'Traguardi', [100, 500, 1000], solvedTot, function (x) { return x + ' esercizi risolti'; }]
    ];
    var ultimo = null, prossimo = null;
    FAM.forEach(function (f) {
      var c = st.cups[f[0]] || [];
      f[2].forEach(function (soglia, i) {
        var dt = c[i];
        if (dt && inPeriodo(dt) && (!ultimo || dt > ultimo.data)) ultimo = { nome: f[1], data: dt, testo: f[4](soglia) };
      });
      if (!prossimo) {
        var now = f[3], i;
        for (i = 0; i < 3; i++) if (!(c[i]) && now < f[2][i]) { prossimo = { fam: f, i: i, now: now, next: f[2][i] }; break; }
      }
    });
    var h = '<section class="st-card pr-card" id="prPremi"><h2 class="an-h2">Premi</h2>';
    h += '<p class="pr-lead">Ultimo · ' + (ultimo ? esc(ultimo.nome) + ': ' + esc(ultimo.testo) : 'Nessun premio in questo periodo') + '</p>';
    if (prossimo) {
      var p = Math.max(0, Math.min(1, prossimo.now / prossimo.next));
      h += '<p>Prossimo · ' + esc(prossimo.fam[4](prossimo.next)) + '</p>';
      h += '<span class="pr-sbar"><i style="width:' + Math.round(p * 100) + '%"></i></span>';
      h += '<p class="pr-note">' + esc(prossimo.fam[4](prossimo.now).split(' ')[0]) + ' / ' + esc(String(prossimo.next)) + '</p>';
    } else h += '<p class="pr-note">Tutti i traguardi di questa raccolta sono già raggiunti, oppure mancano ancora i dati.</p>';
    h += '<a class="ps-lnk" href="premi.html" data-pg="premi.html">Vedi tutti</a>';
    return h + '</section>';
  }

  function disegno() {
    var t = tatticaPeriodo();
    var esPeriodo = 0, parPeriodo = filtraBot(botN).length;
    Object.keys(st.diary).forEach(function (k) { if (inPeriodo(k)) esPeriodo += (st.diary[k].r || 0); });
    var h = '';
    if (DEMO) h += '<p class="pr-demo" role="status">Dati di esempio: inventati, solo per mostrare il layout. Non sono i tuoi risultati.</p>';
    h += '<header class="an-top pr-top"><h1>Progressi</h1>' +
      '<button class="hd15-b" data-pg="salvati.html" aria-label="I miei salvati">' + ic('bookmark', 24) + '</button>' +
      '<button class="hd15-b" data-pg="impostazioni.html" aria-label="Impostazioni">' + ic('settings', 24) + '</button></header>';
    h += '<div class="pr-p2">' + chips('per', PERIODI, periodo) + '</div>';
    h += htmlRadar(t);
    h += '<div class="pr-p2"><div class="pr-kpis">' +
      kpi(streak, 'giorni di fila', 'serie attuale · non dipende dal periodo') +
      kpi(esPeriodo, 'esercizi risolti') +
      kpi(parPeriodo, 'partite giocate') +
      '</div></div>';
    h += htmlP3(t);
    h += htmlP4();
    h += htmlP5();
    h += htmlP6();
    h += '<section class="st-card pr-card" id="prSal"><h2 class="an-h2">I miei salvati</h2>' +
      '<button type="button" class="ps-lnk" data-pg="salvati.html">Apri la tua biblioteca</button></section>';
    h += '<section class="st-card pr-card" id="prPro"><h2 class="an-h2">Il mio profilo scacchistico</h2>' +
      '<p class="pr-sub">Analisi profonda dei tuoi progressi</p>' +
      '<button type="button" class="btn an-cta" data-pg="profilo_scacchistico.html">Apri il profilo</button></section>';
    h += '<section class="st-card pr-card" id="prArr"><h2 class="an-h2">In arrivo</h2>' +
      '<p class="pr-sub">Finali · Aperture · Strategia</p></section>';
    h += (C.bar ? C.bar(4) : '');
    var root = document.getElementById('pg');
    root.innerHTML = h;
  }

  function cnap() { try { return (W.parent && W.parent.__cnap) || W.__cnap; } catch (e) { return W.__cnap; } }

  function ricalcolaAnalisi(dati) {
    /* dati = {partite, analisi} da CNApProfilo.carica; filtro Tutte/90/30/7 fatto qui (90 giorni ≠ 6 mesi del profilo) */
    var gs = (dati && dati.partite) || [], anMap = (dati && dati.analisi) || {};
    var usate = [], i, g, a, err = 0, bl = 0, precS = 0, precN = 0, punti = [];
    for (i = 0; i < gs.length; i++) {
      g = gs[i]; if (!g || g.variant && g.variant !== 'standard') continue;
      var day = g.playedDate || (g.playedAtMs ? dk(g.playedAtMs) : null);
      if (day && !inPeriodo(day)) continue;
      if (!day && periodo !== 'tutto') continue;
      var lista = anMap[g.gameId] || [];
      a = lista.filter(function (x) { return x && x.status === 'complete'; }).sort(function (x, y) { return (y.analysisRevision || 0) - (x.analysisRevision || 0); })[0];
      if (!a || !g.userColor) continue;
      var mosse = a.positionResults || [];
      var eN = 0, bN = 0;
      mosse.forEach(function (p) {
        if (p.side !== g.userColor) return;
        if (p.label === 'errore') eN++;
        if (p.label === 'blunder') bN++;
      });
      err += eN; bl += bN;
      var acc = a.accuracy && a.accuracy[g.userColor], nM = a.accuracy && a.accuracy.mosseContate && a.accuracy.mosseContate[g.userColor];
      if (acc != null && nM) { precS += acc * nM; precN += nM; }
      punti.push({ day: day || 'sconosciuto', e: eN, b: bN });
      usate.push(g);
    }
    punti.sort(function (a, b) { return a.day < b.day ? -1 : a.day > b.day ? 1 : 0; });
    var n = usate.length;
    analisiCache = {
      n: n,
      prec: precN ? Math.round(precS / precN) : null,
      errMed: n ? err / n : null,
      blMed: n ? bl / n : null,
      serieErr: punti.map(function (x) { return x.e; }),
      serieBl: punti.map(function (x) { return x.b; }),
      serieLab: punti.length ? [itData(punti[0].day), itData(punti[punti.length - 1].day)] : []
    };
    analisiStato = 'ok';
  }

  var caricaDati = null;
  function aggiornaAnalisi(dopo) {
    var x = cnap(), CN = x && x.CN;
    if (DEMO) {
      /* in demo non invento un profilo di analisi: sezione vuota onesta, oppure poche partite fittizie chiaramente di esempio? Meglio vuota + nota già nel banner. */
      analisiCache = { n: 0, prec: null, errMed: null, blMed: null, serieErr: [], serieBl: [], serieLab: [] };
      analisiStato = 'ok';
      if (dopo) dopo();
      return;
    }
    if (!CN || !CN.profilo || typeof CN.profilo.carica !== 'function') {
      analisiCache = null; analisiStato = 'ok'; if (dopo) dopo(); return;
    }
    CN.profilo.carica({ scope: 'self' }).then(function (d) { caricaDati = d; ricalcolaAnalisi(d); if (dopo) dopo(); }).catch(function () { analisiStato = 'ok'; analisiCache = null; if (dopo) dopo(); });
  }

  function ridisegna() {
    if (caricaDati) ricalcolaAnalisi(caricaDati);
    disegno();
  }

  document.addEventListener('click', function (ev) {
    var b = ev.target.closest('[data-per]');
    if (b) { periodo = b.getAttribute('data-per'); ridisegna(); return; }
    b = ev.target.closest('[data-col]');
    if (b) { colBot = b.getAttribute('data-col'); ridisegna(); return; }
    b = ev.target.closest('[data-tmp]');
    if (b) { tempoBot = b.getAttribute('data-tmp'); ridisegna(); return; }
    if (ev.target.closest('#prVediTemi')) { vediTutti = !vediTutti; ridisegna(); }
  });

  var root = document.getElementById('pg');
  if (root) { root.className = 'pg conbar'; disegno(); }
  aggiornaAnalisi(function () { disegno(); });
  /* se l'archivio si apre dopo, ritento un paio di volte */
  var tent = 0, tmr = setInterval(function () {
    tent++;
    if (caricaDati || DEMO || tent > 20) { clearInterval(tmr); return; }
    var x = cnap();
    if (x && x.CN && x.CN.profilo) { clearInterval(tmr); aggiornaAnalisi(function () { disegno(); }); }
  }, 400);
})();
