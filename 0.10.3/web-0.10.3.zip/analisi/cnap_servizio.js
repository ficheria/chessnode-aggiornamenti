/* Chess Node · Analisi profonda · FASE 1 · CNApServizio — collega i moduli: passi 1–3 della pipeline (acquisizione → controllo →
   archiviazione + statistiche leggere) e marcatura del campione mensile per la fase 2. Nessun motore in questa fase.
   Codice originale Chess Node (08/11/2026). Ordine di caricamento nel browser: chess.min.js, cnap_util, cnap_fen, cnap_pgn,
   cnap_import, cnap_archivio_backend, cnap_archivio, cnap_rete, cnap_sorgenti, cnap_statistiche, cnap_campione, cnap_migrazione,
   cnap_servizio. Unico globale nuovo per ciascun file, prefisso CNAp.
   API: CNApServizio.crea({Chess, backend?, fetch?, ora?, limitiPgn?}) → {importaTesto, importaDaSito, statistiche, ricampiona, moduli…} */
(function (root, factory) {
  'use strict';
  var api = factory(root);
  if (typeof module === 'object' && module.exports) module.exports = api; else root.CNApServizio = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function (root) {
  'use strict';

  function crea(d) {
    var g = function (n) { return d[n] || root[n] || (typeof require === 'function' ? null : null); };
    var U = g('CNApUtil'), Fen = g('CNApFen'), PgnM = g('CNApPgn'), ImpM = g('CNApImport'), BE = g('CNApBackend'), ArM = g('CNApArchivio'),
        ReM = g('CNApRete'), SoM = g('CNApSorgenti'), Stat = g('CNApStat'), Camp = g('CNApCampione'), MigM = g('CNApMigrazione');
    var Chess = d.Chess || root.Chess, ora = d.ora || function () { return Date.now(); };
    if (!U || !Fen || !PgnM || !ImpM || !BE || !ArM || !Stat || !Camp || !Chess) throw new Error('CNApServizio: moduli mancanti (controllare l\'ordine di caricamento)');
    var pgn = PgnM.crea({ Chess: Chess, CNApFen: Fen, CNApUtil: U, limiti: d.limitiPgn });
    var imp = ImpM.crea({ CNApPgn: pgn, CNApFen: Fen, CNApUtil: U });
    var backend = d.backend || (typeof indexedDB !== 'undefined' ? BE.indexedDB({ nome: d.nomeDb }) : BE.memoria());
    var arch = ArM.crea({ backend: backend, CNApUtil: U, ora: ora });
    var rete = null, sorg = null;
    if (d.fetch && ReM && SoM) {
      rete = ReM.crea({ fetch: d.fetch, ora: ora, timeoutMs: d.timeoutMs, attendi: d.attendi, attesa429Ms: d.attesa429Ms });
      sorg = SoM.crea({ rete: rete, CNApUtil: U, CNApImport: imp, ora: ora, cache: {
        get: function (k) { return arch.tx(['cache'], 'readonly', function (t) { return t.get('cache', k); }).then(function (x) { return x ? x.valore : null; }); },
        set: function (k, v) { return arch.tx(['cache'], 'readwrite', function (t) { return t.put('cache', { key: k, valore: v, cleanupClass: 1, usatoIl: ora() }); }); }
      } });
    }
    var mig = MigM ? MigM.crea({ archivio: arch, CNApImport: imp, CNApFen: Fen, CNApUtil: U, Chess: Chess, ora: ora }) : null;

    /* ricalcola il campione dei mesi indicati per l'ambito personale (deterministico) */
    async function ricampiona(mesi, scope) {
      scope = scope || 'self';
      var out = {};
      for (var i = 0; i < mesi.length; i++) {
        var gs = await arch.partite({ scope: scope, mese: mesi[i] });
        var rep = Camp.seleziona(gs); out[mesi[i]] = rep;
        await arch.aggiornaCampionamento(Camp.marcature(gs, rep, mesi[i]));
      }
      return out;
    }

    /* import da testo/file PGN (un file = un'unica transazione) */
    async function importaTesto(testo, o) {
      o = o || {};
      var imp0 = await arch.impostazioni();
      var src = { source: o.source || 'file', sourceId: o.sourceId || null, rawPgn: testo, fileName: o.fileName || null, fetchedAt: ora(), scope: o.scope || 'self', identita: o.identita || (imp0.identita.file || []).concat(imp0.identita.lichess || [], imp0.identita.chesscom || []), private: !!o.private };
      var prep = imp.prepara(src, { ora: ora() });
      if (prep.erroreFile) return { ok: false, erroreFile: prep.erroreFile, report: null };
      var rep = await arch.importa(prep, { scope: src.scope });
      var mesi = {}; prep.partite.forEach(function (p) { if (p.game.monthRome) mesi[p.game.monthRome] = 1; });
      if (src.scope === 'self') await ricampiona(Object.keys(mesi));
      return { ok: true, report: rep, diagnostiche: prep.diagnostiche, notifica: notifica(rep.dettagli) };
    }

    /* acquisizione da sito: mese per mese, ogni mese importato in una transazione; cursore avanzato solo dopo il commit */
    async function importaDaSito(sito, nome, o) {
      o = o || {};
      if (!sorg) throw U.errore('RETE_ASSENTE', 'Rete non configurata.');
      var scope = o.scope || 'self';
      var imp0 = await arch.impostazioni(), chiaveId = sito === 'lichess' ? 'lichess' : 'chesscom';
      if (scope === 'self' && imp0.identita[chiaveId].map(function (x) { return x.toLowerCase(); }).indexOf(nome.toLowerCase()) < 0) {
        var idn = U.clone(imp0.identita); idn[chiaveId].push(nome); await arch.salvaImpostazioni({ identita: idn });
      }
      var totali = { nuove: 0, identiche: 0, arricchite: 0, collegate: 0, candidati: 0, nonValide: 0 }, mesiToccati = {}, dettagli = [];
      var rep = await sorg.acquisisci(sito, nome, {
        mesi: o.mesi || 12, perMese: o.perMese || 60, segnale: o.segnale, onAttesa: o.onAttesa, aggiorna: o.aggiorna, ora: o.ora,
        cursori: { get: function (k) { return arch.meta(k); }, set: function (k, v) { return arch.salvaMeta(k, v); } },
        onMese: async function (r) {
          var prepTot = { partite: [], diagnostiche: [] };
          r.sorgenti.forEach(function (s) { s.scope = scope; var p = imp.prepara(s, { ora: ora(), batchId: 'B-' + sito + '-' + r.mese }); prepTot.partite = prepTot.partite.concat(p.partite); prepTot.diagnostiche = prepTot.diagnostiche.concat(p.diagnostiche); });
          var ri = await arch.importa(prepTot, { scope: scope });
          Object.keys(totali).forEach(function (k) { totali[k] += ri[k] || 0; }); dettagli = dettagli.concat(ri.dettagli);
          mesiToccati[r.mese] = 1;
          if (o.onMese) o.onMese(r, ri);
          return ri;
        }
      });
      if (scope === 'self') await ricampiona(Object.keys(mesiToccati));
      rep.totali = totali; rep.notifica = notifica(dettagli);
      return rep;
    }

    /* notifica annullabile (Kiko 08/11 20:32): «3 doppioni collegati» con i mergeId da passare ad annullaFusioni */
    function notifica(dettagli) {
      var ids = (dettagli || []).filter(function (d) { return d.esito === 'collegata' && d.mergeId; }).map(function (d) { return d.mergeId; });
      if (!ids.length) return null;
      return { tipo: 'doppioni_collegati', n: ids.length, mergeIds: ids, testo: ids.length === 1 ? '1 doppione collegato' : ids.length + ' doppioni collegati', azione: 'Annulla' };
    }
    async function annullaNotifica(n) { return n ? arch.annullaFusioni(n.mergeIds) : []; }

    async function statistiche(filtro) { var gs = await arch.partite({ scope: filtro && filtro.scope }); return Stat.calcola(gs, filtro); }

    return { importaTesto: importaTesto, importaDaSito: importaDaSito, annullaNotifica: annullaNotifica, statistiche: statistiche, ricampiona: ricampiona,
      archivio: arch, pgn: pgn, import: imp, rete: rete, sorgenti: sorg, migrazione: mig, backend: backend, Fen: Fen, U: U };
  }
  return { crea: crea, VERSIONE: 'cnap-servizio-1' };
});
