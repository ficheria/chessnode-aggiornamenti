/* Chess Node · Analisi profonda · FASE 1 · CNApArchivio — passo 3 della pipeline: archivio unico, duplicati, backup (A1-04, A1-02 §6.4).
   Codice originale Chess Node (08/11/2026). Dipendenze iniettate: backend (CNApBackend.*), CNApUtil.
   Garanzie:
   - import = UNA transazione: partite+fonti+nodi+diagnostica insieme, oppure niente (spazio finito → dati vecchi intatti);
   - duplicati: identità forte (servizio+ID) → arricchimento; stesse mosse + stessi giocatori + stessa data → collegamento tracciato
     e REVERSIBILE; stesse mosse con metadati incompleti → candidato da confermare, mai cancellazione; reimport identico idempotente;
   - una partita presente sia nel profilo personale sia in uno studio avversario resta UN record con due ambiti (niente doppio peso);
   - la pulizia automatica tocca solo cache, analisi scadute di avversari non salvati e analisi secondarie ricostruibili: MAI
     partite, fonti, nodi, esercizi, progressi o annotazioni; se non basta si sospendono le analisi e si chiede all'utente;
   - backup manuale con manifesto e controlli; ripristino in staging con anteprima dei conflitti. */
(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api; else root.CNApArchivio = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  var SCHEMA = 1;
  var TUTTI = ['games', 'gameSources', 'nodes', 'analyses', 'analysisJobs', 'profileSnapshots', 'exerciseRefs', 'diagnostics', 'mergeLog', 'legacy', 'cache', 'meta'];
  var PERSONALI = ['games', 'gameSources', 'nodes', 'analyses', 'analysisJobs', 'profileSnapshots', 'exerciseRefs', 'mergeLog', 'legacy'];   // nel backup
  var STATI_ARCHIVIO = ['in attesa', 'in analisi', 'analizzata'];
  var IMPOSTAZIONI_DEFAULT = {
    cloudEvalEnabled: false,            // DECISO Q12: spento di default
    cloudEvalNoticeAccepted: false,
    engineNoticeSeen: false,            // primo avviso batteria (A1-05), si mostra fuori dalla scacchiera
    limiteByte: 100 * 1024 * 1024,      // DECISO Q10: 100 MB iniziali, configurabile, da confermare sul telefono
    pulizia: { analisiSecondarieRicostruibili: false },   // classe 3 solo con regola esplicita attivata
    identita: { lichess: [], chesscom: [], file: [] },
    analisiSospese: null                // {motivo, da} quando manca spazio: nessuna nuova analisi finché l'utente non sceglie
  };

  function crea(d) {
    var B = d.backend, U = d.CNApUtil, ora = d.ora || function () { return Date.now(); };
    if (!B || !U) throw new Error('CNApArchivio: servono backend e CNApUtil');
    var usoCache = null;
    // rilievo 5 (11-11): con il database unico v2 il backup comprende anche l'allenamento (esercizi personali, tentativi, sessioni, piani)
    var ALLENAMENTO = ['exercises', 'placements', 'attempts', 'sessions', 'plans'];
    var PERS = PERSONALI.concat((B.versione || 1) >= 2 ? ALLENAMENTO : []);
    function metaNelBackup(k) { return k === 'impostazioni' || k === 'seqTentativi' || /^avversario:/.test(String(k)); }

    /* ---------------- impostazioni (meta) ---------------- */
    async function impostazioni() {
      return B.tx(['meta'], 'readonly', async function (t) {
        var m = await t.get('meta', 'impostazioni'); var v = U.clone(IMPOSTAZIONI_DEFAULT);
        if (m && m.valore) Object.keys(m.valore).forEach(function (k) { v[k] = m.valore[k]; });
        return v;
      });
    }
    async function salvaImpostazioni(patch) {
      return B.tx(['meta'], 'readwrite', async function (t) {
        var m = await t.get('meta', 'impostazioni'), v = U.clone(IMPOSTAZIONI_DEFAULT);
        if (m && m.valore) Object.keys(m.valore).forEach(function (k) { v[k] = m.valore[k]; });
        Object.keys(patch).forEach(function (k) { v[k] = patch[k]; });
        await t.put('meta', { key: 'impostazioni', valore: v, aggiornato: ora() });
        return v;
      });
    }
    async function meta(k) { return B.tx(['meta'], 'readonly', async function (t) { var m = await t.get('meta', k); return m ? m.valore : null; }); }
    async function salvaMeta(k, v) { return B.tx(['meta'], 'readwrite', async function (t) { await t.put('meta', { key: k, valore: v, aggiornato: ora() }); }); }

    /* ---------------- uso dello spazio (stima nostra, coerente tra web e telefono) ---------------- */
    async function uso(forza) {
      if (usoCache && !forza) return usoCache;
      var tot = { totale: 0, perStore: {} };
      await B.tx(TUTTI, 'readonly', async function (t) {
        for (var i = 0; i < TUTTI.length; i++) { var a = await t.all(TUTTI[i]), n = 0; a.forEach(function (v) { n += U.stimaByte(v); }); tot.perStore[TUTTI[i]] = n; tot.totale += n; }
      });
      usoCache = tot; return tot;
    }
    async function richiediPersistenza(nav) {
      nav = nav || (typeof navigator !== 'undefined' ? navigator : null);
      var r = { disponibile: false, concessa: null };
      if (nav && nav.storage && nav.storage.persist) {
        r.disponibile = true;
        try { r.concessa = await nav.storage.persist(); } catch (e) { r.concessa = false; r.errore = String(e && e.message || e); }
      }
      await salvaMeta('persistenza', { esito: r, quando: ora() });
      return r;
    }

    /* ---------------- pulizia ordinata (mai dati personali) ---------------- */
    async function liberaSpazio(byteNecessari, imp) {
      imp = imp || await impostazioni();
      var liberati = 0, dettagli = [];
      await B.tx(['cache', 'analyses'], 'readwrite', async function (t) {
        // 1) cache temporanee e calcoli ricostruibili
        var c = await t.all('cache');
        c.sort(function (a, b) { return (a.cleanupClass || 1) - (b.cleanupClass || 1) || (a.usatoIl || 0) - (b.usatoIl || 0); });
        for (var i = 0; i < c.length && liberati < byteNecessari; i++) { liberati += U.stimaByte(c[i]); await t.del('cache', c[i].key); dettagli.push({ classe: 1, chiave: c[i].key }); }
        if (liberati >= byteNecessari) return;
        // 2) analisi scadute di avversari non salvati
        var an = await t.all('analyses'), adesso = ora();
        for (var j = 0; j < an.length && liberati < byteNecessari; j++) {
          var a = an[j];
          if (a.scope && /^opp:/.test(a.scope) && !a.savedByUser && a.expiresAt && a.expiresAt < adesso) { liberati += U.stimaByte(a); await t.del('analyses', a.analysisId); dettagli.push({ classe: 2, chiave: a.analysisId }); }
        }
        if (liberati >= byteNecessari || !imp.pulizia || !imp.pulizia.analisiSecondarieRicostruibili) return;
        // 3) vecchie analisi secondarie ricostruibili (solo con regola esplicita attiva)
        for (var k = 0; k < an.length && liberati < byteNecessari; k++) {
          var b = an[k];
          if (b.secondary === true && b.rebuildable === true && b.scope !== 'self-protected') { liberati += U.stimaByte(b); await t.del('analyses', b.analysisId); dettagli.push({ classe: 3, chiave: b.analysisId }); }
        }
      });
      usoCache = null;
      return { liberati: liberati, sufficiente: liberati >= byteNecessari, dettagli: dettagli };
    }

    /* ---------------- import transazionale ---------------- */
    function compatibiliIncontro(a, b) {
      var nomi = function (g) { return [g.players.w.name, g.players.b.name].map(function (x) { return x ? x.trim().toLowerCase() : null; }); };
      var na = nomi(a), nb = nomi(b);
      var completi = na[0] && na[1] && nb[0] && nb[1] && a.playedDate && b.playedDate;
      if (!completi) return 'incompleto';
      return na[0] === nb[0] && na[1] === nb[1] && a.playedDate === b.playedDate ? 'uguale' : 'diverso';
    }
    function idForti(g) { return (g.sourceRefs || []).filter(function (s) { return s.source === 'lichess' || s.source === 'chesscom'; }); }
    function conflittoForte(a, b) {   // stesso servizio, ID diversi ⇒ incontri distinti (es. due partite brevi identiche lo stesso giorno)
      return idForti(a).some(function (x) { return idForti(b).some(function (y) { return x.source === y.source && x.sourceId !== y.sourceId; }); });
    }

    /* preparato = output di CNApImport.prepara ; o = {scope} */
    async function importa(preparato, o) {
      o = o || {};
      var imp = await impostazioni();
      if (imp.analisiSospese && imp.analisiSospese.motivo === 'spazio' && !o.ignoraSospensione) {
        // l'import resta possibile: si sospendono solo le NUOVE analisi; qui si controlla comunque lo spazio sotto
      }
      var stima = 0;
      preparato.partite.forEach(function (p) { stima += U.stimaByte(p.game) + U.stimaByte(p.source) + p.nodes.reduce(function (a, n) { return a + U.stimaByte(n); }, 0); });
      preparato.diagnostiche.forEach(function (x) { stima += U.stimaByte(x); });
      var u = await uso();
      if (u.totale + stima > imp.limiteByte) {
        var lib = await liberaSpazio(u.totale + stima - imp.limiteByte, imp);
        if (!lib.sufficiente) {
          try { await salvaImpostazioni({ analisiSospese: { motivo: 'spazio', da: ora() } }); } catch (e5) { /* vedi sotto */ }
          var e = U.errore('SPAZIO', 'Spazio dell\'archivio esaurito (limite ' + Math.round(imp.limiteByte / 1048576) + ' MB): nessuna partita importata, i dati già salvati sono intatti. Esporta un backup o scegli cosa liberare; le nuove analisi sono sospese.', { stimaByte: stima, liberati: lib.liberati });
          throw e;
        }
      }
      var rep = { nuove: 0, identiche: 0, arricchite: 0, collegate: 0, candidati: 0, nonValide: preparato.diagnostiche.length, dettagli: [], batchDiagnostica: preparato.diagnostiche.map(function (x) { return x.diagId; }) };
      try {
        await B.tx(['games', 'gameSources', 'nodes', 'diagnostics', 'mergeLog'], 'readwrite', async function (t) {
          for (var i = 0; i < preparato.diagnostiche.length; i++) await t.put('diagnostics', preparato.diagnostiche[i]);
          for (var j = 0; j < preparato.partite.length; j++) {
            var p = preparato.partite[j], g = p.game, s = p.source, scope = o.scope || g.scopeRefs[0];
            g.scopeRefs = [scope];
            // a) stessa revisione della stessa fonte: idempotente
            var giaRev = await t.get('gameSources', s.sourceRevKey);
            if (giaRev) {
              var gr = await t.get('games', giaRev.gameId);
              if (gr && gr.scopeRefs.indexOf(scope) < 0) { gr.scopeRefs.push(scope); gr.updatedAt = ora(); await t.put('games', gr); rep.dettagli.push({ gameId: gr.gameId, esito: 'identica+ambito' }); }
              else rep.dettagli.push({ gameId: giaRev.gameId, esito: 'identica' });
              rep.identiche++; continue;
            }
            // b) stessa fonte (ID forte o stesso testo), nuova revisione: arricchimento con provenienza
            var stessaFonte = await t.byIndex('gameSources', 'sourceKey', s.sourceKey);
            if (stessaFonte.length) {
              var ge = await t.get('games', stessaFonte[0].gameId);
              s.gameId = ge.gameId; await t.put('gameSources', s);
              arricchisci(ge, g, s, scope);
              await t.put('games', ge); rep.arricchite++; rep.dettagli.push({ gameId: ge.gameId, esito: 'arricchita', note: ge._noteUltimo }); delete ge._noteUltimo; continue;
            }
            // c) stesse mosse da altra fonte
            var cand = (await t.byIndex('games', 'contentKey', g.contentKey)).filter(function (c) { return c.startFen === g.startFen; });
            var uguale = null, incerti = [];
            cand.forEach(function (c) {
              if (conflittoForte(c, g)) return;
              var k = compatibiliIncontro(c, g);
              if (k === 'uguale' && !uguale) uguale = c; else if (k === 'incompleto') incerti.push(c.gameId);
            });
            /* 15-11: partite da file/bot (niente ID Lichess/Chess.com): stesse mosse = stessa partita.
               Prima un PGN con data o intestazioni un po' diverse diventava una partita nuova. */
            if (!uguale && !idForti(g).length) {
              cand.forEach(function (c) { if (!uguale && !idForti(c).length && !conflittoForte(c, g)) uguale = c; });
            }
            if (uguale) {
              var mergeId = 'M-' + U.hash(uguale.gameId + '|' + s.sourceRevKey);
              await t.put('mergeLog', { mergeId: mergeId, keptGameId: uguale.gameId, sourceRevKey: s.sourceRevKey, sourceKey: s.sourceKey, at: ora(), regola: 'stesse-mosse+giocatori+data', propostaGame: g, propostaNodi: p.nodes, ambitoAggiunto: uguale.scopeRefs.indexOf(scope) < 0 ? scope : null, annullata: false });
              s.gameId = uguale.gameId; await t.put('gameSources', s);
              uguale.sourceRefs.push(g.sourceRefs[0]); if (uguale.scopeRefs.indexOf(scope) < 0) uguale.scopeRefs.push(scope);
              arricchisci(uguale, g, s, scope, true);
              await t.put('games', uguale); delete uguale._noteUltimo;
              rep.collegate++; rep.dettagli.push({ gameId: uguale.gameId, esito: 'collegata', mergeId: mergeId }); continue;
            }
            // d) nuova partita (eventualmente candidata duplicato da confermare)
            if (await t.get('games', g.gameId)) { g.gameId = g.gameId + '-' + U.hash(s.sourceRevKey).slice(0, 6); riassegnaId(p, g.gameId); }
            if (incerti.length) { g.duplicateCandidateOf = incerti; rep.candidati++; }
            s.gameId = g.gameId;
            await t.put('games', g); await t.put('gameSources', s);
            for (var n = 0; n < p.nodes.length; n++) await t.put('nodes', p.nodes[n]);
            rep.nuove++; rep.dettagli.push({ gameId: g.gameId, esito: incerti.length ? 'candidato_duplicato' : 'nuova', candidati: incerti });
          }
        });
      } catch (err) {
        usoCache = null;
        if (err && err.code === 'SPAZIO') { try { await salvaImpostazioni({ analisiSospese: { motivo: 'spazio', da: ora() } }); } catch (e4) { /* anche il flag può non entrare: l'errore resta comunque esplicito */ } throw U.errore('SPAZIO', 'Il dispositivo ha esaurito lo spazio: nessuna partita importata, i dati già salvati sono intatti. Esporta un backup o libera spazio; le nuove analisi sono sospese.'); }
        throw err;
      }
      if (usoCache) { usoCache = { totale: usoCache.totale + stima, perStore: usoCache.perStore, stimato: true }; }   // aggiornamento incrementale (stima prudente): niente riscansione completa a ogni mese
      return rep;
    }
    function riassegnaId(p, nuovo) {
      var vecchio = p.nodes.length ? p.nodes[0].gameId : null; if (!vecchio) return;
      var sub = function (x) { return x == null ? x : x.replace(vecchio + ':', nuovo + ':'); };
      p.nodes.forEach(function (n) { n.gameId = nuovo; n.nodeId = sub(n.nodeId); n.parentId = sub(n.parentId); n.childIds = n.childIds.map(sub); });
      p.game.rootNodeId = nuovo + ':n0';
    }
    /* arricchimento: si aggiunge solo ciò che manca, con provenienza; mai sovrascrivere dati locali verificati */
    function arricchisci(esistente, nuovo, fonte, scope, giaAggiuntaFonte) {
      var note = [];
      if (!giaAggiuntaFonte && !esistente.sourceRefs.some(function (r) { return r.sourceKey === nuovo.sourceRefs[0].sourceKey; })) esistente.sourceRefs.push(nuovo.sourceRefs[0]);
      if (esistente.scopeRefs.indexOf(scope) < 0) esistente.scopeRefs.push(scope);
      if (!esistente.externalAccuracy && nuovo.externalAccuracy) { esistente.externalAccuracy = nuovo.externalAccuracy; note.push('precisione esterna aggiunta da ' + fonte.source); }
      if (!esistente.opening && nuovo.opening) { esistente.opening = nuovo.opening; note.push('apertura aggiunta'); }
      if (esistente.playedAtMs == null && nuovo.playedAtMs != null) { esistente.playedAt = nuovo.playedAt; esistente.playedAtMs = nuovo.playedAtMs; esistente.datePrecision = nuovo.datePrecision; esistente.dateSource = nuovo.dateSource; esistente.monthRome = nuovo.monthRome; note.push('data/ora precise aggiunte'); }
      if (!esistente.timeClass && nuovo.timeClass) { esistente.timeClass = nuovo.timeClass; esistente.timeClassSource = nuovo.timeClassSource; }
      if (esistente.userColor == null && nuovo.userColor != null) { esistente.userColor = nuovo.userColor; esistente.userColorState = nuovo.userColorState; note.push('colore dell\'utente identificato'); }
      ['w', 'b'].forEach(function (c) { if (esistente.players[c].rating == null && nuovo.players[c].rating != null) esistente.players[c].rating = nuovo.players[c].rating; });
      if (esistente.resultStatus !== 'dichiarato' && nuovo.resultStatus === 'dichiarato') { esistente.resultCandidates = (esistente.resultCandidates || []).concat([{ result: nuovo.result, fonte: fonte.sourceKey }]); note.push('nuovo risultato disponibile da confermare (non sovrascritto)'); }
      else if (esistente.resultStatus === 'dichiarato' && nuovo.resultStatus === 'dichiarato' && esistente.result !== nuovo.result) { esistente.resultConflicts = (esistente.resultConflicts || []).concat([{ result: nuovo.result, fonte: fonte.sourceKey }]); note.push('risultato diverso da un\'altra fonte: segnalato, non sovrascritto'); }
      if (U.canon(esistente.mainLineUci) !== U.canon(nuovo.mainLineUci)) { esistente.sourceConflicts = (esistente.sourceConflicts || []).concat([{ fonte: fonte.sourceKey, motivo: 'mosse diverse' }]); note.push('ATTENZIONE: la nuova fonte ha mosse diverse; conservata come fonte, partita non modificata'); }
      if (nuovo.rawPgn !== esistente.rawPgn) note.push('nuovo testo PGN conservato come fonte (commenti/varianti non fusi nell\'albero in questa fase)');
      esistente.updatedAt = ora(); esistente._noteUltimo = note;
    }

    /* annulla un collegamento automatico: la fonte torna una partita separata con i suoi nodi */
    async function annullaFusione(mergeId) {
      return B.tx(['games', 'gameSources', 'nodes', 'mergeLog'], 'readwrite', async function (t) {
        var m = await t.get('mergeLog', mergeId);
        if (!m) throw U.errore('NON_TROVATO', 'Collegamento non trovato.');
        if (m.annullata) return { gia: true };
        var g = await t.get('games', m.keptGameId);
        g.sourceRefs = g.sourceRefs.filter(function (r) { return r.sourceKey !== m.sourceKey; });
        if (m.ambitoAggiunto) g.scopeRefs = g.scopeRefs.filter(function (s) { return s !== m.ambitoAggiunto; });
        g.updatedAt = ora(); await t.put('games', g);
        var nuovo = m.propostaGame; var nodi = m.propostaNodi;
        if (await t.get('games', nuovo.gameId)) { var p = { game: nuovo, nodes: nodi }; nuovo.gameId = nuovo.gameId + '-' + U.hash(mergeId).slice(0, 6); riassegnaId(p, nuovo.gameId); }
        nuovo.duplicateCandidateOf = [g.gameId]; nuovo.separatedFromMerge = mergeId;
        await t.put('games', nuovo);
        for (var i = 0; i < nodi.length; i++) await t.put('nodes', nodi[i]);
        var src = await t.get('gameSources', m.sourceRevKey); src.gameId = nuovo.gameId; await t.put('gameSources', src);
        m.annullata = true; m.annullataIl = ora(); m.nuovoGameId = nuovo.gameId; await t.put('mergeLog', m);
        return { gia: false, nuovoGameId: nuovo.gameId };
      });
    }
    /* annulla più collegamenti in una volta (notifica «N doppioni collegati · Annulla»); ognuno nella sua transazione */
    async function annullaFusioni(mergeIds) {
      var out = [];
      for (var i = 0; i < mergeIds.length; i++) { try { out.push(Object.assign({ mergeId: mergeIds[i] }, await annullaFusione(mergeIds[i]))); } catch (e) { out.push({ mergeId: mergeIds[i], errore: e.message }); } }
      return out;
    }
    /* conferma o respinge un candidato duplicato (scelta dell'utente, tracciata) */
    async function decidiCandidato(gameId, decisione) {
      return B.tx(['games', 'mergeLog'], 'readwrite', async function (t) {
        var g = await t.get('games', gameId); if (!g) throw U.errore('NON_TROVATO', 'Partita non trovata.');
        g.duplicateDecision = { decisione: decisione, il: ora() };   // 'distinta' | 'stessa' (la fusione fisica resta un'azione separata, fase successiva)
        if (decisione === 'distinta') delete g.duplicateCandidateOf;
        await t.put('games', g); return g;
      });
    }

    /* 15-11: pulizia dei doppioni già salvati (stesse mosse, partite da file/bot). Si tiene l'analisi più completa. */
    function fen4(f) { return String(f || '').trim().split(/\s+/).slice(0, 4).join(' '); }
    function chiaveContenuto(g) { return fen4(g.startFen) + '|' + (g.mainLineUci || []).join(' '); }
    function puntiPartita(g) {
      return (g.localAnalysisId ? 8 : 0) + (g.archiveState === 'analizzata' ? 4 : 0) + (g.archiveState === 'in analisi' ? 2 : 0)
        + ((g.players && g.players.w && g.players.w.name && g.players.b && g.players.b.name) ? 2 : 0)
        + ((g.playedDate || g.playedAtMs) ? 2 : 0) + ((g.sourceRefs && g.sourceRefs.length) || 0);
    }
    async function fondiDuplicatiContenuto(o) {
      o = o || {};
      var gs = await partite({ scope: o.scope || 'self' }), gruppi = {}, fusi = 0, i, k, arr, keep;
      gs.forEach(function (g) {
        if (!g || !g.mainLineUci || g.mainLineUci.length < 2 || idForti(g).length) return;
        k = chiaveContenuto(g); (gruppi[k] = gruppi[k] || []).push(g);
      });
      for (k in gruppi) {
        arr = gruppi[k];
        if (arr.length < 2) continue;
        arr.sort(function (a, b) { return puntiPartita(b) - puntiPartita(a) || (a.createdAt || 0) - (b.createdAt || 0); });
        keep = arr[0];
        for (i = 1; i < arr.length; i++) { await fondiIn(keep.gameId, arr[i].gameId); fusi++; }
      }
      return { fusi: fusi };
    }
    async function fondiIn(keepId, dropId) {
      if (!keepId || !dropId || keepId === dropId) return;
      return B.tx(['games', 'gameSources', 'nodes', 'analyses', 'analysisJobs', 'mergeLog'], 'readwrite', async function (t) {
        var k = await t.get('games', keepId), d = await t.get('games', dropId), i, srcs, an, jobs, nd;
        if (!k || !d) return;
        srcs = (typeof t.byIndex === 'function') ? await t.byIndex('gameSources', 'gameId', dropId) : [];
        for (i = 0; i < srcs.length; i++) { srcs[i].gameId = keepId; await t.put('gameSources', srcs[i]); }
        (d.sourceRefs || []).forEach(function (r) {
          if (!(k.sourceRefs || []).some(function (x) { return x.sourceKey === r.sourceKey; })) k.sourceRefs.push(r);
        });
        if (k.scopeRefs.indexOf(d.scopeRefs[0]) < 0 && d.scopeRefs[0]) k.scopeRefs.push(d.scopeRefs[0]);
        var aK = k.localAnalysisId ? await t.get('analyses', k.localAnalysisId) : null;
        var aD = d.localAnalysisId ? await t.get('analyses', d.localAnalysisId) : null;
        var best = null;
        if (aK && aK.status === 'complete' && aD && aD.status === 'complete') best = (aD.analysisRevision || 0) > (aK.analysisRevision || 0) ? aD : aK;
        else if (aD && aD.status === 'complete') best = aD;
        else if (aK && aK.status === 'complete') best = aK;
        else best = aK || aD;
        if (best) {
          if (best.gameId !== keepId) { best.gameId = keepId; await t.put('analyses', best); }
          k.localAnalysisId = best.analysisId;
          if (best.status === 'complete') k.archiveState = 'analizzata';
        } else if (d.archiveState === 'analizzata' && k.archiveState !== 'analizzata') k.archiveState = d.archiveState;
        if (k.playedAtMs == null && d.playedAtMs != null) { k.playedAt = d.playedAt; k.playedAtMs = d.playedAtMs; k.playedDate = d.playedDate; k.monthRome = d.monthRome; }
        if (k.userColor == null && d.userColor != null) { k.userColor = d.userColor; k.userColorState = d.userColorState; }
        ['w', 'b'].forEach(function (c) {
          if (k.players && d.players && !k.players[c].name && d.players[c].name) k.players[c].name = d.players[c].name;
        });
        k.updatedAt = ora();
        await t.put('games', k);
        await t.put('mergeLog', { mergeId: 'M-dup-' + U.hash(keepId + '|' + dropId), keptGameId: keepId, sourceRevKey: 'dup:' + dropId, sourceKey: 'dup:' + dropId, at: ora(), regola: 'stesse-mosse-pulizia', annullata: false });
        try { jobs = await t.all('analysisJobs'); } catch (eJ) { jobs = []; }
        jobs = (jobs || []).filter(function (j) { return j && j.gameId === dropId; });
        for (i = 0; i < jobs.length; i++) { jobs[i].gameId = keepId; await t.put('analysisJobs', jobs[i]); }
        try { nd = await t.byIndex('nodes', 'gameId', dropId); } catch (eN) { nd = []; }
        for (i = 0; i < (nd || []).length; i++) await t.del('nodes', nd[i].nodeId);
        await t.del('games', dropId);
      });
    }

    /* ---------------- letture ---------------- */
    async function partite(f) {
      f = f || {};
      return B.tx(['games'], 'readonly', async function (t) {
        var a = f.scope ? await t.byIndex('games', 'scope', f.scope) : await t.all('games');
        if (f.mese) a = a.filter(function (g) { return g.monthRome === f.mese; });
        if (f.stato) a = a.filter(function (g) { return g.archiveState === f.stato; });
        a.sort(function (x, y) { return (y.playedAtMs || 0) - (x.playedAtMs || 0) || (x.gameId < y.gameId ? -1 : 1); });
        return a;
      });
    }
    async function partita(id) { return B.tx(['games'], 'readonly', function (t) { return t.get('games', id); }); }
    async function nodi(id) { return B.tx(['nodes'], 'readonly', function (t) { return t.byIndex('nodes', 'gameId', id); }); }
    async function fonti(id) { return B.tx(['gameSources'], 'readonly', function (t) { return t.byIndex('gameSources', 'gameId', id); }); }
    async function diagnostiche(batchIds) {
      return B.tx(['diagnostics'], 'readonly', async function (t) { var a = await t.all('diagnostics'); return batchIds ? a.filter(function (x) { return batchIds.indexOf(x.diagId) >= 0 || batchIds.indexOf(x.batchId) >= 0; }) : a; });
    }
    async function aggiornaStato(gameId, stato) {
      if (STATI_ARCHIVIO.indexOf(stato) < 0) throw U.errore('STATO', 'Stato archivio non ammesso: ' + stato);
      return B.tx(['games'], 'readwrite', async function (t) { var g = await t.get('games', gameId); g.archiveState = stato; g.updatedAt = ora(); await t.put('games', g); });
    }
    async function aggiornaCampionamento(mappa) {   // {gameId: sampling}
      return B.tx(['games'], 'readwrite', async function (t) {
        var ids = Object.keys(mappa);
        for (var i = 0; i < ids.length; i++) { var g = await t.get('games', ids[i]); if (!g) continue; g.sampling = mappa[ids[i]]; await t.put('games', g); }
      });
    }

    /* ---------------- backup manuale ---------------- */
    async function esportaBackup(o) {
      o = o || {};
      var dati = {};
      await B.tx(PERS.concat(['meta']), 'readonly', async function (t) {
        for (var i = 0; i < PERS.length; i++) dati[PERS[i]] = await t.all(PERS[i]);
        dati.meta = (await t.all('meta')).filter(function (m) { return metaNelBackup(m.key); });   // impostazioni, seqTentativi, studi avversario
      });
      var conteggi = {}, controlli = {};
      Object.keys(dati).forEach(function (s) {
        dati[s].sort(function (a, b) { var k = BKEY(s); return a[k] < b[k] ? -1 : a[k] > b[k] ? 1 : 0; });
        conteggi[s] = dati[s].length; controlli[s] = U.hash(U.canon(dati[s]));
      });
      var manifest = { formato: 'chessnodeplay-backup', schemaVersion: SCHEMA, creatoIl: U.isoRoma(ora()), app: o.app || 'it.chessnode.play', moduli: 'cnap-fase1', conteggi: conteggi, controlli: controlli, nota: 'Backup personale locale. Non contiene dati della biblioteca originale.' };
      manifest.controlloManifesto = U.hash(U.canon({ conteggi: conteggi, controlli: controlli, schemaVersion: SCHEMA }));
      return { manifest: manifest, dati: dati };
    }
    function BKEY(s) { return { games: 'gameId', gameSources: 'sourceRevKey', nodes: 'nodeId', analyses: 'analysisId', analysisJobs: 'jobId', profileSnapshots: 'snapshotId', exerciseRefs: 'refId', mergeLog: 'mergeId', legacy: 'key', meta: 'key', exercises: 'exerciseId', placements: 'placementId', attempts: 'attemptId', sessions: 'sessionId', plans: 'planId' }[s]; }
    function verificaBackup(testoOObj) {
      var b, errori = [];
      try { b = typeof testoOObj === 'string' ? JSON.parse(testoOObj) : testoOObj; } catch (e) { return { ok: false, errori: ['Il file di backup non è JSON leggibile (forse è incompleto o danneggiato).'] }; }
      if (!b || !b.manifest || b.manifest.formato !== 'chessnodeplay-backup') return { ok: false, errori: ['Non è un backup di Chess Node Play.'] };
      if (b.manifest.schemaVersion > SCHEMA) errori.push('Backup creato da una versione più recente (schema ' + b.manifest.schemaVersion + '): aggiornare l\'app prima di ripristinarlo.');
      var m = b.manifest;
      if (m.controlloManifesto !== U.hash(U.canon({ conteggi: m.conteggi, controlli: m.controlli, schemaVersion: m.schemaVersion }))) errori.push('Manifesto alterato.');
      Object.keys(m.conteggi || {}).forEach(function (s) {
        var a = (b.dati || {})[s];
        if (!Array.isArray(a)) { errori.push('Sezione «' + s + '» mancante.'); return; }
        if (a.length !== m.conteggi[s]) errori.push('Sezione «' + s + '»: ' + a.length + ' elementi invece di ' + m.conteggi[s] + '.');
        else if (U.hash(U.canon(a)) !== m.controlli[s]) errori.push('Sezione «' + s + '»: contenuto danneggiato (controllo non corrispondente).');
      });
      // riferimenti: ogni nodo/fonte punta a una partita presente
      if (!errori.length) {
        var ids = {}; (b.dati.games || []).forEach(function (g) { ids[g.gameId] = 1; });
        var orfani = (b.dati.nodes || []).filter(function (n) { return !ids[n.gameId]; }).length + (b.dati.gameSources || []).filter(function (s) { return !ids[s.gameId]; }).length;
        if (orfani) errori.push(orfani + ' riferimenti a partite assenti nel backup.');
      }
      return { ok: !errori.length, errori: errori, backup: errori.length ? null : b };
    }
    /* anteprima: niente viene scritto */
    async function anteprimaRipristino(testoOObj) {
      var v = verificaBackup(testoOObj); if (!v.ok) return { ok: false, errori: v.errori };
      var b = v.backup, out = { ok: true, nuove: [], identiche: [], conflitti: [] };
      await B.tx(['games'], 'readonly', async function (t) {
        for (var i = 0; i < b.dati.games.length; i++) {
          var g = b.dati.games[i], e = await t.get('games', g.gameId);
          if (!e) out.nuove.push(g.gameId); else if (U.canon(e.mainLineUci) === U.canon(g.mainLineUci) && e.rawHash === g.rawHash) out.identiche.push(g.gameId); else out.conflitti.push({ gameId: g.gameId, motivo: 'stesso ID con contenuto diverso' });
        }
      });
      return out;
    }
    /* ripristino: solo elementi nuovi (mai sovrascritture); conflitti lasciati all'utente. Tutto o niente. */
    async function ripristina(testoOObj) {
      var v = verificaBackup(testoOObj); if (!v.ok) throw U.errore('BACKUP_NON_VALIDO', 'Backup non valido: ' + v.errori.join(' '));
      var b = v.backup, rep = { aggiunti: {}, saltati: {} };
      var conAll = PERS.length > PERSONALI.length;
      await B.tx(PERS.concat(['meta']), 'readwrite', async function (t) {
        for (var i = 0; i < PERS.length; i++) {
          var s = PERS[i], k = BKEY(s), a = b.dati[s] || []; rep.aggiunti[s] = 0; rep.saltati[s] = 0;
          for (var j = 0; j < a.length; j++) { if (await t.get(s, a[j][k])) rep.saltati[s]++; else { await t.put(s, a[j]); rep.aggiunti[s]++; } }
        }
        // studi avversario: il record torna solo se manca (mai sovrascritto)
        var mb = b.dati.meta || [];
        for (var q = 0; q < mb.length; q++) if (/^avversario:/.test(String(mb[q].key)) && !(await t.get('meta', mb[q].key))) await t.put('meta', mb[q]);
        if (!conAll) return;
        // seqTentativi = max(presente, backup, ordine più alto tra i tentativi): mai un valore più basso
        var seqOra = await t.get('meta', 'seqTentativi'), seqB = mb.filter(function (m) { return m.key === 'seqTentativi'; })[0];
        var maxOrd = (await t.all('attempts')).reduce(function (m, x) { return Math.max(m, x.ordine || 0); }, 0);
        var seq = Math.max(seqOra ? seqOra.valore || 0 : 0, seqB ? seqB.valore || 0 : 0, maxOrd);
        if (!seqOra || seq !== (seqOra.valore || 0)) await t.put('meta', Object.assign({}, seqOra || {}, { key: 'seqTentativi', valore: seq }));
      });
      usoCache = null; return rep;
    }

    /* ---------------- legacy e cursori ---------------- */
    async function tx(stores, mode, fn) { var r = await B.tx(stores, mode, fn); if (mode === 'readwrite') usoCache = null; return r; }
    async function conteggi() {
      return B.tx(TUTTI, 'readonly', async function (t) { var o = {}; for (var i = 0; i < TUTTI.length; i++) o[TUTTI[i]] = await t.count(TUTTI[i]); return o; });
    }

    return {
      impostazioni: impostazioni, salvaImpostazioni: salvaImpostazioni, meta: meta, salvaMeta: salvaMeta,
      uso: uso, richiediPersistenza: richiediPersistenza, liberaSpazio: liberaSpazio,
      importa: importa, annullaFusione: annullaFusione, annullaFusioni: annullaFusioni, decidiCandidato: decidiCandidato, fondiDuplicatiContenuto: fondiDuplicatiContenuto,
      partite: partite, partita: partita, nodi: nodi, fonti: fonti, diagnostiche: diagnostiche, aggiornaStato: aggiornaStato, aggiornaCampionamento: aggiornaCampionamento,
      esportaBackup: esportaBackup, verificaBackup: verificaBackup, anteprimaRipristino: anteprimaRipristino, ripristina: ripristina,
      tx: tx, conteggi: conteggi, SCHEMA: SCHEMA, STATI: STATI_ARCHIVIO
    };
  }
  return { crea: crea, SCHEMA: SCHEMA, IMPOSTAZIONI_DEFAULT: IMPOSTAZIONI_DEFAULT, VERSIONE: 'cnap-archivio-1' };
});
