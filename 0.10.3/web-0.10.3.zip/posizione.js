/* Chess Node · «Posizione personalizzata» (Kiko t1940u/t1941u 14-11, via libera t1969u/t1970u 15-11).
   Scritto da noi da zero: NESSUN codice di Lichess (lila/ui/editor è AGPL, chessground GPL). Si prende solo l'idea di come
   funziona l'editor, con la NOSTRA scacchiera, i nostri pezzi (__app.psrc), i colori del tema e lo stampo (stampo_scacchiera.js).
   - scelta(): foglio dal basso «Editor dei pezzi» / «Muovi i pezzi» (+ «Riprendi l'ultima analisi» se c'è);
   - editor: tavolozza pezzi neri e bianchi, mano (sposta), gomma; tocco, trascinamento, pittura; tocco lungo = togli;
     Svuota, Posizione iniziale, Ruota, chi muove, arrocchi, presa al varco, FEN con controllo dal vivo in italiano;
   - analisi (analisi_pagina.js, modalità libera): fisarmoniche «Mosse giocate da te» (le tue partite, tutto sul telefono)
     e «Mosse degli altri giocatori» (explorer di Lichess, con il TOKEN dell'utente: dal marzo 2026 l'explorer lo richiede);
   - CNLichess: accesso con Lichess (OAuth2 PKCE, client pubblico senza segreto, pagina ufficiale di Lichess, nessuna password,
     token solo sul dispositivo, scollegabile da Impostazioni › Profilo e account).
   chess.js v1 (BSD-2) per regole e controlli. */
(function(){
  'use strict';
  var A = window.__app;
  if (!A || typeof Chess === 'undefined') return;
  var START = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';
  var L = window.LUCIDE || {};
  var EXTRA = {   // icone nostre (disegnate qui, stile a tratto come le altre)
    mano: '<path d="M5 9l-3 3 3 3"/><path d="M9 5l3-3 3 3"/><path d="M15 19l-3 3-3-3"/><path d="M19 9l3 3-3 3"/><path d="M2 12h20"/><path d="M12 2v20"/>',
    gruppo: '<circle cx="9" cy="8" r="3.2"/><path d="M3 20c.6-3.4 3-5.4 6-5.4s5.4 2 6 5.4"/><circle cx="17" cy="9" r="2.6"/><path d="M16.4 14.2c2.6.2 4.2 2 4.6 4.8"/>',
    lucchetto: '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>'
  };
  function svg(n, s){ s = s || 20; var p = L[n] || EXTRA[n]; return p ? '<svg class="lu" viewBox="0 0 24 24" width="' + s + '" height="' + s + '" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' + p + '</svg>' : ''; }
  function esc(s){ return String(s == null ? '' : s).replace(/[&<>"']/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }
  function it(s){ return A.itSan ? A.itSan(s) : s; }
  function rd(k){ try { return JSON.parse(localStorage.getItem(k) || 'null'); } catch(e){ return null; } }
  function wr(k, v){ try { if (v == null) localStorage.removeItem(k); else localStorage.setItem(k, JSON.stringify(v)); } catch(e){} }
  function moto(){ return window.CNStampo ? CNStampo.moto() : 0; }
  function fkey(fen){ return String(fen).split(' ').slice(0, 4).join(' '); }
  function nativo(){ var C = window.Capacitor; return !!(C && C.isNativePlatform && C.isNativePlatform()); }
  function plug(n){ var C = window.Capacitor; if (!nativo()) return null; var p = C.Plugins && C.Plugins[n]; if (!p && C.registerPlugin) try { p = C.registerPlugin(n); } catch(e){ p = null; } return p || null; }
  function vibra(){ try { if (window.CNVibra && CNVibra.tap) CNVibra.tap(); else if (navigator.vibrate) navigator.vibrate(15); } catch(e){} }
  function fmtN(n){ n = +n || 0; if (n >= 1e6) return (n / 1e6).toFixed(n >= 1e7 ? 0 : 1).replace('.', ',') + ' mln'; if (n >= 1e4) return Math.round(n / 1000) + ' mila'; return String(n).replace(/\B(?=(\d{3})+(?!\d))/g, '.'); }

  /* ---------- avviso breve (sopra tutto: Home, analisi, editor) ---------- */
  var tEl = null, tT = 0;
  function toast(t){
    if (!tEl){ tEl = document.createElement('div'); tEl.className = 'pp-toast'; tEl.setAttribute('role', 'status'); tEl.setAttribute('aria-live', 'polite'); document.body.appendChild(tEl); }
    tEl.textContent = t; tEl.classList.add('on'); clearTimeout(tT); tT = setTimeout(function(){ tEl.classList.remove('on'); }, 3200);
  }

  /* =====================================================================================================================
     ACCESSO CON LICHESS (OAuth2 Authorization Code + PKCE S256, client pubblico: Lichess ammette client non registrati)
     Ritorno nell'app:
       - APK con lo schema «it.chessnode.play://oauth» (dalla prossima APK, build >= 15): ritorno diretto;
       - APK 0.10.2 (schema chessnode://oauth, che Lichess rifiuta: vuole la notazione a dominio rovesciato «com.esempio://»):
         pagina ponte https sulla nostra GitHub Pages che rimanda a chessnode://oauth?code=…&state=… (l'intent-filter c'è già);
       - sito / browser: ritorno alla stessa pagina (?code=…&state=…).
     Il token resta SOLO nel localStorage del dispositivo; nessuno «scope»: basta per l'explorer e non dà poteri sull'account.
     ===================================================================================================================== */
  var LK = 'chessnodeplay-lichess-accesso-v1', PK = 'chessnodeplay-lichess-pkce-v1';
  var CLIENT = 'chessnode-play', LI = 'https://lichess.org';
  var PONTE = 'https://ficheria.github.io/chessnode-aggiornamenti/oauth/';
  var DIRETTO = 'it.chessnode.play://oauth', BUILD_DIRETTO = 15;
  function b64u(buf){ var s = '', b = new Uint8Array(buf); for (var i = 0; i < b.length; i++) s += String.fromCharCode(b[i]); return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''); }
  function casuale(n){ var a = new Uint8Array(n); crypto.getRandomValues(a); return b64u(a); }
  function sha(t){ return crypto.subtle.digest('SHA-256', new TextEncoder().encode(t)).then(b64u); }
  function buildNativo(){ var AP = plug('App'); if (!AP || !AP.getInfo) return Promise.resolve(0); return AP.getInfo().then(function(i){ return parseInt(i && i.build, 10) || 0; }, function(){ return 0; }); }
  function ritornoUri(){
    if (!nativo()) return Promise.resolve(location.origin + location.pathname);
    return buildNativo().then(function(b){ return b >= BUILD_DIRETTO ? DIRETTO : PONTE; });
  }
  function emetti(){ try { window.dispatchEvent(new CustomEvent('cnlichess:stato', {detail:LIC.stato()})); } catch(e){} }
  var LIC = {
    token: function(){ var a = rd(LK); return a && a.token ? String(a.token) : ''; },
    stato: function(){ var a = rd(LK) || {}; return {collegato:!!a.token, utente:a.utente || '', quando:a.quando || 0}; },
    collega: function(ctx){
      if (!(window.crypto && crypto.subtle)){ toast('Questo browser non permette l\'accesso sicuro a Lichess.'); return Promise.resolve(false); }
      var v = casuale(48), st = casuale(16);
      return Promise.all([sha(v), ritornoUri()]).then(function(r){
        wr(PK, {v:v, s:st, r:r[1], t:Date.now(), ctx:ctx || null});
        var u = LI + '/oauth?response_type=code&client_id=' + encodeURIComponent(CLIENT) + '&redirect_uri=' + encodeURIComponent(r[1]) +
          '&code_challenge_method=S256&code_challenge=' + encodeURIComponent(r[0]) + '&state=' + encodeURIComponent(st);
        var acc = rd('chessnodeplay-account-v1') || {};   // il nome già salvato (pubblico) precompila la pagina di Lichess
        if (acc.lichess && /^[A-Za-z0-9_-]{2,30}$/.test(acc.lichess)) u += '&username=' + encodeURIComponent(acc.lichess);
        LIC._ultimoUrl = u;
        if (nativo()) window.open(u, '_blank', 'noopener');   // Capacitor: fuori dall'app, nel browser del telefono
        else location.assign(u);
        return true;
      });
    },
    // url = chessnode://oauth?…, it.chessnode.play://oauth?…, oppure la pagina stessa (?code=…&state=…)
    gestisci: function(url){
      var q; try { q = new URL(String(url).replace(/^(chessnode|it\.chessnode\.play):\/\//, 'https://x/')).searchParams; } catch(e){ return Promise.resolve(false); }
      var code = q.get('code'), state = q.get('state'), err = q.get('error'), pk = rd(PK);
      if (!pk || !state || state !== pk.s){ if (code || err) toast('Accesso a Lichess non riuscito: riprova da «Collega Lichess».'); return Promise.resolve(false); }
      wr(PK, null);
      if (err || !code){ toast(err === 'access_denied' ? 'Accesso a Lichess annullato.' : 'Accesso a Lichess non riuscito.'); emetti(); return Promise.resolve(false); }
      if (!/^[A-Za-z0-9_]+$/.test(code)){ toast('Accesso a Lichess non riuscito.'); return Promise.resolve(false); }
      var body = 'grant_type=authorization_code&code=' + encodeURIComponent(code) + '&code_verifier=' + encodeURIComponent(pk.v) +
        '&redirect_uri=' + encodeURIComponent(pk.r) + '&client_id=' + encodeURIComponent(CLIENT);
      return fetch(LI + '/api/token', {method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body:body})
        .then(function(r){ if (!r.ok) throw new Error('token ' + r.status); return r.json(); })
        .then(function(j){
          var tk = j && j.access_token; if (!tk || !/^[A-Za-z0-9_]+$/.test(tk)) throw new Error('token');
          var rec = {token:tk, utente:'', quando:Date.now(), scade:j.expires_in ? Date.now() + j.expires_in * 1000 : 0};
          wr(LK, rec);
          return fetch(LI + '/api/account', {headers:{Authorization:'Bearer ' + tk}}).then(function(r){ return r.ok ? r.json() : null; }).catch(function(){ return null; })
            .then(function(a){ if (a && a.username){ rec.utente = String(a.username).slice(0, 30); wr(LK, rec); }
              toast(rec.utente ? 'Lichess collegato come ' + rec.utente + '.' : 'Lichess collegato.'); emetti(); return pk.ctx || true; });
        })
        .catch(function(){ toast('Lichess non ha confermato l\'accesso: riprova tra poco.'); emetti(); return false; });
    },
    scollega: function(){
      var tk = LIC.token(); wr(LK, null); emetti();
      if (tk) try { fetch(LI + '/api/token', {method:'DELETE', headers:{Authorization:'Bearer ' + tk}}).catch(function(){}); } catch(e){}
      toast('Lichess scollegato: il permesso è stato tolto da questo telefono.');
    },
    _ritornoUri: ritornoUri, PONTE:PONTE, DIRETTO:DIRETTO
  };
  window.CNLichess = LIC;
  // ritorno nell'app (deep link) e ritorno nel browser
  (function(){
    function dopo(ctx){ if (ctx && ctx.fen && ctx.da === 'posizione') setTimeout(function(){ riapri(ctx); }, 400); else refreshAltri(); }
    function riapri(ctx){
      if (!(window.CNAnalisi)) return;
      if (CNAnalisi.isOpen()){ refreshAltri(true); return; }
      if (window.CNHome && CNHome.go){ window.__ppApri = ctx; CNHome.go('anlibera', 'ctx'); }
      else CNAnalisi.open({fen:ctx.fen, flip:ctx.flip});
    }
    var AP = plug('App');
    if (AP && AP.addListener){
      try { AP.addListener('appUrlOpen', function(e){ var u = e && e.url || ''; if (/^(chessnode|it\.chessnode\.play):\/\/oauth/.test(u)) LIC.gestisci(u).then(function(c){ if (c) dopo(c); }); }); } catch(e){}
      try { if (AP.getLaunchUrl) AP.getLaunchUrl().then(function(r){ var u = r && r.url || ''; if (/^(chessnode|it\.chessnode\.play):\/\/oauth/.test(u)) LIC.gestisci(u).then(function(c){ if (c) dopo(c); }); }).catch(function(){}); } catch(e){}
    }
    if (!nativo() && /[?&]state=/.test(location.search) && rd(PK)){
      var url = location.href;
      try { history.replaceState(null, '', location.pathname + location.hash); } catch(e){}
      LIC.gestisci(url).then(function(c){ if (c){ var t0 = Date.now(), iv = setInterval(function(){ if ((window.__cnap && __cnap.stato === 'pronto') || Date.now() - t0 > 8000){ clearInterval(iv); dopo(c); } }, 200); } });
    }
  })();

  /* =====================================================================================================================
     SCELTA: Editor dei pezzi / Muovi i pezzi
     ===================================================================================================================== */
  var KEY_AN = 'chessnodeplay-analisi-v1', KEY_ED = 'chessnodeplay-editor-v1';
  function mini(fen, px){
    var g; try { g = new Chess(fen); } catch(e){ return ''; }
    var b = g.board(), h = '';
    for (var r = 0; r < 8; r++) for (var f = 0; f < 8; f++){ var p = b[r][f];
      h += '<i class="' + ((r + f) % 2 ? 'd' : 'l') + '">' + (p ? '<img alt="" src="' + A.psrc(p.color + p.type.toUpperCase()) + '">' : '') + '</i>'; }
    return '<span class="pp-mini" style="--mp:' + (px || 76) + 'px" aria-hidden="true">' + h + '</span>';
  }
  function ultimaAnalisi(){   // c'è un'analisi libera con mosse o da una posizione diversa dall'iniziale?
    var sv = rd(KEY_AN); if (!sv) return null;
    var n = Array.isArray(sv.sans) ? sv.sans.length : 0, f0 = sv.startFen || START;
    if (!n && f0 === START) return null;
    var fen = f0; try { var g = new Chess(f0); (sv.sans || []).slice(0, sv.ply == null ? n : sv.ply).forEach(function(m){ g.move(m); }); fen = g.fen(); } catch(e){}
    return {fen:fen, n:n};
  }
  var sheet = null, sheetLast = null;
  function chiudiScelta(cb){
    if (!sheet || sheet.hidden){ if (cb) cb(); return; }
    sheet.classList.remove('show');
    var s = sheet; if (moto() === 2){ s.hidden = true; if (cb) cb(); } else setTimeout(function(){ s.hidden = true; if (cb) cb(); }, 220);
    if (!cb && sheetLast && sheetLast.focus) try { sheetLast.focus({preventScroll:true}); } catch(e){}
  }
  function scelta(){
    if (!sheet){
      sheet = document.createElement('div'); sheet.id = 'ppScelta'; sheet.className = 'pp-sheet'; sheet.hidden = true;
      sheet.setAttribute('role', 'dialog'); sheet.setAttribute('aria-modal', 'true'); sheet.setAttribute('aria-label', 'Posizione personalizzata');
      document.body.appendChild(sheet);
      sheet.addEventListener('click', function(e){
        if (e.target.closest('.pp-scrim') || e.target.closest('.pp-sx')){ chiudiScelta(); return; }
        var b = e.target.closest('[data-pp]'); if (!b) return;
        var k = b.dataset.pp;
        chiudiScelta(function(){
          var H = window.CNHome;
          if (k === 'editor'){ if (H) H.go('aneditor'); else apriEditor(); }
          else if (k === 'muovi'){ if (H) H.go('anlibera', 'muovi'); else if (window.CNAnalisi) CNAnalisi.open({nuova:true}); }
          else if (k === 'riprendi'){ if (H) H.go('anlibera'); else if (window.CNAnalisi) CNAnalisi.open(); }
        });
      });
    }
    var ua = ultimaAnalisi(), edf = (rd(KEY_ED) || {}).fen;
    sheet.innerHTML = '<div class="pp-scrim"></div><div class="pp-card" tabindex="-1"><div class="pp-grab"></div>' +
      '<h2 class="pp-st">Posizione personalizzata</h2><p class="pp-ss">Da dove vuoi partire?</p>' +
      '<div class="pp-opz">' +
        '<button type="button" class="pp-o" data-pp="editor">' + mini(edf && validaFenBase(edf) ? edf : '4k3/8/8/3q4/8/2N5/8/4K2R w K - 0 1') +
          '<span class="pp-ot"><b>' + svg('pencil', 18) + 'Editor dei pezzi</b><small>Metti i pezzi dove vuoi, scegli chi muove e gli arrocchi.</small></span></button>' +
        '<button type="button" class="pp-o" data-pp="muovi">' + mini(START) +
          '<span class="pp-ot"><b>' + svg('mano', 18) + 'Muovi i pezzi</b><small>Parti dalla posizione iniziale e muovi tu, con motore e teoria.</small></span></button>' +
      '</div>' +
      (ua ? '<button type="button" class="pp-rip" data-pp="riprendi">' + svg('undo-2', 18) + '<span>Riprendi l\'ultima analisi<small>' + (ua.n ? ua.n + (ua.n === 1 ? ' semimossa' : ' semimosse') : 'posizione salvata') + '</small></span>' + svg('chevron-right', 18) + '</button>' : '') +
      '<p class="pp-nota">Per incollare una partita o una FEN usa «Incolla PGN» nella pagina Analisi.</p>' +
      '<button type="button" class="pp-sx">Chiudi</button></div>';
    sheetLast = document.activeElement; sheet.hidden = false;
    var go = function(){ sheet.classList.add('show'); var c = sheet.querySelector('.pp-card'); if (c) c.focus({preventScroll:true}); };
    if (moto() === 2) go(); else requestAnimationFrame(function(){ requestAnimationFrame(go); });
    return true;
  }
  function validaFenBase(f){ try { new Chess(f); return true; } catch(e){ return false; } }

  /* =====================================================================================================================
     EDITOR DEI PEZZI
     ===================================================================================================================== */
  var FILES = 'abcdefgh', PEZZI = ['K', 'Q', 'R', 'B', 'N', 'P'];
  var NOMI = {K:'Re', Q:'Donna', R:'Torre', B:'Alfiere', N:'Cavallo', P:'Pedone'};
  var E = {B:{}, turno:'w', arr:{K:true, Q:true, k:true, q:true}, ep:'-', hm:0, fm:1, flip:false, tool:'mano', sel:null, ctx:null};
  var ed = null, $e = function(s){ return ed.querySelector(s); };
  function daFen(fen){
    var p = String(fen || '').trim().split(/\s+/), rows = (p[0] || '').split('/');
    if (rows.length !== 8) return false;
    var B = {};
    for (var r = 0; r < 8; r++){
      var f = 0, row = rows[r];
      for (var i = 0; i < row.length; i++){
        var c = row[i];
        if (/[1-8]/.test(c)) f += +c;
        else if (/[prnbqkPRNBQK]/.test(c)){ if (f > 7) return false; B[FILES[f] + (8 - r)] = (c === c.toUpperCase() ? 'w' : 'b') + c.toUpperCase(); f++; }
        else return false;
      }
      if (f !== 8) return false;
    }
    E.B = B;
    E.turno = p[1] === 'b' ? 'b' : 'w';
    var ca = p[2] || '-'; E.arr = {K:ca.indexOf('K') >= 0, Q:ca.indexOf('Q') >= 0, k:ca.indexOf('k') >= 0, q:ca.indexOf('q') >= 0};
    E.ep = /^[a-h][36]$/.test(p[3] || '') ? p[3] : '-';
    E.hm = Math.max(0, parseInt(p[4], 10) || 0); E.fm = Math.max(1, parseInt(p[5], 10) || 1);
    return true;
  }
  function piazzamento(){
    var s = '';
    for (var r = 8; r >= 1; r--){ var vuote = 0;
      for (var f = 0; f < 8; f++){ var q = E.B[FILES[f] + r];
        if (!q){ vuote++; continue; } if (vuote){ s += vuote; vuote = 0; }
        s += q[0] === 'w' ? q[1] : q[1].toLowerCase(); }
      if (vuote) s += vuote; if (r > 1) s += '/'; }
    return s;
  }
  function arrPossibili(){ var B = E.B; return {K:B.e1 === 'wK' && B.h1 === 'wR', Q:B.e1 === 'wK' && B.a1 === 'wR', k:B.e8 === 'bK' && B.h8 === 'bR', q:B.e8 === 'bK' && B.a8 === 'bR'}; }
  function epPossibili(){   // case di presa al varco per chi muove: pedone avversario appena avanzato di due
    var out = [], B = E.B, me = E.turno, op = me === 'w' ? 'b' : 'w', r5 = me === 'w' ? 5 : 4, r6 = me === 'w' ? 6 : 3, r7 = me === 'w' ? 7 : 2;
    for (var f = 0; f < 8; f++){ var F = FILES[f];
      if (B[F + r5] !== op + 'P' || B[F + r6] || B[F + r7]) continue;
      var vic = [FILES[f - 1], FILES[f + 1]].filter(Boolean).some(function(x){ return B[x + r5] === me + 'P'; });
      if (vic) out.push(F + r6); }
    return out;
  }
  function fen(){
    var ap = arrPossibili(), ca = ['K', 'Q', 'k', 'q'].filter(function(k){ return E.arr[k] && ap[k]; }).join('') || '-';
    var ep = epPossibili().indexOf(E.ep) >= 0 ? E.ep : '-';
    return piazzamento() + ' ' + E.turno + ' ' + ca + ' ' + ep + ' ' + E.hm + ' ' + E.fm;
  }
  function nomeCol(c, art){ return c === 'w' ? (art ? 'il Bianco' : 'Bianco') : (art ? 'il Nero' : 'Nero'); }
  /* controllo dal vivo: errori (bloccano «Analizza»), avvisi (no) e informazioni */
  function valida(){
    var err = [], avv = [], inf = [], B = E.B, n = {w:{}, b:{}}, tot = {w:0, b:0}, pedBordo = [];
    Object.keys(B).forEach(function(sq){ var p = B[sq]; n[p[0]][p[1]] = (n[p[0]][p[1]] || 0) + 1; tot[p[0]]++; if (p[1] === 'P' && /[18]$/.test(sq)) pedBordo.push(sq); });
    ['w', 'b'].forEach(function(c){
      var k = n[c].K || 0, col = c === 'w' ? 'bianco' : 'nero';
      if (!k) err.push('Manca il Re ' + col + '.');
      else if (k > 1) err.push('Ci sono ' + k + ' Re ' + (c === 'w' ? 'bianchi' : 'neri') + ': ne serve uno solo.');
    });
    if (pedBordo.length) err.push((pedBordo.length > 1 ? 'I pedoni in ' : 'Il pedone in ') + pedBordo.sort().join(', ') + (pedBordo.length > 1 ? ' non possono' : ' non può') + ' stare sulla prima o sull\'ottava traversa.');
    ['w', 'b'].forEach(function(c){
      if ((n[c].P || 0) > 8) err.push(nomeCol(c, true).replace(/^il/, 'Il') + ' ha ' + n[c].P + ' pedoni: al massimo 8.');
      if (tot[c] > 16) err.push(nomeCol(c, true).replace(/^il/, 'Il') + ' ha ' + tot[c] + ' pezzi: al massimo 16.');
      var promossi = Math.max(0, (n[c].Q || 0) - 1) + Math.max(0, (n[c].R || 0) - 2) + Math.max(0, (n[c].B || 0) - 2) + Math.max(0, (n[c].N || 0) - 2);
      if (promossi > 8 - (n[c].P || 0) && tot[c] <= 16) avv.push(nomeCol(c, true).replace(/^il/, 'Il') + ' ha più pezzi promossi di quanti pedoni mancano: in una partita vera non succede.');
    });
    var f = fen(), g = null;
    if (!err.length){
      var kw = Object.keys(B).filter(function(s){ return B[s] === 'wK'; })[0], kb = Object.keys(B).filter(function(s){ return B[s] === 'bK'; })[0];
      if (Math.abs(FILES.indexOf(kw[0]) - FILES.indexOf(kb[0])) <= 1 && Math.abs(+kw[1] - +kb[1]) <= 1) err.push('I due Re non possono stare su case vicine.');
    }
    if (!err.length){
      var q = f.split(' '); q[1] = E.turno === 'w' ? 'b' : 'w'; q[3] = '-';
      var altro = null; try { altro = new Chess(q.join(' ')); } catch(e){}
      if (altro && altro.inCheck()) err.push('Il Re ' + (E.turno === 'w' ? 'nero' : 'bianco') + ' è sotto scacco, ma muove ' + nomeCol(E.turno, true) + ': così non può essere. Cambia chi muove o sposta i pezzi.');
    }
    if (!err.length){
      try { g = new Chess(f); } catch(e2){ err.push('Posizione non valida: ' + String(e2 && e2.message || '').replace(/^Invalid FEN:\s*/i, '') + '.'); }
    }
    if (g){
      if (g.isCheckmate()) inf.push('Scacco matto: ' + nomeCol(E.turno === 'w' ? 'b' : 'w', true) + ' ha già vinto.');
      else if (g.isStalemate()) inf.push('Stallo: ' + nomeCol(E.turno, true) + ' non ha mosse. È patta.');
      else if (g.inCheck()) inf.push('Il Re ' + (E.turno === 'w' ? 'bianco' : 'nero') + ' è sotto scacco.');
      else if (g.isInsufficientMaterial()) inf.push('Materiale insufficiente: nessuno può dare matto.');
    }
    return {ok:!err.length, err:err, avv:avv, inf:inf, fen:f};
  }
  function salvaEd(){ wr(KEY_ED, {fen:fen(), flip:E.flip, tool:E.tool}); }

  function build(){
    ed = document.createElement('div'); ed.id = 'ppEd'; ed.className = 'pped'; ed.hidden = true;
    ed.setAttribute('role', 'dialog'); ed.setAttribute('aria-modal', 'true'); ed.setAttribute('aria-label', 'Editor dei pezzi');
    ed.innerHTML =
      '<header class="pped-top">' +
        '<button type="button" class="pped-ib pped-back" aria-label="Indietro">' + svg('chevron-left', 24) + '</button>' +
        '<div class="pped-tt"><b>Editor dei pezzi</b><small>Scegli un pezzo e tocca le case</small></div>' +
        '<button type="button" class="pped-ib pped-flip" aria-label="Ruota la scacchiera">' + svg('arrow-up-down', 22) + '</button>' +
      '</header>' +
      '<div class="pped-main">' +
        '<div class="pped-pal" data-pos="su" role="toolbar"></div>' +
        '<div class="pped-bw"><div class="pped-board" role="grid" aria-label="Scacchiera dell\'editor"></div></div>' +
        '<div class="pped-pal" data-pos="giu" role="toolbar"></div>' +
      '</div>' +
      '<div class="pped-opz">' +
        '<div class="pped-msg" role="status" aria-live="polite"></div>' +
        '<div class="pped-gr"><span class="pped-l">Chi muove</span><div class="pped-seg pped-turno" role="radiogroup" aria-label="Chi muove">' +
          '<button type="button" role="radio" data-t="w"><i class="pped-dot w"></i>Muove il Bianco</button><button type="button" role="radio" data-t="b"><i class="pped-dot b"></i>Muove il Nero</button></div></div>' +
        '<div class="pped-gr"><span class="pped-l">Arrocchi possibili</span><div class="pped-arr">' +
          '<button type="button" data-a="K" role="switch"><i class="pped-dot w"></i>O-O</button><button type="button" data-a="Q" role="switch"><i class="pped-dot w"></i>O-O-O</button>' +
          '<button type="button" data-a="k" role="switch"><i class="pped-dot b"></i>O-O</button><button type="button" data-a="q" role="switch"><i class="pped-dot b"></i>O-O-O</button></div>' +
          '<p class="pped-mu pped-arrn"></p></div>' +
        '<div class="pped-gr pped-epg" hidden><span class="pped-l">Presa al varco</span><div class="pped-seg pped-ep" role="radiogroup" aria-label="Presa al varco"></div></div>' +
        '<div class="pped-az">' +
          '<button type="button" class="pped-b" data-x="iniziale">' + svg('rotate-ccw', 18) + 'Posizione iniziale</button>' +
          '<button type="button" class="pped-b" data-x="svuota">' + svg('trash-2', 18) + 'Svuota</button>' +
          '<button type="button" class="pped-b" data-x="ruota">' + svg('arrow-up-down', 18) + 'Ruota</button>' +
        '</div>' +
        '<label class="pped-l pped-fl" for="ppFen">FEN della posizione</label>' +
        '<div class="pped-fen"><input id="ppFen" class="pped-fin" spellcheck="false" autocapitalize="off" autocomplete="off" inputmode="text" aria-describedby="ppFenM">' +
          '<button type="button" class="pped-ib pped-cp" aria-label="Copia la FEN">' + svg('copy', 18) + '</button></div>' +
        '<p class="pped-mu" id="ppFenM">Puoi anche incollare qui una FEN: la scacchiera si aggiorna da sola.</p>' +
      '</div>' +
      '<footer class="pped-ft"><button type="button" class="pped-go">' + svg('search', 20) + '<span>Analizza questa posizione</span></button></footer>';
    document.body.appendChild(ed);
    $e('.pped-back').onclick = function(){ chiudiEditor(); };
    $e('.pped-flip').onclick = function(){ E.flip = !E.flip; ridisegna(); };
    $e('.pped-turno').onclick = function(e){ var b = e.target.closest('[data-t]'); if (!b) return; E.turno = b.dataset.t; E.ep = '-'; cambia(); };
    $e('.pped-arr').onclick = function(e){ var b = e.target.closest('[data-a]'); if (!b || b.disabled) return; E.arr[b.dataset.a] = !E.arr[b.dataset.a]; cambia(); };
    $e('.pped-ep').onclick = function(e){ var b = e.target.closest('[data-ep]'); if (!b) return; E.ep = b.dataset.ep; cambia(); };
    $e('.pped-az').onclick = function(e){ var b = e.target.closest('[data-x]'); if (!b) return; var x = b.dataset.x;
      if (x === 'iniziale'){ daFen(START); E.sel = null; cambia(); msgBreve('Posizione iniziale.'); }
      else if (x === 'svuota'){ var tenuti = {}; E.B = tenuti; E.sel = null; E.arr = {K:false, Q:false, k:false, q:false}; E.ep = '-'; cambia(); msgBreve('Scacchiera vuota: metti i due Re e gli altri pezzi.'); }
      else if (x === 'ruota'){ E.flip = !E.flip; ridisegna(); } };
    var fin = $e('.pped-fin'), fT = 0;
    fin.addEventListener('input', function(){ clearTimeout(fT); fT = setTimeout(function(){ leggiFen(fin.value, false); }, 250); });
    fin.addEventListener('change', function(){ leggiFen(fin.value, true); });
    fin.addEventListener('keydown', function(e){ if (e.key === 'Enter'){ e.preventDefault(); leggiFen(fin.value, true); fin.blur(); } });
    $e('.pped-cp').onclick = function(){ copia(fen()); };
    $e('.pped-go').onclick = analizza;
    var bd = $e('.pped-board');
    bd.addEventListener('pointerdown', bdDown);
    ed.querySelectorAll('.pped-pal').forEach(function(p){ p.addEventListener('pointerdown', palDown); p.addEventListener('click', palClick); });
    bd.addEventListener('contextmenu', function(e){ e.preventDefault(); });
    window.addEventListener('resize', function(){ if (ed && !ed.hidden) misura(); });
  }
  var msgT = 0, msgX = '';
  function msgBreve(t){ msgX = t; clearTimeout(msgT); msgT = setTimeout(function(){ msgX = ''; if (ed && !ed.hidden) controlli(); }, 2600); controlli(); }
  function leggiFen(t, definitivo){
    t = String(t || '').trim(); var m = $e('#ppFenM');
    if (!t){ m.textContent = 'Incolla una FEN, per esempio quella di un sito o di un libro.'; m.className = 'pped-mu'; return; }
    var p = t.split(/\s+/); while (p.length < 6) p.push(['w', '-', '-', '0', '1'][p.length - 1]);
    var copia_ = JSON.parse(JSON.stringify({B:E.B, turno:E.turno, arr:E.arr, ep:E.ep, hm:E.hm, fm:E.fm}));
    if (!daFen(p.join(' '))){
      for (var k in copia_) E[k] = copia_[k];
      m.textContent = 'Questa FEN non si legge: servono 8 traverse separate da «/» (es. «rnbqkbnr/pppppppp/8/…»).'; m.className = 'pped-mu pped-er'; return;
    }
    m.textContent = 'FEN letta.'; m.className = 'pped-mu pped-okm'; E.sel = null; cambia(true);
  }
  function copia(t){
    function fb(){ var ta = document.createElement('textarea'); ta.value = t; ta.style.position = 'fixed'; ta.style.opacity = '0'; document.body.appendChild(ta); ta.select(); try { document.execCommand('copy'); } catch(e){} ta.remove(); toast('FEN copiata.'); }
    if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(t).then(function(){ toast('FEN copiata.'); }, fb); else fb();
  }
  function lato(){ return E.flip ? 'b' : 'w'; }
  function palette(){
    var su = E.flip ? 'w' : 'b', giu = E.flip ? 'b' : 'w';
    function riga(c){
      return '<button type="button" class="pped-t' + (E.tool === 'mano' ? ' on' : '') + '" data-tool="mano" aria-pressed="' + (E.tool === 'mano') + '" aria-label="Mano: sposta i pezzi">' + svg('mano', 22) + '</button>' +
        PEZZI.map(function(p){ var id = c + p, on = E.tool === id;
          return '<button type="button" class="pped-t pped-pz' + (on ? ' on' : '') + '" data-tool="' + id + '" aria-pressed="' + on + '" aria-label="' + NOMI[p] + ' ' + (c === 'w' ? 'bianco' : 'nero') + '"><img alt="" draggable="false" src="' + A.psrc(id) + '"></button>'; }).join('') +
        '<button type="button" class="pped-t' + (E.tool === 'gomma' ? ' on' : '') + '" data-tool="gomma" aria-pressed="' + (E.tool === 'gomma') + '" aria-label="Gomma: togli i pezzi">' + svg('eraser', 22) + '</button>';
    }
    ed.querySelector('.pped-pal[data-pos=su]').innerHTML = riga(su);
    ed.querySelector('.pped-pal[data-pos=giu]').innerHTML = riga(giu);
  }
  function scacchiera(){
    var h = '', hov = drag && drag.hov;
    for (var r = 0; r < 8; r++) for (var f = 0; f < 8; f++){
      var rr = E.flip ? r : 7 - r, ff = E.flip ? 7 - f : f, sq = FILES[ff] + (rr + 1), p = E.B[sq];
      var k = 'pped-sq ' + ((rr + ff) % 2 ? 'l' : 'd') + (sq === E.sel ? ' sel' : '') + (sq === hov ? ' hov' : '') + (drag && drag.moved && drag.from === sq ? ' via' : '');
      h += '<div class="' + k + '" data-sq="' + sq + '" role="gridcell" aria-label="' + sq + (p ? ' ' + NOMI[p[1]] + ' ' + (p[0] === 'w' ? 'bianco' : 'nero') : ' vuota') + '">' +
        (f === 0 ? '<i class="pped-co r">' + (rr + 1) + '</i>' : '') + (r === 7 ? '<i class="pped-co f">' + FILES[ff] + '</i>' : '') +
        (p ? '<img alt="" draggable="false" src="' + A.psrc(p) + '">' : '') + '</div>';
    }
    $e('.pped-board').innerHTML = h;
  }
  function controlli(){
    var v = valida(), ap = arrPossibili(), epl = epPossibili();
    ed.querySelectorAll('.pped-turno [data-t]').forEach(function(b){ var on = b.dataset.t === E.turno; b.classList.toggle('on', on); b.setAttribute('aria-checked', on); });
    var mancano = [];
    ed.querySelectorAll('.pped-arr [data-a]').forEach(function(b){ var k = b.dataset.a, pos = ap[k], on = pos && E.arr[k];
      b.disabled = !pos; b.classList.toggle('on', !!on); b.setAttribute('aria-checked', !!on);
      b.setAttribute('aria-label', (k === k.toUpperCase() ? 'Bianco ' : 'Nero ') + (k.toLowerCase() === 'k' ? 'arrocco corto' : 'arrocco lungo') + (pos ? '' : ': non possibile'));
      if (!pos) mancano.push(k); });
    $e('.pped-arrn').textContent = mancano.length === 4 ? 'Per arroccare servono il Re e la Torre sulle case di partenza (e1/h1, e1/a1, e8/h8, e8/a8).' : mancano.length ? 'Gli arrocchi spenti non sono possibili: Re o Torre non sono sulla casa di partenza.' : '';
    var eg = $e('.pped-epg'); eg.hidden = !epl.length;
    if (epl.length){ if (epl.indexOf(E.ep) < 0) E.ep = epl.indexOf(E.ep) >= 0 ? E.ep : '-';
      $e('.pped-ep').innerHTML = ['-'].concat(epl).map(function(x){ var on = (E.ep === x); return '<button type="button" role="radio" data-ep="' + x + '" aria-checked="' + on + '" class="' + (on ? 'on' : '') + '">' + (x === '-' ? 'Nessuna' : x) + '</button>'; }).join(''); }
    var m = $e('.pped-msg'), h = '';
    if (v.err.length) h = v.err.map(function(t){ return '<p class="pped-er">' + svg('circle-help', 16) + '<span>' + esc(t) + '</span></p>'; }).join('');
    else h = '<p class="pped-okm">' + svg('check', 16) + '<span>Posizione valida · muove ' + nomeCol(E.turno, true) + '.</span></p>';
    h += v.avv.map(function(t){ return '<p class="pped-av">' + svg('info', 16) + '<span>' + esc(t) + '</span></p>'; }).join('');
    h += v.inf.map(function(t){ return '<p class="pped-in">' + svg('info', 16) + '<span>' + esc(t) + '</span></p>'; }).join('');
    if (msgX) h = '<p class="pped-in pped-tmp">' + svg('info', 16) + '<span>' + esc(msgX) + '</span></p>' + h;
    m.innerHTML = h;
    m.classList.toggle('ko', !v.ok);
    var go = $e('.pped-go'); go.disabled = !v.ok; go.setAttribute('aria-disabled', !v.ok);
    var fin = $e('.pped-fin'); if (document.activeElement !== fin) fin.value = v.fen;
    var tt = $e('.pped-tt small');
    tt.textContent = E.tool === 'mano' ? 'Trascina i pezzi · tocco lungo per toglierli' : E.tool === 'gomma' ? 'Gomma: tocca o passa sulle case' : (NOMI[E.tool[1]] + ' ' + (E.tool[0] === 'w' ? 'bianco' : 'nero') + ': tocca le case');
    return v;
  }
  function ridisegna(){ palette(); scacchiera(); controlli(); misura(); salvaEd(); }
  function cambia(daFenInput){ scacchiera(); var v = controlli(); salvaEd(); if (!daFenInput){ var m = $e('#ppFenM'); m.textContent = 'Puoi anche incollare qui una FEN: la scacchiera si aggiorna da sola.'; m.className = 'pped-mu'; } return v; }
  function misura(){
    if (!ed || ed.hidden) return;
    var W = ed.clientWidth || innerWidth, H = ed.clientHeight || innerHeight;
    var hd = $e('.pped-top').offsetHeight, ft = $e('.pped-ft').offsetHeight, minOpz = H < 700 ? 118 : 190;
    var cell = Math.min(52, Math.max(36, Math.floor(W / 9)));
    var palH = cell + 10;
    var side = Math.min(W, 560, H - hd - ft - minOpz - 2 * palH);
    side = Math.max(240, Math.floor(side / 8) * 8);
    ed.style.setProperty('--ebw', side + 'px'); ed.style.setProperty('--ept', cell + 'px');
  }

  /* ---------- tocco, trascinamento, pittura ---------- */
  var drag = null, paint = null;
  function sqAt(x, y){ var el = document.elementFromPoint(x, y); el = el && el.closest && el.closest('.pped-sq'); return el && ed.contains(el) ? el.dataset.sq : null; }
  function ghost(piece, x, y, touch){
    var g = document.createElement('img'); g.className = 'pped-ghost'; g.alt = ''; g.src = A.psrc(piece); g.draggable = false;
    var c = $e('.pped-sq').getBoundingClientRect().width || 40; g.style.width = g.style.height = Math.round(c * 1.15) + 'px';
    g.dataset.dy = touch ? Math.round(c * 0.55) : 0;
    document.body.appendChild(g); spostaGhost(g, x, y); return g;
  }
  function spostaGhost(g, x, y){ g.style.transform = 'translate(' + Math.round(x) + 'px,' + Math.round(y - (+g.dataset.dy || 0)) + 'px) translate(-50%,-50%)'; }
  function applicaPittura(sq){
    if (!paint || !sq || paint.visti[sq]) return; paint.visti[sq] = 1;
    if (paint.metti) E.B[sq] = paint.metti; else delete E.B[sq];
    E.sel = null; cambia();
  }
  function bdDown(e){
    if (e.button > 0) return;
    var sq = sqAt(e.clientX, e.clientY); if (!sq) return;
    e.preventDefault();
    var p = E.B[sq];
    if (E.tool === 'mano'){
      if (E.sel && E.sel !== sq && !p){ E.B[sq] = E.B[E.sel]; delete E.B[E.sel]; E.sel = null; cambia(); return; }
      if (E.sel && E.sel !== sq && p){ E.B[sq] = E.B[E.sel]; delete E.B[E.sel]; E.sel = null; cambia(); return; }
      if (!p){ E.sel = null; scacchiera(); return; }
      drag = {piece:p, from:sq, x0:e.clientX, y0:e.clientY, moved:false, touch:e.pointerType !== 'mouse', hov:null};
      drag.lungo = setTimeout(function(){ if (drag && !drag.moved && drag.from === sq){ delete E.B[sq]; E.sel = null; drag = null; vibra(); cambia(); msgBreve('Pezzo tolto.'); } }, 520);
    } else {
      paint = {metti:E.tool === 'gomma' ? null : (p === E.tool ? null : E.tool), visti:{}};
      applicaPittura(sq);
    }
    document.addEventListener('pointermove', mv, {passive:false});
    document.addEventListener('pointerup', up); document.addEventListener('pointercancel', up);
  }
  function palClick(e){   // con la tastiera (Invio/Spazio) il «click» arriva senza pointerdown
    if (e.detail !== 0) return;
    var b = e.target.closest('[data-tool]'); if (!b) return; scegliTool(b.dataset.tool);
  }
  function scegliTool(t){ E.tool = t; E.sel = null; palette(); scacchiera(); controlli(); salvaEd(); }
  function palDown(e){
    var b = e.target.closest('[data-tool]'); if (!b || e.button > 0) return;
    e.preventDefault();
    var t = b.dataset.tool; scegliTool(t);
    if (/^[wb][KQRBNP]$/.test(t)){
      drag = {piece:t, from:null, x0:e.clientX, y0:e.clientY, moved:false, touch:e.pointerType !== 'mouse', hov:null};
      document.addEventListener('pointermove', mv, {passive:false});
      document.addEventListener('pointerup', up); document.addEventListener('pointercancel', up);
    }
  }
  function mv(e){
    if (drag){
      var dx = e.clientX - drag.x0, dy = e.clientY - drag.y0;
      if (!drag.moved && dx * dx + dy * dy > 36){ drag.moved = true; clearTimeout(drag.lungo); drag.g = ghost(drag.piece, e.clientX, e.clientY, drag.touch); E.sel = null; scacchiera(); }
      if (drag.moved){ e.preventDefault(); spostaGhost(drag.g, e.clientX, e.clientY - (drag.touch ? 0 : 0));
        var h = sqAt(e.clientX, e.clientY - (+drag.g.dataset.dy || 0)); if (h !== drag.hov){ drag.hov = h; scacchiera(); } }
    } else if (paint){ e.preventDefault(); applicaPittura(sqAt(e.clientX, e.clientY)); }
  }
  function up(e){
    document.removeEventListener('pointermove', mv); document.removeEventListener('pointerup', up); document.removeEventListener('pointercancel', up);
    if (paint){ paint = null; return; }
    var d = drag; drag = null; if (!d) return;
    clearTimeout(d.lungo);
    if (d.g) d.g.remove();
    if (d.moved){
      var to = e.type === 'pointercancel' ? null : sqAt(e.clientX, e.clientY - (d.g ? +d.g.dataset.dy || 0 : 0));
      if (d.from){ if (to && to !== d.from){ E.B[to] = d.piece; delete E.B[d.from]; } else if (!to){ delete E.B[d.from]; msgBreve('Pezzo tolto: l\'hai lasciato fuori dalla scacchiera.'); } }
      else if (to) E.B[to] = d.piece;
      E.sel = null; cambia(); return;
    }
    if (d.from){ E.sel = E.sel === d.from ? null : d.from; scacchiera(); }
  }

  /* ---------- apertura / chiusura / analizza ---------- */
  var edLast = null;
  function apriEditor(o){
    o = o || {};
    if (!ed) build();
    var sv = rd(KEY_ED) || {};
    if (!(o.fen && daFen(o.fen)) && !(sv.fen && daFen(sv.fen))) daFen(START);
    E.flip = o.flip != null ? !!o.flip : !!sv.flip; E.tool = sv.tool && (/^[wb][KQRBNP]$/.test(sv.tool) || sv.tool === 'gomma') ? sv.tool : 'mano'; E.sel = null; E.ctx = o.da || null;
    edLast = document.activeElement;
    ed.hidden = false; document.documentElement.classList.add('pped-on');
    ridisegna(); requestAnimationFrame(misura);
    try { $e('.pped-back').focus({preventScroll:true}); } catch(e){}
    return true;
  }
  function chiudiEditor(){
    if (!ed || ed.hidden) return;
    if (drag && drag.g) drag.g.remove(); drag = null; paint = null;
    ed.hidden = true; document.documentElement.classList.remove('pped-on');
    if (edLast && edLast.focus) try { edLast.focus({preventScroll:true}); } catch(e){}
  }
  function analizza(){
    var v = controlli(); if (!v.ok){ var m = $e('.pped-msg'); m.classList.remove('scuoti'); void m.offsetWidth; m.classList.add('scuoti'); return; }
    if (!window.CNAnalisi) return;
    var gia = CNAnalisi.isOpen();
    var ok = CNAnalisi.open({fen:v.fen, flip:E.flip, daEditor:true});
    if (ok === false) return;
    chiudiEditor();
    if (!gia && window.CNHome && CNHome.osservaAnalisi) CNHome.osservaAnalisi();
  }

  /* tasto Indietro / Esc: prima il popup, poi il foglio di scelta, poi l'editor (prima dell'analisi che sta sotto) */
  window.addEventListener('keydown', function(ev){
    if (ev.key !== 'Escape') return;
    if (pop && !pop.hidden){ ev.preventDefault(); ev.stopImmediatePropagation(); chiudiPop(); return; }
    if (sheet && !sheet.hidden){ ev.preventDefault(); ev.stopImmediatePropagation(); chiudiScelta(); return; }
    if (ed && !ed.hidden){ ev.preventDefault(); ev.stopImmediatePropagation(); chiudiEditor(); }
  }, true);
  try { var U = window.UI; if (U && U.modalOpen && !U.__ppWrap){ var mo = U.modalOpen; U.modalOpen = function(){ return (ed && !ed.hidden) || (sheet && !sheet.hidden) || (pop && !pop.hidden) || mo(); }; U.__ppWrap = 1; } } catch(e){}

  /* =====================================================================================================================
     FISARMONICHE DELL'ANALISI: «Mosse giocate da te» e «Mosse degli altri giocatori»
     ===================================================================================================================== */
  function I(){ return window.CNAnalisi && CNAnalisi._int; }
  function aroot(){ var i = I(); return i ? i.root() : null; }
  function fenOra(){ try { return CNAnalisi.state().fen; } catch(e){ return START; } }
  function suoMossa(san){   // gioca una mossa (SAN) dalla posizione attuale
    try { var g = new Chess(fenOra()), m = g.move(san); if (m) CNAnalisi.play({from:m.from, to:m.to, promotion:m.promotion}); } catch(e){}
  }
  function barra(w, d, b, etich){
    var t = (w + d + b) || 1, pw = Math.round(w * 100 / t), pb = Math.round(b * 100 / t), pd = Math.max(0, 100 - pw - pb);
    var lab = etich || ['Bianco', 'Patta', 'Nero'];
    return '<span class="pp-bar" role="img" aria-label="' + lab[0] + ' ' + pw + '%, ' + lab[1] + ' ' + pd + '%, ' + lab[2] + ' ' + pb + '%">' +
      '<i class="w" style="width:' + pw + '%">' + (pw >= 14 ? pw + '%' : '') + '</i><i class="d" style="width:' + pd + '%">' + (pd >= 14 ? pd + '%' : '') + '</i><i class="b" style="width:' + pb + '%">' + (pb >= 14 ? pb + '%' : '') + '</i></span>';
  }

  /* ---------- Mosse giocate da te: indice per posizione costruito sul telefono (partite coi bot, analizzate, importate) ---------- */
  var IDX = null, idxFirma = '', idxP = null, MAXPLY = 40;
  function esitoUtente(res, me){ if (!me || !res) return null; if (res === '1/2-1/2') return 'p'; if (res === '1-0') return me === 'w' ? 'v' : 's'; if (res === '0-1') return me === 'b' ? 'v' : 's'; return null; }
  function raccogli(){
    var out = [], visti = {};
    function add(start, sans, me, es, fonte){ if (!Array.isArray(sans) || !sans.length) return; var k = (start || START) + '|' + sans.slice(0, MAXPLY).join(' '); if (visti[k]) return; visti[k] = 1; out.push({start:start || START, sans:sans, me:me || null, es:es || null, fonte:fonte}); }
    var bot = rd('chessnodeplay-partite-bot-v1'); (Array.isArray(bot) ? bot : []).forEach(function(r){ if (r) add(r.fen, r.sans, r.colore, r.esito, 'bot'); });
    var st = rd('chessnodeplay-analisi-storico-v1'); ((st && st.g) || []).forEach(function(x){ if (x) add(x.fen, x.sans, x.me, x.esito, x.fonte || 'pgn'); });
    var CN = window.__cnap && __cnap.CN;
    var arch = CN && CN.archivio && CN.archivio.partite ? CN.archivio.partite({scope:'self'}).catch(function(){ return []; }) : Promise.resolve([]);
    return arch.then(function(gs){ (gs || []).forEach(function(g){ if (g && g.variant !== 'fromPosition') add(g.startFen, g.mainLineSan, g.userColor, esitoUtente(g.result, g.userColor), (g.sourceRefs && g.sourceRefs[0] && g.sourceRefs[0].source) || 'import'); }); return out; });
  }
  function costruisciIndice(){
    if (idxP) return idxP;
    idxP = raccogli().then(function(ps){
      var firma = ps.length + ':' + ps.reduce(function(a, p){ return a + p.sans.length; }, 0);
      if (IDX && firma === idxFirma){ idxP = null; return IDX; }
      var M = {}, i = 0;
      return new Promise(function(fine){
        function giro(){
          var t0 = Date.now();
          while (i < ps.length && Date.now() - t0 < 12){
            var p = ps[i++], g; try { g = new Chess(p.start); } catch(e){ continue; }
            for (var j = 0; j < p.sans.length && j < MAXPLY; j++){
              var k = fkey(g.fen()), tu = g.turn() === p.me, mv; try { mv = g.move(p.sans[j]); } catch(e){ mv = null; } if (!mv) break;
              var nodo = M[k] || (M[k] = {n:0, m:{}}), x = nodo.m[mv.san] || (nodo.m[mv.san] = {n:0, tu:0, v:0, p:0, s:0});
              nodo.n++; x.n++; if (tu) x.tu++; if (p.es === 'v') x.v++; else if (p.es === 'p') x.p++; else if (p.es === 's') x.s++;
            }
          }
          if (i < ps.length) setTimeout(giro, 0); else { IDX = M; idxFirma = firma; idxP = null; fine(M); }
        }
        giro();
      });
    });
    return idxP;
  }
  function disegnaGiocate(){
    var r = aroot(); if (!r) return; var box = r.querySelector('.anp-gio'), det = r.querySelector('.anp-fxg'); if (!box || !det) return;
    var cnt = det.querySelector('.anp-fxc');
    if (!IDX){ box.innerHTML = '<p class="pp-mu pp-att">Preparo le tue partite…</p>'; costruisciIndice().then(function(){ disegnaGiocate(); }); return; }
    var nodo = IDX[fkey(fenOra())];
    if (cnt) cnt.textContent = nodo ? fmtN(nodo.n) : '';
    if (!nodo){ box.innerHTML = '<p class="pp-mu">Nessuna tua partita da questa posizione' + (Object.keys(IDX).length ? '.' : ': gioca coi bot o importa le tue partite da Lichess o Chess.com.') + '</p>'; return; }
    var mosse = Object.keys(nodo.m).map(function(s){ var x = nodo.m[s]; x.san = s; return x; }).sort(function(a, b){ return b.n - a.n; }).slice(0, 10);
    box.innerHTML = '<p class="pp-mu pp-sub">' + fmtN(nodo.n) + (nodo.n === 1 ? ' tua partita' : ' tue partite') + ' da qui · risultati dal tuo lato</p>' +
      '<div class="pp-tab" role="list">' + mosse.map(function(x){
        var chi = x.tu === x.n ? 'tu' : !x.tu ? 'avversari' : 'tu ' + x.tu + ' · avv. ' + (x.n - x.tu);
        return '<button type="button" class="pp-rg" role="listitem" data-san="' + esc(x.san) + '"><b class="pp-mv">' + esc(it(x.san)) + '</b><span class="pp-nn">' + fmtN(x.n) + '<small>' + chi + '</small></span>' +
          (x.v + x.p + x.s ? barra(x.v, x.p, x.s, ['Vinte', 'Patte', 'Perse']).replace('class="pp-bar"', 'class="pp-bar pp-tuo"') : '<span class="pp-bar pp-nd">esito non noto</span>') + '</button>';
      }).join('') + '</div>';
  }

  /* ---------- Mosse degli altri giocatori: explorer di Lichess (token dell'utente) ---------- */
  var EXP = {db:'lichess', cache:{}, ctrl:null, t:0, attesa:0, chiave:'', popVisto:false};
  var EXP_URL = {lichess:'https://explorer.lichess.org/lichess?variant=standard&speeds=blitz,rapid,classical&ratings=1400,1600,1800,2000,2200,2500&moves=12&topGames=0&recentGames=0&fen=',
                 masters:'https://explorer.lichess.org/masters?moves=12&topGames=0&fen='};
  try { var dbSv = rd('chessnodeplay-explorer-v1'); if (dbSv && dbSv.db === 'masters') EXP.db = 'masters'; } catch(e){}
  function disegnaAltri(forza){
    var r = aroot(); if (!r) return; var box = r.querySelector('.anp-alt'), det = r.querySelector('.anp-fxa'); if (!box || !det) return;
    var tk = LIC.token(), st = LIC.stato(), sub = det.querySelector('.anp-fxc');
    if (sub) sub.innerHTML = tk ? '' : svg('lucchetto', 14);
    if (!tk){
      box.innerHTML = '<div class="pp-inv"><p>Scopri quali mosse hanno giocato milioni di giocatori su Lichess da questa posizione, con le percentuali di vittoria.</p>' +
        '<p class="pp-mu">Lichess chiede di accedere con il tuo account (gratis). La password la scrivi solo sulla pagina di Lichess.</p>' +
        '<button type="button" class="pp-btn pp-pri" data-li="collega">' + svg('external-link', 18) + 'Collega Lichess</button>' +
        '<button type="button" class="pp-lnk" data-li="perche">Perché serve?</button></div>';
      return;
    }
    if (!det.open) return;
    var f = fenOra(), k = EXP.db + '|' + String(f).split(' ').slice(0, 4).join(' ');
    var testa = '<div class="pp-exh"><div class="pp-seg" role="radiogroup" aria-label="Archivio">' +
      [['lichess', 'Giocatori Lichess'], ['masters', 'Maestri']].map(function(x){ var on = EXP.db === x[0]; return '<button type="button" role="radio" data-db="' + x[0] + '" aria-checked="' + on + '" class="' + (on ? 'on' : '') + '">' + x[1] + '</button>'; }).join('') +
      '</div><span class="pp-who" title="Account collegato">' + esc(st.utente || 'Lichess') + '</span></div>';
    var c = EXP.cache[k];
    if (c && !forza){ box.innerHTML = testa + tabellaAltri(c); return; }
    if (EXP.attesa > Date.now()){ box.innerHTML = testa + '<p class="pp-mu pp-er">Lichess chiede di aspettare un momento (troppe richieste). Riprovo da solo tra ' + Math.ceil((EXP.attesa - Date.now()) / 1000) + ' s.</p>'; return; }
    if (EXP.chiave === k && EXP.ctrl) return;   // già in arrivo
    box.innerHTML = testa + '<p class="pp-mu pp-att">Cerco le partite su Lichess…</p>';
    clearTimeout(EXP.t);
    EXP.t = setTimeout(function(){ chiedi(k, f, tk); }, 260);
  }
  function chiedi(k, f, tk){
    if (EXP.ctrl) try { EXP.ctrl.abort(); } catch(e){}
    var ctrl = EXP.ctrl = (window.AbortController ? new AbortController() : null); EXP.chiave = k;
    var to = setTimeout(function(){ if (ctrl) ctrl.abort(); }, 9000);
    fetch(EXP_URL[EXP.db] + encodeURIComponent(f), {headers:{Authorization:'Bearer ' + tk, Accept:'application/json'}, signal:ctrl ? ctrl.signal : undefined})
      .then(function(r){
        if (r.status === 401 || r.status === 403){ var e = new Error('auth'); e.auth = true; throw e; }
        if (r.status === 429){ var e2 = new Error('429'); e2.lim = true; throw e2; }
        if (!r.ok) throw new Error('http ' + r.status);
        return r.json();
      })
      .then(function(j){ EXP.cache[k] = j; fineChiedi(k, null); })
      .catch(function(e){
        if (e && e.name === 'AbortError' && EXP.chiave !== k) return;
        fineChiedi(k, e && e.auth ? 'auth' : e && e.lim ? 'lim' : 'rete');
      })
      .then(function(){ clearTimeout(to); });
  }
  function fineChiedi(k, err){
    EXP.ctrl = null;
    var r = aroot(); if (!r) return; var box = r.querySelector('.anp-alt'); if (!box) return;
    var kOra = EXP.db + '|' + String(fenOra()).split(' ').slice(0, 4).join(' ');
    if (k !== kOra){ disegnaAltri(); return; }   // nel frattempo la posizione è cambiata
    if (!err){ disegnaAltri(); return; }
    var testa = box.querySelector('.pp-exh') ? box.querySelector('.pp-exh').outerHTML : '';
    if (err === 'auth'){ wr(LK, null); emetti();
      box.innerHTML = '<div class="pp-inv"><p class="pp-er">Il collegamento con Lichess è scaduto o è stato tolto dal tuo account.</p><button type="button" class="pp-btn pp-pri" data-li="collega">' + svg('external-link', 18) + 'Collega di nuovo</button></div>'; return; }
    if (err === 'lim'){ EXP.attesa = Date.now() + 60000; setTimeout(function(){ disegnaAltri(); }, 60500); box.innerHTML = testa + '<p class="pp-mu pp-er">Lichess chiede di aspettare un minuto (troppe richieste). Riprovo da solo.</p>'; return; }
    box.innerHTML = testa + '<p class="pp-mu pp-er">Lichess non risponde: controlla la connessione.</p><button type="button" class="pp-btn" data-li="riprova">' + svg('rotate-ccw', 16) + 'Riprova</button>';
  }
  function tabellaAltri(j){
    var tot = (j.white || 0) + (j.draws || 0) + (j.black || 0), mv = (j.moves || []);
    if (!tot || !mv.length) return '<p class="pp-mu">' + (EXP.db === 'masters' ? 'Nessuna partita dei maestri da questa posizione.' : 'Nessuna partita su Lichess da questa posizione.') + '</p>';
    return '<p class="pp-mu pp-sub">' + fmtN(tot) + ' partite · ' + (EXP.db === 'masters' ? 'maestri (OTB, Elo 2200+)' : 'blitz, rapid e classiche') + '</p>' +
      '<div class="pp-tab" role="list">' + mv.slice(0, 12).map(function(m){
        var n = (m.white || 0) + (m.draws || 0) + (m.black || 0);
        return '<button type="button" class="pp-rg" role="listitem" data-san="' + esc(m.san) + '"><b class="pp-mv">' + esc(it(m.san)) + '</b><span class="pp-nn">' + Math.round(n * 100 / tot) + '%<small>' + fmtN(n) + '</small></span>' + barra(m.white || 0, m.draws || 0, m.black || 0) + '</button>';
      }).join('') +
      '<div class="pp-rg pp-tot" role="listitem"><b class="pp-mv">Σ</b><span class="pp-nn">100%<small>' + fmtN(tot) + '</small></span>' + barra(j.white || 0, j.draws || 0, j.black || 0) + '</div></div>' +
      '<p class="pp-src">Dati: <a href="https://lichess.org/analysis" target="_blank" rel="noopener">Lichess Opening Explorer</a> (database aperto di Lichess, CC0)</p>';
  }
  function refreshAltri(forza){ try { disegnaAltri(forza); } catch(e){} }

  /* ---------- popup «Collega Lichess» ---------- */
  var pop = null, popLast = null;
  function chiudiPop(){ if (!pop || pop.hidden) return; pop.classList.remove('show'); var p = pop; if (moto() === 2) p.hidden = true; else setTimeout(function(){ p.hidden = true; }, 200); if (popLast && popLast.focus) try { popLast.focus({preventScroll:true}); } catch(e){} }
  function popup(){
    if (!pop){
      pop = document.createElement('div'); pop.id = 'ppLiPop'; pop.className = 'pp-pop'; pop.hidden = true;
      pop.setAttribute('role', 'dialog'); pop.setAttribute('aria-modal', 'true'); pop.setAttribute('aria-labelledby', 'ppLiT');
      pop.innerHTML = '<div class="pp-scrim"></div><div class="pp-pc" tabindex="-1">' +
        '<div class="pp-pi" aria-hidden="true">' + svg('gruppo', 30) + '</div>' +
        '<h2 id="ppLiT">Mosse degli altri giocatori</h2>' +
        '<p>Qui vedi quali mosse hanno giocato gli altri da questa posizione su <b>Lichess</b> (milioni di partite) o nelle partite dei <b>maestri</b>, con le percentuali di vittoria.</p>' +
        '<p>Da marzo 2026 Lichess fa usare questo archivio solo a chi accede con un account (è gratis). Per questo ti chiediamo di collegarlo una volta.</p>' +
        '<ul class="pp-ul"><li>' + svg('check', 16) + '<span>Accedi sulla pagina ufficiale di Lichess: Chess Node non vede mai la tua password.</span></li>' +
          '<li>' + svg('check', 16) + '<span>Chess Node riceve solo un permesso di lettura, senza poteri sul tuo account. Resta su questo telefono.</span></li>' +
          '<li>' + svg('check', 16) + '<span>Le posizioni che guardi vengono inviate a Lichess per la ricerca. Puoi scollegarlo quando vuoi da Impostazioni › Profilo e account.</span></li></ul>' +
        '<button type="button" class="pp-btn pp-pri" data-li="collega">' + svg('external-link', 18) + 'Collega Lichess</button>' +
        '<button type="button" class="pp-btn" data-li="nonora">Non ora</button>' +
        '<p class="pp-mu pp-c">Non hai un account? <a href="https://lichess.org/signup" target="_blank" rel="noopener">Crealo su Lichess</a></p></div>';
      document.body.appendChild(pop);
      pop.addEventListener('click', function(e){
        if (e.target.closest('.pp-scrim')){ chiudiPop(); return; }
        var b = e.target.closest('[data-li]'); if (!b) return;
        if (b.dataset.li === 'nonora') chiudiPop();
        else if (b.dataset.li === 'collega'){ chiudiPop(); collegaDaAnalisi(); }
      });
      pop.addEventListener('click', function(e){ var a = e.target.closest('a[href^="https://lichess.org/signup"]'); if (a && nativo()){ e.preventDefault(); window.open(a.href, '_blank', 'noopener'); } });
    }
    popLast = document.activeElement; pop.hidden = false;
    var go = function(){ pop.classList.add('show'); var c = pop.querySelector('.pp-pc'); if (c) c.focus({preventScroll:true}); };
    if (moto() === 2) go(); else requestAnimationFrame(function(){ requestAnimationFrame(go); });
  }
  function collegaDaAnalisi(){
    var s = {}; try { s = CNAnalisi.state(); } catch(e){}
    LIC.collega({da:'posizione', fen:s.fen || START, flip:!!s.flip});
  }

  /* ---------- aggancio all'analisi (chiamato da analisi_pagina.js a ogni disegno in modalità libera) ---------- */
  var agganciato = false;
  function aggancia(r){
    if (agganciato) return; agganciato = true;
    r.addEventListener('click', function(e){
      var b = e.target.closest('.anp-gio [data-san], .anp-alt [data-san]'); if (b){ suoMossa(b.dataset.san); return; }
      var d = e.target.closest('.anp-alt [data-db]'); if (d){ EXP.db = d.dataset.db; wr('chessnodeplay-explorer-v1', {db:EXP.db}); disegnaAltri(); return; }
      var l = e.target.closest('.anp-alt [data-li]'); if (l){ var a = l.dataset.li; if (a === 'collega') collegaDaAnalisi(); else if (a === 'perche') popup(); else if (a === 'riprova') disegnaAltri(true); }
    });
    var fa = r.querySelector('.anp-fxa'), fg = r.querySelector('.anp-fxg');
    if (fa) fa.addEventListener('toggle', function(){ if (fa.open){ if (!LIC.token() && !EXP.popVisto){ EXP.popVisto = true; popup(); } disegnaAltri(); } });
    if (fg) fg.addEventListener('toggle', function(){ if (fg.open) disegnaGiocate(); });
    window.addEventListener('cnlichess:stato', function(){ disegnaAltri(); });
  }
  function testoFumetto(r){
    var t = r.querySelector('.anp-lz .cn-st-txt'); if (!t) return;
    var s = {}; try { s = CNAnalisi.state(); } catch(e){}
    var g = null; try { g = new Chess(s.fen); } catch(e){}
    var th = r.querySelector('.anp-thd'), inTeo = th && !th.hidden, x;
    if (g && g.isCheckmate()) x = 'Scacco matto! Torna indietro con ‹ o prova un\'altra mossa.';
    else if (g && g.isStalemate()) x = 'Stallo: chi muove non ha mosse legali. È patta.';
    else if (!s.ply && !s.inVariante) x = s.startFen && s.startFen !== START ? 'La tua posizione è pronta: muovi i pezzi per provare le idee, il motore valuta ogni mossa.' : 'Muovi un pezzo: il motore valuta ogni posizione e sotto trovi la teoria d\'apertura.';
    else if (inTeo) x = 'Sei nella teoria d\'apertura: qui sotto le mosse dei libri e degli altri giocatori.';
    else x = 'Fuori dalla teoria: segui il motore e le mosse degli altri giocatori.';
    if (t.textContent !== x) t.textContent = x;
    var w = r.querySelector('.anp-lz-t');   // titolo: nome dell'apertura, «Posizione iniziale» solo se lo è davvero
    if (w && s.startFen && s.startFen !== START && /^(Posizione iniziale|Analisi libera)$/.test(w.textContent)) w.textContent = 'La tua posizione';
  }
  function onRender(){
    var r = aroot(); if (!r || r.hidden || !r.classList.contains('anp-pp')) return;
    aggancia(r);
    var fg = r.querySelector('.anp-fxg'), fa = r.querySelector('.anp-fxa');
    if (fg && fg.open) disegnaGiocate(); else if (fg && IDX){ var nodo = IDX[fkey(fenOra())], c = fg.querySelector('.anp-fxc'); if (c) c.textContent = nodo ? fmtN(nodo.n) : ''; }
    if (fa) disegnaAltri();
    testoFumetto(r);
  }
  function onOpen(){ IDX = null; idxFirma = ''; }   // a ogni apertura si rilegge l'archivio (partite nuove)

  window.CNPosizione = {scelta:scelta, chiudiScelta:chiudiScelta, apriEditor:apriEditor, chiudiEditor:chiudiEditor, editorAperto:function(){ return !!(ed && !ed.hidden); },
    onRender:onRender, onOpen:onOpen, popup:popup, toast:toast, _E:E, _valida:valida, _fen:fen, _daFen:function(f){ var ok = daFen(f); if (ed && !ed.hidden) ridisegna(); return ok; },
    _indice:function(){ return costruisciIndice(); }, _exp:EXP};
})();
