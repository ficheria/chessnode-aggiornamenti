/* Chess Node · aggiornamenti senza reinstallare (live update dei soli file web), Kiko t1950u/t1951u 14-11.
   Motore nativo: @capgo/capacitor-updater (MPL-2.0) in modalità manuale, SENZA cloud: niente statistiche, niente server Capgo.
   - manifest.json su un indirizzo nostro (https), FIRMATO con la nostra chiave ECDSA P-256 (la pubblica è qui sotto,
     la privata resta fuori dall'app: chiavi_aggiornamenti/). Firma sbagliata → l'aggiornamento si scarta.
   - lo zip si scarica con il controllo sha256 (fatto dal plugin) e si installa al PROSSIMO avvio (next()).
   - se la nuova versione non arriva a «pronta» (notifyAppReady) entro 10 s, il plugin torna da solo alla precedente.
   API: window.CNAgg = {controlla(), info(), stato(), impostaUrl(u)}. Sul web (anteprima) dice solo «disponibile nell'app». */
(function (W) {
  'use strict';
  var PUB = 'MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAErZe+/pPlFYlKYkKVW3Nv5OuLolOcDWyyqd45VEEGiT/bNtxMSiym68gFCNHGouo5BwdOuwtAoNM/hBapOzLjAg==';
  var KEY = 'chessnodeplay-aggiornamenti-v1';
  var MANIFEST_PREDEFINITO = 'https://ficheria.github.io/chessnode-aggiornamenti/manifest.json';  // GitHub Pages, deciso 15-11
  function rd(){ try { return JSON.parse(localStorage.getItem(KEY) || 'null') || {}; } catch (e) { return {}; } }
  function wr(s){ try { localStorage.setItem(KEY, JSON.stringify(s)); } catch (e) {} }
  function cap(){ return W.Capacitor; }
  function nativo(){ var C = cap(); return !!(C && C.isNativePlatform && C.isNativePlatform()); }
  function plug(nome){ var C = cap(); if (!nativo()) return null; var p = C.Plugins && C.Plugins[nome]; if (!p && C.registerPlugin) { try { p = C.registerPlugin(nome); } catch (e) { p = null; } } return p || null; }
  function b64(s){ var b = atob(s), u = new Uint8Array(b.length); for (var i = 0; i < b.length; i++) u[i] = b.charCodeAt(i); return u; }
  function confronta(a, b){ var x = String(a || '0').split(/[.-]/).map(function (n) { return parseInt(n, 10) || 0; }), y = String(b || '0').split(/[.-]/).map(function (n) { return parseInt(n, 10) || 0; });
    for (var i = 0; i < Math.max(x.length, y.length); i++) { if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0) ? 1 : -1; } return 0; }
  var verWeb = null;
  function versioneWeb(){
    if (verWeb) return Promise.resolve(verWeb);
    if (!nativo()) { verWeb = 'sviluppo'; return Promise.resolve(verWeb); } // nel browser di sviluppo il file non c'è (lo scrive la build)
    return fetch('versione_web.json', { cache: 'no-store' }).then(function (r) { return r.ok ? r.json() : {}; }).then(function (j) { verWeb = (j && j.versione) || 'sviluppo'; return verWeb; }, function () { verWeb = 'sviluppo'; return verWeb; });
  }
  function testoFirmato(m){ return ['cn-agg-1', m.versione, m.nativoMin || 0, m.url, m.sha256].join('\n'); }
  function verificaFirma(m){
    var S = W.crypto && W.crypto.subtle;
    if (!S || !m || !m.firma) return Promise.resolve(false);
    return S.importKey('spki', b64(PUB), { name: 'ECDSA', namedCurve: 'P-256' }, false, ['verify'])
      .then(function (k) { return S.verify({ name: 'ECDSA', hash: 'SHA-256' }, k, b64(m.firma), new TextEncoder().encode(testoFirmato(m))); })
      .catch(function () { return false; });
  }
  function buildNativo(){
    var AP = plug('App');
    if (!AP || !AP.getInfo) return Promise.resolve(0);
    return AP.getInfo().then(function (i) { return parseInt(i && i.build, 10) || 0; }, function () { return 0; });
  }
  function esito(e, extra){ var s = rd(); s.esito = Object.assign({ e: e, quando: Date.now() }, extra || {}); wr(s); return s.esito; }

  var inCorso = null;
  function controlla(o){
    if (inCorso) return inCorso;
    o = o || {};
    inCorso = (async function () {
      var s = rd(), url = s.url || MANIFEST_PREDEFINITO;
      s.ultimoControllo = Date.now(); wr(s);
      if (!url) return esito('nonconfigurato');
      if (!/^https:\/\//i.test(url)) return esito('errore', { testo: 'L\'indirizzo deve iniziare con https://' });
      var m;
      try { var r = await fetch(url + (url.indexOf('?') < 0 ? '?' : '&') + 't=' + Date.now(), { cache: 'no-store' }); if (!r.ok) throw new Error('HTTP ' + r.status); m = await r.json(); }
      catch (e) { return esito('rete', { testo: 'Non riesco a raggiungere il server degli aggiornamenti.' }); }
      if (!m || !m.versione || !/^https:\/\//i.test(m.url || '') || !/^[0-9a-f]{64}$/.test(m.sha256 || '')) return esito('errore', { testo: 'Manifest non valido.' });
      if (!(await verificaFirma(m))) return esito('firma', { testo: 'Firma non valida: aggiornamento scartato.' });
      var cur = await versioneWeb();
      if (confronta(m.versione, cur) <= 0) return esito('aggiornata', { versione: cur });
      var b = await buildNativo();
      if (m.nativoMin && b && b < m.nativoMin) return esito('serveapk', { versione: m.versione, testo: 'Questa novità richiede la nuova app (APK).' });
      var P = plug('CapacitorUpdater');
      if (!P) return esito('soloapp', { versione: m.versione });
      s = rd();
      if (s.scaricata && s.scaricata.versione === m.versione) return esito('pronta', { versione: m.versione, note: m.note || '' });
      try {
        var bundle = await P.download({ url: m.url, version: m.versione, checksum: m.sha256 });
        await P.next({ id: bundle.id });
        s = rd(); s.scaricata = { versione: m.versione, id: bundle.id, quando: Date.now() }; wr(s);
        return esito('pronta', { versione: m.versione, note: m.note || '' });
      } catch (e) { return esito('errore', { testo: 'Scaricamento non riuscito: riprova più tardi.' }); }
    })();
    inCorso.then(function () { inCorso = null; }, function () { inCorso = null; });
    return inCorso;
  }

  async function info(){
    var P = plug('CapacitorUpdater'), cur = null;
    if (P && P.current) { try { cur = await P.current(); } catch (e) { cur = null; } }
    return { web: await versioneWeb(), nativo: nativo(), build: await buildNativo(), bundle: cur && cur.bundle ? { id: cur.bundle.id, versione: cur.bundle.version } : null,
      url: rd().url || MANIFEST_PREDEFINITO, esito: rd().esito || null };
  }
  function impostaUrl(u){ var s = rd(); s.url = String(u || '').trim(); wr(s); return s.url; }

  /* avvio: «pronta» solo quando la Home o l'esercizio sono davvero su (altrimenti il plugin torna alla versione precedente) */
  function pronta(){
    var P = plug('CapacitorUpdater'); if (!P) return;
    var giri = 0;
    (function prova(){
      var ok = !!(W.__app && W.CNHome && (W.CNHome.visibile() || document.getElementById('board')));
      if (ok) {
        P.notifyAppReady().then(function (r) {
          var s = rd(), v = r && r.bundle && r.bundle.version;
          if (s.scaricata && v && v === s.scaricata.versione) { s.installata = { versione: v, quando: Date.now() }; s.scaricata = null; wr(s); }
        }).catch(function () {});
        return;
      }
      if (++giri < 40) setTimeout(prova, 250);   // ~10 s, poi niente conferma → il plugin ripristina la precedente
    })();
    try {
      P.addListener('updateFailed', function (ev) { var s = rd(); s.scaricata = null; s.ripristino = { versione: ev && ev.bundle && ev.bundle.version, quando: Date.now() }; wr(s); });
    } catch (e) {}
    /* controllo automatico silenzioso: al massimo una volta al giorno, solo se c'è un indirizzo */
    setTimeout(function () { var s = rd(); if ((s.url || MANIFEST_PREDEFINITO) && (!s.ultimoControllo || Date.now() - s.ultimoControllo > 864e5)) controlla({ silenzioso: true }); }, 20000);
  }
  if (document.readyState === 'complete') pronta(); else W.addEventListener('load', function () { setTimeout(pronta, 300); });

  W.CNAgg = { dimenticaRipristino: function () { var s = rd(); if (s.ripristino) { s.ripristino = null; wr(s); } }, controlla: controlla, info: info, stato: rd, impostaUrl: impostaUrl, _verificaFirma: verificaFirma, _confronta: confronta };
})(window);
