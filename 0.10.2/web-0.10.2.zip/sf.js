// Versione moderna: integrazione dell'analisi Stockfish precalcolata (sfdata.js).
// Livello di difficoltà, soluzione verificata, tentativi, conteggio aiuti e valutazioni già pronte per Analizza/barra.
(function(){
  'use strict';
  var A = window.__app, D = window.SFDATA;
  if (!A || !A.MOD || !D) return;
  var KEY = 'chessnodeplay-sf-v1';
  var st = load();
  function load(){ try { var x = JSON.parse(localStorage.getItem(KEY) || '{}'); return {h:x.h || {}, t:x.t || {}}; } catch(e){ return {h:{}, t:{}}; } }
  function save(){ try { localStorage.setItem(KEY, JSON.stringify(st)); } catch(e){} }
  function $(id){ return document.getElementById(id); }
  function info(n){ return D.ex[n] || null; }

  // ---------- E: valutazioni precalcolate ----------
  function pkey(fen){ return String(fen).split(' ').slice(0, 3).join(' '); }
  function toLines(p){
    var out = [];
    for (var i = 2; i < p.length; i++) out.push({depth:p[0], type:p[i][0] === 'm' ? 'mate' : 'cp', v:p[i][1], pv:String(p[i][2]).split(' '), pre:true});
    return out;
  }
  var E = A.Engine, orig = E.analyse;
  E.analyse = function(fen, opts){
    opts = opts || {};
    var p = D.pre[pkey(fen)];
    if (!p) return orig.call(E, fen, opts);
    var lines = toLines(p), mp = opts.multipv || 1;
    if (p[1]){ // analisi completa: niente motore
      var ls = lines.slice(0, mp);
      if (opts.onInfo && ls[0]) { try { opts.onInfo(ls[0], fen); } catch(e){} }
      return Promise.resolve({best:ls[0] ? ls[0].pv[0] : null, lines:ls, fen:fen, pre:true});
    }
    // solo la valutazione: si mostra subito, poi il motore completa le linee
    if (opts.onInfo && lines[0]) { try { opts.onInfo(lines[0], fen); } catch(e){} }
    var o2 = {}; for (var k in opts) o2[k] = opts[k];
    if (opts.onInfo) o2.onInfo = function(l, f){ if (l && l.depth >= 12) opts.onInfo(l, f); };
    return orig.call(E, fen, o2).then(function(r){ return r && r.lines && r.lines.length ? r : {best:lines[0] ? lines[0].pv[0] : null, lines:lines.slice(0, mp), fen:fen, pre:true}; },
      function(){ return {best:lines[0] ? lines[0].pv[0] : null, lines:lines.slice(0, mp), fen:fen, pre:true}; });
  };

  // ---------- D/G: livello, verificata, tentativi ----------
  var cur = null, counted = false;
  function decorate(n){
    var x = info(n), t = $('exTitle'); if (!t) return;
    var pill = $('exLevel');
    if (!x){ if (pill) pill.remove(); if ($('fLevel')) $('fLevel').remove(); return; }
    if (!pill){ pill = document.createElement('span'); pill.id = 'exLevel'; t.insertAdjacentElement('afterend', pill); }
    pill.className = 'sfpill l' + x.d; pill.title = 'Difficoltà (dal punteggio Lichess del puzzle)';
    pill.innerHTML = '<i aria-hidden="true"></i>' + D.nomi[x.d];
    // Concentrazione (telefono): la stessa pillola sulla riga del capitolo, sotto «Esercizio N»
    var ft = $('fSub');
    if (ft){
      var fp = $('fLevel');
      if (!fp){
        var row = document.createElement('div'); row.className = 'sfrow';
        ft.parentNode.insertBefore(row, ft); row.appendChild(ft);
        fp = document.createElement('span'); fp.id = 'fLevel'; row.appendChild(fp);
      }
      fp.className = 'sfpill sm l' + x.d; fp.title = 'Difficoltà: ' + D.nomi[x.d]; fp.setAttribute('aria-label', fp.title); fp.innerHTML = pill.innerHTML;
    }
    var b = $('badges'); if (!b) return;
    var old = b.querySelectorAll('.sfver,.sftry'); Array.prototype.forEach.call(old, function(o){ o.remove(); });
    if (x.k !== 'n'){
      var w = b.querySelector('.badge.warn'); if (w) w.remove();
      b.insertAdjacentHTML('beforeend', '<span class="badge sfver" title="Puzzle Lichess: soluzione verificata dal motore">' + mi('cpu') + 'Verificata</span>');
    }
    tries(n);
  }
  function mi(k){ var L = window.LUCIDE || {}; return L[k] ? '<svg class="lu mi" viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' + L[k] + '</svg>' : ''; }
  function tries(n){
    var b = $('badges'); if (!b) return;
    var o = b.querySelector('.sftry'), c = st.t[n] || 0;
    if (!c){ if (o) o.remove(); return; }
    var h = st.h[n] || 0;
    var txt = mi('rotate-ccw') + c + (c === 1 ? ' tentativo' : ' tentativi') + (h ? ' · ' + h + (h === 1 ? ' aiuto' : ' aiuti') : '');
    if (o) o.innerHTML = txt; else b.insertAdjacentHTML('beforeend', '<span class="badge sftry" title="Quante volte hai provato questo esercizio">' + txt + '</span>');
  }
  function attempt(){
    if (cur == null || counted) return;
    counted = true; st.t[cur] = (st.t[cur] || 0) + 1; save(); tries(cur);
  }
  document.addEventListener('cnp:load', function(ev){ cur = ev.detail.n; counted = false; decorate(cur); });
  ['try', 'show', 'solved', 'gentle'].forEach(function(k){ document.addEventListener('cnp:' + k, attempt); });
  document.addEventListener('cnp:hint', function(ev){
    var n = ev.detail.n; attempt();
    st.h[n] = (st.h[n] || 0) + 1; save(); tries(n);
  });
  document.addEventListener('cnp:reset', function(){ st = {h:{}, t:{}}; save(); if (cur != null) decorate(cur); });

  // ---------- statistiche: aiuti usati ----------
  function summaryHtml(){
    var ks = Object.keys(st.h).filter(function(n){ return st.h[n] > 0; });
    var tot = ks.reduce(function(a, n){ return a + st.h[n]; }, 0);
    var tt = Object.keys(st.t).reduce(function(a, n){ return a + st.t[n]; }, 0);
    ks.sort(function(a, b){ return st.h[b] - st.h[a] || a - b; });
    var h = '<section class="scard sfaiuti"><h3>💡 Aiuti usati</h3><div class="kpis">' +
      '<div class="kpi"><b id="sfHints">' + tot + '</b><span>aiuti in tutto</span></div>' +
      '<div class="kpi"><b id="sfHintEx">' + ks.length + '</b><span>esercizi con aiuti</span></div>' +
      '<div class="kpi"><b id="sfTries">' + tt + '</b><span>tentativi</span></div></div>';
    h += ks.length ? '<p class="lookhelp">Esercizi in cui hai chiesto più aiuti (ogni passo dell\'Aiuto conta uno):</p><ol class="weaklist sfhl">' +
      ks.slice(0, 10).map(function(n){ var x = info(n); return '<li><a href="#" data-n="' + n + '">Esercizio ' + n + '</a> <span class="muted">· ' + st.h[n] + (st.h[n] === 1 ? ' aiuto' : ' aiuti') + ' · ' + (st.t[n] || 0) + ' tentativi' + (x ? ' · ' + D.nomi[x.d] : '') + '</span></li>'; }).join('') + '</ol>'
      : '<p class="lookhelp">Nessun aiuto usato finora.</p>';
    return h + '</section>';
  }
  window.SF = {summaryHtml:summaryHtml, data:function(){ return st; }, level:function(n){ var x = info(n); return x ? x.d : 0; }};
  if (A.state && A.state.ex) { cur = A.state.ex.n; decorate(cur); }
})();
