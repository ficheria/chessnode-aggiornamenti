/* Chess Node · anteprima 12-11: analisi a due schermate (Riepilogo + Revisione).
   Solo sulla copia da_integrare/analisi_due_schermate_12-11/web/. Niente in app/web.
   Sistema come la revisione di Chess.com, grafica nostra. Riusa: grafico v3b, icone mosse, riepilogo,
   «Vedi la variante» (qui «Mossa migliore», freccia V5), bottoni verdi 3D, transizione della pila,
   formula CNPrecisione.P per giudicare Riprova. «NO REGALARE NIENTE»: se prima si è usata
   Mossa migliore, Riprova non conta come trovata da soli. Niente «Prossimo errore», niente punteggio stimato. */
(function(){
  'use strict';
  var SCH = null;                 // 'a' | 'b' | null (fuori dalla partita commentata)
  var veloceT = null, veloceOn = false;
  var riprovaDi = -1;             // indice della mossa sbagliata che si sta riprovando (−1 = no)
  var riprovaTok = 0;
  var riprovaTesto = null;        // testo nel fumetto durante Riprova (invito o verdetto)
  var aiuto = {};                 // aiuto[i] = si è già vista la Mossa migliore di quella semimossa
  var trans = false;
  var DEBOUNCE = 500;             // ms: fumetto e pallino tornano quando si smette di andare avanti/indietro
  var SOGLIA_BUONA = 7;           // perdita ≤ 5+2 (stesso margine dell'analisi) = almeno Buona
  var MSG = {
    cerca:'Tocca la scacchiera e prova una mossa migliore di quella giocata.',
    aspetta:'Valuto la tua mossa…',
    bravo:'Bravo: è una mossa buona. L\'hai trovata da solo.',
    bravoNome:function(n){ return 'Bravo: è una ' + n + '. L\'hai trovata da solo.'; },
    aiuto:'È una mossa buona, ma l\'hai vista dopo «Mossa migliore»: non conta come trovata da solo.',
    no:'Non è ancora la mossa giusta. Puoi riprovare o vedere la mossa migliore.',
    noMotore:'Non sono riuscito a valutare la mossa. Riprova, oppure guarda la mossa migliore.'
  };

  function A(){ return window.__app || {}; }
  function root(){ return window.CNAnalisi && CNAnalisi.root(); }
  function I(){ return window.CNAnalisi && CNAnalisi._int; }
  function mot(){
    var b = document.body.classList, h = document.documentElement.classList;
    if (b.contains('anim-off') || h.contains('cn-mot-spente')) return 'spente';
    if (b.contains('anim-reduced') || h.contains('cn-mot-ridotte')) return 'ridotte';
    try { if (matchMedia('(prefers-reduced-motion: reduce)').matches) return 'ridotte'; } catch(e){}
    return 'attive';
  }
  function $(sel, r){ return (r || root()).querySelector(sel); }
  function esc(s){ return String(s == null ? '' : s).replace(/[&<>"']/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }
  function stato(){ try { return window.CNAnalisi.state(); } catch(e){ return null; } }
  function rec(){ try { var s = window.CNAnalisiPartita.stato(); return s && s.rec && s.rec.fatto ? s.rec : null; } catch(e){ return null; } }
  function lab(){ try { var c = window.CNAnalisiPartitaUI._commenti(); return c && c.lab; } catch(e){ return null; } }
  function metaUI(){ try { return window.CNAnalisiPartitaUI.__meta || window.__cngMeta || null; } catch(e){ return null; } }
  function it(s){ var i = I(); return i && i.it ? i.it(s) : s; }
  function nomeCl(cl){ try { return window.CNAnalisiPartitaUI.nome(cl); } catch(e){ return cl; } }
  function badge(cl){
    if (!cl) return '';
    var v = window.CNIconeMosse && CNIconeMosse.svg(cl);
    return v ? '<i class="apa-ic apa-' + cl + '">' + v + '</i>' : '';
  }

  /* ---------- montaggio: CTA, riga mosse, comandi (una volta) ---------- */
  function monta(r){
    if (!r || r.__revMonta) return;
    r.__revMonta = 1;
    var cta = document.createElement('div');
    cta.className = 'anp-rev-cta';
    cta.innerHTML = '<button type="button" class="anp-btn anp-pri anp-rev-inizia">Inizia revisione</button>';
    r.appendChild(cta);
    cta.querySelector('button').addEventListener('click', function(){ inizia(); });

    var riga = document.createElement('div');
    riga.className = 'anp-rev-riga';
    riga.setAttribute('role', 'list');
    riga.setAttribute('aria-label', 'Mosse della partita');
    var scroll = r.querySelector('.anp-scroll'), bw = r.querySelector('.anp-bw');
    if (scroll && bw && bw.parentNode === scroll) scroll.insertBefore(riga, bw.nextSibling);
    else r.appendChild(riga);
    riga.addEventListener('click', function(e){
      var b = e.target.closest('[data-ply]'); if (!b) return;
      esciRiprova(true);
      window.CNAnalisi.go(+b.dataset.ply);
      navVeloce();
    });

    var msg = document.createElement('p');
    msg.className = 'anp-rev-msg';
    msg.setAttribute('role', 'status');
    r.appendChild(msg);

    var err = document.createElement('div');
    err.className = 'anp-rev-err';
    err.innerHTML =
      '<button type="button" class="anp-btn anp-rev-riprova">Riprova</button>' +
      '<button type="button" class="anp-btn anp-rev-meglio">Mossa migliore</button>';
    r.appendChild(err);
    err.querySelector('.anp-rev-riprova').addEventListener('click', onRiprova);
    err.querySelector('.anp-rev-meglio').addEventListener('click', onMeglio);

    var ctl = document.createElement('nav');
    ctl.className = 'anp-rev-ctl';
    ctl.setAttribute('aria-label', 'Revisione della partita');
    ctl.innerHTML =
      '<button type="button" class="anp-btn anp-rev-indietro">Indietro</button>' +
      '<button type="button" class="anp-btn anp-pri anp-rev-avanti">Avanti</button>';
    r.appendChild(ctl);
    ctl.querySelector('.anp-rev-indietro').addEventListener('click', function(){ passo('indietro'); });
    ctl.querySelector('.anp-rev-avanti').addEventListener('click', function(){ passo('avanti'); });

    if (!r.__revResize){ r.__revResize = 1; window.addEventListener('resize', function(){ if (SCH === 'b') misuraScacchiera(); }); }
    r.querySelector('.anp-close').addEventListener('click', function(e){
      if (SCH === 'b'){ e.preventDefault(); e.stopImmediatePropagation(); vaiA(); }
    }, true);
    r.addEventListener('click', function(e){
      if (SCH !== 'a') return;
      if (e.target.closest('.cnr')){ e.stopPropagation(); }             // tabella sempre aperta
      if (e.target.closest('.cng-t, .cng-bar')){ e.preventDefault(); e.stopImmediatePropagation(); }
    }, true);
  }

  function titolo(t){ var b = root() && $('.anp-tt b'); if (b) b.textContent = t; }

  /* ---------- ingresso / uscita ---------- */
  function avviaA(){
    var r = root(); if (!r || !r.classList.contains('anp-pm')) return;
    monta(r);
    aiuto = {}; riprovaDi = -1; fermaVeloce(true);
    applica('a', true);
    try { window.CNAnalisi.go(0); } catch(e){}
    // un attimo dopo: il riepilogo e il grafico sono stati disegnati
    setTimeout(function(){ if (SCH === 'a'){ pulisciFumettoA(); aggiorna(); } }, 40);
  }
  function esci(){
    fermaVeloce(true); esciRiprova(false);
    var r = root();
    if (r){
      r.classList.remove('anp-rev-a', 'anp-rev-b', 'anp-rev-veloce', 'anp-rev-err-on', 'anp-rev-msg-on', 'anp-rev-riprova');
      r.removeAttribute('data-schermo');
      titolo('Analisi');
    }
    SCH = null;
  }

  function applica(sch, subito){
    var r = root(); if (!r) return;
    SCH = sch;
    r.classList.toggle('anp-rev-a', sch === 'a');
    r.classList.toggle('anp-rev-b', sch === 'b');
    r.setAttribute('data-schermo', sch);
    titolo('Analisi');
    if (sch === 'a'){
      fermaVeloce(true); esciRiprova(false);
      pulisciFumettoA();
      r.classList.remove('anp-rev-err-on', 'anp-rev-msg-on', 'anp-rev-riprova');
      var g = r.querySelector('.cng'); if (g) g.classList.remove('chiuso');
    } else {
      var bub = $('.anp-bub');
      if (bub && !bub.style.maxHeight) { /* adattaFumetto della prova integrata si occupa dello spazio stretto */ }
    }
    aggiorna();
    if (window.CNGrafico && CNGrafico.adattaFumetto && sch === 'b'){
      try { CNGrafico.adattaFumetto(); } catch(e){}
    }
  }
  function pulisciFumettoA(){
    var bub = root() && $('.anp-bub');
    if (bub){ bub.style.maxHeight = ''; bub.classList.remove('anp-bub-piu'); }
  }

  /* ---------- transizione (stessa regola di home_app.js) ---------- */
  function vaiA(){ if (SCH === 'a' || trans) return; anima(false, function(){ try { window.CNAnalisi.go(0); } catch(e){} applica('a'); }); }
  function vaiB(ply){
    if (trans) return;
    // 14-11: la mossa si imposta DOPO che il riepilogo è sfumato (il ridisegno è pesante: prima bloccava la dissolvenza)
    anima(true, function(){ if (ply != null) try { window.CNAnalisi.go(ply); } catch(e){} applica('b'); });
  }
  function inizia(){
    var st = stato(), n = st && st.sans ? st.sans.length : 0;
    vaiB(n ? 1 : 0);
  }
  function dalGrafico(){ if (SCH === 'a') vaiB(); }

  /* 14-11 (Kiko t1933u: «manca la dissolvenza e c'è un incastro grafico, immagini strane»). Prima si clonava tutta la pagina
     (cloneNode) come «foto» della schermata vecchia: il clone perdeva l'id #anPage, quindi TUTTE le regole CSS della pagina
     (avatar enorme, pezzi in colonna, zona fumetto della scacchiera libera visibile, grafici vuoti) e stava SOPRA (z-index 91)
     senza animazione, poi spariva di colpo. Ora niente clone: il contenuto della pagina sfuma via (110 ms), si cambia schermata
     e il nuovo contenuto entra (Attive: dissolvenza + 28 px da destra in 220 ms, Indietro al contrario; Ridotte: solo
     dissolvenza 150 ms; Spente: subito). Intestazione e sfondo restano fermi: niente sotto che si vede, niente sovrapposizioni. */
  function anima(avanti, fn){
    var r = root(), m = mot();
    if (!r || m === 'spente' || SCH == null){ fn(); return; }
    trans = true;
    var fade = m === 'ridotte', fatto = false;
    r.classList.remove('anp-rev-in-fwd', 'anp-rev-in-back', 'anp-rev-in-fade');
    r.classList.add('anp-rev-uscita');
    setTimeout(function(){
      try { fn(); } catch(e){ console.warn(e); }
      r.classList.remove('anp-rev-uscita');
      var cl = fade ? 'anp-rev-in-fade' : (avanti ? 'anp-rev-in-fwd' : 'anp-rev-in-back');
      void r.offsetWidth;   // riparte l'animazione anche se la classe c'era già
      r.classList.add(cl);
      setTimeout(function(){ r.classList.remove(cl); trans = false; fatto = true; }, (fade ? 150 : 220) + 30);
    }, fade ? 90 : 110);
    // rete di sicurezza: mai bloccati in transizione
    setTimeout(function(){ if (!fatto){ r.classList.remove('anp-rev-uscita', 'anp-rev-in-fwd', 'anp-rev-in-back', 'anp-rev-in-fade'); trans = false; } }, 900);
  }

  /* ---------- aggiornamento schermata B ---------- */
  function aggiorna(){
    var r = root(); if (!r || !SCH) return;
    if (SCH === 'b'){
      try { disegnaRiga(); } catch(e){ console.warn(e); }
      try { disegnaBadge(); } catch(e){ console.warn(e); }
      try { disegnaErr(); } catch(e){ console.warn(e); }
      var st = stato() || {};
      var prev = r.querySelector('.anp-rev-indietro');
      var next = r.querySelector('.anp-rev-avanti');
      if (prev) prev.disabled = !st.ply;
      if (next) next.disabled = !st.sans || st.ply >= st.sans.length || st.inVariante;
      try { misuraScacchiera(); } catch(e){ console.warn(e); }
      if (riprovaDi >= 0) try { bollaRiprova(); } catch(e){ console.warn(e); }
    } else {
      // forza la tabella aperta (il click sul .cnr è disattivato via CSS cursor, ma la classe serve al markup)
      var cnr = r.querySelector('.cnr');
      if (cnr && !cnr.classList.contains('aperto')) cnr.classList.add('aperto');
    }
  }

  function disegnaRiga(){
    var box = root() && $('.anp-rev-riga'); if (!box) return;
    var st = stato(); if (!st || !st.sans){ box.innerHTML = ''; return; }
    var L = lab() || [];
    var h = '', i;
    for (i = 0; i < st.sans.length; i++){
      var info = numSan(st, i);
      var cl = L[i] || '';
      var err = /^(imprecisione|errore|svarione)$/.test(cl);
      var on = st.ply === i + 1;
      h += '<button type="button" class="anp-rev-m' + (on ? ' on' : '') + '" data-ply="' + (i + 1) + '" role="listitem"' +
        (on ? ' aria-current="true"' : '') + '>' +
        (info.num ? '<span class="anp-rev-n">' + info.num + '</span>' : '') +
        esc(info.san) +
        (err ? '<i class="anp-rev-dot apa-' + cl + '" aria-label="' + esc(nomeCl(cl)) + '"></i>' : '') +
        '</button>';
    }
    box.innerHTML = h;
    var cur = box.querySelector('.anp-rev-m.on');
    if (cur){
      try { cur.scrollIntoView({inline:'center', block:'nearest', behavior:'auto'}); }
      catch(e){ try { cur.scrollIntoView(); } catch(e2){} }
    }
  }
  function numSan(st, i){
    var fen = null;
    try {
      var T = I().T(), m = window.CNAnalisi._int, linea = m.main();
      var n = linea[i];
      var p = n && n.padre && n.padre.fen ? n.padre.fen.split(' ') : null;
      var num = p ? ((+p[5] || 1) + (p[1] === 'w' ? '.' : '')) : '';
      if (!p){ num = (Math.floor(i / 2) + 1) + (i % 2 ? '' : '.'); if (i % 2) num = ''; }
      else if (p[1] !== 'w') num = '';
      return {num:num, san:it(st.sans[i])};
    } catch(e){
      return {num:(i % 2 === 0 ? (Math.floor(i / 2) + 1) + '.' : ''), san:it(st.sans[i])};
    }
  }

  function disegnaBadge(){
    var r = root(); if (!r) return;
    var old = r.querySelectorAll('.anp-rev-badge');
    for (var i = 0; i < old.length; i++) old[i].parentNode.removeChild(old[i]);
    if (SCH !== 'b' || veloceOn || riprovaDi >= 0) return;
    var st = stato(); if (!st || st.inVariante || !st.ply) return;
    var L = lab(); if (!L) return;
    var cl = L[st.ply - 1]; if (!cl || cl === 'nogiud') return;
    var ic = badge(cl); if (!ic) return;
    var to = casaArrivo(st.ply - 1); if (!to) return;
    var sq = r.querySelector('.anp-sq[data-sq="' + to + '"]'); if (!sq) return;
    var el = document.createElement('span');
    el.className = 'anp-rev-badge';
    el.setAttribute('aria-hidden', 'true');
    el.setAttribute('data-sq', to);
    el.setAttribute('data-cl', cl);
    el.innerHTML = ic;
    sq.appendChild(el);
  }
  function casaArrivo(i){
    try {
      var s = window.CNAnalisiPartita.stato();
      var u = s && s.p && s.p.ucis && s.p.ucis[i];
      if (u) return u.slice(2, 4);
    } catch(e){}
    var st = stato();
    try {
      var c = new Chess(st.startFen);
      var mv;
      for (var k = 0; k <= i; k++) mv = c.move(st.sans[k]);
      return mv && mv.to;
    } catch(e2){ return null; }
  }

  function eErrore(i){
    var L = lab(); if (!L || i < 0) return false;
    return /^(imprecisione|errore|svarione)$/.test(L[i] || '');
  }
  function puoMeglio(){
    try { return !!(window.CNAnalisiPartitaUI && CNAnalisiPartitaUI.puoVariante()); } catch(e){ return false; }
  }
  function disegnaErr(){
    var r = root(); if (!r) return;
    var st = stato() || {};
    var i = (st.ply || 0) - 1;
    var inVar = !!st.inVariante;
    var show = SCH === 'b' && !veloceOn && (riprovaDi >= 0 || inVar || eErrore(i));
    r.classList.toggle('anp-rev-err-on', !!show);
    var bM = r.querySelector('.anp-rev-meglio');
    var bR = r.querySelector('.anp-rev-riprova');
    if (bM){
      if (inVar && riprovaDi < 0){ bM.textContent = 'Torna alla partita'; bM.disabled = false; }
      else { bM.textContent = 'Mossa migliore'; bM.disabled = inVar ? true : !puoMeglio() && riprovaDi < 0; }
    }
    if (bR){
      bR.disabled = inVar && riprovaDi < 0;
      bR.textContent = (riprovaDi >= 0 && inVar) ? 'Riprova ancora' : 'Riprova';
    }
  }

  /* ---------- navigazione in Revisione ---------- */
  function passo(op){
    if (SCH !== 'b') return;
    esciRiprova(true);
    window.CNAnalisi.nav(op);
    navVeloce();
  }
  function navVeloce(){
    if (SCH !== 'b') return;
    var r = root(); if (!r) return;
    r.classList.add('anp-rev-veloce');
    veloceOn = true;
    r.setAttribute('data-veloce', '1');
    // togli subito il pallino (non aspettare il debounce)
    var old = r.querySelectorAll('.anp-rev-badge');
    for (var i = 0; i < old.length; i++) old[i].parentNode.removeChild(old[i]);
    if (veloceT) clearTimeout(veloceT);
    veloceT = setTimeout(function(){ fermaVeloce(false); }, DEBOUNCE);
    disegnaRiga();
    disegnaErr();
  }
  function fermaVeloce(silenzio){
    if (veloceT){ clearTimeout(veloceT); veloceT = null; }
    veloceOn = false;
    var r = root();
    if (r){ r.classList.remove('anp-rev-veloce'); r.removeAttribute('data-veloce'); }
    if (!silenzio && SCH === 'b'){ disegnaBadge(); disegnaErr(); disegnaRiga(); }
  }

  /* ---------- Mossa migliore = «Vedi la variante» già esistente (freccia V5) ---------- */
  function onMeglio(){
    if (SCH !== 'b') return;
    var st = stato() || {};
    var btn = root() && $('.anp-rev-meglio');
    if (st.inVariante && riprovaDi < 0){
      window.CNAnalisi.torna();
      aggiorna();
      return;
    }
    var i = (st.ply || 0) - 1;
    if (riprovaDi >= 0){
      var idx = riprovaDi;
      esciRiprova(true);
      window.CNAnalisi.go(idx + 1);
      i = idx;
    }
    if (i >= 0) aiuto[i] = 1;
    if (window.CNAnalisiPartitaUI && CNAnalisiPartitaUI.vediVariante) CNAnalisiPartitaUI.vediVariante();
    setMsg(null);
    aggiorna();
  }
  function riprovaPly(){ return riprovaDi >= 0 ? riprovaDi + 1 : ((stato() || {}).ply || 0); }

  /* Layout schermata B = stesso calcolo di esercizio_v6.js fit() (anteprima 08b, 31/10).
     Costanti copiate di là, non inventate: need 104/112, CMIN 84/100, CMAX 156, tetto 560,
     v6small se H < 720. Lo spazio in più va SOPRA l'istruttore (--v6off), così la scacchiera
     scende per il pollice; sotto restano solo riga mosse e tasti. La scacchiera non si allunga. */
  function visH(el){
    if (!el || el.hidden) return 0;
    var cs = getComputedStyle(el);
    if (cs.display === 'none' || cs.visibility === 'hidden') return 0;
    return el.getBoundingClientRect().height;
  }
  function misuraScacchiera(){
    var r = root(); if (!r || SCH !== 'b') return;
    var bw = r.querySelector('.anp-bw'); if (!bw) return;
    var W = r.clientWidth, H = r.clientHeight || window.innerHeight;
    var small = H < 720;
    var topEl = r.querySelector('.anp-top');
    var topH = (topEl && topEl.offsetHeight) || 56;
    var evH = visH(r.querySelector('.anp-evr'));
    /* In Revisione il banner della variante sta DENTRO la zona istruttore (stessa --v6ch e --v6off).
       Non si somma come altezza extra, altrimenti la scacchiera salta. La zona è sempre riservata. */
    var altH = 0;
    var need = small ? 104 : 112;          // 08b: riga mosse + una fila di pulsanti
    var extra = 0;                         // seconda fila (Riprova / Mossa migliore / messaggio), misurata
    if (r.classList.contains('anp-rev-err-on')) extra += visH(r.querySelector('.anp-rev-err'));
    if (r.classList.contains('anp-rev-msg-on')) extra += visH(r.querySelector('.anp-rev-msg'));
    need += extra;
    var CMIN = small ? 84 : 100, CMAX = 156;
    var X = window.CNAllinea && window.CNAllinea.exTop ? window.CNAllinea.exTop(W, H) : null;
    var coachH, bh, off;
    if (X){
      /* 14-11 (Kiko): la scacchiera parte alla STESSA y (e con lo stesso lato) dell'esercizio. Sotto ci sono riga mosse e tasti
         (in fondo, come la barra dell'esercizio); lo spazio della barra dell'esercizio accoglie anche Riprova/messaggio
         senza far saltare la scacchiera. Solo se non basta, la scacchiera sale di quel tanto. */
      bh = X.bh;
      var sotto = H - X.top - bh, serve = need + 2;   // need = riga mosse + tasti (+ seconda fila se c'è)
      var su = Math.max(0, Math.ceil(serve - sotto));
      var y = X.top - su;
      coachH = Math.max(CMIN, Math.min(CMAX, y - topH - altH - evH));
      off = Math.max(0, Math.floor(y - topH - altH - evH - coachH));
      if (y - topH - altH - evH < CMIN){ coachH = Math.max(60, y - topH - altH - evH); off = 0; }
    } else {
      var freeH = H - topH - altH - evH - 2 - need - Math.min(W, 560);
      coachH = Math.max(CMIN, Math.min(CMAX, freeH));
      var byW = W, byH = H - topH - coachH - altH - evH - 2 - need;
      var size = Math.max(200, Math.min(byW, byH, 560));
      bh = Math.floor(size / 8 * 100) / 100 * 8;
      off = Math.max(0, Math.floor(H - topH - coachH - altH - evH - 2 - bh - need));
    }
    r.style.setProperty('--v6ch', coachH + 'px');
    r.style.setProperty('--v6off', off + 'px');
    bw.style.setProperty('--bw', bh + 'px');
  }

  /* Durante Riprova il fumetto deve nominare l'ERRORE da migliorare, non la mossa precedente
     (go(i) mostra la posizione prima, e bolla() commenterebbe quella, es. «7. Ab3 · Migliore»). */
  function bollaRiprova(){
    if (riprovaDi < 0 || SCH !== 'b') return;
    var r = root(), b = r && r.querySelector('.anp-bub'); if (!b) return;
    var i = riprovaDi, L = lab() || [], cl = L[i] || '';
    var st = stato() || {}, san = it((st.sans || [])[i] || '');
    var info = numSan(st, i), nome = nomeCl(cl);
    var h = '<p class="anp-bh">' + badge(cl) + '<span>' + esc(info.num ? info.num + ' ' : '') + '<span class="anp-san">' + esc(String(san).replace(/O-O-O/g, 'O\u2011O\u2011O').replace(/O-O/g, 'O\u2011O')) + '</span>' + (nome ? ' · ' + esc(nome) : '') + '</span></p>';
    h += '<p>' + (riprovaTesto || MSG.cerca) + '</p>';
    b.innerHTML = h;
    b.style.maxHeight = '';
    b.classList.remove('anp-bub-piu');
  }

  /* ---------- Riprova (stile esercizio, giudizio con CNPrecisione.P) ---------- */
  function onRiprova(){
    if (SCH !== 'b') return;
    var st = stato() || {};
    var i = riprovaDi >= 0 ? riprovaDi : (st.ply || 0) - 1;
    if (i < 0 || !eErrore(i)) return;
    if (st.inVariante) window.CNAnalisi.torna();
    riprovaDi = i;
    riprovaTok++;
    riprovaTesto = MSG.cerca;
    var r = root();
    if (r) r.classList.add('anp-rev-riprova');
    window.CNAnalisi.go(i);          // posizione PRIMA della mossa sbagliata (tocca a chi ha sbagliato)
    setMsg(null);                    // l'invito sta nel fumetto, accanto al nome dell'errore
    aggiorna();
  }
  function esciRiprova(tornaPartita){
    var era = riprovaDi;
    riprovaDi = -1;
    riprovaTok++;
    riprovaTesto = null;
    var r = root();
    if (r) r.classList.remove('anp-rev-riprova');
    setMsg(null);
    if (tornaPartita && era >= 0){
      var st = stato() || {};
      if (st.inVariante) window.CNAnalisi.torna();
    }
  }
  function setMsg(t){
    var r = root(); if (!r) return;
    var p = r.querySelector('.anp-rev-msg');
    if (riprovaDi >= 0 && t && t !== MSG.cerca) riprovaTesto = t;
    if (!t || t === MSG.cerca){ r.classList.remove('anp-rev-msg-on'); if (p) p.textContent = ''; if (riprovaDi >= 0) bollaRiprova(); return; }
    p.innerHTML = t;
    r.classList.add('anp-rev-msg-on');
    if (riprovaDi >= 0) bollaRiprova();
  }

  function dopoMossaUtente(m, nodo){
    if (riprovaDi < 0 || SCH !== 'b' || !nodo) return;
    var i = riprovaDi, tok = ++riprovaTok;
    var uci = (m.from + m.to + (m.promotion || '')).toLowerCase();
    var recX = rec(), labI = recX && recX.lab && recX.lab[i];
    var best = labI && labI.best;
    setMsg(MSG.aspetta);
    // 1) mossa del motore: giudizio immediato, senza nuova ricerca
    if (best && uci === String(best).toLowerCase()){
      verdetto(i, {loss:0, cl:'migliore', tok:tok});
      return;
    }
    valuta(i, nodo.fen, tok);
  }
  function cpBianco(fen, line){
    if (!line) return null;
    var side = String(fen).split(' ')[1] === 'w' ? 1 : -1;   // il punteggio del motore è di chi deve muovere
    if (line.mate != null) return (line.mate > 0 ? 1 : -1) * side * (window.CNPrecisione ? CNPrecisione.CLIP : 1000);
    if (line.type === 'mate') return (line.v > 0 ? 1 : -1) * side * (window.CNPrecisione ? CNPrecisione.CLIP : 1000);
    var cp = line.cp != null ? line.cp : line.v;
    return cp * side;
  }
  function valuta(i, fenDopo, tok){
    var recX = rec(); if (!recX || !recX.E || !recX.E[i]){ if (tok === riprovaTok) setMsg(MSG.noMotore); return; }
    var p = null;
    try { p = window.CNAnalisiPartita.stato().p; } catch(e){}
    var fenPrima = p && p.fens ? p.fens[i] : null;
    var side = fenPrima && fenPrima.split(' ')[1] === 'w' ? 1 : -1;
    var e0 = recX.E[i];
    var cpPrima = e0.mate != null ? (e0.mate > 0 ? side : -side) * (CNPrecisione.CLIP || 1000) : (e0.cp * side);
    // e0.cp è dal punto di vista di chi muove (come evalAt): per il Bianco serve il segno già applicato sopra? 
    // In evalAt: v = e.cp * w, con w = 1 se muove il Bianco. Quindi e.cp è di chi muove. cpBianco(fenPrima, {cp:e0.cp}) = e0.cp * side, e side è +1 se Bianco: cpW = e0.cp * side. Yes.
    var cpW0 = (e0.mate != null)
      ? ((e0.mate > 0 ? 1 : -1) * side * (window.CNPrecisione.CLIP || 1000))
      : (e0.cp * side);

    function fine(cpW1){
      if (tok !== riprovaTok) return;
      var P = window.CNPrecisione && CNPrecisione.P ? CNPrecisione.P : function(cp){ return 50; };
      var perdita = Math.max(0, P(side * cpW0) - P(side * cpW1));
      // side * cpW = valutazione dal punto di vista di chi muove (Bianco: +cpW, Nero: −cpW). Corretto: side è +1/−1, cpW è del Bianco, side*cpW è di chi muove.
      var cl = perdita > 22 ? 'svarione' : perdita > 12 ? 'errore' : perdita > SOGLIA_BUONA ? 'imprecisione' : (perdita <= 2 ? 'ottima' : 'buona');
      if (perdita === 0) cl = 'migliore';
      verdetto(i, {loss:perdita, cl:cl, tok:tok});
    }

    var Eng = A().Engine;
    if (!Eng || !Eng.analyse){ setMsg(MSG.noMotore); return; }
    try { Eng.stop(); } catch(e){}
    Eng.analyse(fenDopo, {movetime:900, depth:16, multipv:1}).then(function(res){
      if (tok !== riprovaTok) return;
      var line = res && res.lines && res.lines[0];
      if (!line){ setMsg(MSG.noMotore); return; }
      var cpW1 = cpBianco(fenDopo, line);
      if (cpW1 == null){ setMsg(MSG.noMotore); return; }
      fine(cpW1);
      try { if (window.CNAnalisi.live) window.CNAnalisi.live(); } catch(e){}
    }, function(){ if (tok === riprovaTok) setMsg(MSG.noMotore); });
  }
  function verdetto(i, o){
    if (o.tok !== riprovaTok) return;
    var ok = o.loss <= SOGLIA_BUONA;
    var conAiuto = !!aiuto[i];
    if (ok && !conAiuto){
      var n = nomeCl(o.cl);
      setMsg('<b>' + (o.cl === 'migliore' || o.cl === 'ottima' || o.cl === 'buona' ? MSG.bravoNome(n.toLowerCase()) : MSG.bravo) + '</b>');
    } else if (ok && conAiuto){
      setMsg('<b>' + MSG.aiuto + '</b>');
    } else {
      setMsg(MSG.no);
    }
    aggiorna();
  }

  /* ---------- ganci sulla pagina esistente (senza toccare il cuore se non serve) ---------- */
  function gancia(){
    if (!window.CNAnalisi || CNAnalisi.__revHook) return false;
    CNAnalisi.__revHook = 1;
    var _open = CNAnalisi.open, _close = CNAnalisi.close, _play = CNAnalisi.play;
    CNAnalisi.open = function(o){
      var r = _open.apply(this, arguments);
      if (r && o && o.partita) avviaA(); else esci();
      return r;
    };
    CNAnalisi.close = function(){ esci(); return _close.apply(this, arguments); };
    CNAnalisi.play = function(m, origine){
      var n = _play.apply(this, arguments);
      if (riprovaDi >= 0 && !origine) dopoMossaUtente(m, n);
      return n;
    };
    if (window.CNAnalisiPartitaUI && !CNAnalisiPartitaUI.__revHook){
      var _or = CNAnalisiPartitaUI.onRender;
      CNAnalisiPartitaUI.onRender = function(){
        var x = _or.apply(this, arguments);
        if (SCH) aggiorna();
        return x;
      };
      CNAnalisiPartitaUI.__revHook = 1;
    }
    return true;
  }

  function avvio(){
    if (gancia()) return;
    var n = 0, t = setInterval(function(){ if (gancia() || ++n > 80) clearInterval(t); }, 50);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', avvio);
  else avvio();

  window.CNAnalisiRevisione = {
    schermo:function(){ return SCH; },
    vaiA:vaiA, vaiB:vaiB, inizia:inizia, dalGrafico:dalGrafico,
    riprova:onRiprova, meglio:onMeglio,
    veloce:function(){ return veloceOn; },
    inRiprova:function(){ return riprovaDi; },
    misuraScacchiera:misuraScacchiera,
    DEBOUNCE:DEBOUNCE
  };
})();
