/* Chess Node · pannello laterale più pulito (solo interfaccia moderna)
   - il ripasso diventa un chip dentro la scheda dell'obiettivo
   - badge + serie in un'unica riga discreta
   - legenda dei colori chiusa dietro «Legenda colori» */
(function(){
  'use strict';
  if (!document.documentElement.classList.contains('moderna') && !document.body.classList.contains('moderna')) return;
  var $ = function(id){ return document.getElementById(id); };
  var L = window.LUCIDE || {};
  function mi(k){ return L[k] ? '<svg class="lu mi" viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' + L[k] + '</svg>' : ''; }

  // 1) un'unica scheda in alto: il chip del ripasso va dentro #pgBar
  function joinCard(){
    var pg = $('pgBar'), rb = $('reviewBar');
    if (pg && rb && rb.parentNode !== pg) pg.appendChild(rb);
  }

  // 2) riga dei dettagli: #badges + #streakBar insieme
  var meta = null;
  function joinMeta(){
    var b = $('badges'), sk = $('streakBar'); if (!b) return;
    if (!meta){ meta = document.createElement('div'); meta.className = 'pnmeta'; b.parentNode.insertBefore(meta, b); }
    if (b.parentNode !== meta) meta.appendChild(b);
    if (sk && sk.parentNode !== meta) meta.appendChild(sk);
  }
  var MAP = [
    [/risolto al primo colpo/i, 'target', 'Primo colpo'],
    [/^\W*risolto$/i, 'check', 'Risolto'],
    [/soluzione già vista/i, 'eye', 'Soluzione vista'],
    [/posizione da verificare/i, null, null],
    [/corretta in automatico/i, null, 'Corretta in automatico']
  ];
  function tidyBadges(){
    var b = $('badges'); if (!b) return;
    Array.prototype.forEach.call(b.querySelectorAll('.badge:not([data-pn])'), function(x){
      x.setAttribute('data-pn', '1');
      if (x.classList.contains('sfver') || x.classList.contains('sftry')){
        if (!x.querySelector('svg') && x.classList.contains('sfver')) x.innerHTML = mi('cpu') + 'Verificata';
        return;
      }
      var t = x.textContent.trim();
      for (var i = 0; i < MAP.length; i++) if (MAP[i][0].test(t)){
        if (MAP[i][2]) x.innerHTML = (MAP[i][1] ? mi(MAP[i][1]) : '') + MAP[i][2];
        break;
      }
    });
    var empty = !b.querySelector('.badge'), sk = $('streakBar');
    if (meta) meta.hidden = empty && (!sk || sk.hidden);
  }

  // 5) legenda colori: chiusa di base
  var legOpen = false;
  try { legOpen = sessionStorage.getItem('cnp-legenda') === '1'; } catch(e){}
  function wrapLegend(){
    var ex = $('explain'); if (!ex) return;
    var lg = ex.querySelector('.xlegend'); if (!lg || (lg.parentNode && lg.parentNode.classList.contains('xleg'))) return;
    var d = document.createElement('details'); d.className = 'xleg'; d.open = legOpen;
    d.innerHTML = '<summary>Legenda colori' + (L['chevron-down'] ? '<svg class="lu xlchev" viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + L['chevron-down'] + '</svg>' : ' ▾') + '</summary>';
    lg.parentNode.insertBefore(d, lg); d.appendChild(lg);
    d.addEventListener('toggle', function(){ legOpen = d.open; try { sessionStorage.setItem('cnp-legenda', legOpen ? '1' : '0'); } catch(e){} });
  }

  function all(){ joinCard(); joinMeta(); tidyBadges(); wrapLegend(); }
  function init(){
    all();
    var b = $('badges'); if (b) new MutationObserver(tidyBadges).observe(b, {childList:true});
    var sk = $('streakBar'); if (sk) new MutationObserver(tidyBadges).observe(sk, {attributes:true, attributeFilter:['hidden']});
    var ex = $('explain'); if (ex) new MutationObserver(wrapLegend).observe(ex, {childList:true});
    // la barra può essere spostata (mazzo della Concentrazione): il chip la segue perché è dentro
    var pnl = document.querySelector('.panel'); if (pnl) new MutationObserver(function(){ joinCard(); joinMeta(); }).observe(pnl, {childList:true});
    ['load', 'solved', 'show', 'mistake', 'reset', 'focus'].forEach(function(k){ document.addEventListener('cnp:' + k, function(){ setTimeout(all, 0); }); });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
  window.__pannello = {refresh: all};
})();
