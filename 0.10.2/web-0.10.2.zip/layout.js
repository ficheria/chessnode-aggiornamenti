/* Chess Node · disposizione moderna (solo index_moderna.html, caricato per ultimo)
   1. Materiale stile Lichess sopra e sotto la scacchiera durante l'analisi (pezzi in più e +N).
   2. Telefono/tablet in concentrazione: scacchiera a tutta larghezza, consegna sempre visibile,
      pannelli espandibili Istruttore / Spiegazione / Soluzione (si spostano i nodi veri, nessun doppione).
   3. Meno controlli: sotto la scacchiera Aiuto · Soluzione · Riprova · Analizza (+ ⋯ su telefono);
      il ⋯ apre un foglio stile iOS (Ruota, Disegno, Condividi, Ripasso errori…);
      la penna ha colori e gomma in un piccolo popover (computer) o in una fila sotto la scacchiera (telefono). */
(function(){
  'use strict';
  var A = window.__app; if (!A || !document.getElementById('board')) return;
  var root = document.documentElement;
  if (!root.classList.contains('moderna')) return;
  function $(id){ return document.getElementById(id); }
  function esc(s){ return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }
  var L = window.LUCIDE || {};
  function svg(n, s){ return L[n] ? '<svg class="lu" viewBox="0 0 24 24" width="' + (s || 20) + '" height="' + (s || 20) + '" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' + L[n] + '</svg>' : ''; }
  function el(tag, attrs, html){ var e = document.createElement(tag); for (var k in attrs) e.setAttribute(k, attrs[k]); if (html != null) e.innerHTML = html; return e; }
  var mqPhone = window.matchMedia('(max-width: 600px)');
  function phone(){ return mqPhone.matches; }
  function focusOn(){ return root.classList.contains('focus'); }
  // "compatto": telefono, oppure concentrazione (anche su tablet) -> fila con ⋯, niente barra verticale
  function compact(){ return phone() || focusOn(); }

  // ======================= 1. materiale =======================
  var board = $('board'), wrap = document.querySelector('.boardwrap');
  var stack = el('div', {'class':'bstack'});
  wrap.insertBefore(stack, board);
  var matTop = el('div', {id:'matTop', 'class':'matrow top', 'aria-live':'off'});
  var matBot = el('div', {id:'matBot', 'class':'matrow bot', 'aria-live':'off'});
  stack.appendChild(matTop); stack.appendChild(board); stack.appendChild(matBot);
  var VAL = {p:1, n:3, b:3, r:5, q:9};
  var ORDER = ['q', 'r', 'b', 'n', 'p'];
  var NAME = {p:'pedone', n:'cavallo', b:'alfiere', r:'torre', q:'donna'};
  function material(){
    var cnt = {w:{p:0, n:0, b:0, r:0, q:0}, b:{p:0, n:0, b:0, r:0, q:0}}, bd = A.game().board();
    for (var r = 0; r < 8; r++) for (var c = 0; c < 8; c++){ var p = bd[r][c]; if (p && p.type !== 'k') cnt[p.color][p.type]++; }
    // per ogni tipo, chi ne ha di più mostra (come catturati) i pezzi avversari che mancano all'altro
    var out = {w:[], b:[], score:0};
    ORDER.forEach(function(t){
      var d = cnt.w[t] - cnt.b[t];
      for (var i = 0; i < Math.abs(d); i++) (d > 0 ? out.w : out.b).push(t);
      out.score += d * VAL[t];
    });
    return out;
  }
  function rowHtml(color, m){
    var mine = m[color], opp = color === 'w' ? 'b' : 'w', h = '', prev = null;
    mine.forEach(function(t){
      h += '<img class="mp' + (prev && prev !== t ? ' gap' : '') + '" src="' + (A.psrc ? A.psrc(opp + t.toUpperCase()) : '') + '" alt="' + NAME[t] + '">';
      prev = t;
    });
    var adv = color === 'w' ? m.score : -m.score;
    if (adv > 0) h += '<b class="mscore">+' + adv + '</b>';
    return h;
  }
  var matT = 0, lastKey = '';
  function updateMat(){
    matT = 0;
    if (!A.state.analysis){ if (lastKey){ matTop.innerHTML = matBot.innerHTML = ''; lastKey = ''; } return; }
    var m = material(), bottom = A.state.orient === 'b' ? 'b' : 'w', top = bottom === 'w' ? 'b' : 'w';
    var key = A.game().fen().split(' ')[0] + bottom + (A.psrc ? A.psrc('wP') : '').length;
    if (key === lastKey) return; lastKey = key;
    matTop.innerHTML = rowHtml(top, m); matBot.innerHTML = rowHtml(bottom, m);
    matTop.dataset.side = top; matBot.dataset.side = bottom;
    var adv = m.score > 0 ? 'w' : m.score < 0 ? 'b' : '';
    var t = function(s){ return (s === 'w' ? 'Bianco' : 'Nero') + (adv === s ? ': +' + Math.abs(m.score) + ' di materiale' : ''); };
    matTop.title = t(top); matBot.title = t(bottom);
  }
  function schedMat(){ if (!matT) matT = requestAnimationFrame(updateMat); }
  new MutationObserver(schedMat).observe(board, {childList:true});
  document.addEventListener('cnp:analysis', function(ev){ var on = !!(ev.detail && ev.detail.on); root.classList.toggle('anaon', on); schedMat(); if (!on) relayout(); });
  document.addEventListener('cnp:load', function(){ root.classList.toggle('anaon', !!A.state.analysis); schedMat(); });

  // ======================= 3. controlli =======================
  var bar = document.querySelector('.actionbar'), tools = $('boardTools');
  // Riprova (era «Ricomincia»), Aiuto (era «Suggerimento»): etichette brevi
  function relabel(id, txt, title){ var b = $(id); if (!b) return; var s = b.querySelector('.lbl-t'); if (s) s.textContent = txt; if (title) b.title = title; b.setAttribute('aria-label', txt); }
  relabel('tHint', 'Aiuto', 'Aiuto: quale pezzo muovere (premi ancora per la casa e la freccia)');
  relabel('tRestart', 'Riprova', 'Riprova: ricomincia l\'esercizio dalla posizione iniziale');
  relabel('tShow', 'Soluzione', 'Mostra la soluzione animata (chiede conferma)');
  // il pulsante ⇄ era il Ripasso: ripropone gli esercizi sbagliati, aiutati o saltati
  var rev = $('tReview');
  if (rev){
    rev.title = 'Ripasso errori: ripropone gli esercizi sbagliati, aiutati o saltati';
    rev.setAttribute('aria-label', 'Ripasso errori');
    rev.classList.add('tool');
    var lt = rev.querySelector('.lbl-t'); if (lt) lt.textContent = ' Ripasso errori';
    tools.appendChild(rev);                                // barra verticale (computer/tablet); su telefono è nel ⋯
  }
  var more = el('button', {id:'tMore', type:'button', 'class':'has-ico', title:'Altro: ruota, disegno, condividi, ripasso', 'aria-label':'Altro', 'aria-haspopup':'dialog', 'aria-expanded':'false'}, svg('ellipsis'));
  bar.appendChild(more);

  // --- penna: colori + gomma (popover sul computer, fila sotto la scacchiera sul telefono) ---
  var pop = el('div', {id:'drawPop', 'class':'drawpop', role:'group', 'aria-label':'Colori e gomma del disegno'});
  pop.appendChild($('swatches'));
  var clr = $('tClear'); clr.title = 'Gomma: cancella frecce e cerchi'; clr.setAttribute('aria-label', 'Gomma: cancella i disegni');
  pop.appendChild(clr);
  var off = el('button', {id:'dpOff', type:'button', 'class':'tool has-ico', title:'Spegni la penna (torna a muovere i pezzi)', 'aria-label':'Spegni la penna'}, svg('pencil-off'));
  pop.appendChild(off);
  off.onclick = function(){ A.setDrawMode(false); };
  var tDraw = $('tDraw');
  tDraw.title = 'Penna: disegna frecce e cerchi (anche col tasto destro)'; 
  function drawOn(){ return tDraw.getAttribute('aria-pressed') === 'true'; }
  new MutationObserver(function(){ syncDraw(); }).observe(tDraw, {attributes:true, attributeFilter:['aria-pressed', 'class']});

  // --- foglio ⋯ ---
  var sheet = el('div', {id:'moreSheet', 'class':'msheet', role:'dialog', 'aria-modal':'true', 'aria-label':'Altro', hidden:''},
    '<div class="ms-scrim"></div><div class="ms-card"><div class="ms-grab"></div>' +
    // blocco 4 (28/10): sul telefono (v6) le funzioni della schermata classica che mancavano
    '<div class="ms-group ms-v6">' +
      '<button type="button" class="ms-item" data-a="fav" aria-pressed="false">' + svg('bookmark') + '<span class="ms-favl">Aggiungi ai Preferiti<small>Lo ritrovi nei Capitoli, in cima</small></span></button>' +
      '<button type="button" class="ms-item" data-a="intro">' + svg('book-open') + '<span>Introduzione del tema<small class="ms-intro"></small></span></button>' +
      '<button type="button" class="ms-item" data-a="todo">' + svg('skip-forward') + '<span>Prossimo da fare<small>Il prossimo non risolto del tema, poi il tema dopo</small></span></button>' +
      '<button type="button" class="ms-item" data-a="restart">' + svg('rotate-ccw') + '<span>Ricomincia<small>Rifai questo esercizio dall\'inizio</small></span></button>' +
    '</div>' +
    '<div class="ms-group">' +
      '<button type="button" class="ms-item" data-a="flip">' + svg('arrow-up-down') + '<span>Ruota scacchiera</span></button>' +
      '<button type="button" class="ms-item" data-a="draw" aria-pressed="false">' + svg('pencil') + '<span>Disegno</span><i class="ms-switch"></i></button>' +
      '<div class="ms-drawslot"></div>' +
      '<button type="button" class="ms-item" data-a="share">' + svg('share-2') + '<span>Condividi<small>PGN, immagine e GIF</small></span></button>' +
      '<button type="button" class="ms-item" data-a="review">' + svg('repeat') + '<span>Ripasso di oggi<small>Gli errori tornano dopo 1, 3 e 7 giorni · max 10 al giorno</small></span><b class="ms-count"></b></button>' +
    '</div>' +
    '<div class="ms-group ms-focus">' +
      '<button type="button" class="ms-item" data-a="chapters">' + svg('list') + '<span>Capitoli</span></button>' +
      '<button type="button" class="ms-item" data-a="stats">' + svg('chart-column') + '<span>Statistiche</span></button>' +
      '<button type="button" class="ms-item" data-a="profile"><span class="ms-av">' + svg('circle') + '</span><span>Il tuo profilo<small>Nome e avatar</small></span></button>' +
      '<button type="button" class="ms-item" data-a="coach">' + svg('message-circle') + '<span>Istruttore<small>Scegli chi ti accompagna</small></span></button>' +
      '<button type="button" class="ms-item" data-a="focus" aria-pressed="false">' + svg('focus') + '<span>Concentrazione</span><i class="ms-switch"></i></button>' +
    '</div>' +
    '<button type="button" class="ms-close">Chiudi</button></div>');
  document.body.appendChild(sheet);
  var lastFocus = null;
  function sheetOpen(){ return !sheet.hidden; }
  function openSheet(){
    lastFocus = document.activeElement;
    syncSheet(); sheet.hidden = false; more.setAttribute('aria-expanded', 'true');
    relayout();
    requestAnimationFrame(function(){ sheet.classList.add('show'); });
    var f = sheet.querySelector('.ms-item'); if (f) try { f.focus({preventScroll:true}); } catch(e){}
  }
  function closeSheet(){
    if (sheet.hidden) return;
    sheet.classList.remove('show'); sheet.hidden = true; more.setAttribute('aria-expanded', 'false');
    relayout();
    if (lastFocus && lastFocus.focus) try { lastFocus.focus({preventScroll:true}); } catch(e){}
  }
  function syncSheet(){
    var d = sheet.querySelector('[data-a=draw]'); d.setAttribute('aria-pressed', drawOn() ? 'true' : 'false');
    var f = sheet.querySelector('[data-a=focus]'); f.setAttribute('aria-pressed', focusOn() ? 'true' : 'false');
    f.hidden = !(window.__focus && __focus.eligible()) || !!(window.__focus && __focus.phone && __focus.phone());   // telefono: sempre la v6, niente scelta
    sheet.querySelector('[data-a=chapters]').hidden = sheet.querySelector('[data-a=stats]').hidden = !focusOn();
    // telefono in concentrazione: avatar e interruttore non stanno nella barra in alto -> qui
    sheet.querySelector('[data-a=profile]').hidden = sheet.querySelector('[data-a=coach]').hidden = !focusOn();
    var av = sheet.querySelector('.ms-av'), pr = window.__profilo && __profilo.get();
    if (av){ try { av.innerHTML = pr ? __profilo.avatar(pr, 22) : svg('circle'); } catch(e){} }
    var rc = rev && rev.querySelector('.rcount'); sheet.querySelector('.ms-count').textContent = rc ? rc.textContent : '';
    sheet.querySelector('[data-a=review]').classList.toggle('on', !!(rev && rev.classList.contains('active')));
    var fv = $('favBtn'), isF = !!(fv && fv.classList.contains('on')), fi = sheet.querySelector('[data-a=fav]');
    fi.setAttribute('aria-pressed', isF ? 'true' : 'false'); fi.classList.toggle('on', isF);
    fi.querySelector('.ms-favl').firstChild.textContent = isF ? 'Togli dai Preferiti' : 'Aggiungi ai Preferiti';
    var ex = A.state && A.state.ex, ch = ex && A.chById && A.chById[ex.c];
    sheet.querySelector('.ms-intro').textContent = ch ? ch.name : '';
  }
  function click(id){ var b = $(id); if (b && !b.disabled) b.click(); }
  more.onclick = function(ev){ ev.stopPropagation(); if (sheetOpen()) closeSheet(); else openSheet(); };
  sheet.addEventListener('click', function(ev){
    if (ev.target.classList.contains('ms-scrim') || ev.target.classList.contains('ms-close')){ closeSheet(); return; }
    var b = ev.target.closest('.ms-item'); if (!b) return;
    var a = b.dataset.a;
    if (a === 'draw'){ A.setDrawMode(!drawOn()); syncSheet(); return; }   // il foglio resta aperto: si vedono colori e gomma
    if (a === 'focus'){ closeSheet(); if (window.__focus) __focus.toggle(!focusOn()); return; }
    if (a === 'fav'){ click('favBtn'); syncSheet(); return; }
    closeSheet();
    if (a === 'intro'){ if (window.__v6 && __v6.on && __v6.on()) __v6.intro(true); else { var ib = $('introBox'); if (ib){ ib.open = true; try { ib.scrollIntoView({block:'center'}); } catch(e){} } } return; }
    if (a === 'todo'){ click('nextUnsolved'); return; }
    if (a === 'restart'){ click('tRestart'); return; }
    if (a === 'review'){ var S = window.__stats; if (window.__v6 && __v6.on && __v6.on() && S && S.beginReview) S.beginReview(); else click('tReview'); return; }
    if (a === 'flip') click('tFlip'); else if (a === 'share') click('tShare');
    else if (a === 'chapters') click('menuBtn'); else if (a === 'stats') click('statsBtn');
    else if (a === 'profile' || a === 'coach'){
      try { A.openSettings(a === 'profile' ? 'look' : 'voice'); } catch(e){ return; }
      setTimeout(function(){ var s = a === 'profile' ? $('profSet') : document.querySelector('.coachset'); if (s) s.scrollIntoView({block:'start', behavior:'smooth'}); }, 80);
    }
  });
  document.addEventListener('keydown', function(ev){ if (ev.key === 'Escape' && sheetOpen()){ ev.preventDefault(); ev.stopImmediatePropagation(); closeSheet(); } }, true);

  // ======================= 2. concentrazione a pannelli =======================
  var PKEY = 'cnp-pannelli';
  var pst = {}; try { pst = JSON.parse(localStorage.getItem(PKEY) || '{}') || {}; } catch(e){ pst = {}; }
  var deck = el('div', {id:'fDeck', 'class':'fdeck'});
  var taskBar = el('div', {id:'fTask', 'class':'ftask', role:'status'});
  var scroll = el('div', {'class':'fscroll'});
  function panel(key, icon, title){
    var d = el('details', {'class':'fpanel', 'data-p':key});
    d.innerHTML = '<summary>' + svg(icon, 18) + '<span>' + title + '</span><i class="fdot" hidden></i>' + svg('chevron-down', 18).replace('class="lu"', 'class="lu fchev"') + '</summary><div class="fpbody"></div>';
    if (pst[key]) d.open = true;
    d.addEventListener('toggle', function(){ pst[key] = d.open; if (d.open) d.querySelector('.fdot').hidden = true; try { localStorage.setItem(PKEY, JSON.stringify(pst)); } catch(e){} });
    return d;
  }
  var pCoach = panel('coach', 'message-circle', 'Istruttore'), pEx = panel('explain', 'book-open', 'Spiegazione'), pSol = panel('sol', 'list-ordered', 'Soluzione');
  var listen = el('button', {type:'button', id:'fListen', 'class':'flisten has-ico', title:'Ascolta la consegna o il commento'}, svg('volume-2', 18) + '<span>Ascolta</span>');
  listen.onclick = function(){ click('tListen'); };
  scroll.appendChild(pCoach); scroll.appendChild(pEx); scroll.appendChild(pSol);
  deck.appendChild(taskBar); deck.appendChild(scroll);
  var layoutEl = document.querySelector('.layout');
  layoutEl.parentNode.insertBefore(deck, layoutEl.nextSibling);

  // spostamenti con segnaposto, così si torna esattamente al posto di prima
  var moved = [];
  function moveTo(node, parent, before){
    if (!node) return;
    if (!node.__home){ var ph = document.createComment('home:' + (node.id || node.className)); node.parentNode.insertBefore(ph, node); node.__home = ph; moved.push(node); }
    if (before) parent.insertBefore(node, before); else parent.appendChild(node);
  }
  function restoreAll(){
    moved.slice().reverse().forEach(function(n){ var ph = n.__home; if (ph && ph.parentNode){ ph.parentNode.insertBefore(n, ph); ph.parentNode.removeChild(ph); } n.__home = null; });
    moved = [];
  }
  var boardcol = document.querySelector('.boardcol'), frame = document.querySelector('.boardframe');
  var deckOn = false;
  function buildDeck(){
    // fila dei pulsanti in alto nel mazzo, poi consegna; nella parte che scorre: esito, analisi, pannelli, info
    moveTo(bar, deck, taskBar);
    moveTo($('feedback'), scroll, pCoach);
    moveTo($('anaBox'), scroll, pCoach);
    var body = pCoach.querySelector('.fpbody'); moveTo($('fCoach'), body); body.appendChild(listen);
    moveTo($('explain'), pEx.querySelector('.fpbody'));
    moveTo($('moves'), pSol.querySelector('.fpbody')); moveTo($('stepNav'), pSol.querySelector('.fpbody'));
    moveTo($('fInfo'), deck);             // fuori dalla parte che scorre: resta visibile anche in analisi
    // frecce dell'esercizio accanto al titolo
    var fb = $('fBar'), tt = fb && fb.querySelector('.ftitle');
    if (tt){ moveTo($('fPrev'), fb, tt); moveTo($('fNext'), fb, tt.nextSibling); }
    deckOn = true;
  }
  function placeDrawPop(){
    var dest, before = null;
    if (sheetOpen() && compact()) dest = sheet.querySelector('.ms-drawslot');
    else if (compact()){ dest = boardcol; before = frame.nextSibling; }
    else { dest = tools; before = tDraw.nextSibling; }
    if (pop.parentNode !== dest || (before && pop.nextSibling !== before && pop !== before)) dest.insertBefore(pop, before);
    posPop();
  }
  function posPop(){
    if (pop.parentNode !== tools || !drawOn()) return;
    pop.classList.remove('left');
    pop.style.setProperty('--dpTop', Math.round(tDraw.offsetTop + tDraw.offsetHeight / 2 - pop.offsetHeight / 2) + 'px');
    var r = pop.getBoundingClientRect();
    if (r.right > document.documentElement.clientWidth - 4) pop.classList.add('left');
  }
  function relayout(){
    var want = focusOn();
    if (want && !deckOn) buildDeck();
    else if (!want && deckOn){ restoreAll(); deckOn = false; }
    root.classList.toggle('flay', want);
    root.classList.toggle('lcompact', compact());
    placeDrawPop(); syncDraw(true); renderTask(); placeEval();
    if (!compact() && sheetOpen()) closeSheet();
  }
  var lastDraw = null;
  function syncDraw(noFit){
    var on = drawOn();
    root.classList.toggle('penon', on);
    if (on) posPop();
    var d = sheet.querySelector('[data-a=draw]'); if (d) d.setAttribute('aria-pressed', on ? 'true' : 'false');
    if (on !== lastDraw){ lastDraw = on; if (!noFit && focusOn() && window.__focus) __focus.fit(); }
  }

  // --- consegna sempre visibile ---
  function txt(n){ return n ? (n.textContent || '').replace(/\s+/g, ' ').trim() : ''; }
  var lastTask = '';
  function renderTask(){
    var s = A.state && A.state.side === 'b' ? 'b' : 'w', t = txt($('task'));
    var h = '<span class="fside ' + s + '" title="Muove il ' + (s === 'b' ? 'Nero' : 'Bianco') + '"></span><span class="ftask-t">' + esc(t || ('Muove il ' + (s === 'b' ? 'Nero' : 'Bianco'))) + '</span>';
    if (h !== lastTask){ lastTask = h; taskBar.innerHTML = h; }
  }
  new MutationObserver(renderTask).observe($('task'), {childList:true, subtree:true, characterData:true});
  // pallino "nuovo" sulla Spiegazione quando compare il commento a pannello chiuso
  function markNew(){ if (deckOn && !pEx.open) pEx.querySelector('.fdot').hidden = false; }
  ['solved', 'show'].forEach(function(k){ document.addEventListener('cnp:' + k, markNew); });
  document.addEventListener('cnp:load', function(){ pEx.querySelector('.fdot').hidden = true; setTimeout(renderTask, 0); });

  // altezze per focus.js (fit): spazio fisso accanto alla scacchiera
  window.__flay = {
    active:function(){ return deckOn && focusOn(); },
    boardExtra:function(){
      var h = 0;
      // telefono: barra di valutazione e materiale stanno sotto la scacchiera e non la rimpiccioliscono
      if (A.state.analysis && !phone()) h += matTop.offsetHeight + matBot.offsetHeight;
      if (compact() && drawOn() && pop.parentNode === boardcol) h += pop.offsetHeight + 6;
      return h;
    },
    minBelow:function(){ return bar.offsetHeight + taskBar.offsetHeight + 2 * 50 + 16; },
    openSheet:openSheet, closeSheet:closeSheet, sheetOpen:sheetOpen, material:material, relayout:relayout
  };
  document.addEventListener('cnp:focus', function(){ relayout(); if (window.__focus) __focus.fit(); });

  // ======================= 4. telefono / tablet: ritocchi =======================
  // barra di valutazione: su telefono orizzontale sotto la scacchiera (la scacchiera non si sposta né si stringe)
  function placeEval(){
    var eb = $('evalBar'); if (!eb) return;
    if (phone()){ if (eb.parentNode !== stack || eb.previousSibling !== board) stack.insertBefore(eb, board.nextSibling); eb.classList.add('horiz'); }
    else { if (eb.parentNode !== wrap) wrap.insertBefore(eb, stack); eb.classList.remove('horiz'); }
  }
  // titolo in concentrazione: «Esercizio 220» -> «Es. 220» -> «220» se non entra
  var fT = $('fTitle'), fullT = '', tBusy = false;
  function fitTitle(){
    if (!fT || tBusy) return;
    var t = fT.textContent;
    if (/^Esercizio /.test(t)) fullT = t;
    if (!fullT || !focusOn()) return;
    var n = fullT.replace(/^Esercizio /, '');
    // le scritture qui non devono ridestare l'osservatore (prima ripartiva a ogni fotogramma)
    tBusy = true; if (tMO) tMO.disconnect();
    fT.textContent = fullT;
    var fin = fullT;
    if (fT.scrollWidth > fT.clientWidth + 1){ fin = 'Es. ' + n; fT.textContent = fin; if (fT.scrollWidth > fT.clientWidth + 1){ fin = n; fT.textContent = fin; } }
    if (fT.textContent !== fin) fT.textContent = fin;
    if (fT.title !== fullT) fT.title = fullT;
    if (tMO){ tMO.takeRecords(); tMO.observe(fT, {childList:true, characterData:true, subtree:true}); }
    tBusy = false;
  }
  var tMO = null;
  if (fT){ tMO = new MutationObserver(function(){ if (!tBusy) requestAnimationFrame(fitTitle); }); tMO.observe(fT, {childList:true, characterData:true, subtree:true}); }
  // cassetto dei capitoli: pulsante ✕ nell'intestazione
  var sh = document.querySelector('#sidebar .sidehead');
  if (sh && !$('sideClose')){
    var sc = el('button', {id:'sideClose', type:'button', 'class':'sideclose has-ico', title:'Chiudi i capitoli', 'aria-label':'Chiudi i capitoli'}, svg('x', 20));
    sh.appendChild(sc);
    sc.onclick = function(){ var s = $('scrim'); if (s) s.click(); else $('sidebar').classList.remove('open');
      try { document.activeElement && document.activeElement.blur(); } catch(e){} };
  }
  // dopo il tocco su ☰ / ← il pulsante non resta evidenziato (l'anello resta solo da tastiera: :focus-visible)
  // «Analizza» diventa il pulsante principale solo a esercizio finito; prima lo è Aiuto
  function syncPrimary(){ var done = !!(A.state && (A.state.finished || A.state.shown)); root.classList.toggle('lpre', !done); }
  ['load', 'solved', 'show', 'reset'].forEach(function(k){ document.addEventListener('cnp:' + k, function(){ setTimeout(syncPrimary, 0); }); });
  syncPrimary();
  var rT = 0;
  window.addEventListener('resize', function(){ clearTimeout(rT); rT = setTimeout(function(){ relayout(); fitTitle(); }, 70); });
  if (mqPhone.addEventListener) mqPhone.addEventListener('change', relayout);
  relayout(); fitTitle();
  if (focusOn() && window.__focus) __focus.fit();
  updateMat();
})();
