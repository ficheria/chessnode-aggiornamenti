/* Chess Node · «Scacchiera di analisi» — anteprima 16 (31/10/2026), grande aggiornamento blocco 5 (11-11-2026).
   Adattata dal file scacchiera.js di Kiko (codice originale del progetto, nessun codice Lichess):
   - pezzi e scacchiera dell'app: immagini di pieces.js via __app.psrc() (set scelto, di base Elegante), colori dal tema;
   - blocco 5: le mosse stanno in un ALBERO (cn_varianti.js 1.1, fase_03): una mossa diversa da quella della partita NON taglia
     più la linea ma apre una variante («La tua variante», colore diverso), annidata nella notazione; «Torna alla partita» riporta
     ESATTAMENTE alla mossa da cui si era partiti (L.801–806);
   - blocco 5: frecce Frecce V5 (ChessNodeArrows), spente di base; animate solo con Animazioni «Attive»;
   - motore: il NOSTRO Stockfish nel Worker separato (engine/, invariato), progressivo e annullato a ogni cambio di posizione.
     Blocco 5: le valutazioni già pronte del cloud di Lichess (cloud-eval, chiamata pubblica senza token) sono SPENTE di base
     e si accendono solo dall'ingranaggio (prefs.an.cloud);
   - teoria d'apertura da data/wikibooks_aperture.json (CC BY-SA 4.0), nomi ECO da data/aperture_eco.json (CC0);
   - modalità «partita» (schermata 22b): partita commentata dall'istruttore scelto (analisi_commenti.js), schermata fissa
     senza scorrimento della pagina: scorre solo la notazione.
   chess.js v1 (BSD-2, lib/chess.min.js). */
(function(){
  'use strict';
  var A = window.__app;
  if (!A || typeof Chess === 'undefined' || !window.CNVarianti) return;
  var START = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';
  var CLOUD = 'https://lichess.org/api/cloud-eval';
  var KEY = 'chessnodeplay-analisi-v1';
  var DEPTH = 22, MOVETIME = 45000, MPV_LOCAL = 2, MPV_CLOUD = 3, CLOUD_TIMEOUT = 3500;
  var VAR_DEPTH = 18, VAR_MOVETIME = 8000, CONFERMA_DEPTH = 16;   // varianti nella partita commentata: profondità minima per le etichette
  var L = window.LUCIDE || {};
  function svg(n, s){ s = s || 20; return L[n] ? '<svg class="lu" viewBox="0 0 24 24" width="' + s + '" height="' + s + '" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' + L[n] + '</svg>' : ''; }
  function esc(s){ return String(s == null ? '' : s).replace(/[&<>"']/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }
  function fkey(fen){ return String(fen).split(' ').slice(0, 4).join(' '); }
  function it(s){ return A.itSan ? A.itSan(s) : s; }

  /* ---------- preferenze dell'analisi (Impostazioni › Analisi e ingranaggio): tutte spente di base ---------- */
  function AP(){ var p = A.prefs || {}; var a = p.an || {}; return {frecce:!!a.frecce, minaccia:!!a.minaccia, voce:!!a.voce, cloud:!!a.cloud, lingua:a.lingua === 'en' ? 'en' : 'it', teoriaChiusa:!!a.teoriaChiusa}; }
  function setAP(k, v){ if (!A.prefs) return; var a = A.prefs.an || {}; a[k] = v; A.prefs.an = a; try { A.savePrefs(); } catch(e){} }
  function anim(){ var b = document.body.classList; return b.contains('anim-off') ? 'off' : b.contains('anim-reduced') ? 'reduced' : 'normal'; }

  /* ---------- stato: albero delle mosse (cn_varianti) ---------- */
  // S.mode: 'libera' (Scacchiera di analisi) | 'partita' (22b). S.mainLen: in «partita» la linea della partita è fissa.
  // S.ritorno: id del nodo da cui è partita la variante (ritorno ESATTO). S.orig: {id:'u'|'m'} chi ha creato il nodo.
  var S = {startFen:START, flip:false, sel:null, engOn:true, promo:null, mode:'libera', mainLen:null, ritorno:null, orig:{}, meta:null, conf:false};
  var T = CNVarianti.nuovoAlbero({fen:START});
  try { var sv = JSON.parse(localStorage.getItem(KEY) || '{}');
    if (sv.engOn === false) S.engOn = false;
    S.flip = !!sv.flip;
    if (sv.albero && T.daJSON(sv.albero)){ S.startFen = T.radice.fen; S.orig = sv.orig || {}; S.ritorno = sv.ritorno && T.nodo(sv.ritorno) ? sv.ritorno : null; }
    else if (sv.startFen && Array.isArray(sv.sans)){ T.daMosse(sv.sans, sv.startFen); S.startFen = sv.startFen; var mn = T.linea(); T.vaiA(mn[Math.min(sv.ply | 0, mn.length) - 1] || T.radice); }
  } catch(e){ T = CNVarianti.nuovoAlbero({fen:START}); S.startFen = START; }
  var saved = null;   // stato della scacchiera libera mentre si guarda una partita commentata
  function save(){
    if (S.mode !== 'libera') return;
    var m = main(), ply = mainPly();
    try { localStorage.setItem(KEY, JSON.stringify({engOn:S.engOn, startFen:S.startFen, sans:m.map(function(n){ return n.san; }), ply:ply, flip:S.flip, albero:T.aJSON(), orig:S.orig, ritorno:S.ritorno})); } catch(e){}
  }
  function main(){ var l = T.linea(); return S.mainLen != null ? l.slice(0, S.mainLen) : l; }
  function depth(n){ var d = 0; while (n && n.padre){ d++; n = n.padre; } return d; }
  function isMain(n){ n = n || T.corrente; if (!T.eInPrincipale(n)) return false; return S.mainLen == null || depth(n) <= S.mainLen; }
  function mainPly(){   // posizione nella partita: il nodo corrente, oppure (in una variante) la mossa da cui si è partiti
    var n = T.corrente;
    if (isMain(n)) return depth(n);
    if (S.ritorno && T.nodo(S.ritorno) && isMain(T.nodo(S.ritorno))) return depth(T.nodo(S.ritorno));
    while (n.padre && !isMain(n)) n = n.padre; return depth(n);
  }
  function path(){ var out = [], n = T.corrente; while (n.padre){ out.unshift(n); n = n.padre; } return out; }
  function pos(){ return new Chess(T.corrente.fen); }
  function fensUpTo(){ return [fkey(S.startFen)].concat(path().map(function(n){ return fkey(n.fen); })); }
  function inVar(){ return !isMain(T.corrente); }
  function varTipo(){   // 'u' = la tua variante, 'm' = variante del motore («Vedi la variante»)
    var n = T.corrente; while (n.padre && !isMain(n)){ if (S.orig[n.id] === 'u') return 'u'; n = n.padre; } return 'm';
  }

  /* ---------- dati (file separati, caricati alla prima apertura) ---------- */
  var ECO = null, WB = null, AK = null, dataP = null;
  function loadData(){
    if (dataP) return dataP;
    function j(u){ return fetch(u).then(function(r){ if (!r.ok) throw new Error(r.status); return r.json(); }).catch(function(){ return null; }); }
    dataP = Promise.all([j('data/aperture_eco.json'), j('data/wikibooks_aperture.json'), j('data/aperture_kiko.json')]).then(function(r){
      ECO = (r[0] && r[0].voci) || {}; WB = (r[1] && r[1].voci) || {}; AK = (r[2] && r[2].nomi && r[2].pos && r[2].fam) ? r[2] : null;
    });
    return dataP;
  }

  /* 14-11 (Kiko): le tre scacchiere (esercizio, analisi partita, Scacchiera di analisi libera) partono alla STESSA altezza.
     Riferimento = esercizio_v6.js fit() (08b): stesse costanti (barra 56 + fotocamera, barra in basso 70 + bordo 1 + gesti, need 104/112,
     istruttore 84/100..156, tetto 560, v6small se H < 720). Restituisce top e lato della scacchiera dell'esercizio. */
  /* 14-11 giro C: le misure stanno nello STAMPO UNICO (stampo_scacchiera.js, CNStampo.misure = stessa formula dell'esercizio;
     CNAllinea resta come alias per analisi_revisione.js). */
  function exTop(W, H){ return window.CNStampo.misure(W, H); }
  var ST = null;   // stampo di questa pagina (creato in build)
  /* Scacchiera libera: sopra la scacchiera si riserva la zona del fumetto (come nell'esercizio), così parte alla stessa y.
     Nel fumetto: l'istruttore e la posizione (nome dell'apertura) con un aiuto breve. La scacchiera non è mai coperta. */
  function allineaLibera(){
    if (!root || root.hidden || S.mode === 'partita') return;
    var z = $('.anp-lz'), bw = $('.anp-bw'), sc = $('.anp-scroll'); if (!z || !bw || !sc) return;
    var e = $('.anp-lz-t'), eco = $('.anp-eco'); if (e && eco) e.textContent = eco.textContent || 'Posizione iniziale';
    var r = ST ? ST.allinea({maxLato:520}) : null;   // stampo: zona fumetto + stesso lato dell'esercizio sugli schermi bassi
    z.classList.toggle('anp-lz-0', !r || r.zona < 56);
  }
  /* ---------- DOM ---------- */
  var root = null, $ = function(s){ return root.querySelector(s); };
  function build(){
    root = document.createElement('div');
    root.id = 'anPage'; root.className = 'anp'; root.hidden = true;
    root.setAttribute('role', 'dialog'); root.setAttribute('aria-modal', 'true'); root.setAttribute('aria-label', 'Scacchiera di analisi');
    root.innerHTML =
      '<header class="anp-top">' +
        '<button type="button" class="anp-ib anp-close" aria-label="Indietro">' + svg('chevron-left', 24) + '</button>' +
        '<div class="anp-tt"><b>Analisi</b><small class="anp-eco"></small></div>' +
        '<button type="button" class="anp-ib anp-save" aria-label="Salva la partita" aria-pressed="false">' + svg('bookmark', 22) + '</button>' +
        '<button type="button" class="anp-engbtn" role="switch" aria-checked="true" aria-label="Motore acceso o spento"><span>Motore</span><i class="anp-sw"></i></button>' +
        '<button type="button" class="anp-ib anp-gearbtn" aria-label="Impostazioni dell\'analisi" aria-expanded="false">' + svg('settings', 22) + '</button>' +
        '<button type="button" class="anp-ib anp-more" aria-label="Altro: importa, esporta, condividi, nuova" aria-haspopup="dialog">' + svg('ellipsis', 22) + '</button>' +   // 14-11 stampo: menu ⋯
      '</header>' +
      '<div class="anp-coach" aria-live="polite">' +
        '<button type="button" class="anp-av" aria-label="Ascolta il commento"><img alt="" src=""></button>' +
        '<div class="anp-bub"></div>' +
      '</div>' +
      '<div class="anp-ban" hidden role="status"><span class="anp-bt"></span><button type="button" class="anp-btn anp-torna">' + svg('undo-2', 16) + 'Torna alla partita</button></div>' +
      '<div class="anp-evr" aria-label="Valutazione dal lato del Bianco"></div>' +
      '<div class="anp-scroll">' +
        // 14-11 ritocco: avatar grande con anello e fumetto chiaro come l'esercizio (componente dello stampo .cn-st-coach)
        '<div class="anp-lz cn-st-coach" aria-hidden="true"><span class="cn-st-ava anp-lz-av"><img alt="" src="istruttori/tondi/chessnote.webp"></span>' +
          '<div class="cn-st-bub anp-lz-b"><b class="cn-st-who anp-lz-t">Posizione iniziale</b><p class="cn-st-txt">Muovi un pezzo o incolla una partita: il motore valuta ogni posizione.</p></div></div>' +
        '<div class="anp-bw">' +
          '<div class="anp-bar" aria-hidden="true"><div class="anp-fill"></div><span class="anp-bl"></span></div>' +
          '<div class="anp-board" role="grid" aria-label="Scacchiera"></div>' +
        '</div>' +
        '<div class="anp-promo" hidden></div>' +
        '<section class="anp-gear" hidden aria-label="Impostazioni dell\'analisi"></section>' +
        '<div class="anp-eng anp-lib" aria-live="polite"></div>' +
        '<nav class="anp-nav anp-lib" aria-label="Navigazione mosse">' +
          '<button type="button" class="anp-ib" data-a="start" aria-label="Inizio">' + svg('chevrons-left') + '</button>' +
          '<button type="button" class="anp-ib" data-a="prev" aria-label="Indietro">' + svg('chevron-left') + '</button>' +
          '<button type="button" class="anp-ib" data-a="next" aria-label="Avanti">' + svg('chevron-right') + '</button>' +
          '<button type="button" class="anp-ib" data-a="end" aria-label="Fine">' + svg('chevrons-right') + '</button>' +
          '<button type="button" class="anp-ib" data-a="flip" aria-label="Ruota scacchiera">' + svg('arrow-up-down') + '</button>' +
        '</nav>' +
        '<section class="anp-card anp-apa anp-lib" aria-live="polite"></section>' +
        '<section class="anp-card anp-mc"><h3 class="anp-lib">Mosse</h3><div class="anp-moves"></div></section>' +
        '<details class="anp-card anp-lib anp-thd"' + (AP().teoriaChiusa ? '' : ' open') + '><summary><h3>' + svg('book-open', 18) + 'Teoria d\'apertura' + svg('chevron-down', 18) + '</h3></summary><div class="anp-th"></div></details>' +   // 14-11: richiudibile
        '<section class="anp-card anp-mst anp-lib"><h3>' + svg('trophy', 18) + 'Partite dei campioni</h3><div class="anp-ms"></div></section>' +
        '<section class="anp-card anp-lib anp-imp"><h3>' + svg('upload', 18) + 'Importa una partita</h3>' +
          '<textarea class="anp-txt" rows="3" spellcheck="false" autocapitalize="off" aria-label="PGN o FEN" placeholder="Incolla qui una partita (PGN) o una posizione (FEN)"></textarea>' +
          '<div class="anp-row">' +
            '<button type="button" class="anp-btn anp-pri" data-a="imp">Carica</button>' +
            '<button type="button" class="anp-btn anp-imore" data-a="more">' + svg('ellipsis', 16) + 'Da file, copia, nuova…</button>' +   // 14-11: tutto il resto nel menu ⋯
          '</div>' +
          '<input type="file" class="anp-file" accept=".pgn,.txt,text/plain" hidden>' +
          '<p class="anp-msg anp-mu" role="status"></p>' +
        '</section>' +
      '</div>' +
      '<nav class="anp-ctl" aria-label="Mosse della partita">' +
        '<button type="button" class="anp-ib anp-cb" data-a="prev" aria-label="Mossa precedente">' + svg('chevron-left', 26) + '</button>' +
        '<button type="button" class="anp-btn anp-pri anp-vv" data-a="vv">Vedi la variante</button>' +
        '<button type="button" class="anp-ib anp-cb" data-a="next" aria-label="Mossa successiva">' + svg('chevron-right', 26) + '</button>' +
      '</nav>';
    document.body.appendChild(root);

    $('.anp-close').onclick = close;
    $('.anp-engbtn').onclick = function(){ setEngine(!S.engOn); };
    $('.anp-gearbtn').onclick = function(){ gear(!gearOpen); };
    $('.anp-save').onclick = function(){ if (window.CNAnalisiPartitaUI) window.CNAnalisiPartitaUI.salva(); };
    $('.anp-torna').onclick = torna;
    var bd = $('.anp-board');
    bd.addEventListener('click', onBoard);
    bd.addEventListener('pointerdown', dragStart);
    $('.anp-nav').onclick = function(e){
      var b = e.target.closest('button'); if (!b) return; var a = b.dataset.a;
      if (a === 'start') nav('inizio'); else if (a === 'prev') nav('indietro'); else if (a === 'next') nav('avanti'); else if (a === 'end') nav('fine');
      else if (a === 'flip') flip();
    };
    $('.anp-ctl').onclick = function(e){
      var b = e.target.closest('button'); if (!b || b.disabled) return; var a = b.dataset.a;
      if (a === 'prev') nav('indietro'); else if (a === 'next') nav('avanti');
      else if (a === 'vv'){ if (inVar()) torna(); else if (window.CNAnalisiPartitaUI) window.CNAnalisiPartitaUI.vediVariante(); }
    };
    $('.anp-moves').onclick = function(e){ var a = e.target.closest('[data-id]'); if (a){ conf(false); S.sel = null; T.vaiA(a.dataset.id); afterNav(); } };   // tocco su una mossa: scacchiera, banner e motore si aggiornano
    $('.anp-promo').onclick = function(e){ var b = e.target.closest('[data-pr]'); if (!b || !S.promo) return; var p = S.promo; S.promo = null; $('.anp-promo').hidden = true; play({from:p.from, to:p.to, promotion:b.dataset.pr}); };
    root.querySelector('.anp-row').onclick = function(e){
      var b = e.target.closest('button'); if (!b) return; var a = b.dataset.a;
      if (a === 'imp') importText($('.anp-txt').value);
      else if (a === 'file') $('.anp-file').click();
      else if (a === 'cfen') copy(pos().fen(), 'FEN copiata');
      else if (a === 'cpgn') copy(pgnText(), 'PGN copiato');
      else if (a === 'ex') fromExercise();
      else if (a === 'new'){ carica(START, []); msg(''); }
      else if (a === 'more') altro();
    };
    $('.anp-more').onclick = altro;
    $('.anp-thd').addEventListener('toggle', function(){ setAP('teoriaChiusa', !$('.anp-thd').open); });
    ST = window.CNStampo ? window.CNStampo.crea('analisi', {root:root, zona:'.anp-lz', wrap:'.anp-bw', scroll:'.anp-scroll', board:'.anp-bw',
      aiuto:false, valutazione:true, premove:false, condividi:true, motore:true}) : null;
    $('.anp-file').onchange = function(e){ var f = e.target.files && e.target.files[0]; if (!f) return; var r = new FileReader(); r.onload = function(){ importText(String(r.result)); }; r.readAsText(f); e.target.value = ''; };
    $('.anp-eng').onclick = function(e){ var a = e.target.closest('[data-l]'); if (a) playLine(+a.dataset.l); };
    $('.anp-gear').onclick = onGear;
    $('.anp-av').onclick = function(){ if (window.CNAnalisiPartitaUI) window.CNAnalisiPartitaUI.ascolta(); };
    $('.anp-bub').onclick = function(e){ var b = e.target.closest('[data-x]'); if (b && window.CNAnalisiPartitaUI) window.CNAnalisiPartitaUI.azione(b.dataset.x); };
  }

  /* ---------- scacchiera ---------- */
  function boardPos(){ return S.conf && window.CNAnalisiPartitaUI ? (window.CNAnalisiPartitaUI.confFen() || T.corrente.fen) : T.corrente.fen; }
  function render(){
    if (!root) return;
    var g = new Chess(boardPos()), b = g.board(), n = T.corrente, last = null;
    if (!S.conf && n.uci) last = {from:n.uci.slice(0, 2), to:n.uci.slice(2, 4)};
    var legal = S.sel && !S.conf ? g.moves({square:S.sel, verbose:true}).map(function(m){ return m.to; }) : [];
    var inCheck = g.inCheck && g.inCheck(), html = '';
    for (var r = 0; r < 8; r++) for (var f = 0; f < 8; f++){
      var rr = S.flip ? 7 - r : r, ff = S.flip ? 7 - f : f, sq = 'abcdefgh'[ff] + (8 - rr), p = b[rr][ff];
      var k = ['anp-sq', (rr + ff) % 2 ? 'd' : 'l'];
      if (sq === S.sel) k.push('sel');
      if (last && (sq === last.from || sq === last.to)) k.push('last');
      if (legal.indexOf(sq) >= 0) k.push(p ? 'cap' : 'dot');
      if (inCheck && p && p.type === 'k' && p.color === g.turn()) k.push('anp-chk');
      html += '<div class="' + k.join(' ') + '" data-sq="' + sq + '" role="gridcell" aria-label="' + sq + (p ? ' ' + p.color + p.type.toUpperCase() : '') + '">' +
        (f === 0 ? '<i class="anp-co r">' + (8 - rr) + '</i>' : '') + (r === 7 ? '<i class="anp-co f">' + 'abcdefgh'[ff] + '</i>' : '') +
        (p ? '<img alt="" draggable="false" src="' + A.psrc(p.color + p.type.toUpperCase()) + '">' : '') + '</div>';
    }
    $('.anp-board').innerHTML = html + '<svg class="anp-arrows" viewBox="0 0 8 8" aria-hidden="true"></svg>';
    renderMoves(); banner(); drawArrow();
    if (S.mode === 'libera'){ opening(); masters(); }
    else $('.anp-eco').textContent = sotto();
    if (window.CNAnalisiPartita) try { window.CNAnalisiPartita.onRender(); } catch(e){}
    if (S.mode === 'partita' && window.CNAnalisiPartitaUI) try { window.CNAnalisiPartitaUI.onRender(); } catch(e){}
  }
  function sotto(){ var m = S.meta || {}; return m.titolo || ''; }
  function moveNo(n){ var p = n.padre && n.padre.fen ? n.padre.fen.split(' ') : ['', 'w', '', '', '', '1']; return {num:+p[5] || 1, w:p[1] === 'w'}; }
  function sym(n, i){   // simbolo accanto alla mossa: partita commentata (UI), «Analizza tutta la partita» (libera), o variante confermata dal motore
    if (i != null){
      if (S.mode === 'partita' && window.CNAnalisiPartitaUI) return window.CNAnalisiPartitaUI.tag(i);
      return window.CNAnalisiPartita ? window.CNAnalisiPartita.tag(i) : '';
    }
    var c = S.vlab[n.id]; return c && window.CNAnalisiPartitaUI ? window.CNAnalisiPartitaUI.icona(c) : '';
  }
  function mbtn(n, i, conNum){
    var mn = moveNo(n), cls = 'anp-m' + (n === T.corrente ? ' cur' : '') + (S.orig[n.id] === 'u' ? ' u' : '');
    return (conNum ? '<span class="anp-vn">' + mn.num + (mn.w ? '.' : '…') + '</span>' : '') +
      '<button type="button" data-id="' + esc(n.id) + '" class="' + cls + '">' + esc(it(n.san)) + sym(n, i) + '</button>';
  }
  function vline(n){   // una variante in linea, con le sotto-varianti tra parentesi
    var h = '', num = true;
    while (n){
      h += mbtn(n, null, num || moveNo(n).w); num = false;
      if (n.figli.length > 1){ h += n.figli.slice(1).map(function(x){ return '<span class="anp-vp">(' + vline(x) + ')</span>'; }).join(''); num = true; }
      n = n.figli[0];
    }
    return h;
  }
  function vblock(nodes, lv){ return nodes.map(function(x){ return '<div class="anp-v' + (S.orig[x.id] === 'u' ? ' u' : '') + '" style="--lv:' + lv + '">' + vline(x) + '</div>'; }).join(''); }
  S.vlab = {};
  function renderMoves(){
    if (!root) return;
    var m = main(), h = '', row = null;
    function flush(){ if (row){ h += '<div class="anp-r"><span class="anp-n">' + row.num + '.</span>' + (row.w || '<span class="anp-m anp-e">…</span>') + (row.b || '') + '</div>'; row = null; } }
    for (var i = 0; i < m.length; i++){
      var n = m[i], mn = moveNo(n), vars = n.padre.figli.slice(1);
      if (mn.w){ flush(); row = {num:mn.num, w:mbtn(n, i), b:''}; }
      else { if (!row) row = {num:mn.num, w:'', b:''}; row.b = mbtn(n, i); }
      if (vars.length){   // le alternative a questa mossa, subito dopo la sua riga
        flush(); h += vblock(vars, 1);
        if (mn.w && i + 1 < m.length) row = {num:mn.num, w:'', b:''};
      }
    }
    flush();
    if (S.mainLen != null && m.length){   // in una partita: le mosse giocate oltre la fine sono una variante
      var last = m[m.length - 1]; if (last.figli.length) h += vblock(last.figli, 1);
    } else if (S.mainLen != null && !m.length && T.radice.figli.length) h += vblock(T.radice.figli, 1);
    var box = $('.anp-moves');
    box.innerHTML = h ? '<div class="anp-nt">' + h + '</div>' : '<p class="anp-mu">Nessuna mossa. Trascina un pezzo, oppure toccalo e poi tocca la casa dove vuoi muoverlo.</p>';
    vediCorrente(); requestAnimationFrame(vediCorrente);
  }
  // blocco 5 rifiniture (Kiko 11-11, dubbio 8): la riga della mossa corrente è SEMPRE tutta visibile (frecce, tocchi, Vedi la variante,
  // Torna alla partita). Scorre SOLO la notazione (scrollIntoView sposterebbe anche la pagina e la scacchiera).
  function vediCorrente(){
    var box = root && $('.anp-moves'); if (!box || box.scrollHeight <= box.clientHeight + 1) return;
    var c = box.querySelector('.cur'); if (!c) return;
    var row = c.closest('.anp-r') || c.closest('.anp-v') || c, bb = box.getBoundingClientRect(), rb = row.getBoundingClientRect();
    if (rb.height > bb.height - 8) rb = c.getBoundingClientRect();
    if (rb.top < bb.top + 2) box.scrollTop -= Math.ceil(bb.top - rb.top) + 6;
    else if (rb.bottom > bb.bottom - 2) box.scrollTop += Math.ceil(rb.bottom - bb.bottom) + 6;
  }

  /* ---------- mosse: tocco + tocco, oppure trascinamento ---------- */
  var dg = null, dragDone = false;
  function sqAt(x, y){ var el = document.elementFromPoint(x, y); el = el && el.closest && el.closest('.anp-sq'); return el && root.contains(el) ? el.dataset.sq : null; }
  function dragStart(e){
    if (S.conf || (e.button != null && e.button > 0)) return;
    var s = e.target.closest('.anp-sq'); if (!s) return;
    var g = pos(), sq = s.dataset.sq, p = g.get(sq);
    if (!p || p.color !== g.turn()) return;
    dg = {from:sq, x:e.clientX, y:e.clientY, img:s.querySelector('img'), ghost:null, size:s.getBoundingClientRect().width};
    window.addEventListener('pointermove', dragMove, {passive:false});
    window.addEventListener('pointerup', dragEnd);
    window.addEventListener('pointercancel', dragEnd);
  }
  function dragMove(e){
    if (!dg) return;
    if (!dg.ghost){
      if (Math.hypot(e.clientX - dg.x, e.clientY - dg.y) < 6 || !dg.img) return;
      var gh = dg.img.cloneNode(); gh.className = 'anp-ghost'; gh.style.width = gh.style.height = dg.size + 'px';
      document.body.appendChild(gh); dg.ghost = gh; dg.img.style.opacity = '.3';
      S.sel = dg.from;
      var g = pos(), tos = g.moves({square:dg.from, verbose:true});
      tos.forEach(function(m){ var el = root.querySelector('.anp-sq[data-sq="' + m.to + '"]'); if (el) el.classList.add(g.get(m.to) ? 'cap' : 'dot'); });
      var fe = root.querySelector('.anp-sq[data-sq="' + dg.from + '"]'); if (fe) fe.classList.add('sel');
    }
    e.preventDefault();
    dg.ghost.style.transform = 'translate(' + (e.clientX - dg.size / 2) + 'px,' + (e.clientY - dg.size / 2) + 'px)';
  }
  function dragEnd(e){
    window.removeEventListener('pointermove', dragMove); window.removeEventListener('pointerup', dragEnd); window.removeEventListener('pointercancel', dragEnd);
    var d = dg; dg = null; if (!d || !d.ghost) return;
    d.ghost.remove(); dragDone = true; setTimeout(function(){ dragDone = false; }, 60);
    var to = e.type === 'pointerup' ? sqAt(e.clientX, e.clientY) : null, g = pos();
    var ms = to ? g.moves({square:d.from, verbose:true}).filter(function(m){ return m.to === to; }) : [];
    if (!ms.length){ S.sel = null; render(); return; }
    if (ms.some(function(m){ return m.promotion; })){ render(); askPromo(d.from, to, g.turn()); return; }
    play({from:d.from, to:to});
  }
  function onBoard(e){
    if (dragDone) return;
    if (S.conf){ conf(false); render(); return; }
    var s = e.target.closest('.anp-sq'); if (!s) return;
    var sq = s.dataset.sq, g = pos();
    if (S.sel){
      var ms = g.moves({square:S.sel, verbose:true}).filter(function(m){ return m.to === sq; });
      if (ms.length){
        if (ms.some(function(m){ return m.promotion; })){ askPromo(S.sel, sq, g.turn()); return; }
        play({from:S.sel, to:sq}); return;
      }
    }
    var p = g.get(sq); S.sel = (p && p.color === g.turn() && S.sel !== sq) ? sq : null; render();
  }
  function askPromo(from, to, color){
    S.promo = {from:from, to:to}; var box = $('.anp-promo');
    box.innerHTML = '<span>Promuovi a:</span>' + ['q','r','b','n'].map(function(t){ return '<button type="button" class="anp-pb" data-pr="' + t + '" aria-label="' + {q:'Donna',r:'Torre',b:'Alfiere',n:'Cavallo'}[t] + '"><img alt="" src="' + A.psrc(color + t.toUpperCase()) + '"></button>'; }).join('');
    box.hidden = false;
  }
  // una mossa (a mano o dal motore): se la partita continua con la stessa mossa si va avanti; altrimenti nasce una variante
  function play(m, origine){
    var from = T.corrente, wasMain = isMain(from), g = pos(), mv;
    try { mv = g.move(m); } catch(e){ mv = null; }
    S.sel = null; S.promo = null; if (root) $('.anp-promo').hidden = true;
    if (!mv){ render(); return null; }
    conf(false);
    var uci = mv.from + mv.to + (mv.promotion || ''), esiste = from.figli.some(function(x){ return x.uci === uci; });
    var n = T.aggiungiMossa(from, {from:mv.from, to:mv.to, promotion:mv.promotion});
    if (!n){ render(); return null; }
    if (!esiste && !isMain(n)) S.orig[n.id] = origine || 'u';
    if (wasMain && !isMain(n)) S.ritorno = from.id;     // il punto ESATTO da cui riprendere la partita
    try { if (A.Sound && A.Sound.play) A.Sound.play(mv.captured ? 'capture' : 'move'); } catch(e){}
    if (!origine) update();
    return n;
  }
  function afterNav(){ if (isMain(T.corrente)) S.ritorno = null; update(); }
  function nav(op){
    conf(false); S.sel = null; S.promo = null; if (root) $('.anp-promo').hidden = true;
    var n = T.corrente;
    if (op === 'avanti' && S.mainLen != null && isMain(n) && depth(n) >= S.mainLen) return;   // fine della partita: non si entra da soli nelle varianti
    if (op === 'fine' && S.mainLen != null && isMain(n)){ var m = main(); T.vaiA(m[m.length - 1] || T.radice); }
    else T[op]();
    if (n !== T.corrente) afterNav();
  }
  function go(k){   // k = semimossa della partita (0 = posizione iniziale)
    var m = main(); k = Math.max(0, Math.min(m.length, k));
    var n = k ? m[k - 1] : T.radice; if (n === T.corrente && !S.sel) return;
    conf(false); S.sel = null; T.vaiA(n); afterNav();
  }
  function torna(){
    conf(false); S.sel = null;
    var r = S.ritorno && T.nodo(S.ritorno);
    if (r && isMain(r)) T.vaiA(r);
    else { var n = T.corrente; while (n.padre && !isMain(n)) n = n.padre; T.vaiA(n); }
    S.ritorno = null; update();
  }
  function flip(){ S.flip = !S.flip; save(); render(); drawEval(); }
  function update(){ save(); render(); analyse(); }
  function conf(on){ if (S.conf === !!on) return; S.conf = !!on; }
  function banner(){
    var b = $('.anp-ban'), v = inVar() && !S.conf, tipo = v ? varTipo() : '';
    b.hidden = !v; root.classList.toggle('anp-invar', v);
    if (v){
      b.className = 'anp-ban ' + (tipo === 'u' ? 'u' : 'm');
      var t = tipo === 'u' ? 'La tua variante' : 'Stai esplorando una variante';
      var c = S.vlab[T.corrente.id], n = T.corrente;
      var extra = c && window.CNAnalisiPartitaUI ? ' · ' + esc(it(n.san)) + ': ' + esc(window.CNAnalisiPartitaUI.nome(c)) : '';
      b.querySelector('.anp-bt').innerHTML = '<b>' + t + '</b>' + extra;
    }
    var vv = $('.anp-vv');
    if (S.mode === 'partita'){
      if (v){ vv.textContent = 'Torna alla partita'; vv.disabled = false; vv.classList.add('torna'); }
      else { vv.textContent = 'Vedi la variante'; vv.classList.remove('torna'); vv.disabled = !(window.CNAnalisiPartitaUI && window.CNAnalisiPartitaUI.puoVariante()); }
      var n2 = T.corrente;
      root.querySelector('.anp-ctl [data-a=prev]').disabled = !n2.padre;
      root.querySelector('.anp-ctl [data-a=next]').disabled = !n2.figli.length || (isMain(n2) && depth(n2) >= S.mainLen);
    }
  }

  /* ---------- ingranaggio: una sola rotella, sotto la scacchiera (non la copre mai) ---------- */
  var gearOpen = false;
  function sw(k, on, t, sub){ return '<button type="button" class="anp-gi" role="switch" aria-checked="' + !!on + '" data-k="' + k + '"><span>' + esc(t) + (sub ? '<small>' + esc(sub) + '</small>' : '') + '</span><i class="anp-sw"></i></button>'; }
  function gear(on){
    gearOpen = !!on; if (!root) return;
    var g = $('.anp-gear'), p = AP(), h = '';
    $('.anp-gearbtn').setAttribute('aria-expanded', gearOpen ? 'true' : 'false');
    root.classList.toggle('anp-gearon', gearOpen);
    g.hidden = !gearOpen; if (!gearOpen) return;
    if (S.mode === 'partita'){
      h += sw('voce', p.voce, 'Voce dell\'istruttore', 'Il commento scritto resta sempre visibile');
      h += sw('frecce', p.frecce, 'Frecce', 'Azzurra: la mossa migliore');
      h += sw('minaccia', p.minaccia, 'Minaccia', 'Rossa: solo se il motore la conferma');
      h += '<div class="anp-gr"><span>Lingua dei commenti</span><div class="anp-seg" role="radiogroup">' +
        ['it', 'en'].map(function(l){ return '<button type="button" role="radio" data-lang="' + l + '" aria-checked="' + (p.lingua === l) + '" class="' + (p.lingua === l ? 'on' : '') + '">' + l.toUpperCase() + '</button>'; }).join('') + '</div></div>';
    } else {
      h += sw('frecce', p.frecce, 'Frecce', 'Azzurra: la mossa migliore del motore');
      h += sw('cloud', p.cloud, 'Valutazioni pronte di Lichess', 'Usa Internet: posizioni già analizzate dal cloud di Lichess');
    }
    var bg = (A.prefs && A.prefs.bg) === 'bianco' ? 'bianco' : 'notte';
    if (S.mode === 'partita') h += '<div class="anp-gr"><span>Tema</span><div class="anp-seg" role="radiogroup">' +
      [['notte', 'Scuro'], ['bianco', 'Chiaro']].map(function(x){ return '<button type="button" role="radio" data-bg="' + x[0] + '" aria-checked="' + (bg === x[0]) + '" class="' + (bg === x[0] ? 'on' : '') + '">' + x[1] + '</button>'; }).join('') + '</div></div>';
    if (S.mode === 'partita') h += '<button type="button" class="anp-gi anp-gflip" data-k="flip"><span>Ruota la scacchiera</span>' + svg('arrow-up-down', 18) + '</button>';
    else h += '<p class="anp-gnote">Tema chiaro/scuro: interruttore nella Home o Impostazioni › Aspetto. Ruota: tasto sotto la scacchiera.</p>';   // 14-11: niente doppioni
    g.innerHTML = h;
  }
  function onGear(e){
    var b = e.target.closest('button'); if (!b) return;
    if (b.dataset.lang){ setAP('lingua', b.dataset.lang); gear(true); if (window.CNAnalisiPartitaUI) window.CNAnalisiPartitaUI.onRender(); return; }
    if (b.dataset.bg){ try { if (A.pickEnv) A.pickEnv(b.dataset.bg); } catch(x){} gear(true); return; }
    var k = b.dataset.k; if (!k) return;
    if (k === 'flip'){ flip(); return; }
    setAP(k, !AP()[k]); gear(true);
    if (k === 'cloud') analyse();
    else if (k === 'voce' && window.CNAnalisiPartitaUI) window.CNAnalisiPartitaUI.voce(AP().voce);
    else { if (k === 'minaccia' && window.CNAnalisiPartitaUI) window.CNAnalisiPartitaUI.onRender(); drawArrow(); }
  }

  /* ---------- nome apertura + teoria (file dati separati) ---------- */
  function wbLang(){
    var p = (A.prefs && A.prefs.lang) || document.documentElement.lang || 'en';
    p = String(p).toLowerCase();
    return p.indexOf('it') === 0 ? 'it' : 'en';
  }
  function nomeKiko(keys){   // nome italiano della lista di Kiko per la linea giocata ('' se non c'è)
    if (!AK) return '';
    var x = null;
    for (var k = keys.length - 1; k >= 1 && x == null; k--) if (AK.pos[keys[k]] != null) x = AK.pos[keys[k]];
    for (var j = keys.length - 1; j >= 1 && x == null; j--) if (AK.fam[keys[j]] != null) x = AK.fam[keys[j]];
    var n = x != null && AK.nomi[x] ? String(AK.nomi[x].it || '') : '';
    return n.replace(/\.\s*$/, '');
  }
  function wbNomeIt(keys){   // titolo italiano di Wikibooks della posizione con nota più profonda ('' se non c'è)
    if (!WB) return '';
    for (var k = keys.length - 1; k >= 1; k--){ var w = WB[keys[k]]; if (w && w.nome_it) return String(w.nome_it).replace(/\.\s*$/, ''); }
    return '';
  }
  function opening(){
    var ecoEl = $('.anp-eco'), th = $('.anp-th');
    if (!ECO || !WB){ ecoEl.textContent = ''; th.innerHTML = '<p class="anp-mu">Carico le note d\'apertura…</p>'; loadData().then(function(){ if (root && !root.hidden) opening(); }); return; }
    var keys = fensUpTo(), name = null;
    for (var i = keys.length - 1; i >= 0 && !name; i--) if (ECO[keys[i]]) name = ECO[keys[i]];
    // 12-11: in italiano il nome viene dalla lista di Kiko (data/aperture_kiko.json, stessa regola dei commenti: la posizione con nome
    // più profonda, poi la famiglia); il codice ECO resta. Senza nome italiano si mostra solo il codice: mai il nome inglese.
    var it_ = wbLang() === 'it', nk = it_ ? nomeKiko(keys) : '', txt;
    if (it_ && S.mode !== 'partita'){
      // 14-11 ritocco (Kiko): nella Scacchiera di analisi libera SOLO il nome italiano (lista di Kiko, poi il titolo italiano di Wikibooks
      // della posizione più profonda); niente codice ECO tipo «C40» (resta solo nel suggerimento al passaggio del dito).
      txt = nk || wbNomeIt(keys);
      ecoEl.title = name ? name[0] : '';
    }
    else if (it_) txt = name ? name[0] + (nk ? ' · ' + nk : '') : nk;
    else txt = name ? name[0] + ' · ' + name[1] : '';
    ecoEl.textContent = txt || (T.corrente.padre || S.startFen !== START ? 'Analisi libera' : 'Posizione iniziale');
    if (!(it_ && S.mode !== 'partita')) ecoEl.title = txt || '';
    if (!T.corrente.padre && S.startFen === START){ th.innerHTML = '<p class="anp-mu">Gioca una mossa (o carica una partita) per vedere la teoria d\'apertura.</p>'; return; }
    var at = -1;
    for (var j = keys.length - 1; j >= 1; j--) if (WB[keys[j]]){ at = j; break; }
    if (at < 0){ th.innerHTML = '<p class="anp-mu">Nessuna nota di teoria per questa linea.</p>'; return; }
    var e = WB[keys[at]], note = '', lang = wbLang();
    var useIt = lang === 'it' && e.testo_it;
    var titolo = useIt ? (e.nome_it || e.nome) : e.nome;
    var corpo = useIt ? e.testo_it : e.testo;
    if (at < keys.length - 1){
      note = '<p class="anp-mu anp-sm">Nota della posizione dopo ' + esc(moveLabel(at)) + ': per la posizione attuale non c\'è una pagina.</p>';
    }
    var attr = useIt
      ? 'Fonte: <a href="' + esc(e.url) + '" target="_blank" rel="noopener">Wikibooks, Chess Opening Theory</a> · ' +
        '<a href="https://creativecommons.org/licenses/by-sa/4.0/deed.it" target="_blank" rel="noopener">CC BY-SA 4.0</a> · testo italiano (traduzione), estratto e abbreviato'
      : 'Source: <a href="' + esc(e.url) + '" target="_blank" rel="noopener">Wikibooks, Chess Opening Theory</a> · ' +
        '<a href="https://creativecommons.org/licenses/by-sa/4.0/" target="_blank" rel="noopener">CC BY-SA 4.0</a> · English text, extracted and shortened';
    th.innerHTML = (titolo ? '<p class="anp-thn">' + esc(titolo) + '</p>' : '') + note +
      '<p class="anp-tx" lang="' + (useIt ? 'it' : 'en') + '">' + esc(corpo) + '</p>' +
      '<p class="anp-src anp-sm">' + attr + '</p>';
  }
  function moveLabel(n){   // «3…Cc6» per la semimossa n (1-based) della linea
    var base = new Chess(S.startFen), n0 = +S.startFen.split(' ')[5] || 1, off = base.turn() === 'b' ? 1 : 0, i = n - 1;
    var num = n0 + Math.floor((i + off) / 2), white = (i + off) % 2 === 0;
    var pp = path(); return num + (white ? '. ' : '…') + it(pp[i] ? pp[i].san : '');
  }

  /* ---------- «Partite dei campioni»: albero d'apertura dal file separato data/campioni_albero.json ---------- */
  // chiave = hash FNV-1a (32 bit, base36) della FEN senza contatori: la stessa funzione hkey di strumenti/crea_campioni.js
  var MS = null, msP = null, msErr = false, msAll = false, msKey = '', MS_TOP = 8;   // msAll: «Mostra tutte», si azzera a ogni cambio di posizione
  function hkey(s){ var a = 0x811c9dc5; for (var i = 0; i < s.length; i++) a = Math.imul(a ^ s.charCodeAt(i), 16777619) >>> 0; return a.toString(36); }
  function loadMasters(){
    if (msP) return msP;
    msP = fetch('data/campioni_albero.json').then(function(r){ if (!r.ok) throw new Error(r.status); return r.json(); })
      .then(function(j){ MS = j || {p:{}}; }, function(){ msErr = true; msP = null; });
    return msP;
  }
  function pc(x, n){ return n ? Math.round(x * 100 / n) : 0; }
  var CAMPIONI_ON = false;   // 0.9.0 (app): «Partite dei campioni» solo al via di Kiko → sezione nascosta, file dati non caricato
  function masters(){
    var box = $('.anp-ms'); if (!box) return;
    if (!CAMPIONI_ON){ var sc = box.closest('.anp-mst'); if (sc) sc.hidden = true; return; }
    if (!box.__on){ box.__on = 1; box.onclick = function(e){ if (e.target.closest('[data-msall]')){ msAll = !msAll; masters(); return; } var b = e.target.closest('[data-san]'); if (b) play(b.dataset.san); }; }
    if (!MS){
      box.innerHTML = '<p class="anp-mu">' + (msErr ? 'Partite dei campioni non disponibili.' : 'Carico le partite dei campioni…') + '</p>';
      if (!msErr) loadMasters().then(function(){ if (root && !root.hidden) masters(); });
      return;
    }
    var mk = hkey(fkey(pos().fen())); if (mk !== msKey){ msKey = mk; msAll = false; }
    var raw = MS.p && MS.p[mk], src = '<p class="anp-src anp-sm">Partite a tavolino 2020-2026, giocatori 2200+ (Lichess, ' +
      '<a href="https://creativecommons.org/licenses/by-sa/4.0/deed.it" target="_blank" rel="noopener">CC BY-SA</a>)</p>';
    if (!raw){ box.innerHTML = '<p class="anp-mu">Nessuna partita dei campioni in questa posizione.</p>' + src; return; }
    var rows = raw.split(';').map(function(r){ var a = r.split(','); return {san:a[0], n:+a[1], w:+a[2], d:+a[3], elo:+a[4] + 2000}; });
    var tot = rows.reduce(function(t, r){ return t + r.n; }, 0), nf = function(x){ return x.toLocaleString('it-IT'); };
    box.innerHTML = '<div class="anp-mh" aria-hidden="true"><span>Mossa</span><span>Partite</span><span>Bianco · patta · Nero</span><span>Elo</span></div>' +
      (msAll ? rows : rows.slice(0, MS_TOP)).map(function(r){
        var pw = pc(r.w, r.n), pd = pc(r.d, r.n), pb = Math.max(0, 100 - pw - pd);
        function seg(c, p){ return '<i class="' + c + '" style="width:' + p + '%">' + (p >= 14 ? p + '%' : '') + '</i>'; }
        return '<button type="button" class="anp-mr" data-san="' + esc(r.san) + '" aria-label="' + esc(it(r.san)) + ': ' + nf(r.n) + ' partite, Bianco ' + pw + '%, patta ' + pd + '%, Nero ' + pb + '%, Elo medio ' + r.elo + '">' +
          '<b>' + esc(it(r.san)) + '</b><span class="anp-mn">' + nf(r.n) + '</span>' +
          '<span class="anp-wdb" aria-hidden="true">' + seg('w', pw) + seg('d', pd) + seg('b', pb) + '</span><span class="anp-me">' + r.elo + '</span></button>';
      }).join('') +
      (rows.length > MS_TOP ? '<button type="button" class="anp-btn anp-msall" data-msall="1" aria-expanded="' + msAll + '">' + (msAll ? 'Mostra meno' : 'Mostra tutte (' + rows.length + ')') + '</button>' : '') +
      '<p class="anp-mu anp-sm anp-mt">' + nf(tot) + ' partite in questa posizione. Tocca una mossa per giocarla.</p>' + src;
  }


  /* ---------- motore misto: cloud-eval (cache Lichess) → Stockfish nel telefono ---------- */
  var tok = 0, ctrl = null, timer = null, cache = {}, backoff = 0, cur = null, raf = 0;
  // cur = {fen, src:'cloud'|'telefono', lines:[{type,v,depth,pv}] con v dal punto di vista del BIANCO, done}
  function toWhite(l, fen){ var s = String(fen).split(' ')[1] === 'b' ? -1 : 1; return {type:l.type, v:l.v * s, depth:l.depth, pv:l.pv}; }
  function normArrocco(fen, uci){   // e1h1 / e8a8 (re prende la propria torre) → e1g1 / e8c8 (casa dove arriva il re)
    if (!uci || uci.length < 4) return uci;
    var fr = uci.slice(0, 2), to = uci.slice(2, 4);
    try {
      var g = new Chess(fen), pc = g.get(fr), tg = g.get(to);
      if (pc && pc.type === 'k' && tg && tg.type === 'r' && tg.color === pc.color)
        to = (to[0] > fr[0] ? 'g' : 'c') + to[1];
    } catch(e){}
    return fr + to + (uci[4] || '');
  }
  function frecciaArrocco(fen, uci){   // freccia del re: sempre dalla casa di partenza a g/c (O-O / O-O-O), ben visibile
    var u = normArrocco(fen, uci); if (!u || u.length < 4) return null;
    var fr = u.slice(0, 2), to = u.slice(2, 4);
    var item = {from:fr, to:to, color:'best', opacity:1};
    if (fr[1] === to[1] && fr[0] === 'e' && (to[0] === 'g' || to[0] === 'c')) item.short = 1;
    return item;
  }
  function normPv(fen, pv){   // la cloud-eval scrive l'arrocco come «re prende torre» (e1h1): lo portiamo a e1g1 per chess.js
    var g = new Chess(fen), out = [];
    for (var i = 0; i < pv.length; i++){
      var u = pv[i], fr = u.slice(0, 2), to = u.slice(2, 4), pc = g.get(fr), tg = g.get(to);
      if (pc && pc.type === 'k' && tg && tg.type === 'r' && tg.color === pc.color) to = (to[0] > fr[0] ? 'g' : 'c') + to[1];
      try { g.move({from:fr, to:to, promotion:u[4]}); } catch(e){ break; }
      out.push(fr + to + (u[4] || ''));
    }
    return out;
  }
  function cloud(fen){   // blocco 5: SOLO se acceso dall'ingranaggio (spento di base) e mai nella partita commentata
    if (!AP().cloud || S.mode !== 'libera') return Promise.resolve(null);
    if (navigator.onLine === false || Date.now() < backoff) return Promise.resolve(null);
    var k = fkey(fen); if (k in cache) return Promise.resolve(cache[k]);
    ctrl = window.AbortController ? new AbortController() : null;
    var c = ctrl, to = setTimeout(function(){ if (c) c.abort(); }, CLOUD_TIMEOUT);
    return fetch(CLOUD + '?multiPv=' + MPV_CLOUD + '&fen=' + encodeURIComponent(fen), {signal:c ? c.signal : undefined, headers:{Accept:'application/json'}})
      .then(function(r){
        clearTimeout(to);
        if (r.status === 429){ backoff = Date.now() + 60000; return null; }      // limite: un minuto di pausa (docs API Lichess)
        if (r.status === 404){ cache[k] = null; return null; }                   // posizione non in cache: si usa il telefono
        if (!r.ok) return null;
        return r.json().then(function(j){
          if (!j || !j.pvs || !j.pvs.length) { cache[k] = null; return null; }
          var out = j.pvs.map(function(p){ return {type:p.mate != null ? 'mate' : 'cp', v:p.mate != null ? p.mate : p.cp, depth:j.depth, pv:normPv(fen, String(p.moves || '').split(' ').filter(Boolean))}; });
          cache[k] = out; return out;                                              // cloud-eval: valori già dal punto di vista del Bianco
        });
      }, function(){ clearTimeout(to); return null; });
  }
  function analyse(){
    var my = ++tok;
    if (ctrl){ try { ctrl.abort(); } catch(e){} ctrl = null; }
    clearTimeout(timer);
    try { A.Engine.stop(); } catch(e){}
    var g = pos(), fen = g.fen();
    if (S.mode === 'partita' && isMain(T.corrente)){ cur = null; drawEval(); drawArrow(); return; }   // la partita ha già le sue valutazioni: niente motore dal vivo (batteria)
    if (window.CNAnalisiPartita && window.CNAnalisiPartita.busy()){ cur = null; engMsg(window.CNAnalisiPartita.t('pausa')); drawEval(); drawArrow(); return; }   // anteprima 20: un motore alla volta
    if (!S.engOn && S.mode === 'libera'){ cur = null; engMsg('Motore spento.'); drawEval(); drawArrow(); return; }
    if (g.isGameOver()){
      cur = {fen:fen, src:'', lines:[], done:true, over:g.isCheckmate() ? (g.turn() === 'w' ? -1 : 1) : 0};
      engMsg(g.isCheckmate() ? 'Scacco matto.' : g.isStalemate() ? 'Stallo: patta.' : 'Partita finita: patta.'); drawEval(); drawArrow(); return;
    }
    cur = {fen:fen, src:'', lines:[], done:false};
    engMsg('Analisi in corso…', true); drawEval(); drawArrow();
    timer = setTimeout(function(){                       // piccola attesa: se scorri le mosse veloce non parte niente
      cloud(fen).then(function(r){
        if (my !== tok) return;
        if (r){ cur = {fen:fen, src:'cloud', lines:r, done:true}; showEngine(); return; }
        local(fen, my);
      });
    }, 220);
  }
  function local(fen, my){
    cur = {fen:fen, src:'telefono', lines:[], done:false};
    var pm = S.mode === 'partita';
    A.Engine.analyse(fen, {multipv:pm ? 1 : MPV_LOCAL, depth:pm ? VAR_DEPTH : DEPTH, movetime:pm ? VAR_MOVETIME : MOVETIME, onInfo:function(l, f){
      if (my !== tok || f !== fen || !l) return;
      cur.lines = [toWhite(l, fen)].concat(cur.lines.slice(1)); schedule();
    }}).then(function(r){
      if (my !== tok || !r || r.fen !== fen) return;      // risposta di una posizione vecchia: ignorata
      if (r.lines && r.lines.length) cur.lines = r.lines.map(function(l){ return toWhite(l, fen); });
      cur.done = true; ricorda(fen, cur.lines[0]); showEngine();
    }, function(){ if (my === tok) engMsg('Il motore non è disponibile su questo dispositivo.'); });
  }
  function schedule(){ if (raf) return; raf = requestAnimationFrame(function(){ raf = 0; showEngine(); }); }
  function fmt(l){
    if (l.type === 'mate') return (l.v > 0 ? '+' : '−') + 'M' + Math.abs(l.v);
    var x = Math.abs(l.v / 100).toFixed(1); return (l.v > 0 ? '+' : l.v < 0 ? '−' : '') + x;
  }
  function pvText(fen, pv, max){
    var g = new Chess(fen), out = [], n = +fen.split(' ')[5] || 1, black = g.turn() === 'b';
    for (var i = 0; i < pv.length && i < max; i++){
      var u = pv[i], m; try { m = g.move({from:u.slice(0, 2), to:u.slice(2, 4), promotion:u[4]}); } catch(e){ break; }
      if (black) { if (i === 0) out.push(n + '…' + it(m.san)); else out.push(it(m.san)); n++; black = false; }
      else { out.push(n + '. ' + it(m.san)); black = true; }
    }
    return out.join(' ');
  }
  function engMsg(t, busy){ if (!root) return; $('.anp-eng').innerHTML = '<p class="anp-mu' + (busy ? ' anp-busy' : '') + '">' + esc(t) + '</p>'; }
  function showEngine(){
    if (!root || !cur) return;
    if (!cur.lines.length){ engMsg('Analisi in corso…', true); return; }
    var d = cur.lines[0].depth, src = cur.src === 'cloud' ? 'cloud' : 'telefono';
    $('.anp-eng').innerHTML = cur.lines.map(function(l, i){
      return '<button type="button" class="anp-ln' + (i ? '' : ' first') + '" data-l="' + i + '"><b>' + fmt(l) + '</b><span>' + esc(pvText(cur.fen, l.pv, i ? 6 : 8)) + '</span></button>';
    }).join('') + '<p class="anp-meta"><span class="anp-chip" title="' + (src === 'cloud' ? 'Analisi già pronta dal cloud di Lichess' : 'Stockfish sul tuo telefono') + '">' + src + ' · prof. ' + d + (cur.done ? '' : ' …') + '</span></p>';   // 14-11: un solo chip, in alto a destra
    drawEval(); drawArrow();
    if (cur.done && S.mode === 'partita' && window.CNAnalisiPartitaUI) try { window.CNAnalisiPartitaUI.onEngine(cur); } catch(e){}
  }
  function playLine(i){ var l = cur && cur.lines[i]; if (!l || !l.pv[0]) return; var u = l.pv[0]; play({from:u.slice(0, 2), to:u.slice(2, 4), promotion:u[4]}); }
  function drawEval(){
    if (!root) return;
    var bar = $('.anp-bar'), fill = $('.anp-fill'), lbl = $('.anp-bl');
    bar.classList.toggle('flip', S.flip); bar.classList.toggle('off', !S.engOn);
    var e = null, ue = S.mode === 'partita' && window.CNAnalisiPartitaUI && isMain(T.corrente) ? window.CNAnalisiPartitaUI.evalAt(depth(T.corrente)) : null;
    if (ue) e = ue;
    else if (cur && cur.over != null) e = cur.over ? {type:'mate', v:cur.over > 0 ? 1 : -1} : {type:'cp', v:0};
    else if (cur && cur.lines[0]) e = cur.lines[0];
    var U = window.EvalUtil, p = e ? (U ? U.pct(e) : 50) : 50;
    if (e && e.type === 'mate' && e.v === 0) p = 50;
    fill.style.height = p + '%';
    lbl.textContent = e ? (U ? U.label(e) : '') : '';
    lbl.className = 'anp-bl ' + (p >= 50 ? 'w' : 'b');
    bar.setAttribute('title', e && U ? U.words(e) : '');
    var ev = $('.anp-evr');   // 22b: valutazione sempre dal lato del Bianco (+ Bianco, − Nero; M5 / −M5)
    if (ev) ev.textContent = !e ? '' : e.type === 'mate' ? (e.v === 0 ? '' : (e.v > 0 ? 'M' : '−M') + Math.abs(e.v)) : (e.v > 0 ? '+' : e.v < 0 ? '−' : '') + Math.abs(e.v / 100).toFixed(1).replace('.', ',');
  }
  /* ---------- frecce (Frecce V5): azzurra = migliore, rossa = minaccia confermata, arancione = mossa giocata (Confronta) ---------- */
  function drawArrow(){
    if (!root) return; var s = $('.anp-arrows'); if (!s) return;
    var CA = window.ChessNodeArrows, UI = window.CNAnalisiPartitaUI, items = [];
    if (S.conf && UI) items = UI.confArrows() || [];
    else {
      if (AP().frecce){
        var u = null;
        if (S.mode === 'partita' && UI && isMain(T.corrente)) u = UI.bestAt(depth(T.corrente));
        else if ((S.engOn || S.mode === 'partita') && cur && cur.fen === T.corrente.fen && cur.lines[0]) u = cur.lines[0].pv[0];
        if (u) items.push({from:u.slice(0, 2), to:u.slice(2, 4), color:'best'});
      }
      if (S.mode === 'partita' && AP().minaccia && UI){ var t = UI.minaccia(); if (t) items.push({from:t.slice(0, 2), to:t.slice(2, 4), color:'threat'}); }
      // anteprima due schermate: «Mossa migliore» / «Vedi la variante» — freccia V5 sulla mossa appena giocata dal motore
      if (S.mode === 'partita' && !isMain(T.corrente) && T.corrente.uci && S.orig[T.corrente.id] === 'm'){
        var fa = frecciaArrocco(T.corrente.padre && T.corrente.padre.fen, T.corrente.uci) || {from:T.corrente.uci.slice(0, 2), to:T.corrente.uci.slice(2, 4), color:'best'};
        items.push(fa);
      }
    }
    if (!CA){ s.innerHTML = ''; return; }
    CA.render(s, items, {orient:S.flip ? 'b' : 'w', animate:anim() !== 'off'});
  }
  function setEngine(on){
    S.engOn = !!on; save();
    var b = $('.anp-engbtn'); b.setAttribute('aria-checked', S.engOn ? 'true' : 'false'); b.classList.toggle('on', S.engOn);
    analyse();
  }

  /* ---------- etichette delle TUE mosse nelle varianti: solo se il motore le conferma (stesse soglie dell'analisi) ---------- */
  var EV = {};   // fkey → valutazione (dal Bianco) {type, v, depth}
  function ricorda(fen, l){ if (!l) return; var k = fkey(fen), o = EV[k]; if (!o || (o.depth || 0) <= (l.depth || 0)) EV[k] = {type:l.type, v:l.v, depth:l.depth}; conferma(T.corrente); T.corrente.figli.forEach(conferma); }
  function evalOf(n){
    if (S.mode === 'partita' && isMain(n) && window.CNAnalisiPartitaUI){ var e = window.CNAnalisiPartitaUI.evalAt(depth(n)); if (e) return {type:e.type, v:e.v, depth:99}; }
    return EV[fkey(n.fen)] || null;
  }
  function winFor(e, col){ var P = window.CNPrecisione && window.CNPrecisione.P; if (!P) return null; var cp = e.type === 'mate' ? (e.v > 0 ? 10000 : e.v < 0 ? -10000 : 0) : e.v; return P(col === 'w' ? cp : -cp); }
  function conferma(n){
    if (!n || !n.padre || S.orig[n.id] !== 'u') return;
    var pe = evalOf(n.padre), ce = evalOf(n), AP2 = window.CNAnalisiPartita;
    if (!pe || !ce || !AP2 || (pe.depth || 0) < CONFERMA_DEPTH || (ce.depth || 0) < CONFERMA_DEPTH) return;
    var col = n.padre.fen.split(' ')[1], wB = winFor(pe, col), wA = winFor(ce, col); if (wB == null || wA == null) return;
    var loss = Math.max(0, wB - wA), Sg = AP2.SOGLIE, M = AP2.MARGINE_SOGLIA, c = null;
    c = loss > Sg.sva + M ? 'svarione' : loss > Sg.err + M ? 'errore' : loss > Sg.imp + M ? 'imprecisione' : null;
    if (c && AP2.PROTEZIONE_PERSA && wB <= AP2.PERSA) c = null;
    if (c && wA >= AP2.CHIARO && c !== 'imprecisione') c = 'imprecisione';
    if (!c && loss <= 1) c = 'ottima';
    if (c) S.vlab[n.id] = c; else delete S.vlab[n.id];
    if (n === T.corrente || n.padre === T.corrente) { renderMoves(); banner(); }
  }

  /* ---------- import / export ---------- */
  function msg(t){ if (root) $('.anp-msg').textContent = t || ''; }
  function carica(fen, sans, alla){   // nuova partita nell'albero (le varianti precedenti si chiudono)
    T.daMosse(sans, fen); S.startFen = T.radice.fen; S.orig = {}; S.ritorno = null; S.vlab = {}; S.sel = null; conf(false);
    var m = T.linea(); if (S.mainLen != null) S.mainLen = m.length;
    T.vaiA(alla === 0 ? T.radice : (m[m.length - 1] || T.radice));
    update();
  }
  // p16: posizione impossibile (il Re di chi non deve muovere è già sotto scacco)
  function reAvversarioInPresa(fen){ var q = String(fen).split(' '); q[1] = q[1] === 'w' ? 'b' : 'w'; q[3] = '-'; try { return new Chess(q.join(' ')).inCheck(); } catch(e){ return false; } }
  var ERR_RE = 'Posizione non valida: il Re di chi non deve muovere è sotto scacco.';
  function leggi(t){   // → {fen, sans} oppure {err}
    t = String(t || '').trim(); if (!t) return {err:'Incolla prima un PGN o una FEN.'};
    try {
      if (/^[rnbqkpRNBQKP1-8]+(\/[rnbqkpRNBQKP1-8]+){7}(\s|$)/.test(t)){
        var p = t.split(/\s+/).slice(0, 6), def = ['w', '-', '-', '0', '1'];
        while (p.length < 6) p.push(def[p.length - 1]);
        var f1 = new Chess(p.join(' ')).fen(); if (reAvversarioInPresa(f1)) return {err:ERR_RE};
        return {fen:f1, sans:[]};
      }
      var g2 = new Chess(); g2.loadPgn(t);
      var hd = g2.getHeaders ? g2.getHeaders() : {};
      if (hd.Variant && !/^(standard|from position)$/i.test(hd.Variant)) return {err:'Questa partita è una variante (' + hd.Variant + '): la scacchiera di analisi legge solo gli scacchi normali.'};
      var f0 = hd.FEN || START; new Chess(f0); if (hd.FEN && reAvversarioInPresa(f0)) return {err:ERR_RE};
      return {fen:f0, sans:g2.history(), hd:hd};
    } catch(e){
      var bad = String(e && e.message || '').match(/move[^:]*:\s*(\S+)/i);   // anteprima 20: dice QUALE mossa non torna (niente partite troncate in silenzio)
      return {err:'Non riesco a leggere questo testo: controlla che sia un PGN o una FEN validi.' + (bad ? ' Mossa non valida: ' + bad[1] + '.' : '')};
    }
  }
  function importText(t, alla){
    var r = leggi(t); if (r.err){ msg(r.err); return false; }
    if (root) $('.anp-scroll').scrollTop = 0;   // dopo l'import si torna alla scacchiera
    carica(r.fen, r.sans, alla);
    msg(r.sans.length ? 'Partita caricata: ' + r.sans.length + ' semimosse.' : 'Posizione caricata.');
    return true;
  }
  function pgnText(){
    var g = new Chess(S.startFen);
    if (S.startFen !== START){ g.setHeader('SetUp', '1'); g.setHeader('FEN', S.startFen); }
    main().forEach(function(n){ g.move(n.san); }); return g.pgn();
  }
  function copy(t, ok){
    function fb(){ var ta = document.createElement('textarea'); ta.value = t; ta.style.position = 'fixed'; ta.style.opacity = '0'; document.body.appendChild(ta); ta.select(); var r = false; try { r = document.execCommand('copy'); } catch(e){} ta.remove(); msg(r ? ok : 'Copia non riuscita.'); }
    if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(t).then(function(){ msg(ok); }, fb); else fb();
  }
  function fromExercise(){
    var g = A.game && A.game(); if (!g || !g.fen){ msg('Nessun esercizio aperto.'); return; }
    carica(g.fen(), [], 0); msg('Posizione dell\'esercizio caricata.');
  }

  /* ---------- 14-11 stampo: menu ⋯ (Importa / Esporta / Nuova) e Condividi ---------- */
  function sorgente(){   // la linea mostrata: la partita principale (o la variante in cui si è) fino all'ultima mossa, posizione = mossa attuale
    var p = path(), m = main(), inMain = !p.length || isMain(T.corrente), line = inMain ? m : p, ply = inMain ? p.length : p.length;
    var meta = S.mode === 'partita' ? (S.meta || {}) : null, tags = {}, avv = meta && meta.titolo ? String(meta.titolo).replace(/^Tu vs\s*/i, '') : '';
    if (meta){ tags.White = meta.me === 'b' ? (avv || '?') : 'Tu'; tags.Black = meta.me === 'b' ? 'Tu' : (avv || '?'); tags.Event = meta.titolo || 'Partita';
      if (meta.esito === 'p') tags.Result = '1/2-1/2'; else if (meta.esito === 'v' || meta.esito === 's') tags.Result = ((meta.esito === 'v') === (meta.me !== 'b')) ? '1-0' : '0-1'; }
    var eco = ($('.anp-eco') && $('.anp-eco').textContent) || '';
    return {fen0:S.startFen, sans:line.map(function(n){ return n.san; }), ply:ply, orient:S.flip ? 'b' : 'w', tags:tags,
      titolo:meta ? 'Analisi · ' + (meta.titolo || 'partita') : 'Scacchiera di analisi', etichetta:meta ? 'Analisi' : 'Scacchiera',
      sub:eco || (meta ? (meta.titolo || '') : 'Analisi libera'), nome:meta ? 'chessnode_analisi_partita' : 'chessnode_scacchiera'};
  }
  function condividi(tab){ gear(false); if (!(ST && ST.condividi(sorgente(), tab))) msg('Condividi non disponibile.'); }
  function altro(){
    if (!window.CNStampo) return;
    gear(false);
    var pm = S.mode === 'partita';
    var esp = [{id:'share', testo:'Condividi', sub:'PGN, immagine e GIF', icona:'share-2'},
      {id:'cfen', testo:'Copia FEN', sub:'La posizione sulla scacchiera', icona:'copy'},
      {id:'cpgn', testo:'Copia PGN', sub:'Tutte le mosse', icona:'copy'}];
    var gruppi = pm ? [esp, [{id:'flip', testo:'Ruota la scacchiera', icona:'arrow-up-down'}]] : [
      [{id:'paste', testo:'Incolla PGN o FEN', sub:'Scrivi o incolla nel riquadro «Importa una partita»', icona:'upload'},
       {id:'file', testo:'Da file…', sub:'Un file .pgn o .txt', icona:'upload'},
       {id:'ex', testo:'Dall\'esercizio', sub:'La posizione dell\'ultimo esercizio aperto', icona:'book-open'}],
      esp,
      [{id:'new', testo:'Nuova', sub:'Scacchiera dalla posizione iniziale', icona:'rotate-ccw'}]];
    window.CNStampo.menu({titolo:pm ? 'Analisi della partita' : 'Importa · Esporta · Nuova', gruppi:gruppi, scegli:function(a){
      if (a === 'share') condividi('pgn');
      else if (a === 'cfen') copy(pos().fen(), 'FEN copiata');
      else if (a === 'cpgn') copy(pgnText(), 'PGN copiato');
      else if (a === 'paste'){ var t = $('.anp-txt'); if (t){ t.scrollIntoView({block:'center'}); t.focus({preventScroll:true}); } }
      else if (a === 'file') $('.anp-file').click();
      else if (a === 'ex') fromExercise();
      else if (a === 'new'){ carica(START, []); msg(''); }
      else if (a === 'flip') flip();
    }});
  }

  /* ---------- apertura / chiusura ---------- */
  var lastF = null;
  function libera(){   // torna alla scacchiera libera com'era
    if (S.mode === 'libera') return;
    if (window.CNAnalisiPartita && window.CNAnalisiPartita.busy()) try { window.CNAnalisiPartita.cancel(); } catch(e){}   // un'analisi alla volta: resta salvata e si riprende
    S.mode = 'libera'; S.meta = null; S.mainLen = null; S.vlab = {};
    var sv = saved; saved = null;
    // blocco 5: la scacchiera libera torna con il SUO verso (non quello della partita appena vista)
    var vl = sv ? sv.flip : (function(){ try { return JSON.parse(localStorage.getItem(KEY) || '{}').flip; } catch(e){ return false; } })(); S.flip = !!vl;
    if (sv && T.daJSON(sv.albero)){ S.startFen = T.radice.fen; S.orig = sv.orig || {}; S.ritorno = sv.ritorno; }
    else { T.daMosse([], START); S.startFen = START; S.orig = {}; S.ritorno = null; }
  }
  function open(o){
    if (!root) build();
    o = o || {};
    if (o.partita){
      var r = leggi(o.pgn || o.fen);
      if (r.err){ if (window.CNP && window.CNP.toast) window.CNP.toast(r.err); else msg(r.err); return false; }
      if (S.mode === 'libera') saved = {albero:T.aJSON(), orig:S.orig, ritorno:S.ritorno, flip:S.flip};
      var stessa = S.mode === 'partita' && S.startFen === r.fen && main().map(function(n){ return n.san; }).join(' ') === r.sans.join(' ');
      if (!stessa && window.CNAnalisiPartita && window.CNAnalisiPartita.busy()) try { window.CNAnalisiPartita.cancel(); } catch(e){}
      S.mode = 'partita'; S.meta = o.partita;
      S.flip = o.partita.me === 'b';   // verso SEMPRE dal colore dell'utente (Bianco sotto se ha giocato il Bianco o se non si sa), anche riaprendo la stessa partita
      if (!stessa){ S.mainLen = r.sans.length; T.daMosse(r.sans, r.fen); S.startFen = T.radice.fen; S.orig = {}; S.ritorno = null; S.vlab = {}; S.sel = null; conf(false);
        var m = T.linea(); T.vaiA(o.partita.ply != null ? (m[o.partita.ply - 1] || T.radice) : T.radice); }
    } else {
      libera();
      if (o.pgn || o.fen) importText(o.pgn || o.fen);
    }
    var pm = S.mode === 'partita';
    root.classList.toggle('anp-pm', pm);
    $('.anp-tt b').textContent = 'Analisi';   // 12-11 (Kiko): titolo «Analisi» anche nella scacchiera libera (prima «Scacchiera di analisi», tagliato a 360 px)
    root.setAttribute('aria-label', pm ? 'Analisi della partita' : 'Scacchiera di analisi');
    $('.anp-close').setAttribute('aria-label', pm ? 'Torna all\'elenco delle analisi' : 'Indietro');
    gear(false);
    lastF = document.activeElement;
    root.hidden = false; document.documentElement.classList.add('anp-on');
    var b = $('.anp-engbtn'); b.setAttribute('aria-checked', S.engOn ? 'true' : 'false'); b.classList.toggle('on', S.engOn);
    if (pm && window.CNAnalisiPartitaUI) try { window.CNAnalisiPartitaUI.apri(S.meta); } catch(e){ console.warn(e); }
    loadData(); render(); analyse();
    try { allineaLibera(); requestAnimationFrame(allineaLibera); } catch(e){}
    return true;
  }
  function close(){
    if (!root || root.hidden) return;
    tok++; if (ctrl){ try { ctrl.abort(); } catch(e){} } clearTimeout(timer);
    try { A.Engine.stop(); } catch(e){}
    if (S.mode === 'partita'){ if (window.CNAnalisiPartitaUI) try { window.CNAnalisiPartitaUI.chiudi(); } catch(e){} }   // l'analisi della partita continua (la pagina Analisi mostra a che punto è)
    else if (window.CNAnalisiPartita) try { window.CNAnalisiPartita.cancel(); } catch(e){}   // si ferma davvero; resta salvata e si riprende
    gear(false); conf(false);
    root.hidden = true; document.documentElement.classList.remove('anp-on');
    if (lastF && lastF.focus) try { lastF.focus({preventScroll:true}); } catch(e){}
  }
  var renderBase = render; render = function(){ renderBase.apply(this, arguments); try { allineaLibera(); } catch(e){} };   // 14-11: l'intestazione può cambiare altezza (nome apertura su 2 righe)
  function isOpen(){ return !!(root && !root.hidden); }
  window.addEventListener('resize', function(){ try { allineaLibera(); } catch(e){} });
  // tasto Indietro / Esc / scorciatoie dell'app: la pagina conta come finestra aperta. Indietro chiude prima l'ingranaggio e il Confronta.
  try { var U = window.UI; if (U && U.modalOpen && !U.__anpWrap){ var mo = U.modalOpen; U.modalOpen = function(){ return isOpen() || mo(); }; U.__anpWrap = 1; } } catch(e){}
  document.addEventListener('keydown', function(ev){
    if (!isOpen()) return;
    var tg = ev.target && ev.target.tagName;
    if (ev.key === 'Escape'){
      ev.preventDefault(); ev.stopImmediatePropagation();
      if (window.CNStampo && CNStampo.menuAperto()){ CNStampo.chiudiMenu(); return; }
      if (window.CNShare && CNShare.isOpen && CNShare.isOpen()){ CNShare.close(); return; }
      if (gearOpen){ gear(false); return; }
      if (S.conf){ conf(false); render(); return; }
      close(); return;
    }
    if (tg === 'TEXTAREA' || tg === 'INPUT') return;
    if ((window.CNShare && CNShare.isOpen && CNShare.isOpen()) || (window.CNStampo && CNStampo.menuAperto())) return;   // 14-11: frecce alla finestra aperta
    var k = {ArrowLeft:'indietro', ArrowRight:'avanti'}[ev.key];
    if (k){ ev.preventDefault(); ev.stopImmediatePropagation(); nav(k); }
    else if (ev.key === 'Home'){ ev.preventDefault(); nav('inizio'); } else if (ev.key === 'End'){ ev.preventDefault(); nav('fine'); }
  }, true);

  /* ---------- voce nel foglio «Altro» ---------- */
  var sheet = document.getElementById('moreSheet');
  if (sheet){
    var card = sheet.querySelector('.ms-card'), ref = sheet.querySelector('.ms-ag') || sheet.querySelector('.ms-close');
    var g = document.createElement('div'); g.className = 'ms-group ms-anp';
    g.innerHTML = '<button type="button" class="ms-item" data-a="analisi">' + svg('search') + '<span>Scacchiera di analisi<small>Muovi liberamente, motore e teoria d\'apertura</small></span></button>';
    if (card && ref) card.insertBefore(g, ref);
    g.addEventListener('click', function(ev){ if (ev.target.closest('.ms-item')) setTimeout(open, 0); });
  }

  window.CNAnalisi = {open:open, close:close, isOpen:isOpen, load:importText, go:go, torna:torna, nav:nav, play:play,
    normArrocco:normArrocco, frecciaArrocco:frecciaArrocco,
    root:function(){ return root; }, eco:function(){ return loadData().then(function(){ return ECO; }); }, live:analyse, moves:renderMoves,   // anteprima 20
    mode:function(){ return S.mode; }, altro:altro, condividi:condividi, sorgente:function(){ return sorgente(); },
    state:function(){ return {startFen:S.startFen, sans:main().map(function(n){ return n.san; }), ply:mainPly(), engOn:S.engOn, src:cur && cur.src, depth:cur && cur.lines[0] && cur.lines[0].depth, done:cur && cur.done,
      mode:S.mode, inVariante:inVar(), variante:inVar() ? varTipo() : null, nodo:T.corrente.id, fen:T.corrente.fen, ritorno:S.ritorno, flip:S.flip}; },
    _int:{S:S, T:function(){ return T; }, main:main, isMain:isMain, depth:depth, update:update, render:render, drawArrow:drawArrow, drawEval:drawEval, renderMoves:renderMoves, banner:banner,
      conf:function(on){ conf(on); render(); }, AP:AP, esc:esc, it:it, svg:svg, root:function(){ return root; }, cur:function(){ return cur; }, anim:anim}};
})();
