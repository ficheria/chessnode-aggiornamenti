/* Grande aggiornamento, blocco 2 (10-11): aiuti comuni delle pagine nuove dentro la Home (iframe dell'app, stessa origine).
   - preferenze: si scrivono SEMPRE attraverso l'app (parent.__app.prefs + savePrefs), così l'app non le sovrascrive;
     aperta da sola (anteprima/prove) usa direttamente localStorage.
   - navigazione: CNP.vai('pagina.html') apre una pagina (con la pila dell'Indietro in home_app.js); CNP.indietro() torna indietro.
   - una pagina con viste interne (es. Impostazioni › Notifiche) imposta CNP.onBack = function(){ ...; return true; } e
     CNP.canBack = function(){ return true se c'è una vista interna aperta }: il tasto Indietro di Android le usa prima della pila.
   Nessuna rete, nessun segreto. */
(function(){
  'use strict';
  var P = null, A = null;
  try { if (window.parent !== window){ P = window.parent.CNHome || null; A = window.parent.__app || null; } } catch(e){ P = A = null; }
  var PKEY = 'chessnodeplay-prefs-v1';
  function rd(k){ try { return JSON.parse(localStorage.getItem(k)); } catch(e){ return null; } }
  function wr(k, v){ try { localStorage.setItem(k, JSON.stringify(v)); } catch(e){} }
  function esc(s){ return String(s == null ? '' : s).replace(/[&<>"']/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }
  function prefs(){ return (A && A.prefs) || rd(PKEY) || {}; }
  function setPref(k, v){
    if (A && A.prefs){ A.prefs[k] = v; try { A.savePrefs(); } catch(e){} return; }
    var p = rd(PKEY) || {}; p[k] = v; wr(PKEY, p);
  }
  var L = window.LUCIDE || {};
  function ic(n, s){ s = s || 22; return '<svg class="lu" viewBox="0 0 24 24" width="' + s + '" height="' + s + '" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (L[n] || '') + '</svg>'; }
  var pf = prefs(), Q = new URLSearchParams(location.search);
  var tema = Q.get('tema') || pf.bg; if (tema !== 'bianco') tema = 'notte';
  document.body.dataset.bg = tema;
  var ridotte = pf.anim === 'off' || pf.anim === 'reduced';
  try { if (!pf.anim && matchMedia('(prefers-reduced-motion: reduce)').matches) ridotte = true; } catch(e){}
  if (ridotte) document.documentElement.classList.add('cn-ferme');
  /* 11-11: classi per gli effetti UI (Attive / Ridotte / Spente). Se c'è effetti.js, lui precisa. */
  (function(){
    var m = 'attive';
    if (pf.anim === 'off') m = 'spente';
    else if (pf.anim === 'reduced' || ridotte) m = 'ridotte';
    try { if (m === 'attive' && matchMedia('(prefers-reduced-motion: reduce)').matches) m = 'ridotte'; } catch(e){}
    document.documentElement.classList.add('cn-mot-' + m);
    if (m !== 'attive') document.documentElement.classList.add('cn-ferme');
  })();

  function header(titolo, sotto){
    return '<header class="pg-hd"><button class="pg-back" data-back aria-label="Indietro">' + ic('chevron-left', 24) + '</button><h1>' + esc(titolo) + '</h1></header>' +
      (sotto ? '<p class="pg-sub">' + esc(sotto) + '</p>' : '');
  }
  var TABS = [['v2-home', 'Home', 'home.html'], ['v2-studia', 'Studia', 'studia.html'], ['v2-gioca', 'Gioca', 'gioca.html'], ['v2-analisi', 'Analisi', 'analisi.html'], ['v2-progressi', 'Progressi', 'progressi.html']];
  function bar(on){
    return '<nav class="cn-bar" aria-label="Sezioni">' + TABS.map(function(t, i){
      return '<a href="' + (t[2] || '#') + '" class="' + (i === on ? 'on' : '') + '" data-go="tab' + i + '"' + (i === on ? ' aria-current="page"' : '') + '>' + ic(t[0], 24) + t[1] + '</a>'; }).join('') + '</nav>';
  }
  function vai(pg){ if (P && P.apri) P.apri(pg); else location.href = pg; }
  function indietro(){ if (P && P.indietro) P.indietro(); else if (history.length > 1) history.back(); else location.href = 'home.html'; }
  function esterno(u){ if (P && P.esterno) P.esterno(u); else window.open(u, '_blank', 'noopener'); }
  var tT = 0;
  function toast(msg, annulla, ms){
    var old = document.querySelector('.cn-toast'); if (old) old.remove(); clearTimeout(tT);
    var t = document.createElement('div'); t.className = 'cn-toast'; t.setAttribute('role', 'status');
    t.innerHTML = '<span>' + esc(msg) + '</span>' + (annulla ? '<button type="button">Annulla</button>' : '');
    if (annulla) t.querySelector('button').onclick = function(){ t.remove(); annulla(); };
    document.body.appendChild(t); tT = setTimeout(function(){ t.remove(); }, ms || (annulla ? 5000 : 2400));
  }
  function conferma(titolo, testo, ok, cb){
    var o = document.createElement('div'); o.className = 'cn-ov';
    o.innerHTML = '<div class="cn-sheet" role="dialog" aria-modal="true"><h2>' + esc(titolo) + '</h2><p class="tx">' + esc(testo) + '</p>' +
      '<div class="bts"><button class="btn sec" data-no>Annulla</button><button class="btn" data-si>' + esc(ok) + '</button></div></div>';
    document.body.appendChild(o);
    var prevB = CNP.onBack, prevC = CNP.canBack;
    function chiudi(){ o.remove(); CNP.onBack = prevB; CNP.canBack = prevC; }
    CNP.onBack = function(){ chiudi(); return true; }; CNP.canBack = function(){ return true; };
    o.addEventListener('click', function(ev){ if (ev.target === o || ev.target.closest('[data-no]')){ chiudi(); } else if (ev.target.closest('[data-si]')){ chiudi(); cb(); } });
  }
  // controlli dell'app (cassetto Impostazioni): si imposta il valore e si lancia l'evento, così l'app fa tutto come prima
  function ctl(id, v){
    if (!A) return false;
    var d = window.parent.document, el = d.getElementById(id); if (!el) return false;
    if (el.type === 'checkbox') el.checked = !!v; else el.value = v;
    try { el.dispatchEvent(new window.parent.Event('input', {bubbles:true})); el.dispatchEvent(new window.parent.Event('change', {bubbles:true})); } catch(e){ return false; }
    return true;
  }
  function ctlVal(id){ if (!A) return null; var el = window.parent.document.getElementById(id); return el ? (el.type === 'checkbox' ? el.checked : el.value) : null; }
  // mini scacchiera (solo disegno). Ritocchi blocco 2 (10-11, Kiko): stessi colori e stessi pezzi della scacchiera vera
  // (prefs themeM / lightM / darkM / psetM dell'app; predefiniti Bosco + Elegante), anche le scacchiere a trama; uguale nei due temi.
  var SCACC = [['bosco','#efe7d4','#5f8f74'], ['ardesia','#eee6d6','#5d8088'], ['marrone','#f0d9b5','#b58863'], ['verde','#eeeed2','#769656'],
    ['blu','#dee3e6','#8ca2ad'], ['grigio','#e6e6e6','#9a9a9a'], ['lilla','#9f90b0','#7d4a8d'], ['avorio','#ececec','#c1c18e'],
    ['ghiaccio','#d9e4e8','#7ba1b5'], ['torneo','#eaeae4','#316549'], ['noce','#b89472','#87624d','scacchiere/noce.jpg'],
    ['pergamena','#dad6b4','#ae9d6c','scacchiere/pergamena.jpg'], ['acero','#c3986a','#916348','scacchiere/acero.jpg'],
    ['marmo','#d0dee2','#698e9a','scacchiere/marmo_azzurro.jpg']];
  function scacc(){   // [chiara, scura, trama|null, id]
    var p = rd(PKEY) || {}; if (A && A.prefs) p = A.prefs;
    var id = p.themeM || 'bosco';
    if (id === 'custom') return [p.lightM || SCACC[0][1], p.darkM || SCACC[0][2], null, 'custom'];
    var L2 = (A && A.THEMES) ? A.THEMES.map(function(t){ return [t[0], t[2], t[3], t[4]]; }) : SCACC;
    var t = L2.filter(function(x){ return x[0] === id; })[0] || L2[0];
    return [t[1], t[2], t[3] || null, t[0]];
  }
  function pezzi(){ return (window.cnPezzi && window.cnPezzi()) || (window.PIECES && (PIECES.elegante || PIECES.chessnode)) || {}; }
  function mb(fen, px){ var PZ = pezzi(), c = scacc(), h = '', r = 0;
    String(fen || '8/8/8/8/8/8/8/8').split(' ')[0].split('/').forEach(function(row){ var f = 0; row.split('').forEach(function(ch){
      if (/\d/.test(ch)){ for (var i = 0; i < +ch; i++){ h += '<div class="' + ((r + f) % 2 ? 'd' : '') + '"></div>'; f++; } }
      else { var k = (ch === ch.toUpperCase() ? 'w' : 'b') + ch.toUpperCase(); h += '<div class="' + ((r + f) % 2 ? 'd' : '') + '"><img alt="" src="' + (PZ[k] || '') + '"></div>'; f++; } }); r++; });
    return '<div class="mb' + (c[2] ? ' mb-tex' : '') + '" data-sc="' + esc(c[3]) + '" style="width:' + px + 'px;height:' + px + 'px;--sql:' + c[0] + ';--sqd:' + c[1] +
      (c[2] ? ';background-image:url(' + c[2] + ')' : '') + '" aria-hidden="true">' + h + '</div>'; }
  function versione(cb){ try { if (window.parent.__cnVersion){ window.parent.__cnVersion(cb); return; } } catch(e){} cb('web'); }

  var CNP = window.CNP = {P:P, A:A, rd:rd, wr:wr, esc:esc, prefs:prefs, setPref:setPref, ic:ic, header:header, bar:bar, vai:vai, indietro:indietro, esterno:esterno,
    toast:toast, conferma:conferma, mb:mb, scacc:scacc, pezzi:pezzi, ctl:ctl, ctlVal:ctlVal, versione:versione, ridotte:ridotte, tema:tema, inApp:!!P,
    LIBRO:'https://www.amazon.it/dp/B0HMWH1QRQ', TITOLO:"L'ultima mossa non esiste",
    PLAY:'https://play.google.com/store/apps/details?id=it.chessnode.play', onBack:null, canBack:null};
  // Indietro (Android / Esc): prima le viste interne della pagina, poi la pila di home_app.js
  window.__cnIndietro = function(){ try { return !!(CNP.onBack && CNP.canBack && CNP.canBack() && CNP.onBack()); } catch(e){ return false; } };
  window.__cnPuoTornare = function(){ try { return !!(CNP.canBack && CNP.canBack()); } catch(e){ return false; } };
  document.addEventListener('click', function(ev){
    var b = ev.target.closest('[data-back]'); if (b){ ev.preventDefault(); indietro(); return; }
    var g = ev.target.closest('[data-pg]'); if (g){ ev.preventDefault(); vai(g.dataset.pg); return; }
    var x = ev.target.closest('[data-ext]'); if (x){ ev.preventDefault(); esterno(x.dataset.ext); }
  });
  // fuori dall'app (anteprima aperta da sola) Esc torna indietro
  if (!P) window.addEventListener('keydown', function(ev){ if (ev.key === 'Escape'){ if (!window.__cnIndietro()) indietro(); } });
  // pagine vecchie (Progressi, Statistiche bot): la barra in basso diventa quella nuova, con le icone v2
  function rifaiBarre(){
    [].forEach.call(document.querySelectorAll('nav.hm-tab'), function(n){
      var on = -1; [].forEach.call(n.querySelectorAll('.tab'), function(a, i){ if (a.classList.contains('on')) on = i; });
      var tmp = document.createElement('div'); tmp.innerHTML = bar(on); n.replaceWith(tmp.firstChild);
    });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', rifaiBarre); else rifaiBarre();
  CNP.rifaiBarre = rifaiBarre;
})();
