/* Puzzle Random — 10000 puzzle dal database Lichess (CC0), proposti in base al livello dell'utente.
   Base: da_integrare/puzzle_caso_08-11/v2/puzzle_misti.js (08-11). Blocco 4 del grande aggiornamento (11-11):
   - ingresso da Studia (pagina Puzzle Random, schema 26), non più dal foglio «Altro»;
   - ripasso proprio 1 · 3 · 7 giorni (max 10 al giorno), separato dal Ripasso dei 1001;
   - salvataggio col segnalibro (stesso tasto dell'esercizio) e toast «Puzzle salvato · Annulla»;
   - un puzzle già giocato non cambia più il Puzzle rating (niente punti facili rifacendolo);
   - Esercizio del giorno (giorno.js) e livelli di difficoltà (fasce) aperti da qui.
   Usa la schermata esercizi dell'app così com'è: questo file prepara i puzzle nel formato dei 1001 e sceglie il prossimo.
   - Nessun commento didattico, voce solo coi commenti generici registrati: solo la linea della soluzione.
   - Puzzle rating (stile Elo, parte da 600): giusto al primo colpo → sale, errore / soluzione vista → scende.
   - Progressi, rating, ripasso e salvati stanno in un archivio SEPARATO (chessnodeplay-puzzle-v1): i 1001 esercizi e le loro
     statistiche (precisione, Tris, ripasso) non cambiano (stats.js/progressi.js/app.js ignorano c:'pz'). Conta per Obiettivo di oggi,
     Costanza e Impegno (diario e tempo). Il puzzle aperto è registrato in byN solo mentre è aperto.
   Dati: puzzle_data.js (window.PUZ_DATA, ordinati per difficoltà). */
(function(){
  'use strict';
  var A = window.__app, D = window.PUZ_DATA;
  if (!A || !D || !window.Chess) return;
  var BASE = 100000, KEY = 'chessnodeplay-puzzle-v1', START = 600, STEPS = [1, 3, 7], MAXDAY = 10;
  var CH = {id:'pz', name:'Puzzle Random', intro:[], list:[]};
  A.chById.pz = CH;
  function $(id){ return document.getElementById(id); }

  // ---------- archivio ----------
  var S = {lvl:START, played:{}, favs:[], cnt:0, hist:[], rev:{}, rd:null, ft:{}};
  try { var raw = JSON.parse(localStorage.getItem(KEY) || 'null'); if (raw && typeof raw === 'object'){ S.lvl = +raw.lvl || START; S.played = raw.played || {}; S.favs = raw.favs || []; S.cnt = raw.cnt || 0; S.hist = raw.hist || []; S.rev = raw.rev || {}; S.rd = raw.rd || null; S.ft = raw.ft || {}; } } catch(e){}
  function save(){ try { localStorage.setItem(KEY, JSON.stringify(S)); } catch(e){} try { document.dispatchEvent(new CustomEvent('cnpz:change')); } catch(e){} }

  var IDX = {}; D.forEach(function(p, i){ IDX[p[0]] = i; });

  // ---------- giorni (ora locale) ----------
  function dk(t){ var d = new Date(t == null ? Date.now() : t); return d.getFullYear() + '-' + ('0' + (d.getMonth() + 1)).slice(-2) + '-' + ('0' + d.getDate()).slice(-2); }
  function today(){ return dk(); }
  function addDays(k, n){ var p = k.split('-'); return dk(new Date(+p[0], +p[1] - 1, +p[2] + n, 12).getTime()); }

  // ---------- costruzione dell'esercizio nel formato dei 1001 ----------
  var PN = {p:'pedone', n:'Cavallo', b:'Alfiere', r:'Torre', q:'Donna', k:'Re'};
  function voice(m){
    var s;
    if (m.flags.indexOf('k') >= 0) s = 'arrocco corto';
    else if (m.flags.indexOf('q') >= 0) s = 'arrocco lungo';
    else {
      s = PN[m.piece] + (m.captured ? ' prende in ' : ' in ') + m.to;
      if (m.promotion) s += ', promuove a ' + PN[m.promotion];
    }
    var t = m.san.slice(-1);
    return s + (t === '#' ? ', scacco matto' : t === '+' ? ', scacco' : '');
  }
  var cache = {};
  function build(i){
    if (cache[i]) return cache[i];
    var p = D[i], mv = p[2].split(' '), g = new Chess(p[1]);
    function mk(u){ return g.move({from:u.slice(0,2), to:u.slice(2,4), promotion:u[4] || undefined}); }
    var first = mk(mv[0]), fenAfter = g.fen(), sol = [], line = [], mate = false;
    var num = +fenAfter.split(' ')[5];
    for (var k = 1; k < mv.length; k++){
      var turn = g.turn(), m = mk(mv[k]);
      sol.push([mv[k], A.itSan(m.san), voice(m)]);
      var mine = (k % 2 === 1);
      var pre = turn === 'w' ? num + '.' : (k === 1 ? num + '...' : '');
      line.push((mine ? '<b>' : '') + pre + A.itSan(m.san) + (mine ? '</b>' : ''));
      if (turn === 'b') num++;
    }
    mate = g.isCheckmate();
    var th = ' ' + p[4] + ' ';
    var res = (mate || /\smate/.test(th)) ? 'mate' : /\sequality\s/.test(th) ? 'draw' : 'win';
    var ex = {n:BASE + i + 1, c:'pz', st:'v', fen:fenAfter, lm:{from:first.from, to:first.to}, sol:sol,
      txt:'Soluzione: ' + line.join(' '), voi:'',   // voce: solo i commenti generici registrati degli istruttori
      res:res, src:{id:p[0], r:p[3]}, pz:{id:p[0], r:p[3], i:i, before:p[1], first:mv[0]}};
    if (res !== 'mate') ex.task = res === 'draw' ? 'muove e si salva con la patta.' : 'muove e trova la mossa migliore.';
    cache[i] = ex; return ex;
  }
  // tipo di matto dai temi Lichess (per il testo della notifica e delle schede): «Matto in 2», altrimenti ''
  function matto(id){ var i = IDX[id]; if (i == null) return 0; var m = / mateIn(\d) /.exec(' ' + D[i][4] + ' '); return m ? +m[1] : 0; }
  function info(id){ var i = IDX[id]; if (i == null) return null; var p = D[i]; return {id:p[0], r:p[3], i:i, n:BASE + i + 1, fen:p[1], matto:matto(id), mosse:Math.ceil((p[2].split(' ').length - 1) / 2), temi:p[4]}; }
  // posizione mostrata (dopo la mossa dell'avversario) per le mini scacchiere, calcolata con chess.js (niente FEN scritte a mano)
  function fenDi(id){ var i = IDX[id]; if (i == null) return ''; return build(i).fen; }

  // ---------- registrazione temporanea in byN (i 1001 e le loro statistiche non vedono i puzzle) ----------
  var curN = null;
  function reg(ex){
    if (curN != null && curN !== ex.n) delete A.byN[curN];
    A.byN[ex.n] = ex; curN = ex.n;
    window.CN_MOSSA_PRIMA = window.CN_MOSSA_PRIMA || {};
    window.CN_MOSSA_PRIMA[ex.n] = [ex.pz.before, ex.pz.first];
  }
  function isPz(){ var e = A.state && A.state.ex; return !!(e && e.c === 'pz'); }

  // ---------- fasce di difficoltà (pagina Puzzle Random, schema 26 S4) ----------
  var BANDE = [{id:'b1', nome:'Principiante', da:0, a:1000}, {id:'b2', nome:'Facile', da:1000, a:1400}, {id:'b3', nome:'Medio', da:1400, a:1800},
               {id:'b4', nome:'Difficile', da:1800, a:2200}, {id:'b5', nome:'Esperto', da:2200, a:99999}];
  function lower(r){ var lo = 0, hi = D.length; while (lo < hi){ var m = (lo + hi) >> 1; if (D[m][3] < r) lo = m + 1; else hi = m; } return lo; }
  function bande(){
    return BANDE.map(function(b){
      var i0 = lower(b.da), i1 = lower(b.a), fatti = 0, rip = 0;
      for (var j = i0; j < i1; j++){ var id = D[j][0]; if (S.played[id]) fatti++; if (S.rev[id]) rip++; }
      return {id:b.id, nome:b.nome, da:b.da, a:b.a, tot:i1 - i0, fatti:fatti, rip:rip, i0:i0, i1:i1};
    });
  }

  // ---------- scelta del prossimo ----------
  // i 14 puzzle non giocati più vicini al rating r (dentro [i0, i1) se data una fascia); rnd = funzione casuale (giorno.js la fissa per data)
  function pickNear(r, i0, i1, rnd){
    i0 = i0 || 0; i1 = i1 == null ? D.length : i1;
    var c = Math.max(i0, Math.min(i1 - 1, lower(r))), cand = [], d = 0;
    while (cand.length < 14 && (c - d >= i0 || c + d < i1)){
      [c + d, c - d - 1].forEach(function(j){ if (j >= i0 && j < i1 && !S.played[D[j][0]] && cand.indexOf(j) < 0 && cand.length < 14) cand.push(j); });
      d++;
    }
    return cand.length ? cand[Math.floor((rnd || Math.random)() * cand.length)] : -1;
  }
  function pickNext(){ return pickNear(S.lvl); }
  function expected(r){ return 1 / (1 + Math.pow(10, (r - S.lvl) / 400)); }
  var scored = false;
  function score(v){
    if (scored || !isPz()) return; scored = true;
    var e = A.state.ex, id = e.pz.id;
    rivedi(id, v);
    if (S.played[id]){ save(); return; }   // già giocato: il rating non si muove (niente punti rifacendo lo stesso puzzle)
    var r = e.pz.r, k = S.cnt < 20 ? 48 : 28;
    S.lvl = Math.max(450, Math.min(3000, Math.round(S.lvl + k * (v - expected(r)))));
    S.cnt++;
    S.played[id] = v ? 's' : 'e';
    S.ft[id] = Date.now();
    save(); paint();
  }

  // ---------- ripasso dei puzzle: errore → torna dopo 1 giorno; giusto al primo colpo → 3, poi 7, poi esce. Max 10 al giorno ----------
  function rday(){ var k = today(); if (!S.rd || S.rd.day !== k) S.rd = {day:k, done:[]}; return S.rd; }
  function isDue(id){ var r = S.rev[id]; return !!(r && r.due <= today()); }
  function rivedi(id, ok){
    var r = S.rev[id], due = isDue(id);
    if (due){ var rd = rday(); if (rd.done.indexOf(id) < 0) rd.done.push(id); }
    if (!ok){ r = S.rev[id] || (S.rev[id] = {s:0, due:'', w:0}); r.s = 0; r.w = (r.w || 0) + 1; r.due = addDays(today(), STEPS[0]); return; }
    if (r && due){ r.s++; if (r.s >= STEPS.length) delete S.rev[id]; else r.due = addDays(today(), STEPS[r.s]); }
  }
  function dueList(){ var k = today(); return Object.keys(S.rev).filter(function(id){ return IDX[id] != null && S.rev[id].due <= k; }).sort(function(a, b){ var x = S.rev[a], y = S.rev[b]; return (x.due < y.due ? -1 : x.due > y.due ? 1 : 0) || ((y.w || 0) - (x.w || 0)); }); }
  function todayList(){ var r = rday(), left = Math.max(0, MAXDAY - r.done.length); return dueList().filter(function(id){ return r.done.indexOf(id) < 0; }).slice(0, left); }
  function queue(){ return Object.keys(S.rev).filter(function(id){ return IDX[id] != null; }); }

  // ---------- apertura ----------
  var hist = [];            // puzzle già visti in questa sessione (per «indietro»)
  var modo = {t:'liv'};     // liv = vicino al rating · banda = una fascia · rip = ripasso · giorno = Esercizio del giorno
  function apri(i, noPush){
    var ex = build(i);
    if (!noPush && curN != null && isPz()) hist.push(A.state.ex.pz.i);
    reg(ex); scored = false;
    A.loadEx(ex.n, true);
  }
  function open(arg){
    if (arg && /^b\d$/.test(arg)){ var b = bande().filter(function(x){ return x.id === arg; })[0]; if (b){ modo = {t:'banda', b:b}; var i = pickNear(S.lvl, b.i0, b.i1); if (i < 0){ msg('Hai giocato tutti i puzzle di questa fascia.'); return; } apri(i); return; } }
    if (arg === 'caso'){ modo = {t:'liv'}; var lib = []; for (var t = 0; t < 40 && lib.length < 1; t++){ var j = Math.floor(Math.random() * D.length); if (!S.played[D[j][0]]) lib.push(j); } if (lib.length){ apri(lib[0]); return; } }
    modo = {t:'liv'}; next();
  }
  function next(){
    if (modo.t === 'rip'){ var q = todayList().filter(function(id){ return !(isPz() && A.state.ex.pz.id === id); }); if (q.length){ apri(IDX[q[0]]); return; } modo = {t:'liv'}; msg('Ripasso dei puzzle finito per oggi.'); }
    if (modo.t === 'banda'){ var i0 = pickNear(S.lvl, modo.b.i0, modo.b.i1); if (i0 >= 0){ apri(i0); return; } modo = {t:'liv'}; }
    if (modo.t === 'giorno') modo = {t:'liv'};
    var i = pickNext(); if (i < 0){ msg('Hai giocato tutti i puzzle: complimenti!'); return; } apri(i);
  }
  function ripasso(){ var q = todayList(); if (!q.length){ msg('Nessun puzzle da ripassare oggi.'); open(); return; } modo = {t:'rip'}; apri(IDX[q[0]]); }
  function prev(){ var i = hist.pop(); if (i != null) apri(i, true); }
  function openFavs(){
    var f = S.favs.filter(function(id){ return IDX[id] != null; });
    if (!f.length){ msg('Nessun puzzle salvato: tocca il segnalibro durante un puzzle.'); return; }
    modo = {t:'liv'}; apri(IDX[f[0]]);
  }
  function openId(id, m){ if (IDX[id] != null){ modo = m || {t:'liv'}; apri(IDX[id]); } }

  // ---------- grafica (solo testi e stato del segnalibro, nessun cambio di layout) ----------
  function isFavId(id){ return S.favs.indexOf(id) >= 0; }
  function isFav(){ return isPz() && isFavId(A.state.ex.pz.id); }
  function toggleFav(id){ var k = S.favs.indexOf(id); if (k >= 0) S.favs.splice(k, 1); else S.favs.push(id); save(); paint(); return k < 0; }
  function paint(){
    if (!isPz()) return;
    var e = A.state.ex;
    var t = $('exTitle'); if (t) t.textContent = 'Puzzle ' + e.pz.r;
    var c = $('chapterName'); if (c) c.textContent = 'Puzzle Random';
    var b = $('badges');
    if (b){
      var st = S.played[e.pz.id];
      b.innerHTML = '<span class="badge info" title="Sale quando risolvi, scende quando sbagli. I puzzle si adattano a te.">Puzzle rating: ' + S.lvl + '</span>' +
        (st === 's' ? '<span class="badge ok">✓ già risolto</span>' : st === 'e' ? '<span class="badge warn">già giocato con errori</span>' : '');
    }
    var fb = $('favBtn'); if (fb){ var on = isFav(); fb.textContent = on ? '★' : '☆'; fb.classList.toggle('on', on); fb.title = on ? 'Togli dai salvati' : 'Salva'; }
    var pv = $('prevEx'); if (pv) pv.disabled = !hist.length;
    var nx = $('nextEx'); if (nx) nx.disabled = false;
    var vf = $('v6Fav'); if (vf){ vf.classList.toggle('on', isFav()); vf.setAttribute('aria-pressed', isFav() ? 'true' : 'false'); }
    fixTitles();
  }
  // i titoli della schermata, della modalità concentrazione e dell'Analisi derivano dal numero: per i puzzle mostrano la difficoltà
  var re = /Esercizio 1\d{5}/, GG = ['Domenica', 'Lunedì', 'Martedì', 'Mercoledì', 'Giovedì', 'Venerdì', 'Sabato'];
  function fixTitles(){
    document.documentElement.classList.toggle('cn-giorno', isPz() && modo.t === 'giorno');   // titolo lungo: senza le frecce ‹ › in alto
    if (!isPz()) return;
    var r = A.state.ex.pz.r, gio = modo.t === 'giorno';
    ['v6Title', 'fTitle', 'anaTitle', 'exTitle'].forEach(function(id){
      var el = $(id); if (el && re.test(el.textContent)) el.textContent = el.textContent.replace(re, gio && id === 'v6Title' ? 'Esercizio del giorno' : 'Puzzle ' + r);
    });
    var sb = $('v6Sub'), want = gio ? GG[new Date().getDay()] + ' · difficoltà ' + r : modo.t === 'rip' ? 'Ripasso dei puzzle' : 'Puzzle Random';
    if (sb && sb.textContent !== want && /^(Puzzle Random|Ripasso dei puzzle|.+ · difficoltà \d+)$/.test(sb.textContent)) sb.textContent = want;
  }
  var mo = new MutationObserver(fixTitles);
  ['v6Title', 'v6Sub', 'fTitle', 'anaTitle', 'exTitle'].forEach(function(id){ var el = $(id); if (el) mo.observe(el, {childList:true, characterData:true, subtree:true}); });
  document.addEventListener('cnp:load', function(){
    if (isPz()) paint();
    else { if (curN != null){ delete A.byN[curN]; curN = null; } modo = {t:'liv'}; fixTitles(); }   // si è passati a un esercizio normale
  });
  document.addEventListener('cnp:mistake', function(){ score(0); });
  document.addEventListener('cnp:show', function(){ score(0); });
  document.addEventListener('cnp:giveup', function(){ score(0); });
  document.addEventListener('cnp:hint', function(){ score(0); });   // 14-11 (Kiko t1936u): anche un solo aiuto conta
  document.addEventListener('cnp:solved', function(ev){
    if (!isPz()) return;
    var d = ev.detail || {};
    score(d.perfect ? 1 : 0);
    // il pulsante «Esercizio successivo» propone il prossimo puzzle del livello, non il n+1 dei 1001
    var f = $('fbNext'); if (f) f.onclick = next;
    var id = A.state.ex.pz.id;
    if (!S.played[id]) S.played[id] = d.perfect ? 's' : 'e';
    try { document.dispatchEvent(new CustomEvent('cnpz:solved', {detail:{id:id, ok:!!d.perfect, giorno:modo.t === 'giorno'}})); } catch(e){}
    save(); paint();
  });
  document.addEventListener('cnp:reset', function(){ S.lvl = START; S.played = {}; S.cnt = 0; S.rev = {}; S.rd = null; S.ft = {}; save(); });

  // ---------- pulsanti dell'app, solo quando è aperto un puzzle ----------
  function guard(id, fn){
    var el = $(id); if (!el) return;
    el.addEventListener('click', function(ev){ if (!isPz()) return; ev.stopImmediatePropagation(); ev.preventDefault(); fn(); }, true);
  }
  guard('nextEx', next);
  guard('prevEx', prev);
  guard('favBtn', function(){ toggleFav(A.state.ex.pz.id); });

  // ---------- fine puzzle: «Continua» propone il prossimo puzzle, non il prossimo tema dei 1001 ----------
  function msg(t){ try { if (window.CNB4 && CNB4.toast){ CNB4.toast(t); return; } } catch(e){} try { if (A.UI && A.UI.toast){ A.UI.toast(t); return; } } catch(e){} var f = $('feedback'); if (f) f.textContent = t; }
  (function hookPercorso(){
    var PC = window.__percorso; if (!PC){ return setTimeout(hookPercorso, 300); }
    if (PC.__pz) return; PC.__pz = 1;
    var n0 = PC.next, g0 = PC.go;
    PC.next = function(){ if (isPz()) return {n:1, kind:'tema', c:'pz', name:'Puzzle Random', label:modo.t === 'rip' && todayList().length ? 'Prossimo ripasso' : 'Prossimo puzzle', short:'Puzzle rating ' + S.lvl}; return n0.apply(this, arguments); };
    PC.go = function(){ if (isPz()){ next(); return {n:1, kind:'tema'}; } return g0.apply(this, arguments); };
  })();
  // «Continua» (fbCont / pgCont di percorso.js) usa una funzione interna: lo intercetto prima, solo durante un puzzle
  document.addEventListener('click', function(ev){
    if (!isPz() || !ev.target.closest) return;
    if (ev.target.closest('#fbCont, #pgCont')){ ev.stopImmediatePropagation(); ev.preventDefault(); next(); }
  }, true);
  window.CNPuzzle = {open:open, next:next, prev:prev, openId:openId, openFavs:openFavs, ripasso:ripasso, build:build, state:function(){ return S; }, pickNext:pickNext, pickNear:pickNear,
    total:D.length, isPz:isPz, isFav:isFav, isFavId:isFavId, toggleFav:toggleFav, favs:function(){ return S.favs.filter(function(id){ return IDX[id] != null; }); },
    info:info, fenDi:fenDi, matto:matto, bande:bande, dueList:dueList, todayList:todayList, queue:queue, isDue:isDue, rating:function(){ return S.lvl; },
    provvisorio:function(){ return S.cnt < 20; }, giocati:function(){ return Object.keys(S.played).length; }, modo:function(){ return modo.t; }, lower:lower, D:D, MAXDAY:MAXDAY,
    setModo:function(m){ modo = m; }};
  /* 14-11 stampo unico: Puzzle Random usa la schermata dell'esercizio (misure 08b identiche a CNStampo.misure). Si iscrive allo stampo
     con i suoi pezzi: Aiuto 2 livelli = __app.hint (logica dei puzzle, non toccata), premove = premove.js, Condividi = ⋯ › Condividi
     (condividi.js, didascalia «Puzzle Random · rating …», file chessnode_puzzle_<id>). Nessun root: le classi della pagina restano quelle dell'esercizio. */
  if (window.CNStampo) CNStampo.crea('puzzle', {aiuto:'app', valutazione:false, premove:true, condividi:true, motore:false,
    condividiOra:function(){ if (window.CNShare && isPz()) CNShare.open('img'); }});
})();
