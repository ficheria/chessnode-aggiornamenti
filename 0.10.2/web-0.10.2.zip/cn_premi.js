/* =====================================================================================================
   cn_premi.js — Tutti i PREMI dell'app (sezione «Premi»): generali, per argomento e speciali
   Proprietario: Kiko. Codice originale, scritto da zero. Nessuna dipendenza. Nessun codice GPL / AGPL / NC.
   Solo dati e funzioni: nessuna grafica. Tutto offline (localStorage, chiave 'chessnodeplay-premi-v1').

   FILOSOFIA: si premia quanto si IMPARA e MIGLIORA, non quanto si gioca. Nessun punteggio complessivo, niente stelle.
   Tre regole, scritte nel catalogo:
     a) Si premia la PROVA più del completamento (es. Finali: vincere la posizione contro il motore).
     b) Mai premiare ciò che l'app non può VERIFICARE: ogni famiglia ha  verificabile: true|false.  Se è false il premio
        resta «in_arrivo» (grigio, non sbloccabile, non conta niente) anche se l'argomento è attivo.
     c) Pochi premi: 3–5 famiglie per argomento (ognuna con bronzo/argento/oro), più 3 premi speciali.

   STRUTTURA DEL CATALOGO
     argomento: 'generale' | 'tattica' | 'finali' | 'aperture' | 'strategia' | 'trappole' | 'puzzle_caso' | 'bot'
                (altri argomenti: basta mettere una voce nuova con un argomento nuovo, la logica non cambia)
     famiglia di coppe : categoria 'coppe' (o 'trofei', 'ripasso'), livelli bronzo/argento/oro, soglie[]
     premio speciale   : tipo 'speciale', stile 'speciale', UN solo livello, si prende una volta sola
     Un premio è SBLOCCABILE solo se: argomento attivo + verificabile true + soglie presenti. Altrimenti è «in_arrivo»
     (motivo_in_arrivo: 'argomento' | 'non_verificabile' | 'contenuti').

   SOGLIE (non a caso): per i contenuti finiti si calcolano dal numero REALE di contenuti con calcolaSoglie(contenuti, perc)
   (bronzo ≈10%, argento ≈40%, oro ≈80%, arrotondate in modo sensato). L'app dice quanti contenuti ci sono:
        CNPremi.crea({ contenuti: { finali:{ finali:24, capitoli:10 }, aperture:{ linee:120, aperture:30 }, bot:{ livelli:6 } } })
   Senza il numero le soglie restano vuote e il premio è «in_arrivo». Tattica e Puzzle casuali hanno già i loro numeri.
   Le soglie dei premi che NON hanno contenuti finiti (serie, rating, vittorie…) sono PROPOSTE (origine:'proposta').
   Le regole già esistenti nell'app non cambiano (origine:'regola').

   ARGOMENTI: 'generale' è sempre attivo; 'tattica' è attivo di default (crea({attivi:[…]}) per cambiare). Gli altri
   li accende l'app con attivaArgomento('finali') quando la sezione esiste davvero. Eventi di un argomento non attivo
   sono ignorati.

   EVENTI (registraEvento). TUTTI gli eventi portano l'argomento. Facoltativi su tutti: quando (ms), giorno ('AAAA-MM-GG'),
   fuso (minuti rispetto a UTC): di default si usano ora e calendario del telefono.
     { tipo:'esercizio_risolto',  argomento:'finali', esercizio:12, capitolo:'…', primoColpo:true|false,
                                  aiuto2:false, soluzioneVista:false, errori:0, sopraLivello:true }
           primoColpo:true conta SOLO se non c'è aiuto2:true, errori>0 o soluzioneVista:true e se l'esercizio non porta già il
           segno di un aiuto di 2° livello o di una soluzione vista (vedi «stato persistente» sotto): con dati incoerenti
           vince il caso prudente. Se primoColpo manca, NON è un primo colpo.
     { tipo:'esercizio_sbagliato', argomento:'tattica', esercizio:12, tema:'…' }   ha sbagliato una mossa
     { tipo:'soluzione_vista',     argomento:'tattica', esercizio:12 }              ha guardato la soluzione
     { tipo:'aiuto2_usato',        argomento:'tattica', esercizio:12 }              aiuto di 2° livello (il 1° è gratis, non si manda)
           agisce SUBITO: azzera la serie, conta come esito non pulito in Precisione (se è il primo esito di quell'esercizio),
           segna l'esercizio come visto e lo apre al ripasso.
     { tipo:'esercizio_saltato',   argomento:'tattica', esercizio:12 }              IGNORATO (non conta, non azzera niente)
     RIPASSO: gli stessi eventi con ripasso:true (oppure { tipo:'ripasso', argomento:'tattica', esercizio:12, esito:'giusto'|'sbagliato' }).
           ripasso:true è OBBLIGATORIO per ciò che si fa nella modalità Ripasso: è l'unico modo per «ripulire» un esercizio sporcato.
     { tipo:'tempo',                argomento:'generale', ms:5000 }                 tempo attivo di studio (Impegno)
     { tipo:'capitolo_completato',  argomento:'finali', capitolo:'…' }
     { tipo:'finale_vinto_motore',  argomento:'finali', finale:'…', famiglia:'re_pedone', senzaAiuti:true }
     { tipo:'linea_ripassata',      argomento:'aperture', linea:'…', senzaErrori:true }
     { tipo:'apertura_completata',  argomento:'aperture', apertura:'…' }     (tutte le sue linee ripassate)
     { tipo:'lezione_completata',   argomento:'strategia', lezione:'…' }
     { tipo:'quiz_giusto',          argomento:'strategia', lezione:'…', primoColpo:true }
     { tipo:'trappola_imparata',    argomento:'trappole', trappola:'…' }
     { tipo:'trappola_ripassata',   argomento:'trappole', trappola:'…', senzaErrori:true }
     { tipo:'rating',               argomento:'puzzle_caso', rating:1234 }
     { tipo:'partita_finita',       argomento:'bot', id:'p-0007', livello:3, risultato:'vittoria'|'pareggio'|'sconfitta',
                                    senzaAnnullare:true, senzaAiuti:true, rivincita:true, piuForte:true }
           id = identificativo STABILE della partita (obbligatorio): senza id l'evento è ignorato, e la stessa
           partita mandata due volte conta una volta sola.
     Altri tipi di evento vanno bene per i premi futuri (i filtri del catalogo guardano i campi dell'evento).
     Se in un evento di esercizio manca l'argomento si assume 'tattica' (compatibilità con la versione vecchia).

   REGOLE ANTI-REGALO
     - Aiuto di 2° livello e soluzione vista NON valgono «primo colpo» e azzerano la serie.
     - Saltato: ignorato (non conta, non azzera la serie, non va nel ripasso).
     - NUOVI premi di risoluzione (Tattica · Risoluzione, Puzzle risolti…): non contano gli esercizi risolti con l'aiuto
       di 2° livello né quelli risolti dopo aver visto la soluzione (campo `pulito`). Il vecchio Traguardi non cambia.
     - STATO PERSISTENTE per esercizio: se in un tentativo c'è stato un aiuto di 2° livello o la soluzione, l'esercizio resta
       «sporco»: nessun risolto successivo conta come pulito, né subito dopo né il giorno dopo, e passare la mezzanotte non
       cambia niente. Si ripulisce SOLO quando viene risolto al primo colpo (senza aiuti) in un RIPASSO dovuto (evento con
       ripasso:true, nel ciclo 1/3/7). Lo stato sopravvive al riavvio (anche nella copia minima).
     - Tattica · Ripasso e «Ripassato!» contano una volta per esercizio (esercizi diversi), non a ogni ripasso.
     - Partite: ogni partita (id) conta una volta sola.
     - Contenuti: i livelli già vinti non si tolgono né si nascondono mai; le soglie calcolate non scendono se i contenuti
       calano; con meno di 3 contenuti non si calcola nessuna soglia.
     - Salvataggio: un errore non è mai silenzioso (diagnostica(), opzione onErrore). Una copia minima conserva premi presi,
       esercizi già festeggiati nel ripasso, id delle partite e stato «sporco» degli esercizi, e li recupera all'avvio
       PRIMA di qualunque assegnazione: niente feste ripetute, niente partite ricontate.
     - MIGRAZIONE dai vecchi dati: 's' (progress) significa «almeno UNA esecuzione pulita», non «il primo tentativo di sempre».
       Tattica · Risoluzione parte solo da questi 's'.
     - Lo STESSO esercizio rifatto non conta due volte: serie, precisione, Lacuna colmata e Risoluzione guardano il
       PRIMO esito di ogni esercizio (campo derivato `nuovo`); un errore, invece, azzera sempre la serie.
     - Le cose «una volta sola» (capitolo, linea, trappola, livello del bot, finale…) si contano una volta sola.
     - I premi già presi non si perdono mai (nemmeno con azzeraProgressi()). Il festeggiamento esce UNA volta sola.
     - Giorni di fila: conta il calendario del telefono; orologio indietro = niente (e il riferimento dell'ultimo studio non
       si sposta mai all'indietro); cambio di fuso (≥ 90 minuti, l'ora legale vale 60 e non conta) = il giorno nuovo vale
       solo se dall'ultimo studio sono passate almeno 12 ore vere.

   TIPI DI REGOLA (campo `tipo`; filtri come oggetti {campo: valore | [valori] | {non: valore}})
     'serie' | 'conteggio' (unico:'campo') | 'massimo' | 'perCapitolo' (modo 'recupero') | 'giorniDiFila' |
     'finestra' (modo 'ultimi' | 'periodo') | 'evento' (ripetibile:true) | 'speciale' (regola.base = uno dei tipi sopra)

   USO RAPIDO
     var P = CNPremi.crea({ attivi:['tattica'], contenuti:{ finali:{ finali:24, capitoli:10 } } });
     P.attivaArgomento('finali');
     var nuovi = P.registraEvento({ tipo:'finale_vinto_motore', argomento:'finali', finale:'kpk-1' });
     nuovi.forEach(function(s){ if (s.piuAlto) festeggia(s.titolo_it, s.testo_it, s.stile); });
     P.prossimi(3, 'tattica');   // solo premi raggiungibili e verificabili ('tutti' o niente = tutti gli argomenti)
     P.elenco('finali');         // carosello della pagina Premi
   ===================================================================================================== */
(function (radiceGlobale) {
  'use strict';

  var CHIAVE = 'chessnodeplay-premi-v1';
  var CHIAVE_STATS = 'chessnodeplay-stats-v1';          // dati attuali di stats.js / progressi.js (si leggono, non si toccano)
  var CHIAVE_PROGRESSI = 'chessnodeplay-progress-v1';
  var CHIAVE_MIN = 'chessnodeplay-premi-v1-minimo';      // copia minima dei premi presi, per quando il salvataggio completo fallisce
  var PASSI_RIPASSO = [1, 3, 7];                        // tappe del ripasso, come in stats.js
  var GIORNO_MS = 86400000;
  var STUDIO_MIN_MS = 60000;                            // un giorno è «di studio» con 1 minuto di tempo...
  var STUDIO_MIN_ATTIVITA = 1;                          // ...oppure almeno un'attività registrata
  var SOGLIA_FUSO_MIN = 90;
  var ORE_FUSO_MS = 12 * 3600000;
  var TENERE_GIORNI = 450;
  var PERC_STANDARD = [0.10, 0.40, 0.80];

  // ---------------------------------------------------------------------------------------------
  // CONTENUTI REALI (quanti ce ne sono nell'app). Chiavi 'argomento.cosa'. L'app può aggiungerne con crea({contenuti}).
  // Tattica: 1001 esercizi divisi per tema (somma verificata nei test). Gli altri totali (anche i puzzle) li dice l'app.
  // ---------------------------------------------------------------------------------------------
  var TEMI_TATTICA = {
    matto_in_1: 60, matto_in_2: 121, attacco_doppio: 50, attacco_scoperta: 35, scacco_scoperta: 30, scacco_doppio: 30,
    inchiodatura: 45, infilata: 35, deviazione: 35, sacrificio_adescamento: 35, promozione: 40, finali: 80,
    patta: 24, mediogioco: 211, matto_in_3: 80, matto_in_4: 40, difesa: 50
  };
  var CONTENUTI_BASE = { tattica: { esercizi: 1001, temi: TEMI_TATTICA } };   // i puzzle casuali: il totale lo dice l'app (contenuti)

  function appiattisci(o, pre, out) {
    out = out || {};
    for (var k in o) {
      if (o[k] && typeof o[k] === 'object') appiattisci(o[k], (pre ? pre + '.' : '') + k, out);
      else if (typeof o[k] === 'number') out[(pre ? pre + '.' : '') + k] = o[k];
    }
    return out;
  }

  /* calcolaSoglie(contenuti, percentuali) → soglie per bronzo/argento/oro dal numero reale di contenuti.
     Percentuali di default 10% / 40% / 80%. Arrotondamento: passo 1 sotto 10, 5 sotto 100, 10 sotto 300, 50 sotto 1000,
     100 oltre. Le soglie sono crescenti e mai oltre il numero di contenuti. Con meno di 3 contenuti (o senza) → []: non c'è
     abbastanza materiale per tre livelli e il premio resta «in_arrivo». */
  function calcolaSoglie(contenuti, percentuali) {
    if (typeof contenuti !== 'number' || !isFinite(contenuti) || contenuti < 3) return [];
    var perc = (Array.isArray(percentuali) && percentuali.length) ? percentuali : PERC_STANDARD, out = [], i;
    for (i = 0; i < perc.length; i++) {
      var v = contenuti * perc[i], passo = v < 10 ? 1 : v < 100 ? 5 : v < 300 ? 10 : v < 1000 ? 50 : 100;
      var s = Math.max(1, Math.round(v / passo) * passo);
      if (out.length && s <= out[out.length - 1]) s = out[out.length - 1] + 1;
      if (s > contenuti) break;
      out.push(s);
    }
    return out;
  }

  // ---------------------------------------------------------------------------------------------
  // ARGOMENTI (l'ordine è quello del carosello della pagina Premi)
  // ---------------------------------------------------------------------------------------------
  var ARGOMENTI_BASE = [
    { id: 'generale', nome_it: 'Generali', nome_en: 'General', sempreAttivo: true },
    { id: 'tattica', nome_it: 'Tattica', nome_en: 'Tactics' },
    { id: 'finali', nome_it: 'Finali', nome_en: 'Endgames' },
    { id: 'aperture', nome_it: 'Aperture', nome_en: 'Openings' },
    { id: 'strategia', nome_it: 'Strategia', nome_en: 'Strategy' },
    { id: 'trappole', nome_it: 'Trappole', nome_en: 'Traps' },
    { id: 'puzzle_caso', nome_it: 'Puzzle casuali', nome_en: 'Random puzzles' },
    { id: 'bot', nome_it: 'Bot', nome_en: 'Bot' }
  ];
  var NOME_ARG = {}; ARGOMENTI_BASE.forEach(function (a) { NOME_ARG[a.id] = a; });

  var CATEGORIE = {
    coppe: { nome_it: 'Coppe', nome_en: 'Cups', stile: 'coppa' },
    trofei: { nome_it: 'Trofei', nome_en: 'Trophies', stile: 'trofeo' },
    ripasso: { nome_it: 'Carta del ripasso', nome_en: 'Review card', stile: 'carta' },
    speciali: { nome_it: 'Premi speciali', nome_en: 'Special prizes', stile: 'speciale' }
  };

  // ---------------------------------------------------------------------------------------------
  // CATALOGO (dati puri)
  // ---------------------------------------------------------------------------------------------
  var UN = {
    esercizi: [{ uno: 'esercizio', molti: 'esercizi' }, { uno: 'exercise', molti: 'exercises' }],
    giorni: [{ uno: 'giorno', molti: 'giorni' }, { uno: 'day', molti: 'days' }],
    ore: [{ uno: 'ora', molti: 'ore' }, { uno: 'hour', molti: 'hours' }],
    temi: [{ uno: 'tema', molti: 'temi' }, { uno: 'topic', molti: 'topics' }],
    capitoli: [{ uno: 'capitolo', molti: 'capitoli' }, { uno: 'chapter', molti: 'chapters' }],
    finali: [{ uno: 'finale', molti: 'finali' }, { uno: 'endgame', molti: 'endgames' }],
    linee: [{ uno: 'linea', molti: 'linee' }, { uno: 'line', molti: 'lines' }],
    aperture: [{ uno: 'apertura', molti: 'aperture' }, { uno: 'opening', molti: 'openings' }],
    lezioni: [{ uno: 'lezione', molti: 'lezioni' }, { uno: 'lesson', molti: 'lessons' }],
    trappole: [{ uno: 'trappola', molti: 'trappole' }, { uno: 'trap', molti: 'traps' }],
    livelli: [{ uno: 'livello', molti: 'livelli' }, { uno: 'level', molti: 'levels' }],
    vittorie: [{ uno: 'vittoria', molti: 'vittorie' }, { uno: 'win', molti: 'wins' }],
    punti: [{ uno: 'punto', molti: 'punti' }, { uno: 'point', molti: 'points' }],
    puzzle: [{ uno: 'puzzle', molti: 'puzzle' }, { uno: 'puzzle', molti: 'puzzles' }],
    tappe: [{ uno: 'tappa', molti: 'tappe' }, { uno: 'step', molti: 'steps' }]
  };
  function coppaLivelli(nomeIt, nomeEn, argIt, argEn) {
    var pi = argIt ? argIt + ' · ' : '', pe = argEn ? argEn + ' · ' : '';
    var N = [['bronzo', 'Bronzo', 'Bronze', 'di bronzo', 'bronze'], ['argento', 'Argento', 'Silver', "d'argento", 'silver'], ['oro', 'Oro', 'Gold', "d'oro", 'gold']];
    return N.map(function (x) {
      return { chiave: x[0], nome_it: x[1], nome_en: x[2],
        titolo_it: (x[0] === 'bronzo' ? 'Coppa di bronzo' : 'Coppa ' + x[3]) + ' · ' + pi + nomeIt, titolo_en: x[2] + ' cup · ' + pe + nomeEn,
        testo_it: 'Hai vinto la coppa ' + x[3] + ' «' + pi + nomeIt + '»!', testo_en: 'You won the ' + x[4] + ' cup «' + pe + nomeEn + '»!' };
    });
  }
  function livelloSpeciale(it, en, ti, te) {
    return [{ chiave: 'speciale', nome_it: it, nome_en: en, titolo_it: it, titolo_en: en, testo_it: ti, testo_en: te }];
  }
  function trofeoSerie(k, it, en) {
    return { chiave: 'serie' + k, nome_it: it, nome_en: en, titolo_it: it, titolo_en: en,
      testo_it: k + ' esercizi giusti di fila, al primo colpo.', testo_en: k + ' exercises right in a row, first try.' };
  }

  /* mk: id, arg, tipo, ver (verificabile), org ('regola'|'contenuti'|'proposta'), soglie | cont+perc, it, en, di, de, un, ob, oe, regola… */
  function mk(o) {
    var a = NOME_ARG[o.arg], speciale = o.tipo === 'speciale';
    var p = {
      id: o.id, argomento: o.arg, categoria: o.categoria || (speciale ? 'speciali' : 'coppe'), tipo: o.tipo,
      icona: o.icona || (speciale ? 'medaglia_speciale' : 'coppa'), stile: o.stile || (speciale ? 'speciale' : (CATEGORIE[o.categoria || 'coppe'].stile)),
      verificabile: o.ver, origine_soglie: o.org, soglie: o.soglie || [],
      nome_it: o.it, nome_en: o.en, descrizione_it: o.di || '', descrizione_en: o.de || '',
      unita_it: UN[o.un][0], unita_en: UN[o.un][1], obiettivo_it: o.ob, obiettivo_en: o.oe, regola: o.regola || {}
    };
    if (o.cont) { p.contenuto = o.cont; p.perc = o.perc || PERC_STANDARD; }
    if (o.suffisso) p.suffisso = o.suffisso;
    if (o.ripetibile) p.ripetibile = true;
    if (o.serie_storica) p.serie_storica = true;
    p.livelli = o.livelli || coppaLivelli(o.it, o.en, o.arg === 'generale' ? '' : a.nome_it, o.arg === 'generale' ? '' : a.nome_en);
    return p;
  }
  var VINTO = { tipo: 'partita_finita', risultato: 'vittoria' };
  var AZZERA_ES = ['sbagliato', 'con_aiuto', 'soluzione', 'aiuto2'];

  var CATALOGO_BASE = [
    // ===== GENERALI (tutta l'app) — regole già esistenti, invariate =====
    mk({ id: 'costanza', arg: 'generale', tipo: 'giorniDiFila', ver: true, org: 'regola', soglie: [3, 7, 30], it: 'Costanza', en: 'Consistency', un: 'giorni',
      di: 'Giorni di studio di fila', de: 'Days of study in a row', ob: '{n} giorni di studio di fila', oe: '{n} days of study in a row' }),
    mk({ id: 'impegno', arg: 'generale', tipo: 'finestra', ver: true, org: 'regola', soglie: [1, 5, 20], it: 'Impegno', en: 'Dedication', un: 'ore', regola: { modo: 'periodo' },
      di: 'Ore di studio in un mese', de: 'Hours of study in one month',
      ob: { uno: '{n} ora di studio in un mese', molti: '{n} ore di studio in un mese' }, oe: { uno: '{n} hour of study in a month', molti: '{n} hours of study in a month' } }),
    mk({ id: 'traguardi', arg: 'generale', tipo: 'conteggio', ver: true, org: 'regola', soglie: [100, 500, 1000], it: 'Traguardi', en: 'Milestones', un: 'esercizi',
      regola: { conta: { tipo: 'esercizio', risolto: true }, unico: 'chiaveEs' },
      di: 'Esercizi risolti in tutti gli argomenti', de: 'Exercises solved in every topic', ob: '{n} esercizi risolti', oe: '{n} exercises solved' }),
    mk({ id: 'lacuna', arg: 'generale', tipo: 'perCapitolo', ver: true, org: 'regola', soglie: [1, 2, 3], it: 'Lacuna colmata', en: 'Gap closed', un: 'temi',
      regola: { modo: 'recupero', conta: { tipo: 'esercizio', nuovo: true }, successo: { esito: 'primo_colpo' }, sotto: 0.5, sopra: 0.75, minPrima: 6, minDopo: 8, ultimi: 12 },
      di: 'Un tema (di qualunque argomento) sale da meno del 50% ad almeno il 75%', de: 'A topic (of any subject) climbs from under 50% to at least 75%',
      ob: { uno: 'un tema recuperato (da meno del 50% ad almeno il 75%)', molti: '{n} temi recuperati' }, oe: { uno: 'one topic recovered (from under 50% to at least 75%)', molti: '{n} topics recovered' } }),
    // carta del ripasso, per il SINGOLO esercizio: sbagliato, poi giusto al primo colpo a 1, 3 e 7 giorni («Ripassato!», NON «Lacuna colmata»)
    mk({ id: 'ripassato', arg: 'generale', categoria: 'ripasso', icona: 'carta', tipo: 'evento', ripetibile: true, ver: true, org: 'regola', soglie: [1], it: 'Ripassato!', en: 'Reviewed!', un: 'tappe',
      livelli: [{ chiave: 'ripassato', nome_it: 'Ripassato!', nome_en: 'Reviewed!', titolo_it: 'Ripassato!', titolo_en: 'Reviewed!',
        testo_it: 'Esercizio ripassato: giusto al primo colpo a 1, 3 e 7 giorni. Esce dal ripasso.', testo_en: 'Exercise reviewed: right first try after 1, 3 and 7 days. It leaves the review.' }],
      regola: { filtro: { tipo: 'ripasso_completato' }, unico: 'chiaveEs', progresso: 'ripasso' },
      di: 'Un esercizio sbagliato e poi risolto bene nel ripasso a 1, 3 e 7 giorni', de: 'A mistaken exercise solved well in the review after 1, 3 and 7 days',
      ob: 'Un esercizio risolto bene nel ripasso a 1, 3 e 7 giorni', oe: 'One exercise solved well in the review after 1, 3 and 7 days' }),

    // ===== TATTICA: Risoluzione, Precisione, Serie al primo colpo, Ripasso =====
    mk({ id: 'tattica_risoluzione', arg: 'tattica', tipo: 'conteggio', ver: true, org: 'contenuti', cont: 'tattica.esercizi', it: 'Risoluzione', en: 'Solving', un: 'esercizi',
      regola: { conta: { tipo: 'esercizio', pulito: true }, unico: 'chiaveEs' },
      di: 'Esercizi di tattica risolti senza aiuto di 2° livello e senza soluzione (su 1001)', de: 'Tactics exercises solved without 2nd-level help or the solution (out of 1001)', ob: '{n} esercizi di tattica risolti', oe: '{n} tactics exercises solved' }),
    mk({ id: 'tattica_precisione', arg: 'tattica', tipo: 'finestra', ver: true, org: 'regola', soglie: [60, 70, 80], it: 'Precisione', en: 'Accuracy', un: 'esercizi', suffisso: '%',
      regola: { modo: 'ultimi', n: 50, completa: true, conta: { tipo: 'esercizio', nuovo: true }, successo: { esito: 'primo_colpo' } },
      di: 'Al primo colpo sugli ultimi 50 esercizi (vale solo con 50 completi)', de: 'First-try rate over the last 50 exercises (only with 50 complete)',
      ob: '{n}% al primo colpo sugli ultimi 50 esercizi', oe: '{n}% first try over the last 50 exercises' }),
    mk({ id: 'tattica_serie', arg: 'tattica', categoria: 'trofei', icona: 'trofeo', serie_storica: true, tipo: 'serie', ver: true, org: 'regola', soglie: [3, 5, 10, 20, 50, 100], it: 'Serie al primo colpo', en: 'First-try streak', un: 'esercizi',
      livelli: [trofeoSerie(3, 'Tris!', 'Hat trick!'), trofeoSerie(5, 'Cinquina!', 'Five in a row!'), trofeoSerie(10, 'Dieci di fila!', 'Ten in a row!'),
        trofeoSerie(20, 'Venti di fila!', 'Twenty in a row!'), trofeoSerie(50, 'Cinquanta di fila!', 'Fifty in a row!'), trofeoSerie(100, 'Cento di fila!', 'One hundred in a row!')],
      regola: { conta: { tipo: 'esercizio', esito: 'primo_colpo', nuovo: true }, azzera: { tipo: 'esercizio', esito: AZZERA_ES } },
      di: "Esercizi giusti al primo colpo, uno dopo l'altro: un errore azzera la serie", de: 'Exercises right on the first try, one after another: a mistake resets the streak',
      ob: '{n} esercizi giusti di fila, al primo colpo', oe: '{n} exercises right in a row, first try' }),
    mk({ id: 'tattica_ripasso', arg: 'tattica', tipo: 'conteggio', ver: true, org: 'proposta', soglie: [5, 25, 100], it: 'Ripasso', en: 'Review', un: 'esercizi',
      regola: { conta: { tipo: 'ripasso_completato' }, unico: 'chiaveEs' },
      di: 'Esercizi DIVERSI sbagliati e poi ripassati bene a 1, 3 e 7 giorni', de: 'DIFFERENT mistaken exercises reviewed well after 1, 3 and 7 days',
      ob: '{n} esercizi ripassati bene', oe: '{n} exercises reviewed well' }),

    // ===== FINALI: la PROVA (vincere contro il motore) vale più del completamento =====
    mk({ id: 'finali_prova', arg: 'finali', tipo: 'conteggio', ver: false, org: 'contenuti', cont: 'finali.finali', perc: [0.10, 0.40, 0.80], it: 'Vinti contro il motore', en: 'Won against the engine', un: 'finali',
      regola: { conta: { tipo: 'finale_vinto_motore' }, unico: 'finale' },
      di: 'Posizioni di finale vinte contro il motore', de: 'Endgame positions won against the engine',
      ob: { uno: '{n} finale vinto contro il motore', molti: '{n} finali vinti contro il motore' }, oe: { uno: '{n} endgame won against the engine', molti: '{n} endgames won against the engine' } }),
    mk({ id: 'finali_senza_aiuti', arg: 'finali', tipo: 'conteggio', ver: false, org: 'contenuti', cont: 'finali.finali', perc: [0.05, 0.20, 0.50], it: 'Senza aiuti', en: 'No help', un: 'finali',
      regola: { conta: { tipo: 'finale_vinto_motore', senzaAiuti: true }, unico: 'finale' },
      di: 'Finali vinti contro il motore senza nessun aiuto', de: 'Endgames won against the engine with no help at all',
      ob: { uno: '{n} finale vinto senza aiuti', molti: '{n} finali vinti senza aiuti' }, oe: { uno: '{n} endgame won with no help', molti: '{n} endgames won with no help' } }),
    mk({ id: 'finali_capitoli', arg: 'finali', tipo: 'conteggio', ver: true, org: 'contenuti', cont: 'finali.capitoli', perc: [0.30, 0.60, 1.00], it: 'Capitoli completati', en: 'Chapters completed', un: 'capitoli',
      regola: { conta: { tipo: 'capitolo_completato' }, unico: 'capitolo' },
      di: 'Capitoli del corso sui finali completati', de: 'Endgame course chapters completed',
      ob: { uno: '{n} capitolo completato', molti: '{n} capitoli completati' }, oe: { uno: '{n} chapter completed', molti: '{n} chapters completed' } }),

    // ===== APERTURE =====
    mk({ id: 'aperture_linee', arg: 'aperture', tipo: 'conteggio', ver: true, org: 'contenuti', cont: 'aperture.linee', it: 'Linee ripassate', en: 'Lines reviewed', un: 'linee',
      regola: { conta: { tipo: 'linea_ripassata', senzaErrori: true }, unico: 'linea' },
      di: 'Linee imparate e ripassate senza errori', de: 'Lines learned and reviewed without mistakes', ob: '{n} linee ripassate senza errori', oe: '{n} lines reviewed without mistakes' }),
    mk({ id: 'aperture_complete', arg: 'aperture', tipo: 'conteggio', ver: true, org: 'contenuti', cont: 'aperture.aperture', perc: [0.10, 0.30, 0.60], it: 'Aperture complete', en: 'Openings completed', un: 'aperture',
      regola: { conta: { tipo: 'apertura_completata' }, unico: 'apertura' },
      di: 'Aperture con tutte le linee ripassate', de: 'Openings with every line reviewed', ob: '{n} aperture complete', oe: '{n} openings completed' }),
    // NON verificabile finché non c'è un controllo affidabile di «giocata bene»: resta in arrivo
    mk({ id: 'aperture_partite', arg: 'aperture', tipo: 'conteggio', ver: false, org: 'contenuti', cont: 'aperture.aperture', it: 'Aperture giocate bene', en: 'Openings played well', un: 'aperture',
      regola: { conta: { tipo: 'apertura_giocata_bene' }, unico: 'apertura' },
      di: 'Aperture diverse giocate bene nelle partite', de: 'Different openings played well in games', ob: '{n} aperture giocate bene', oe: '{n} openings played well' }),

    // ===== STRATEGIA =====
    mk({ id: 'strategia_lezioni', arg: 'strategia', tipo: 'conteggio', ver: true, org: 'contenuti', cont: 'strategia.lezioni', it: 'Lezioni completate', en: 'Lessons completed', un: 'lezioni',
      regola: { conta: { tipo: 'lezione_completata' }, unico: 'lezione' },
      di: 'Lezioni di strategia completate', de: 'Strategy lessons completed', ob: '{n} lezioni completate', oe: '{n} lessons completed' }),
    mk({ id: 'strategia_quiz', arg: 'strategia', tipo: 'conteggio', ver: true, org: 'contenuti', cont: 'strategia.lezioni', perc: [0.10, 0.30, 0.60], it: 'Quiz al primo colpo', en: 'First-try quizzes', un: 'lezioni',
      regola: { conta: { tipo: 'quiz_giusto', primoColpo: true }, unico: 'lezione' },
      di: 'Quiz di fine lezione giusti al primo colpo', de: 'End-of-lesson quizzes right on the first try', ob: '{n} quiz giusti al primo colpo', oe: '{n} quizzes right on the first try' }),
    mk({ id: 'strategia_partita', arg: 'strategia', tipo: 'conteggio', ver: false, org: 'contenuti', cont: 'strategia.lezioni', it: 'Buona strategia in partita', en: 'Good strategy in games', un: 'lezioni',
      regola: { conta: { tipo: 'strategia_applicata' }, unico: 'lezione' },
      di: 'Piani di strategia applicati bene in partita', de: 'Strategic plans applied well in games', ob: '{n} piani applicati bene', oe: '{n} plans applied well' }),

    // ===== TRAPPOLE =====
    mk({ id: 'trappole_imparate', arg: 'trappole', tipo: 'conteggio', ver: true, org: 'contenuti', cont: 'trappole.trappole', it: 'Trappole imparate', en: 'Traps learned', un: 'trappole',
      regola: { conta: { tipo: 'trappola_imparata' }, unico: 'trappola' },
      di: 'Trappole imparate', de: 'Traps learned', ob: '{n} trappole imparate', oe: '{n} traps learned' }),
    mk({ id: 'trappole_ripassate', arg: 'trappole', tipo: 'conteggio', ver: true, org: 'contenuti', cont: 'trappole.trappole', perc: [0.10, 0.30, 0.60], it: 'Trappole ripassate', en: 'Traps reviewed', un: 'trappole',
      regola: { conta: { tipo: 'trappola_ripassata', senzaErrori: true }, unico: 'trappola' },
      di: 'Trappole ripassate senza errori', de: 'Traps reviewed without mistakes', ob: '{n} trappole ripassate senza errori', oe: '{n} traps reviewed without mistakes' }),
    // NON verificabile: riconoscere una trappola in partita non si controlla in modo affidabile
    mk({ id: 'trappole_riconosciute', arg: 'trappole', tipo: 'conteggio', ver: false, org: 'contenuti', cont: 'trappole.trappole', perc: [0.05, 0.20, 0.50], it: 'Riconosciute in partita', en: 'Spotted in games', un: 'trappole',
      regola: { conta: { tipo: 'trappola_riconosciuta', modo: ['evitata', 'fatta'] }, unico: 'trappola' },
      di: 'Trappole diverse evitate, o fatte al bot, in partita', de: 'Different traps avoided, or set on the bot, in a game', ob: '{n} trappole riconosciute in partita', oe: '{n} traps spotted in games' }),

    // ===== PUZZLE CASUALI =====
    mk({ id: 'puzzle_risolti', arg: 'puzzle_caso', tipo: 'conteggio', ver: true, org: 'contenuti', cont: 'puzzle_caso.puzzle', perc: [0.01, 0.05, 0.20], it: 'Puzzle risolti', en: 'Puzzles solved', un: 'puzzle',
      regola: { conta: { tipo: 'esercizio', pulito: true }, unico: 'chiaveEs' },
      di: 'Puzzle risolti senza aiuto di 2° livello e senza soluzione (il totale lo dice l\'app: 1%, 5%, 20%)', de: 'Puzzles solved without 2nd-level help or the solution (total comes from the app: 1%, 5%, 20%)', ob: '{n} puzzle risolti', oe: '{n} puzzles solved' }),
    mk({ id: 'puzzle_serie', arg: 'puzzle_caso', tipo: 'serie', ver: true, org: 'proposta', soglie: [5, 15, 30], it: 'Serie al primo colpo', en: 'First-try streak', un: 'esercizi',
      regola: { conta: { tipo: 'esercizio', esito: 'primo_colpo', nuovo: true }, azzera: { tipo: 'esercizio', esito: AZZERA_ES } },
      di: 'Puzzle giusti al primo colpo di fila: un errore azzera', de: 'Puzzles right on the first try in a row: a mistake resets', ob: '{n} puzzle giusti di fila al primo colpo', oe: '{n} puzzles right in a row, first try' }),
    mk({ id: 'puzzle_rating', arg: 'puzzle_caso', tipo: 'massimo', ver: false, org: 'proposta', soglie: [900, 1300, 1700], it: 'Rating che sale', en: 'Rising rating', un: 'punti',
      regola: { campo: 'rating', conta: { tipo: 'rating' } },
      di: 'Il tuo rating personale nei puzzle', de: 'Your personal puzzle rating', ob: 'Rating personale di {n}', oe: 'Personal rating of {n}' }),

    // ===== BOT =====
    mk({ id: 'bot_livelli', arg: 'bot', tipo: 'conteggio', ver: true, org: 'contenuti', cont: 'bot.livelli', perc: [0.10, 0.50, 1.00], it: 'Un livello alla volta', en: 'One level at a time', un: 'livelli',
      regola: { conta: VINTO, unico: 'livello' },
      di: 'Prima vittoria su ogni livello del bot', de: 'First win over each bot level',
      ob: { uno: 'prima vittoria a {n} livello', molti: 'prima vittoria a {n} livelli diversi' }, oe: { uno: 'first win at {n} level', molti: 'first win at {n} different levels' } }),
    // NON verificabile finché l'app non garantisce: id partita, livello minimo del bot, nessuna mossa annullata, nessun aiuto
    mk({ id: 'bot_pulite', arg: 'bot', tipo: 'conteggio', ver: false, org: 'proposta', soglie: [1, 10, 30], it: 'Vittorie pulite', en: 'Clean wins', un: 'vittorie',
      regola: { conta: { tipo: 'partita_finita', risultato: 'vittoria', senzaAnnullare: true, senzaAiuti: true, livello: { min: 2 } } },
      di: 'Vittorie contro bot di livello almeno 2, senza annullare mosse e senza aiuti', de: 'Wins against bots of level 2 or higher, no take-backs, no help',
      ob: { uno: '{n} vittoria senza annullare mosse', molti: '{n} vittorie senza annullare mosse' }, oe: { uno: '{n} win without taking moves back', molti: '{n} wins without taking moves back' } }),

    // ===== PREMI SPECIALI (una volta sola, senza livelli, solo se verificabili) =====
    mk({ id: 'speciale_re_pedone', arg: 'finali', tipo: 'speciale', ver: false, org: 'regola', soglie: [1], it: 'Re e pedone, da solo', en: 'King and pawn, alone', un: 'finali',
      livelli: livelloSpeciale('Re e pedone, da solo', 'King and pawn, alone', 'Il tuo primo finale di Re e pedone vinto senza nessun aiuto!', 'Your first king-and-pawn endgame won with no help at all!'),
      regola: { base: 'conteggio', conta: { tipo: 'finale_vinto_motore', famiglia: 're_pedone', senzaAiuti: true } },
      di: 'Il primo finale di Re e pedone vinto senza aiuti', de: 'Your first king-and-pawn endgame won with no help', ob: 'Vinci un finale di Re e pedone senza aiuti', oe: 'Win a king-and-pawn endgame with no help' }),
    mk({ id: 'speciale_difficili', arg: 'puzzle_caso', tipo: 'speciale', ver: false, org: 'proposta', soglie: [5], it: 'Sopra il tuo livello', en: 'Above your level', un: 'esercizi',
      livelli: livelloSpeciale('Sopra il tuo livello', 'Above your level', '5 puzzle sopra il tuo livello, di fila, tutti al primo colpo!', '5 puzzles above your level, in a row, all first try!'),
      regola: { base: 'serie', conta: { tipo: 'esercizio', esito: 'primo_colpo', nuovo: true, sopraLivello: true }, azzera: { tipo: 'esercizio', sopraLivello: true, esito: AZZERA_ES } },
      di: '5 puzzle sopra il tuo livello, di fila, al primo colpo', de: '5 puzzles above your level, in a row, first try', ob: '5 puzzle difficili di fila al primo colpo', oe: '5 hard puzzles in a row, first try' }),
    mk({ id: 'speciale_bot_forte', arg: 'bot', tipo: 'speciale', ver: false, org: 'regola', soglie: [1], it: 'Più forte di te', en: 'Stronger than you', un: 'vittorie',
      livelli: livelloSpeciale('Più forte di te', 'Stronger than you', 'Hai battuto un bot più forte di te senza annullare nessuna mossa!', 'You beat a bot stronger than you without taking a move back!'),
      regola: { base: 'conteggio', conta: { tipo: 'partita_finita', risultato: 'vittoria', piuForte: true, senzaAnnullare: true } },
      di: 'Una partita vinta contro un bot più forte, senza annullare mosse', de: 'A game won against a stronger bot, without taking moves back', ob: 'Batti un bot più forte senza annullare mosse', oe: 'Beat a stronger bot without taking moves back' })
  ];

  // ---------------------------------------------------------------------------------------------
  // Date (calendario del telefono; i calcoli tra date usano UTC, così l'ora legale non sposta nulla)
  // ---------------------------------------------------------------------------------------------
  function due(n) { return (n < 10 ? '0' : '') + n; }
  function giornoLocale(t) { var d = new Date(t); return d.getFullYear() + '-' + due(d.getMonth() + 1) + '-' + due(d.getDate()); }
  function fusoLocale(t) { return -new Date(t).getTimezoneOffset(); }
  function pezzi(k) { var a = k.split('-'); return Date.UTC(+a[0], a[1] - 1, +a[2]); }
  function diffGiorni(a, b) { return Math.round((pezzi(b) - pezzi(a)) / GIORNO_MS); }
  function aggiungiGiorni(k, n) { var d = new Date(pezzi(k) + n * GIORNO_MS); return d.getUTCFullYear() + '-' + due(d.getUTCMonth() + 1) + '-' + due(d.getUTCDate()); }
  function giornoValido(k) { return typeof k === 'string' && /^\d{4}-\d\d-\d\d$/.test(k); }
  function media(a) { var s = 0, i; for (i = 0; i < a.length; i++) s += a[i]; return a.length ? s / a.length : 0; }
  function copia(o) { return JSON.parse(JSON.stringify(o)); }
  function mesePrefisso(k) { return k.slice(0, 7); }
  function oreDelMese(giorni, mese) { var ms = 0, k; for (k in giorni) if (mesePrefisso(k) === mese) ms += giorni[k].ms || 0; return ms / 3600000; }
  function mancante(x) { return x === undefined || x === null || x === ''; }

  // Filtri: {campo: valore | [valori] | {non: valore|[valori]}}
  function corrisponde(ev, f) {
    if (!f) return true;
    for (var k in f) {
      var atteso = f[k], v = ev[k];
      if (atteso && typeof atteso === 'object' && !Array.isArray(atteso)) {
        if (atteso.min !== undefined && (typeof v !== 'number' || v < atteso.min)) return false;     // {min: N}: numero ≥ N
        var non = atteso.non; if (non === undefined) continue;
        if ((Array.isArray(non) ? non : [non]).indexOf(v) >= 0) return false;
      } else if (Array.isArray(atteso)) { if (atteso.indexOf(v) < 0) return false; }
      else if (v !== atteso) return false;
    }
    return true;
  }
  function riuscito(ev, r) { return corrisponde(ev, r.successo) ? 1 : 0; }

  // ---------------------------------------------------------------------------------------------
  // I TIPI DI REGOLA. applica(st, ev, ctx, premio) → true se l'evento ha contato; valorePremio → numero da confrontare
  // con le soglie; progresso → a che punto siamo. ctx = { giorno, oggi, giorni (diario) }
  // ---------------------------------------------------------------------------------------------
  var TIPI = {
    serie: {
      init: function () { return { cur: 0, best: 0 }; },
      applica: function (st, ev, ctx, p) {
        var r = p.regola;
        if (corrisponde(ev, r.azzera)) { st.cur = 0; return false; }
        if (corrisponde(ev, r.conta)) { st.cur++; if (st.cur > st.best) st.best = st.cur; return true; }
        return false;
      },
      valorePremio: function (st) { return st.best; },
      progresso: function (st) { return { valore: st.cur }; }
    },
    conteggio: {
      init: function () { return { n: 0, visti: {} }; },
      applica: function (st, ev, ctx, p) {
        var r = p.regola;
        if (!corrisponde(ev, r.conta || r.filtro)) return false;
        if (r.unico) { if (mancante(ev[r.unico])) return false; var k = String(ev[r.unico]); if (st.visti[k]) return false; st.visti[k] = 1; }
        st.n++; return true;
      },
      valorePremio: function (st) { return st.n; },
      progresso: function (st) { return { valore: st.n }; }
    },
    massimo: {
      init: function () { return { m: 0 }; },
      applica: function (st, ev, ctx, p) {
        var r = p.regola, v = ev[r.campo];
        if (!corrisponde(ev, r.conta) || typeof v !== 'number' || !isFinite(v)) return false;
        if (v > st.m) st.m = v; return true;
      },
      valorePremio: function (st) { return st.m; },
      progresso: function (st) { return { valore: st.m }; }
    },
    perCapitolo: {   // «capitolo» = tema; la chiave è argomento:tema, così i temi di tutti gli argomenti stanno insieme
      init: function () { return { t: {} }; },
      applica: function (st, ev, ctx, p) {
        var r = p.regola;
        if (!corrisponde(ev, r.conta || r.filtro) || mancante(ev.tema)) return false;
        var chiave = (ev.argomento || '') + ':' + ev.tema, x = st.t[chiave] || (st.t[chiave] = { r: [], low: 0, k: 0, ok: 0 });
        x.r.push(riuscito(ev, r)); var fin = r.ultimi || 12; if (x.r.length > fin) x.r.splice(0, x.r.length - fin);
        if (!x.low) {            // prima fase: almeno minPrima esiti con media sotto `sotto`
          if (x.r.length >= (r.minPrima || 6) && media(x.r) < (r.sotto === undefined ? 0.5 : r.sotto)) { x.low = ev.quando; x.k = 0; }
        } else if (!x.ok) {      // seconda fase: dopo il calo, minDopo esiti con media ≥ `sopra`
          x.k++; var md = r.minDopo || 8;
          if (x.k >= md && media(x.r.slice(-md)) >= (r.sopra === undefined ? 0.75 : r.sopra)) x.ok = ev.quando;
        }
        return true;
      },
      valorePremio: function (st) { var t, n = 0; for (t in st.t) if (st.t[t].ok) n++; return n; },
      progresso: function (st) { return { valore: TIPI.perCapitolo.valorePremio(st) }; },
      dettagli: function (st) {
        var rec = [], inRec = [], t;
        for (t in st.t) { if (st.t[t].ok) rec.push(t); else if (st.t[t].low) inRec.push(t); }
        return { recuperati: rec, inRecupero: inRec };     // chiavi 'argomento:tema'
      }
    },
    giorniDiFila: {
      init: function () { return { cur: 0, best: 0, ultimo: null }; },
      applica: function (st, ev, ctx, p) {
        if (ev.derivato || !ctx.giorno) return false;
        var q = (p.regola && p.regola.qualifica) || {}, g = ctx.giorni[ctx.giorno];
        if (!g) return false;
        if (!((g.ms || 0) >= (q.ms === undefined ? STUDIO_MIN_MS : q.ms) || (g.es || 0) >= (q.attivita === undefined ? STUDIO_MIN_ATTIVITA : q.attivita))) return false;
        var k = ctx.giorno;
        if (st.ultimo === k) return false;
        if (st.ultimo !== null && k < st.ultimo) return false;                         // orologio indietro: non si conta
        st.cur = (st.ultimo !== null && diffGiorni(st.ultimo, k) === 1) ? st.cur + 1 : 1;   // saltato un giorno intero = si ricomincia
        st.ultimo = k; if (st.cur > st.best) st.best = st.cur;
        return true;
      },
      valorePremio: function (st) { return st.best; },
      progresso: function (st, ctx) { return { valore: (st.ultimo !== null && diffGiorni(st.ultimo, ctx.oggi) <= 1) ? st.cur : 0 }; }
    },
    finestra: {
      init: function (p) { return (p.regola && p.regola.modo === 'periodo') ? { best: 0 } : { v: [] }; },
      applica: function (st, ev, ctx, p) {
        var r = p.regola;
        if (r.modo === 'periodo') {                  // ore di studio nel miglior mese (il tempo sta nel diario)
          if (ev.derivato || !ctx.giorno) return false;
          var h = oreDelMese(ctx.giorni, mesePrefisso(ctx.giorno)); if (h > st.best) st.best = h;
          return false;
        }
        if (!corrisponde(ev, r.conta)) return false;
        st.v.push(riuscito(ev, r)); var n = r.n || 50;
        if (st.v.length > n) st.v.splice(0, st.v.length - n);
        return true;
      },
      valorePremio: function (st, ctx, p) {
        var r = p.regola;
        if (r.modo === 'periodo') return st.best;
        var n = r.n || 50;
        if (r.completa !== false && st.v.length < n) return 0;      // vale solo con la finestra piena
        return Math.round(media(st.v) * 100);
      },
      progresso: function (st, ctx, p) {
        var r = p.regola, n = r.n || 50;
        if (r.modo === 'periodo') return { valore: oreDelMese(ctx.giorni, mesePrefisso(ctx.oggi)) };
        if (r.completa !== false && st.v.length < n) return { valore: st.v.length, di: n, nota_it: 'poi conta la percentuale', nota_en: 'then the percentage counts' };
        return { valore: Math.round(media(st.v) * 100) };
      }
    }
  };
  TIPI.evento = TIPI.conteggio;
  // il tipo 'speciale' usa il motore indicato in regola.base (default 'conteggio')
  function R(p) { return TIPI[p.tipo === 'speciale' ? ((p.regola && p.regola.base) || 'conteggio') : p.tipo]; }
  function tipoValido(def) {
    if (def.tipo === 'speciale') return !!TIPI[(def.regola && def.regola.base) || 'conteggio'];
    return !!TIPI[def.tipo];
  }

  // ---------------------------------------------------------------------------------------------
  // Testi
  // ---------------------------------------------------------------------------------------------
  function numero(v, lingua) { var s = String(Math.round(v * 10) / 10); return lingua === 'en' ? s : s.replace('.', ','); }
  function modello(t, n, lingua) {         // t: stringa oppure {uno, molti}; {n} = numero
    if (!t || n === undefined || n === null) return '';
    if (typeof t === 'object') t = (n === 1 && t.uno) ? t.uno : (t.molti || t.uno || '');
    return t.replace(/\{n\}/g, numero(n, lingua));
  }
  function unitaDi(u, n) { return u ? (n === 1 ? (u.uno || u.molti || '') : (u.molti || u.uno || '')) : ''; }

  // ---------------------------------------------------------------------------------------------
  // L'oggetto principale
  // ---------------------------------------------------------------------------------------------
  function Premi(opzioni) {
    opzioni = opzioni || {};
    this._opz = opzioni;
    this._adesso = typeof opzioni.adesso === 'function' ? opzioni.adesso : function () { return Date.now(); };
    this._ar = opzioni.archivio || (typeof localStorage !== 'undefined' ? localStorage : null);
    this._ritardoSalva = opzioni.ritardoSalvataggio === undefined ? 250 : opzioni.ritardoSalvataggio;
    this._timer = null;
    this._catalogo = [];
    this._argomenti = ARGOMENTI_BASE.map(function (a) { return copia(a); });
    this._contenuti = appiattisci(CONTENUTI_BASE);
    var extra = appiattisci(opzioni.contenuti || {}), k;
    for (k in extra) this._contenuti[k] = extra[k];
    this.migrazione = null;
    this._diag = { ok: true, errore: null, quando: null, fallimenti: 0, copiaMinima: false, letturaRovinata: false };
    var self = this;
    CATALOGO_BASE.forEach(function (p) { self._inserisci(copia(p)); });
    (opzioni.catalogo || []).forEach(function (p) { var e = self.aggiungiPremio(p); if (e !== true) throw new Error('cn_premi: premio "' + (p && p.id) + '" non valido: ' + e.join('; ')); });
    this._carica();
    if (typeof window !== 'undefined' && window.addEventListener) window.addEventListener('pagehide', function () { self.salvaOra(); });
  }
  var P = Premi.prototype;

  // ----- catalogo e argomenti -----
  P._inserisci = function (p) {
    p.regola = p.regola || {};
    if (!Array.isArray(p.soglie)) p.soglie = [];
    if (p.contenuto) p.soglie = calcolaSoglie(this._contenuti[p.contenuto], p.perc);        // soglie dai contenuti reali
    this._assicuraLivelli(p);
    if (!p.stile) p.stile = (CATEGORIE[p.categoria] || {}).stile || 'coppa';
    if (!this._argomento(p.argomento)) this._argomenti.push({ id: p.argomento, nome_it: p.argomento_nome_it || p.argomento, nome_en: p.argomento_nome_en || p.argomento_nome_it || p.argomento });
    this._catalogo.push(p);
  };
  // I livelli non si tolgono MAI: se i contenuti aumentano e servono più livelli, quelli mancanti si ricostruiscono.
  P._assicuraLivelli = function (p) {
    if (Array.isArray(p.livelli) && (!p.soglie.length || p.livelli.length >= p.soglie.length)) return;
    var vecchi = Array.isArray(p.livelli) ? p.livelli : [];
    var nuovi = p.soglie.length ? p.soglie.map(function (s, i) {
      return p.soglie.length === 1
        ? { chiave: 'unico', nome_it: p.nome_it, nome_en: p.nome_en, titolo_it: p.nome_it, titolo_en: p.nome_en, testo_it: 'Hai preso «' + p.nome_it + '»!', testo_en: 'You earned «' + p.nome_en + '»!' }
        : { chiave: 'liv' + (i + 1), nome_it: 'Livello ' + (i + 1), nome_en: 'Level ' + (i + 1), titolo_it: p.nome_it + ' · livello ' + (i + 1), titolo_en: p.nome_en + ' · level ' + (i + 1), testo_it: 'Hai preso «' + p.nome_it + '» (livello ' + (i + 1) + ')!', testo_en: 'You earned «' + p.nome_en + '» (level ' + (i + 1) + ')!' };
    }) : coppaLivelli(p.nome_it, p.nome_en, '', '');
    p.livelli = vecchi.concat(nuovi.slice(vecchi.length));
  };
  /* Soglie dai contenuti, PROTETTE: non scendono mai (se i contenuti calano o l'app dà un numero più basso, le soglie già
     usate restano), così non si regala niente; con meno di 3 contenuti calcolaSoglie dà [] e restano quelle già usate. */
  P._soglieDaContenuti = function (p) {
    if (!p.contenuto) return;
    var calc = calcolaSoglie(this._contenuti[p.contenuto], p.perc), mem = (this._dati && this._dati.soglie[p.id]) || [], out = [], i, n = Math.max(calc.length, mem.length);
    for (i = 0; i < n; i++) {
      var v = Math.max(calc[i] || 0, mem[i] || 0);
      if (out.length && v <= out[out.length - 1]) v = out[out.length - 1] + 1;
      out.push(v);
    }
    p.soglie = out;
    if (this._dati) this._dati.soglie[p.id] = out.slice();
    this._assicuraLivelli(p);
  };
  P._premio = function (id) { for (var i = 0; i < this._catalogo.length; i++) if (this._catalogo[i].id === id) return this._catalogo[i]; return null; };
  P._argomento = function (id) { for (var i = 0; i < this._argomenti.length; i++) if (this._argomenti[i].id === id) return this._argomenti[i]; return null; };
  P._attivo = function (id) { var a = this._argomento(id); return !!a && (!!a.sempreAttivo || !!(this._dati && this._dati.attivi && this._dati.attivi[id])); };
  // null = sbloccabile; altrimenti il motivo per cui è «in arrivo»
  P._motivo = function (p) {
    if (!this._attivo(p.argomento)) return 'argomento';
    if (!p.verificabile) return 'non_verificabile';
    if (!p.soglie.length) return 'contenuti';
    return null;
  };

  /* aggiungiPremio(def): aggiunge un premio al catalogo. Ritorna true oppure l'elenco degli errori.
     Campi obbligatori: id, argomento, nome_it, categoria, tipo, soglie (anche vuote), verificabile (true/false).
     Un argomento nuovo nasce da solo (argomento_nome_it / argomento_nome_en nella voce) ed è «in_arrivo» finché non si
     chiama attivaArgomento(). Per soglie calcolate: contenuto:'finali.capitoli' (+ perc:[…]) invece di soglie. */
  P.aggiungiPremio = function (def) {
    var err = [];
    if (!def || typeof def !== 'object') return ['la voce non è un oggetto'];
    if (!def.id || typeof def.id !== 'string') err.push('manca id');
    else if (this._premio(def.id)) err.push('id già esistente: ' + def.id);
    if (!def.argomento || typeof def.argomento !== 'string') err.push('manca argomento');
    if (!def.nome_it) err.push('manca nome_it');
    if (!def.categoria) err.push('manca categoria');
    if (typeof def.verificabile !== 'boolean') err.push('manca verificabile (true o false)');
    if (!tipoValido(def)) err.push('tipo sconosciuto: ' + def.tipo + ' (validi: ' + Object.keys(TIPI).join(', ') + ', speciale)');
    if (!def.contenuto) {
      if (!Array.isArray(def.soglie) || def.soglie.some(function (s, i) { return typeof s !== 'number' || (i && s <= def.soglie[i - 1]); })) err.push('soglie: serve un elenco (anche vuoto) di numeri crescenti');
    }
    if (def.tipo === 'speciale' && Array.isArray(def.soglie) && def.soglie.length > 1) err.push('un premio speciale ha un solo livello');
    if (err.length) return err;
    var p = copia(def); if (!p.nome_en) p.nome_en = p.nome_it;
    if (p.tipo === 'speciale') { p.categoria = p.categoria || 'speciali'; p.stile = 'speciale'; if (!p.icona) p.icona = 'medaglia_speciale'; }
    this._inserisci(p);
    if (this._dati) { this._soglieDaContenuti(p); this._valuta(null, {}, true); this._pianificaSalva(); }
    return true;
  };
  P.catalogo = function () { return copia(this._catalogo); };
  P.calcolaSoglie = calcolaSoglie;

  /* contenuti(oggetto): dice al modulo quanti contenuti ci sono (es. {finali:{finali:24}}); ricalcola le soglie dei premi che
     le derivano dai contenuti. Mai troncare: i livelli già presi restano presi e visibili, le soglie non scendono, i livelli
     mancanti si ricostruiscono se i contenuti aumentano. */
  P.contenuti = function (oggetto) {
    var extra = appiattisci(oggetto || {}), k, self = this;
    for (k in extra) this._contenuti[k] = extra[k];
    this._catalogo.forEach(function (p) { self._soglieDaContenuti(p); });
    this._valuta(null, {}, true); this._pianificaSalva();
    return this;
  };

  P.attivaArgomento = function (id) {
    var a = this._argomento(id); if (!a) return false;
    this._dati.attivi[id] = 1;
    this._valuta(null, {}, true); this.salvaOra(); return true;
  };
  P.argomentoAttivo = function (id) { return this._attivo(id); };
  P.argomenti = function () {
    var self = this;
    return this._argomenti.map(function (a) { return { id: a.id, nome_it: a.nome_it, nome_en: a.nome_en, stato: self._attivo(a.id) ? 'attivo' : 'in_arrivo' }; });
  };

  // ----- dati e salvataggio -----
  function vuoto() { return { v: 1, migrato: false, orologio: null, attivi: {}, soglie: {}, giorni: {}, es: {}, pend: {}, partite: [], regole: {}, ripasso: {}, presi: {} }; }
  P._leggi = function (chiave) {
    if (!this._ar) return null;
    try { var t = this._ar.getItem(chiave); return t ? JSON.parse(t) : null; } catch (e) { return undefined; }   // undefined = file rovinato
  };
  P._carica = function () {
    var d = this._leggi(CHIAVE), self = this;
    if (d === undefined) {       // file rovinato: se ne tiene una copia e si riparte (mai un'eccezione)
      this._diag.letturaRovinata = true;
      try { this._ar.setItem(CHIAVE + '-copia-rovinata', this._ar.getItem(CHIAVE)); } catch (e) {}
      d = null;
    }
    var nuovo = !d || typeof d !== 'object' || d.v !== 1;
    this._dati = nuovo ? vuoto() : d;
    ['giorni', 'es', 'regole', 'ripasso', 'presi', 'attivi', 'soglie', 'pend'].forEach(function (k) { if (typeof self._dati[k] !== 'object' || self._dati[k] === null) self._dati[k] = {}; });
    if (!Array.isArray(this._dati.partite)) this._dati.partite = [];
    (this._opz.attivi === undefined ? ['tattica'] : this._opz.attivi).forEach(function (a) { self._dati.attivi[a] = 1; });
    this._uniscMinimo();                 // PRIMA di qualunque assegnazione: recupero dalla copia minima (se un salvataggio era fallito)
    this._catalogo.forEach(function (p) { self._soglieDaContenuti(p); });
    if (!this._dati.migrato) this._migra();
    else this._valuta(null, {}, true);   // premi nuovi nel catalogo già meritati: si assegnano in silenzio
    this._uniscMinimo();                 // e ancora dopo la migrazione (l'unione è idempotente)
    this.salvaOra();
  };
  // Cosa va nella copia minima oltre ai premi: i contatori «una volta sola» da non rifare (Ripassato!, Ripasso)
  P._vistiProtetti = function () {
    var out = {}, d = this._dati;
    this._catalogo.forEach(function (p) {
      var r = p.regola || {}, rip = p.ripetibile || (r.conta && r.conta.tipo === 'ripasso_completato') || (r.filtro && r.filtro.tipo === 'ripasso_completato');
      var st = d.regole[p.id];
      if (rip && st && st.visti) out[p.id] = { n: st.n || 0, visti: st.visti };
    });
    return out;
  };
  // Se l'ultimo salvataggio completo è fallito, la copia minima ha premi presi, esercizi già festeggiati, id delle partite
  // e stato «sporco»: si riuniscono (unione, mai perdita) così non si rifanno feste né si ricontano partite.
  P._uniscMinimo = function () {
    var m = this._leggi(CHIAVE_MIN), d = this._dati, id, k, i, self = this;
    if (!m || typeof m !== 'object') return;
    for (id in (m.presi || {})) {
      var y = m.presi[id], x = d.presi[id];
      if (!x) { d.presi[id] = y; continue; }
      x.volte = Math.max(x.volte || 0, y.volte || 0); x.liv = x.liv || [];
      (y.liv || []).forEach(function (v, j) { if ((x.liv[j] === null || x.liv[j] === undefined) && v !== null && v !== undefined) x.liv[j] = v; });
    }
    for (k in (m.attivi || {})) d.attivi[k] = 1;
    for (id in (m.soglie || {})) if (!d.soglie[id] || d.soglie[id].length < m.soglie[id].length) d.soglie[id] = m.soglie[id];
    (Array.isArray(m.partite) ? m.partite : []).forEach(function (pid) { if (d.partite.indexOf(pid) < 0) d.partite.push(pid); });
    for (id in (m.pend || {})) { var a = m.pend[id], b = d.pend[id] || { a: 0, s: 0 }; d.pend[id] = { a: (a.a || b.a) ? 1 : 0, s: (a.s || b.s) ? 1 : 0 }; }
    for (id in (m.visti || {})) {
      var p = this._premio(id); if (!p) continue;
      var st = d.regole[id] || (d.regole[id] = R(p).init(p));
      st.visti = st.visti || {};
      for (k in m.visti[id].visti) st.visti[k] = 1;
      st.n = Math.max(st.n || 0, m.visti[id].n || 0);
    }
  };
  P._pianificaSalva = function () {
    var self = this;
    if (this._ritardoSalva <= 0) { this.salvaOra(); return; }
    if (this._timer) return;
    this._timer = setTimeout(function () { self.salvaOra(); }, this._ritardoSalva);
  };
  /* salvaOra(): salva. Un errore (memoria piena, archivio bloccato) NON è mai silenzioso: va in diagnostica() e in
     opzioni.onErrore({messaggio, fallimenti}); in più si prova a salvare almeno la copia minima dei premi presi. */
  P.salvaOra = function () {
    if (this._timer) { clearTimeout(this._timer); this._timer = null; }
    var ks = Object.keys(this._dati.giorni), d = this._dati;
    if (ks.length > TENERE_GIORNI) { ks.sort(); ks.slice(0, ks.length - TENERE_GIORNI).forEach(function (k) { delete d.giorni[k]; }); }
    if (d.partite.length > 3000) d.partite.splice(0, d.partite.length - 3000);
    if (!this._ar) return;
    try {
      this._ar.setItem(CHIAVE, JSON.stringify(d));
      this._diag.ok = true; this._diag.errore = null; this._diag.copiaMinima = false;
      if (typeof this._ar.removeItem === 'function') { try { this._ar.removeItem(CHIAVE_MIN); } catch (e2) {} }
    } catch (e) {
      this._diag.ok = false; this._diag.errore = String((e && e.message) || e); this._diag.quando = this._adesso(); this._diag.fallimenti++;
      try { this._ar.setItem(CHIAVE_MIN, JSON.stringify({ v: 1, presi: d.presi, attivi: d.attivi, soglie: d.soglie, partite: d.partite, pend: d.pend, visti: this._vistiProtetti() })); this._diag.copiaMinima = true; }
      catch (e3) { this._diag.copiaMinima = false; }
      if (typeof this._opz.onErrore === 'function') { try { this._opz.onErrore({ messaggio: this._diag.errore, fallimenti: this._diag.fallimenti, copiaMinima: this._diag.copiaMinima }); } catch (e4) {} }
    }
  };
  /* diagnostica() → { salvataggio:'ok'|'errore', errore, fallimenti, copiaMinima (true = i premi presi sono comunque al sicuro),
     letturaRovinata (true = all'avvio il file era rovinato; ne è stata tenuta una copia) } */
  P.diagnostica = function () {
    var g = this._diag;
    return { salvataggio: g.ok ? 'ok' : 'errore', errore: g.errore, quando: g.quando, fallimenti: g.fallimenti, copiaMinima: g.copiaMinima, letturaRovinata: g.letturaRovinata };
  };

  // ---------------------------------------------------------------------------------------------
  // MIGRAZIONE da stats.js / progressi.js: chi ha già coppe o trofei non perde niente, con le date originali.
  // I vecchi dati si leggono soltanto (restano dove sono). Tutto ciò che esisteva prima era 'tattica' (opzione
  // `argomentoVecchi`, oppure la funzione `argomentoDi(numeroEsercizio)` se i numeri vanno ripartiti).
  // ATTENZIONE: nei vecchi dati 's' vuol dire «almeno UNA esecuzione pulita», non «il primo tentativo di sempre».
  //   cups.costanza/impegno/lacuna/traguardi → stessi premi generali      cups.precisione → Tattica · Precisione
  //   badges (Tris!, Cinquina!…)             → Tattica · Serie al primo colpo
  //   lc (ripassi completati)                → «Ripassato!» (volte) e Tattica · Ripasso
  //   Tattica · Risoluzione è nuova: se hai già risolto abbastanza esercizi si assegna in silenzio (data = oggi).
  // ---------------------------------------------------------------------------------------------
  P._migra = function () {
    var vecchi = this._leggi(CHIAVE_STATS), prog = this._leggi(CHIAVE_PROGRESSI);
    var rap = { daVecchiDati: false, coppe: 0, trofei: 0, ripassati: 0, esercizi: 0, assegnatiInSilenzio: [] };
    var ok = function (x) { return x && typeof x === 'object'; };
    if (ok(vecchi) || ok(prog)) { rap.daVecchiDati = true; this._importa(ok(vecchi) ? vecchi : {}, ok(prog) ? prog : {}, rap); }
    this._dati.migrato = true;
    rap.assegnatiInSilenzio = this._valuta(null, {}, true).map(function (s) { return s.id + ':' + s.indice; });
    this.migrazione = rap;
  };

  P._importa = function (s, prog, rap) {
    var d = this._dati, self = this, n, k;
    var argDi = typeof this._opz.argomentoDi === 'function' ? this._opz.argomentoDi : function () { return self._opz.argomentoVecchi || 'tattica'; };
    var chiaveDi = function (num) { return argDi(num) + ':' + num; };
    // esercizi già visti (bit: 1 = primo colpo, 2 = risolto, 4 = soluzione vista, 8 = visto)
    var visti = {};
    for (n in prog) { var pv = prog[n], b = 8; if (pv === 's') b |= 1 | 2; else if (pv === 'e') b |= 2; else if (pv === 'v') b |= 4; visti[chiaveDi(n)] = b; }
    if (s.fo && typeof s.fo === 'object') for (n in s.fo) { var kk = chiaveDi(n); visti[kk] = (visti[kk] || 0) | 8 | (s.fo[n] === 1 ? 1 : 0); }
    d.es = visti; rap.esercizi = Object.keys(visti).length;
    // diario dei giorni
    var tdays = (s.time && s.time.days) || {}, diary = s.diary || {};
    for (k in tdays) if (giornoValido(k) && tdays[k] > 0) (d.giorni[k] = d.giorni[k] || { ms: 0, es: 0 }).ms = Math.round(tdays[k]);
    for (k in diary) if (giornoValido(k) && diary[k] && diary[k].t > 0) (d.giorni[k] = d.giorni[k] || { ms: 0, es: 0 }).es = diary[k].t;
    // stato delle regole
    var stato = function (id) { var p = self._premio(id); return d.regole[id] || (d.regole[id] = R(p).init(p)); };
    var segnaRisolti = function (st) { st.n = 0; for (var c in visti) if (visti[c] & 2) { st.visti[c] = 1; st.n++; } };
    var ss = stato('tattica_serie'); ss.cur = s.streak | 0; ss.best = Math.max(s.best | 0, s.streak | 0);
    segnaRisolti(stato('traguardi'));             // il vecchio Traguardi resta com'era (tutti i risolti)
    // Tattica · Risoluzione è nuova e non regala: dai vecchi dati si contano solo gli esercizi risolti al primo colpo
    // (non si sa se gli altri erano stati risolti con l'aiuto di 2° livello o dopo la soluzione)
    var rs = stato('tattica_risoluzione'); rs.n = 0; for (var c0 in visti) if (visti[c0] & 1) { rs.visti[c0] = 1; rs.n++; }
    if (Array.isArray(s.p50)) stato('tattica_precisione').v = s.p50.filter(function (x) { return x === 0 || x === 1; }).slice(-50);
    var lst = stato('lacuna'), thr = s.thr || {}, thl = s.thl || {};
    Object.keys(thr).concat(Object.keys(thl)).forEach(function (c) {
      var kc = argDi(c) + ':' + c; if (lst.t[kc]) return;
      var l = thl[c] || {};
      lst.t[kc] = { r: Array.isArray(thr[c]) ? thr[c].slice(-12) : [], low: l.low || 0, k: l.k || 0, ok: l.ok || 0 };
    });
    var cst = stato('costanza'), pc = this._premio('costanza'), ctx0 = { giorni: d.giorni };
    Object.keys(d.giorni).sort().forEach(function (g) { ctx0.giorno = g; TIPI.giorniDiFila.applica(cst, { tipo: 'migrazione' }, ctx0, pc); });
    var ist = stato('impegno'), mesi = {};
    for (k in d.giorni) mesi[mesePrefisso(k)] = (mesi[mesePrefisso(k)] || 0) + (d.giorni[k].ms || 0);
    for (k in mesi) if (mesi[k] / 3600000 > ist.best) ist.best = mesi[k] / 3600000;
    // ripasso: i cicli in corso continuano
    var oggi = giornoLocale(this._adesso()), rev = s.rev || {};
    for (n in rev) {
      var r = rev[n]; if (!r || typeof r !== 'object') continue;
      d.ripasso[chiaveDi(n)] = { s: (r.s >= 0 && r.s <= 2) ? r.s | 0 : 0, due: giornoValido(r.due) ? r.due : oggi, w: r.w | 0 };
    }
    // premi già presi, con le date originali (vecchia famiglia → nuovo id)
    var cups = s.cups || {}, badges = s.badges || {};
    var MAPPA = { costanza: 'costanza', impegno: 'impegno', lacuna: 'lacuna', traguardi: 'traguardi', precisione: 'tattica_precisione' };
    Object.keys(MAPPA).forEach(function (vecchio) {
      var c = cups[vecchio]; if (!Array.isArray(c)) return;
      var liv = [0, 1, 2].map(function (j) { return (typeof c[j] === 'number' && c[j] > 0) ? c[j] : null; });
      if (liv.some(Boolean)) { d.presi[MAPPA[vecchio]] = { liv: liv, volte: 0 }; rap.coppe += liv.filter(Boolean).length; }
    });
    var ps = this._premio('tattica_serie');
    var liv2 = ps.soglie.map(function (so) { var t = badges[so]; return (typeof t === 'number' && t > 0) ? t : null; });
    if (liv2.some(Boolean)) { d.presi.tattica_serie = { liv: liv2, volte: 0 }; rap.trofei = liv2.filter(Boolean).length; }
    var lc = s.lc | 0;
    if (lc > 0) {
      d.presi.ripassato = { liv: [0], volte: lc };         // 0 = data della prima volta mai salvata
      stato('tattica_ripasso').n = lc; rap.ripassati = lc;
    }
  };

  // ---------------------------------------------------------------------------------------------
  // registraEvento
  // ---------------------------------------------------------------------------------------------
  // Trasforma i nomi dell'app negli eventi interni. Ritorna null se l'evento va ignorato.
  function normalizza(evento) {
    var ev = {}, k; for (k in evento) ev[k] = evento[k];
    var T = ev.tipo;
    ev.tipoOriginale = T;
    var esercizio = function (esito) { ev.tipo = 'esercizio'; ev.esito = esito; };
    if (T === 'esercizio_risolto') esercizio(ev.primoColpo === true ? 'primo_colpo' : 'con_aiuto');   // senza primoColpo:true NON è primo colpo
    else if (T === 'esercizio_sbagliato') esercizio('sbagliato');
    else if (T === 'soluzione_vista') esercizio('soluzione');
    else if (T === 'aiuto2_usato') esercizio('aiuto2');
    else if (T === 'esercizio_saltato') return null;
    else if (T === 'ripasso') { ev.ripasso = true; esercizio((ev.esito === 'giusto' || ev.esito === 'primo_colpo') ? 'primo_colpo' : (ev.esito === 'sbagliato' || ev.esito === 'errore' ? 'sbagliato' : ev.esito)); }
    else if (T === 'esercizio') { if (ev.esito === 'saltato') return null; }
    else if (T === 'tempo') { if (typeof ev.ms !== 'number' || !(ev.ms > 0)) return null; ev.ms = Math.min(ev.ms, 600000); }   // al massimo 10 minuti per evento
    if (ev.tipo === 'esercizio') {
      if (['primo_colpo', 'con_aiuto', 'sbagliato', 'soluzione', 'aiuto2'].indexOf(ev.esito) < 0 || mancante(ev.esercizio)) return null;
      // dati incoerenti (primoColpo:true insieme ad aiuto di 2° livello, errori o soluzione vista): vince il caso prudente
      if (ev.esito === 'primo_colpo' && (ev.aiuto2 === true || ev.errori > 0 || ev.soluzioneVista === true)) ev.esito = 'con_aiuto';
      if (mancante(ev.argomento)) ev.argomento = 'tattica';
      if (mancante(ev.tema) && !mancante(ev.capitolo)) ev.tema = ev.capitolo;
    }
    if (mancante(ev.argomento)) ev.argomento = 'generale';
    return ev;
  }

  // Giorno «effettivo» dell'evento, con le protezioni su orologio e fuso (vedi intestazione)
  P._giornoEffettivo = function (ev, t) {
    var d = this._dati, k = giornoValido(ev.giorno) ? ev.giorno : giornoLocale(t);
    var fuso = typeof ev.fuso === 'number' ? ev.fuso : fusoLocale(t), o = d.orologio;
    if (o && giornoValido(o.k)) {
      // orologio tornato indietro, oppure cambio di fuso (non un giorno vero): si resta sul giorno di prima e
      // il «segnale» dell'ultimo studio vero non si tocca
      if (t < o.t) return o.k;                      // ora tornata indietro (anche nello stesso giorno): il riferimento non si sposta
      if (k < o.k) return o.k;
      if (k > o.k && Math.abs(fuso - o.fuso) >= SOGLIA_FUSO_MIN && (t - o.t) < ORE_FUSO_MS) return o.k;
    }
    d.orologio = { k: k, t: t, fuso: fuso };
    return k;
  };

  /* registraEvento(evento) → array dei premi APPENA sbloccati (vuoto se nessuno). Ogni elemento:
       { id, argomento, indice, chiave, categoria, stile, icona, nome_it/en, titolo_it/en, testo_it/en, obiettivo_it/en,
         soglia, quando, primaVolta, piuAlto, volte }
     piuAlto = true sul livello più alto sbloccato in questa chiamata per quel premio (si festeggia quello);
     primaVolta = false solo per i premi ripetibili («Ripassato!») dopo la prima volta. */
  P.registraEvento = function (evento) {
    if (!evento || typeof evento !== 'object' || typeof evento.tipo !== 'string') return [];
    var ev = normalizza(evento); if (!ev) return [];
    if (!this._argomento(ev.argomento) || !this._attivo(ev.argomento)) return [];        // argomento sconosciuto o in arrivo: ignorato
    var d = this._dati;
    var t = (typeof ev.quando === 'number' && ev.quando > 0) ? ev.quando : this._adesso();
    ev.quando = t;

    // partite: l'id è obbligatorio e ogni partita conta UNA volta sola
    if (ev.tipo === 'partita_finita') {
      if (mancante(ev.id)) return [];
      var pid = String(ev.id);
      if (d.partite.indexOf(pid) >= 0) return [];
      d.partite.push(pid);
    }

    // giorno e diario
    var giorno = this._giornoEffettivo(ev, t);
    var g = d.giorni[giorno] || (d.giorni[giorno] = { ms: 0, es: 0 });
    if (ev.tipo === 'tempo') g.ms += ev.ms; else if (ev.tipo !== 'rating') g.es++;

    // campi derivati, registro degli esercizi e ciclo di ripasso a 1, 3 e 7 giorni
    var derivati = [];
    if (ev.tipo === 'esercizio') {
      var id = ev.argomento + ':' + ev.esercizio, codice = d.es[id] || 0;
      ev.chiaveEs = id;
      ev.nuovo = !(codice & 8);                                          // primo esito di sempre per questo esercizio
      // STATO PERSISTENTE: un aiuto di 2° livello o una soluzione vista «sporcano» l'esercizio finché non viene risolto
      // senza aiuti in un RIPASSO dovuto (ripasso:true e scadenza del ciclo 1/3/7). Nessuna scadenza a mezzanotte.
      var pend = d.pend[id] || null, aEv = ev.aiuto2 === true, sEv = ev.soluzioneVista === true, cic0 = d.ripasso[id];
      if (pend && ev.esito === 'primo_colpo' && ev.ripasso === true && cic0 && cic0.due <= giorno) { delete d.pend[id]; pend = null; }
      ev.aiuto2 = aEv || !!(pend && pend.a);
      ev.soluzioneVista = sEv || !!(pend && pend.s);
      if (ev.esito === 'primo_colpo' && (ev.aiuto2 || ev.soluzioneVista)) ev.esito = 'con_aiuto';   // caso prudente
      ev.risolto = ev.esito === 'primo_colpo' || ev.esito === 'con_aiuto';
      ev.pulito = ev.risolto && !ev.aiuto2 && !ev.soluzioneVista;        // risolto SENZA aiuto di 2° livello e senza soluzione
      var segnaA = aEv || ev.esito === 'aiuto2' || !!(pend && pend.a), segnaS = sEv || ev.esito === 'soluzione' || !!(pend && pend.s);
      if (segnaA || segnaS) d.pend[id] = { a: segnaA ? 1 : 0, s: segnaS ? 1 : 0 };
      d.es[id] = codice | 8 | ((ev.nuovo && ev.esito === 'primo_colpo') ? 1 : 0) | (ev.risolto ? 2 : 0) | (ev.esito === 'soluzione' ? 4 : 0) | (ev.esito === 'aiuto2' ? 16 : 0);
      if (ev.esito === 'primo_colpo') {
        var cic = d.ripasso[id];
        if (cic && cic.due <= giorno) {                                  // solo se era DAVVERO ora di ripassarlo
          cic.s++;
          if (cic.s >= PASSI_RIPASSO.length) { delete d.ripasso[id]; derivati.push({ tipo: 'ripasso_completato', argomento: ev.argomento, esercizio: ev.esercizio, chiaveEs: id, tema: ev.tema, quando: t, derivato: true }); }
          else cic.due = aggiungiGiorni(giorno, PASSI_RIPASSO[cic.s]);
        }
      } else {                                                           // errore, aiuto o soluzione: il ciclo riparte da 1 giorno
        var vecchio = d.ripasso[id];
        d.ripasso[id] = { s: 0, due: aggiungiGiorni(giorno, PASSI_RIPASSO[0]), w: ((vecchio && vecchio.w) || 0) + 1 };
      }
    }

    // le regole: i premi di un argomento vedono solo gli eventi di quell'argomento; 'generale' li vede tutti.
    // I premi «in arrivo» (argomento spento, non verificabili, senza soglie) non contano niente.
    var self = this, ctx = { giorno: giorno, oggi: giorno, giorni: d.giorni, dati: d };
    var corsi = {}, tutti = [ev].concat(derivati), i;
    this._catalogo.forEach(function (p) {
      if (self._motivo(p)) return;
      var st = d.regole[p.id] || (d.regole[p.id] = R(p).init(p));
      for (i = 0; i < tutti.length; i++) {
        if (p.argomento !== 'generale' && tutti[i].argomento !== p.argomento) continue;
        if (R(p).applica(st, tutti[i], ctx, p)) corsi[p.id] = (corsi[p.id] || 0) + 1;
      }
    });

    var nuovi = this._valuta(t, corsi, false);
    if (nuovi.length) this.salvaOra(); else this._pianificaSalva();
    if (nuovi.length && typeof this._opz.onSblocco === 'function') { try { this._opz.onSblocco(nuovi); } catch (e) {} }
    return nuovi;
  };

  /* Confronta i valori con le soglie e segna i livelli raggiunti. Ritorna i livelli segnati ora.
     silenzioso = true (avvio, migrazione, premi o argomenti aggiunti dopo): si assegna senza festeggiare i ripetibili. */
  P._valuta = function (t, corsi, silenzioso) {
    var d = this._dati, self = this, out = [], adesso = t || this._adesso();
    var ctx = { oggi: giornoLocale(adesso), giorni: d.giorni, dati: d };
    this._catalogo.forEach(function (p) {
      if (self._motivo(p)) return;                                 // «in arrivo»: niente si sblocca
      var st = d.regole[p.id] || (d.regole[p.id] = R(p).init(p));
      var pr = d.presi[p.id] || (d.presi[p.id] = { liv: p.soglie.map(function () { return null; }), volte: 0 });
      while (pr.liv.length < p.soglie.length) pr.liv.push(null);
      if (p.ripetibile) {                                          // si festeggia a ogni volta
        var c = corsi && corsi[p.id];
        if (c && !silenzioso) {
          var prima = pr.liv[0] === null || pr.liv[0] === undefined; if (prima) pr.liv[0] = adesso;
          pr.volte = (pr.volte || 0) + c;
          out.push(self._sblocco(p, 0, adesso, pr, prima, true));
        }
        return;
      }
      var v = R(p).valorePremio(st, ctx, p), nuovi = [];
      pr.sg = pr.sg || [];
      p.soglie.forEach(function (so, i) { if (v >= so && (pr.liv[i] === null || pr.liv[i] === undefined)) { pr.liv[i] = adesso; pr.sg[i] = so; nuovi.push(i); } });
      nuovi.forEach(function (i, j) { out.push(self._sblocco(p, i, adesso, pr, true, j === nuovi.length - 1)); });
    });
    return out;
  };
  P._sblocco = function (p, i, quando, pr, primaVolta, piuAlto) {
    var L = p.livelli[i];
    return {
      id: p.id, argomento: p.argomento, indice: i, chiave: L.chiave, categoria: p.categoria, stile: p.stile, icona: p.icona || null,
      nome_it: L.nome_it, nome_en: L.nome_en, titolo_it: L.titolo_it, titolo_en: L.titolo_en, testo_it: L.testo_it, testo_en: L.testo_en,
      obiettivo_it: modello(p.obiettivo_it, p.soglie[i], 'it'), obiettivo_en: modello(p.obiettivo_en, p.soglie[i], 'en'),
      soglia: p.soglie[i], quando: quando, primaVolta: primaVolta, piuAlto: piuAlto, volte: pr.volte || 0
    };
  };

  // ---------------------------------------------------------------------------------------------
  // Lettura: progresso, prossimi(), elenco()
  // ---------------------------------------------------------------------------------------------
  P._ctxLettura = function () { var d = this._dati; return { oggi: giornoLocale(this._adesso()), giorni: d.giorni, dati: d }; };
  P._progresso = function (p, i, ctx) {
    var d = this._dati, st = d.regole[p.id] || R(p).init(p), so = p.soglie[i], pg = R(p).progresso(st, ctx, p);
    var pct = !!p.suffisso && pg.di === undefined, di = pg.di !== undefined ? pg.di : so, v = pg.valore, e;
    if (p.regola && p.regola.progresso === 'ripasso') {            // «Ripassato!»: a che tappa è l'esercizio più avanti nel ciclo
      v = 0; for (e in d.ripasso) if (d.ripasso[e].s > v) v = d.ripasso[e].s;
      di = PASSI_RIPASSO.length; pct = false;
    }
    v = Math.min(v, di);
    var mancano = Math.round(Math.max(0, di - v) * 10) / 10;
    var f = function (x, L) { return numero(x, L) + (pct ? p.suffisso : ''); };
    return {
      valore: v, di: di, mancano: mancano, frazione: di ? Math.max(0, Math.min(1, v / di)) : 0,
      testo_it: f(v, 'it') + ' su ' + f(di, 'it'), testo_en: f(v, 'en') + ' of ' + f(di, 'en'),
      mancano_it: (mancano === 1 ? 'manca ' : 'mancano ') + f(mancano, 'it'), mancano_en: f(mancano, 'en') + ' to go',
      unita_it: pct ? '' : unitaDi(p.unita_it, di), unita_en: pct ? '' : unitaDi(p.unita_en, di),
      nota_it: pg.nota_it || null, nota_en: pg.nota_en || null
    };
  };
  function dataIso(ts) { return ts ? giornoLocale(ts) : null; }
  function filtroArg(arg) { return (!arg || arg === 'tutti') ? null : arg; }

  /* elenco(argomento) → [{ argomento, nome_it, nome_en, stato:'attivo'|'in_arrivo', premi:[…] }], un gruppo per argomento
     nell'ordine del carosello: Generali, Tattica, Finali, Aperture, Strategia, Trappole, Puzzle casuali, Bot
     (argomento omesso o 'tutti' = tutti; id sconosciuto = []).
     Ogni premio: id, argomento, categoria ('coppe'|'trofei'|'ripasso'|'speciali'), stile ('coppa'|'trofeo'|'carta'|'speciale'),
     nomi, tipo, icona, descrizione, verificabile, origine_soglie, ripetibile, serie_storica (true = i 6 livelli storici
     Tris!…Cento di fila!: la pagina li mostra a parte, non come tre coppe),
     stato ('attivo'|'in_arrivo'), motivo_in_arrivo (null | 'argomento' | 'non_verificabile' | 'contenuti'),
     presi, totali, completo, volte, livelli[] e (Lacuna colmata) dettagli.
     Ogni livello: { indice, chiave, nome, titolo, soglia (null se ancora vuota), obiettivo, stato:'preso'|'da_prendere'|'in_arrivo',
     quando (ms; null se non preso; 0 = data sconosciuta), data ('AAAA-MM-GG'), progresso:{ valore, di, mancano, frazione,
     testo_it ("12 su 20"), mancano_it, … } (solo se 'da_prendere') }. I premi «in_arrivo» sono da mostrare grigi. */
  P.elenco = function (argomento) {
    var self = this, ctx = this._ctxLettura(), d = this._dati, filtro = filtroArg(argomento);
    return this._argomenti.filter(function (a) { return !filtro || a.id === filtro; }).map(function (a) {
      return {
        argomento: a.id, nome_it: a.nome_it, nome_en: a.nome_en, stato: self._attivo(a.id) ? 'attivo' : 'in_arrivo',
        premi: self._catalogo.filter(function (p) { return p.argomento === a.id; }).map(function (p) {
          var pr = d.presi[p.id] || { liv: [], volte: 0 }, st = d.regole[p.id] || R(p).init(p), presi = 0, motivo = self._motivo(p);
          var liv = p.livelli.map(function (L, i) {
            var ts = pr.liv[i], preso = ts !== null && ts !== undefined;      // un premio già preso non si perde né si nasconde mai
            if (preso) presi++;
            var sbloccabile = !motivo && p.soglie[i] !== undefined;
            var so = p.soglie[i] !== undefined ? p.soglie[i] : (pr.sg && pr.sg[i] !== undefined ? pr.sg[i] : undefined);
            return {
              indice: i, chiave: L.chiave, nome_it: L.nome_it, nome_en: L.nome_en, titolo_it: L.titolo_it, titolo_en: L.titolo_en,
              soglia: so === undefined ? null : so, serie_storica: !!p.serie_storica,
              obiettivo_it: modello(p.obiettivo_it, so, 'it'), obiettivo_en: modello(p.obiettivo_en, so, 'en'),
              stato: preso ? 'preso' : (sbloccabile ? 'da_prendere' : 'in_arrivo'), quando: preso ? ts : null, data: preso ? dataIso(ts) : null,
              progresso: (sbloccabile && !preso) ? self._progresso(p, i, ctx) : null
            };
          });
          var voce = {
            id: p.id, argomento: p.argomento, categoria: p.categoria, stile: p.stile,
            categoria_it: (CATEGORIE[p.categoria] || {}).nome_it || p.categoria, categoria_en: (CATEGORIE[p.categoria] || {}).nome_en || p.categoria,
            nome_it: p.nome_it, nome_en: p.nome_en, tipo: p.tipo, icona: p.icona || null,
            descrizione_it: p.descrizione_it || '', descrizione_en: p.descrizione_en || '',
            verificabile: !!p.verificabile, origine_soglie: p.origine_soglie || null, ripetibile: !!p.ripetibile, serie_storica: !!p.serie_storica,
            stato: motivo ? 'in_arrivo' : 'attivo', motivo_in_arrivo: motivo,
            presi: presi, totali: p.livelli.length, completo: presi > 0 && presi === p.livelli.length,
            volte: pr.volte || 0, livelli: liv
          };
          if (!motivo && R(p).dettagli) voce.dettagli = R(p).dettagli(st, p);
          return voce;
        })
      };
    });
  };

  /* prossimi(n, argomento) → i prossimi n premi più vicini, SOLO sbloccabili e verificabili (mai «in_arrivo»: così il
     «prossimo premio» è sempre raggiungibile davvero). Uno per premio: il primo livello ancora da prendere. Dal più vicino.
     argomento: id, oppure 'tutti' / omesso = l'insieme. Ogni voce: { id, argomento, indice, categoria, stile, icona, nome,
     titolo, soglia, obiettivo, valore, di, mancano, frazione, testo_it ("12 su 20"), mancano_it ("mancano 8"), unita_it, nota_it }.
     Un premio ripetibile già preso (la carta «Ripassato!») non ha un «prossimo». */
  P.prossimi = function (n, argomento) {
    var self = this, ctx = this._ctxLettura(), d = this._dati, out = [], filtro = filtroArg(argomento);
    this._catalogo.forEach(function (p) {
      if (self._motivo(p) || (filtro && p.argomento !== filtro)) return;
      var pr = d.presi[p.id] || { liv: [], volte: 0 }, i;
      if (p.ripetibile && (pr.volte || 0) > 0) return;
      for (i = 0; i < p.soglie.length; i++) if (pr.liv[i] === null || pr.liv[i] === undefined) break;
      if (i >= p.soglie.length) return;
      var L = p.livelli[i], pg = self._progresso(p, i, ctx);
      out.push({
        id: p.id, argomento: p.argomento, indice: i, categoria: p.categoria, stile: p.stile, icona: p.icona || null,
        nome_it: L.nome_it, nome_en: L.nome_en, titolo_it: L.titolo_it, titolo_en: L.titolo_en, soglia: p.soglie[i],
        obiettivo_it: modello(p.obiettivo_it, p.soglie[i], 'it'), obiettivo_en: modello(p.obiettivo_en, p.soglie[i], 'en'),
        valore: pg.valore, di: pg.di, mancano: pg.mancano, frazione: pg.frazione, testo_it: pg.testo_it, testo_en: pg.testo_en,
        mancano_it: pg.mancano_it, mancano_en: pg.mancano_en, unita_it: pg.unita_it, unita_en: pg.unita_en, nota_it: pg.nota_it, nota_en: pg.nota_en
      });
    });
    out.sort(function (a, b) { return (b.frazione - a.frazione) || (a.mancano - b.mancano); });
    return typeof n === 'number' ? out.slice(0, n) : out;
  };

  // Serie di esercizi giusti (di 'tattica' o 'puzzle_caso') e giorni di studio di fila, per la Home
  P.serie = function (argomento) {
    var id = argomento === 'puzzle_caso' ? 'puzzle_serie' : 'tattica_serie';
    var s = this._dati.regole[id] || { cur: 0, best: 0 }, c = this._dati.regole.costanza || { cur: 0, best: 0, ultimo: null };
    var oggi = giornoLocale(this._adesso());
    return { corrente: s.cur, record: s.best, giorniDiFila: (c.ultimo !== null && diffGiorni(c.ultimo, oggi) <= 1) ? c.cur : 0, recordGiorni: c.best };
  };

  /* azzeraProgressi(opzioni): per «Azzera i progressi». I contatori ripartono da zero ma i premi GIÀ PRESI restano
     (non si perdono mai) e gli argomenti attivi restano attivi. Con { premi:true } si cancella davvero tutto. */
  P.azzeraProgressi = function (opzioni) {
    var d = this._dati, presi = d.presi, attivi = d.attivi, soglie = d.soglie;
    this._dati = vuoto(); this._dati.migrato = true; this._dati.attivi = attivi; this._dati.soglie = soglie;
    if (!(opzioni && opzioni.premi)) this._dati.presi = presi;
    this._valuta(null, {}, true);
    this.salvaOra();
    return this;
  };

  // Dati grezzi (per prove e diagnosi)
  P.dati = function () { return this._dati; };

  var CNPremi = {
    versione: '3.2',
    crea: function (opzioni) { return new Premi(opzioni); },
    calcolaSoglie: calcolaSoglie,
    catalogoBase: function () { return copia(CATALOGO_BASE); },
    contenutiBase: function () { return appiattisci(CONTENUTI_BASE); },
    tipiDiRegola: function () { return Object.keys(TIPI).concat(['speciale']); },
    chiave: CHIAVE
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = CNPremi;
  radiceGlobale.CNPremi = CNPremi;
})(typeof window !== 'undefined' ? window : (typeof globalThis !== 'undefined' ? globalThis : this));
