/* Chess Node — marchio (ANTEPRIMA, solo copia). Solo interfaccia moderna. */
(function(){
  if (!document.documentElement.classList.contains('moderna')) return;
  // 28/10: la versione NON è più scritta a mano. Nell'app Android viene dall'APK installato
  // (versionName di build.gradle, letto con @capacitor/app getInfo); nel browser si mostra «web».
  var VER = '';
  var verCbs = [];
  function verLabel(){ return VER || '…'; }
  function setVer(v){
    VER = v || 'web'; try { window.__chessnode.version = VER; } catch(e){}
    document.querySelectorAll('.cn-vernum').forEach(function(n){ n.textContent = VER; });
    var c = verCbs; verCbs = []; c.forEach(function(f){ try { f(VER); } catch(e){} });
  }
  function readVer(){
    try {
      var C = window.Capacitor, nat = C && C.isNativePlatform && C.isNativePlatform(), AP = nat && C.Plugins && C.Plugins.App;
      if (nat && !AP && C.registerPlugin) try { AP = C.registerPlugin('App'); } catch(e){}
      if (AP && AP.getInfo){ AP.getInfo().then(function(i){ setVer(i && i.version); }).catch(function(){ setVer('web'); }); return; }
    } catch(e){}
    setVer('web');
  }
  window.__cnVersion = function(cb){ if (VER) cb(VER); else verCbs.push(cb); };
  var BADGE = '<img class="cn-badge cn-badge-logo" src="logo_cn.png" alt="" aria-hidden="true">';   // blocco 1: logo variante B
  var WORD = '<span class="cn-word"><span class="cn-c">Chess</span> <span class="cn-n">Node</span></span>';
  window.__chessnode = {name:'Chess Node', version:VER, navy:'#0B1F3A', card:'#12305A', border:'#2A4C80', green:'#165B27', greenHi:'#287D3F', greenText:'#34A252', blue:'#0E5292', blueHi:'#679CD4', text:'#BFD0E8'};
  document.title = 'Chess Node';
  function topbar(){
    var h = document.querySelector('.topbar h1'); if (!h || h.classList.contains('cn-h1')) return;
    var sub = h.querySelector('.sub'); var subHTML = sub ? sub.outerHTML : '';
    h.classList.add('cn-h1'); h.setAttribute('aria-label', 'Chess Node – 1000 esercizi di scacchi');
    h.innerHTML = '<img class="cn-logo" src="logo_cn.png" alt="">' + WORD + '<span class="cn-rest">· 1000 esercizi ' + subHTML + '</span>';
  }
  function settings(){
    var t = document.getElementById('setTitle'); if (!t || t.querySelector('.cn-ver')) return;
    var s = document.createElement('small'); s.className = 'cn-ver';
    s.innerHTML = BADGE + WORD + '<span>· versione <span class="cn-vernum">' + verLabel() + '</span></span>'; t.appendChild(s);
  }
  function toast(){
    var tt = document.getElementById('pgToast'); if (!tt) return;
    var box = tt.querySelector('.st-txt'); if (!box || box.querySelector('.cn-tag')) return;
    var g = document.createElement('span'); g.className = 'cn-tag'; g.innerHTML = BADGE + WORD; box.insertBefore(g, box.firstChild);
  }
  function init(){
    readVer(); topbar(); settings();
    var tries = 0;
    (function hook(){
      var tt = document.getElementById('pgToast');
      if (tt){ new MutationObserver(toast).observe(tt, {childList:true}); toast(); return; }
      if (++tries < 40) setTimeout(hook, 250);
    })();
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
