/* Chess Node · Percorso guidato (solo index_moderna.html, caricato per ultimo)
   1. Pulsante «Continua» (30/10, blocco 5: per tema, vedi next()). Prima: alternava una lacuna da ripassare (esercizi sbagliati, aiutati o saltati: la coda del Ripasso
      di stats.js) e un esercizio nuovo (se manca un tipo, l'altro); nuovo = il prossimo esercizio non risolto, nell'ordine del libro, alla difficoltà giusta (precisione recente, SFDATA).
   2. Obiettivo del giorno (5/10/20) con anello di avanzamento, piccola festa quando è raggiunto,
      collegamenti alla Costanza (giorni di studio di fila) e alle Coppe.
   Dati: l'obiettivo scelto in 'chessnodeplay-obiettivo-v1'; gli esercizi contati oggi nel diario di progressi.js
   (diary[giorno].g = numeri degli esercizi, gc = obiettivo già festeggiato). Un esercizio conta una volta al giorno,
   solo se risolto da te (non con «Mostra soluzione»); le riproduzioni della soluzione non emettono 'solved' e non contano. */
(function(){
  'use strict';
  var A = window.__app, S = window.__stats, P = window.__progressi;
  var root = document.documentElement;
  if (!A || !S || !S.data || !root.classList.contains('moderna') || !window.BOOK) return;
  var EX = window.BOOK.ex, byN = A.byN, chById = A.chById, SF = window.SFDATA || {ex:{}, nomi:[]};
  var GKEY = 'chessnodeplay-obiettivo-v1', GOALS = [5, 10, 20];
  var L = window.LUCIDE || {};
  function $(id){ return document.getElementById(id); }
  function esc(s){ return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }
  function svg(n, s){ return L[n] ? '<svg class="lu" viewBox="0 0 24 24" width="' + (s || 18) + '" height="' + (s || 18) + '" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' + L[n] + '</svg>' : ''; }
  function el(tag, attrs, html){ var e = document.createElement(tag); for (var k in attrs) e.setAttribute(k, attrs[k]); if (html != null) e.innerHTML = html; return e; }

  // ---------- obiettivo ----------
  var cfg = {}; try { cfg = JSON.parse(localStorage.getItem(GKEY)) || {}; } catch(e){ cfg = {}; }
  if (GOALS.indexOf(cfg.target) < 0) cfg.target = 10;
  function saveCfg(){ try { localStorage.setItem(GKEY, JSON.stringify(cfg)); } catch(e){} }
  function today(){ return S.dayKey(S.now()); }
  function entry(create){
    var dd = S.data().diary, k = today();
    if (!dd[k]){ if (!create) return null; dd[k] = {t:0, r:0, p:0, s:0, n:0, th:{}}; }
    if (create && !Array.isArray(dd[k].g)) dd[k].g = [];
    return dd[k];
  }
  function count(){ var e = entry(false); return e && Array.isArray(e.g) ? e.g.length : 0; }
  function target(){ return cfg.target; }
  function setGoal(v){
    v = +v; if (GOALS.indexOf(v) < 0) return;
    cfg.target = v; saveCfg(); render(); syncSettings();
  }

  // ---------- livello e prossimo esercizio ----------
  function diff(n){ var x = SF.ex && SF.ex[n]; return x && x.d ? x.d : 2; }
  function diffName(d){ return (SF.nomi && SF.nomi[d]) || ('livello ' + d); }
  // precisione recente = esiti al primo colpo degli ultimi 20 esercizi (p50 di progressi.js)
  function level(){
    var a = (S.data().p50 || []).slice(-20);
    if (a.length < 5) return {lv:1, acc:null, n:a.length};
    var s = 0; a.forEach(function(x){ s += x; }); var acc = s / a.length;
    var lv = acc >= 0.9 ? 5 : acc >= 0.8 ? 4 : acc >= 0.65 ? 3 : acc >= 0.5 ? 2 : 1;
    return {lv:lv, acc:acc, n:a.length};
  }
  var recent = [];   // ultimi esercizi aperti: una lacuna appena sbagliata non torna subito
  document.addEventListener('cnp:load', function(ev){
    var n = ev.detail && ev.detail.n; if (!n) return;
    recent = recent.filter(function(x){ return x !== n; }); recent.push(n); if (recent.length > 3) recent.shift();
    render();
  });
  function curN(){ return A.state && A.state.ex ? A.state.ex.n : 0; }
  function pickLacuna(){
    // solo il «Ripasso di oggi» (tappe 1 · 3 · 7 giorni, max 10 al giorno), già in ordine
    var cur = curN();
    var q = (S.todayList ? S.todayList() : S.queue()).filter(function(n){ return n !== cur && recent.indexOf(n) < 0; });
    return q.length ? q[0] : 0;
  }
  function pickNew(lv){
    var p = A.progress() || {}, rev = S.data().rev, cur = curN();
    var open = EX.filter(function(e){ return e.n !== cur && p[e.n] !== 's' && p[e.n] !== 'e' && !rev[e.n]; });
    if (!open.length) return 0;
    // nell'ordine del libro: prima la difficoltà giusta (o una sotto), poi la più vicina
    var hit = open.filter(function(e){ var x = diff(e.n); return x <= lv && x >= lv - 1; })[0];
    if (hit) return hit.n;
    var best = open[0], bd = 9;
    open.forEach(function(e){ var dd = Math.abs(diff(e.n) - lv); if (dd < bd){ bd = dd; best = e; } });
    return best.n;
  }
  // 30/10 (blocco 5) «Continua per tema»: il prossimo esercizio NON risolto dello STESSO tema (capitolo), nell'ordine
  // del libro dopo quello attuale (poi dall'inizio del tema). Mai uno già risolto ('s'/'e'): quelli si rifanno solo
  // dal «Ripasso di oggi» o da «Da ripassare» (anche gli esercizi in coda di ripasso restano lì, non qui).
  // Tema finito: propone il primo tema successivo (ordine del libro) che ha ancora esercizi da fare.
  function solved(p, n){ return p[n] === 's' || p[n] === 'e'; }
  function chList(c){ var ch = chById[c]; return ch && ch.list ? ch.list : EX.filter(function(e){ return e.c === c; }); }
  function chDone(c){ var p = A.progress() || {}, d = 0; chList(c).forEach(function(e){ if (solved(p, e.n)) d++; }); return d; }
  function openIn(c, after){
    var p = A.progress() || {}, rev = S.data().rev || {}, cur = curN();
    var L = chList(c).filter(function(e){ return e.n !== cur && !solved(p, e.n) && !rev[e.n]; });
    if (!L.length) return 0;
    var a = L.filter(function(e){ return e.n > after; })[0];
    return (a || L[0]).n;
  }
  function next(){
    var e = A.state && A.state.ex, chs = window.BOOK.chapters, c = e ? e.c : chs[0].id, cur = curN();
    var ch = chById[c], tot = chList(c).length, done = chDone(c), w = openIn(c, cur);
    if (w){ var left = tot - done - (e && !solved(A.progress() || {}, cur) ? 1 : 0);
      return {n:w, kind:'tema', c:c, name:ch.name, done:done, tot:tot, label:'Tema ' + ch.name + ': ' + done + ' di ' + tot + ' risolti', short:ch.name + ' · ' + (left === 1 ? 'ne manca 1' : 'ne mancano ' + left)}; }
    var i0 = 0; chs.forEach(function(x, i){ if (x.id === c) i0 = i; });
    for (var k = 1; k <= chs.length; k++){
      var c2 = chs[(i0 + k) % chs.length], n2 = openIn(c2.id, 0);
      if (n2) return {n:n2, kind:'tema-nuovo', c:c2.id, name:c2.name, done:chDone(c2.id), tot:chList(c2.id).length, fromName:ch.name, fromDone:done, fromTot:tot,
        label:'Tema ' + ch.name + ' finito. Prossimo tema: ' + c2.name, short:'Prossimo tema · ' + c2.name};
    }
    return {n:0, kind:'none', label:'Hai fatto tutti gli esercizi!', short:'Tutto fatto!'};
  }
  function go(){
    var t = next(); if (!t.n){ A.UI.toast('Hai risolto tutti gli esercizi: ora restano i ripassi.'); return t; }
    try { if (A.state && A.state.analysis && A.exitAnalysis) A.exitAnalysis(); } catch(e){}
    A.loadEx(t.n);
    try { document.dispatchEvent(new CustomEvent('cnp:continua', {detail:t})); } catch(e){}
    return t;
  }

  // ---------- interfaccia: barra con anello + Continua ----------
  var R = 19, CIRC = 2 * Math.PI * R;
  var bar = el('div', {id:'pgBar', 'class':'pgbar', role:'region', 'aria-label':'Percorso guidato'},
    '<button type="button" id="pgRing" class="pgring" aria-haspopup="dialog" aria-expanded="false">' +
      '<svg viewBox="0 0 48 48" width="48" height="48" aria-hidden="true" focusable="false"><circle class="rg-bg" cx="24" cy="24" r="' + R + '"/>' +
      '<circle class="rg-fg" cx="24" cy="24" r="' + R + '" stroke-dasharray="' + CIRC.toFixed(2) + '" stroke-dashoffset="' + CIRC.toFixed(2) + '" transform="rotate(-90 24 24)"/></svg>' +
      '<span class="rg-txt"><b id="pgCount">0</b><small id="pgTarget">/10</small></span></button>' +
    '<div class="pginfo"><b class="pgtitle">Obiettivo di oggi</b><span id="pgSub" class="pgnote"></span></div>' +
    '<button type="button" id="pgCont" class="pgcont">' + svg('play', 18) + '<span class="pc-t">Continua</span><small id="pgWhy" class="pgwhy"></small></button>');
  var pop = el('div', {id:'pgPop', 'class':'pgpop', role:'dialog', 'aria-label':'Obiettivo del giorno', hidden:''});
  document.body.appendChild(pop);
  place();
  if (!bar.parentNode) return;

  function place(){
    var deck = window.__flay && __flay.active && __flay.active(), dest, before;
    if (deck){ dest = document.querySelector('#fDeck .fscroll'); before = dest && dest.firstChild; }
    else { dest = document.querySelector('.panel'); before = $('reviewBar') || (dest && dest.firstChild); if (before && before.parentNode !== dest) before = dest.firstChild; }
    if (!dest) return;
    if (bar.parentNode !== dest || bar.nextSibling !== before) dest.insertBefore(bar, before);
    root.classList.toggle('pgdeck', !!deck);
  }

  function render(){
    var c = count(), g = target(), t = next(), done = c >= g;
    var f = Math.min(1, c / g);
    bar.querySelector('.rg-fg').setAttribute('stroke-dashoffset', (CIRC * (1 - f)).toFixed(2));
    $('pgCount').textContent = c; $('pgTarget').textContent = '/' + g;
    bar.classList.toggle('done', done);
    var ring = $('pgRing');
    ring.title = 'Obiettivo di oggi: ' + c + ' su ' + g + ' esercizi. Tocca per cambiarlo';
    ring.setAttribute('aria-label', 'Obiettivo di oggi: ' + c + ' su ' + g + ' esercizi risolti. Tocca per cambiarlo');
    $('pgSub').textContent = done ? (c > g ? 'Raggiunto! ' + c + ' esercizi oggi' : 'Raggiunto! 🎉') : (g - c === 1 ? 'Ne manca 1' : 'Ne mancano ' + (g - c));
    $('pgWhy').textContent = t.short;
    var cb = $('pgCont'); cb.disabled = !t.n; cb.dataset.kind = t.kind;
    cb.title = t.n ? 'Continua: ' + t.label + ' (esercizio ' + t.n + ')' : t.label;
    cb.setAttribute('aria-label', 'Continua. ' + t.label);
    bar.classList.toggle('fin', !!(A.state && A.state.finished && $('fbCont')));   // dopo la soluzione Continua solo nell'esito
    var fc = $('fbCont'); if (fc){ var w = fc.querySelector('.pgwhy'); if (w) w.textContent = t.short; fc.disabled = !t.n; fc.dataset.kind = t.kind; }
    if (!pop.hidden) renderPop();
    if (window.__v6 && window.__v6.schedule) window.__v6.schedule();
  }
  $('pgCont').onclick = function(){ go(); };

  // dopo l'esercizio: «Continua» è il passo successivo naturale, nella riga dei pulsanti dell'esito
  function addFbCont(){
    if (!A.state || !A.state.finished) return;   // solo a esercizio concluso, non dopo un errore
    var row = document.querySelector('#feedback .fbbtns'); if (!row || $('fbCont')) return;
    var b = el('button', {type:'button', id:'fbCont', 'class':'fbcont'}, '<span class="pc-t">Continua</span>' + svg('arrow-right', 16) + '<small class="pgwhy"></small>');
    b.onclick = function(){ go(); };
    row.appendChild(b);
    var nx = $('fbNext'); if (nx) nx.classList.add('pgsec');
    render();
  }
  new MutationObserver(function(){ if (!$('fbCont')) addFbCont(); else render(); }).observe($('feedback'), {childList:true});

  // ---------- popover dell'anello ----------
  function costanza(){ try { return P && P.streaks ? P.streaks().cur : 0; } catch(e){ return 0; } }
  function renderPop(){
    var c = count(), g = target(), k = costanza();
    pop.innerHTML = '<div class="pp-head"><b>Obiettivo del giorno</b><button type="button" class="pp-x" aria-label="Chiudi">' + (svg('x', 18) || '✕') + '</button></div>' +
      '<p class="pp-txt">Oggi hai risolto <b>' + c + '</b> ' + (c === 1 ? 'esercizio' : 'esercizi') + ' su ' + g + '.</p>' +
      '<div class="pp-goals" role="radiogroup" aria-label="Esercizi al giorno">' + GOALS.map(function(v){
        return '<button type="button" role="radio" data-g="' + v + '" aria-checked="' + (v === g) + '"' + (v === g ? ' class="on"' : '') + '><b>' + v + '</b><small>' + (v === 5 ? 'leggero' : v === 10 ? 'normale' : 'intenso') + '</small></button>'; }).join('') + '</div>' +
      '<div class="pp-links"><button type="button" data-l="costanza">' + (svg('flame', 18) || '🔥') + '<span>Costanza: <b>' + k + '</b> ' + (k === 1 ? 'giorno' : 'giorni') + ' di fila</span></button>' +
      '<button type="button" data-l="coppe">' + (svg('trophy', 18) || '🏆') + '<span>Le tue coppe</span></button></div>' +
      '<p class="pp-help">Conta ogni esercizio risolto da te una volta al giorno. Si riparte da zero ogni mattina.</p>';
  }
  var lastFocus = null;
  // l'anello visibile: nella v6 (telefono) è il mini-anello nella riga delle mosse
  function ringEl(){ var v = $('v6Goal'); return v && v.offsetWidth ? v : $('pgRing'); }
  var popAnchor = null;
  function openPop(anchor){
    lastFocus = document.activeElement; renderPop();
    popAnchor = anchor && anchor.getBoundingClientRect ? anchor : ringEl();
    // blocco 4: nella v6 (telefono) il pannello sta nella zona libera sotto la riga delle mosse, dentro il flusso: non copre mai la scacchiera
    var fr = $('v6Free'), mv = $('v6Mv');
    if (document.documentElement.classList.contains('v6') && fr && mv){
      if (pop.parentNode !== fr || pop.previousElementSibling !== mv) fr.insertBefore(pop, mv.nextSibling);
      pop.classList.add('inl'); pop.style.width = pop.style.left = pop.style.top = ''; pop.hidden = false; fr.scrollTop = 0;
      popAnchor.setAttribute('aria-expanded', 'true');
      var f0 = pop.querySelector('.pp-goals .on'); if (f0) try { f0.focus({preventScroll:true}); } catch(e){}
      return;
    }
    if (pop.classList.contains('inl')){ pop.classList.remove('inl'); document.body.appendChild(pop); }
    pop.hidden = false;
    var r = popAnchor.getBoundingClientRect(), W = document.documentElement.clientWidth, H = window.innerHeight;
    var pw = Math.min(320, W - 16); pop.style.width = pw + 'px';
    var left = Math.max(8, Math.min(W - pw - 8, r.left)), top = r.bottom + 8;
    var ph = pop.offsetHeight;
    if (document.documentElement.classList.contains('v6')){
      // telefono: in basso, sopra la barra dei comandi (come un foglio), centrato
      var bot = $('v6Bot'), bt = bot && bot.offsetHeight ? bot.getBoundingClientRect().top : H;
      left = Math.round((W - pw) / 2); top = Math.max(8, bt - ph - 8);
    } else if (top + ph > H - 8) top = Math.max(8, r.top - ph - 8);
    pop.style.left = left + 'px';
    pop.style.top = top + 'px';
    popAnchor.setAttribute('aria-expanded', 'true');
    var f = pop.querySelector('.pp-goals .on'); if (f) try { f.focus({preventScroll:true}); } catch(e){}
  }
  function closePop(){ if (pop.hidden) return; pop.hidden = true; (popAnchor || $('pgRing')).setAttribute('aria-expanded', 'false'); if (lastFocus && lastFocus.focus) try { lastFocus.focus({preventScroll:true}); } catch(e){} }
  $('pgRing').onclick = function(ev){ ev.stopPropagation(); if (pop.hidden) openPop(); else closePop(); };
  pop.addEventListener('click', function(ev){
    ev.stopPropagation();
    var b = ev.target.closest('button'); if (!b) return;
    if (b.classList.contains('pp-x')){ closePop(); return; }
    if (b.dataset.g){ setGoal(b.dataset.g); var f = pop.querySelector('.pp-goals .on'); if (f) f.focus(); return; }
    if (b.dataset.l){ closePop(); openCoppe(b.dataset.l === 'costanza'); }
  });
  document.addEventListener('click', function(ev){ if (!pop.hidden && !pop.contains(ev.target)) closePop(); });
  document.addEventListener('keydown', function(ev){ if (ev.key === 'Escape' && !pop.hidden){ ev.preventDefault(); ev.stopImmediatePropagation(); closePop(); } }, true);
  window.addEventListener('resize', function(){ closePop(); });
  function openCoppe(flash){
    try { S.selectTab('coppe'); S.openStats(); S.selectTab('coppe'); } catch(e){ return; }
    if (flash) setTimeout(function(){
      var c = document.querySelector('#statsDlg .cupcard[data-fam=costanza]'); if (!c) return;
      try { c.scrollIntoView({block:'center', behavior:'smooth'}); } catch(e){}
      c.classList.remove('pgflash'); void c.offsetWidth; c.classList.add('pgflash');
    }, 120);
  }

  // ---------- conteggio ----------
  document.addEventListener('cnp:solved', function(ev){
    var d = ev.detail || {};
    if (d.shown || !d.n) return;                       // soluzione vista: non conta
    var e = entry(true);
    if (e.g.indexOf(d.n) >= 0){ render(); return; }   // stesso esercizio rifatto oggi: conta una volta
    e.g.push(d.n); S.save();
    render(); pulse();
    var c = e.g.length, g = target();
    if (c >= g && (e.gc || 0) < g){ e.gc = g; S.save(); setTimeout(function(){ celebrate(c, g); }, 900); }
  });
  document.addEventListener('cnp:reset', function(){ setTimeout(render, 0); });
  document.addEventListener('cnp:focus', function(){ setTimeout(function(){ place(); render(); }, 0); });
  ['solved', 'show', 'mistake', 'giveup', 'hint'].forEach(function(k){ document.addEventListener('cnp:' + k, function(){ setTimeout(render, 0); }); });
  var dayNow = today();
  setInterval(function(){ var k = today(); if (k !== dayNow){ dayNow = k; render(); } }, 30000);

  function anim(){ return document.body.classList.contains('anim-normal') || (!document.body.classList.contains('anim-reduced') && !document.body.classList.contains('anim-off') && !(window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches)); }
  function pulse(){ var r = ringEl(); r.classList.remove('bump'); void r.offsetWidth; r.classList.add('bump'); }

  // ---------- festa ----------
  var toast = el('div', {id:'pgToast', 'class':'streaktoast pgtoast', role:'status', hidden:''});
  document.body.appendChild(toast);
  function celebrate(c, g){
    var k = costanza();
    var go2 = function(){
      toast.innerHTML = '<div class="pt-ring">' + (svg('target', 28) || '🎯') + '</div><div class="st-txt"><b>Obiettivo di oggi raggiunto!</b><span>' + c + ' esercizi risolti oggi. ' +
        (k > 1 ? 'Costanza: ' + k + ' giorni di fila 🔥' : 'Torna domani per la Costanza 🔥') + '</span></div>';
      toast.hidden = false; void toast.offsetWidth; toast.classList.remove('show'); void toast.offsetWidth; toast.classList.add('show');
      bar.classList.add('party');
      try { A.Sound.play('brilliant', 0); } catch(e){}
      // scacco matto 10-11: niente coriandoli (al loro posto, nell'esercizio, il riflesso dorato sui pezzi)
      window.__goalWins = (window.__goalWins || []).concat([g]);
      try { document.dispatchEvent(new CustomEvent('cnp:goal', {detail:{count:c, target:g}})); } catch(e){}
      clearTimeout(toast._t); toast._t = setTimeout(function(){ toast.classList.remove('show'); bar.classList.remove('party'); setTimeout(function(){ if (!toast.classList.contains('show')) toast.hidden = true; }, 400); }, 4200);
    };
    var st = S.toastEl; if (st && !st.hidden) setTimeout(go2, 3800); else go2();
  }
  // coriandoli leggeri che partono dall'anello
  function confetti(){
    var r = ringEl().getBoundingClientRect(); if (!r.width) r = {left:innerWidth / 2, top:innerHeight / 3, width:0, height:0};
    var cv = document.createElement('canvas'), dpr = Math.min(2, window.devicePixelRatio || 1), W = 360, H = 300;
    cv.className = 'pgconf'; cv.width = W * dpr; cv.height = H * dpr;
    var cx = r.left + r.width / 2, cy = r.top + r.height / 2;
    cv.style.left = (cx - W / 2) + 'px'; cv.style.top = (cy - H / 2) + 'px'; cv.style.width = W + 'px'; cv.style.height = H + 'px';
    document.body.appendChild(cv);
    var ctx = cv.getContext('2d'), cols = ['#e0a33a', '#34c759', '#0a84ff', '#ff453a', '#f3efe6', '#b06ad9'], pts = [];
    for (var i = 0; i < 46; i++){ var a = Math.random() * Math.PI * 2, v = (2.5 + Math.random() * 4.5) * dpr;
      pts.push({x:W * dpr / 2, y:H * dpr / 2, vx:Math.cos(a) * v, vy:Math.sin(a) * v - 2 * dpr, s:(3 + Math.random() * 4) * dpr, a:Math.random() * 6, va:(Math.random() - 0.5) * 0.4, c:cols[i % cols.length]}); }
    var t0 = performance.now();
    (function frame(t){
      var k = (t - t0) / 1300; ctx.clearRect(0, 0, cv.width, cv.height);
      if (k >= 1){ cv.remove(); return; }
      ctx.globalAlpha = k < 0.6 ? 1 : (1 - k) / 0.4;
      pts.forEach(function(p){ p.vy += 0.18 * dpr; p.x += p.vx; p.y += p.vy; p.vx *= 0.98; p.a += p.va;
        ctx.save(); ctx.translate(p.x, p.y); ctx.rotate(p.a); ctx.fillStyle = p.c; ctx.fillRect(-p.s / 2, -p.s / 4, p.s, p.s / 2); ctx.restore(); });
      requestAnimationFrame(frame);
    })(t0);
  }

  // ---------- impostazioni (scheda Dati, in cima) ----------
  var pane = $('pane-data');
  if (pane){
    var sec = el('div', {id:'pgSet', 'class':'pgset'}, '<h3>Obiettivo del giorno</h3><div class="lookrow"><span class="lbl">Esercizi al giorno</span><select id="pgGoalSel">' +
      GOALS.map(function(v){ return '<option value="' + v + '">' + v + (v === 5 ? ' (leggero)' : v === 10 ? ' (normale)' : ' (intenso)') + '</option>'; }).join('') + '</select></div>' +
      '<p class="lookhelp">L\'anello accanto a «Continua» si riempie con gli esercizi risolti oggi. «Continua» alterna un esercizio da ripassare e uno nuovo adatto al tuo livello.</p>');
    pane.insertBefore(sec, pane.firstChild);
    $('pgGoalSel').onchange = function(){ setGoal(this.value); };
  }
  function syncSettings(){ var s = $('pgGoalSel'); if (s) s.value = String(target()); }
  syncSettings();

  window.__percorso = {next:next, go:go, count:count, target:target, setGoal:setGoal, level:level, render:render, place:place, celebrate:celebrate, openPop:openPop, closePop:closePop, recent:function(){ return recent; }};
  var rT = 0; window.addEventListener('resize', function(){ clearTimeout(rT); rT = setTimeout(place, 120); });
  place(); render();
  if (A.state && (A.state.finished || A.state.shown)) addFbCont();
})();
