/* 0.9.0 (01/11): la Home e i Progressi dentro l'app (iframe a tutto schermo, stessa origine: stessi dati in localStorage).
   Blocco 2 del grande aggiornamento (10-11): Home 15f, barra fissa v2, pagine nuove (I miei salvati, Impostazioni, Info e crediti,
   Sostieni, Primo avvio) con una PILA per il tasto Indietro:
   - Indietro chiede prima alla pagina (viste interne, es. Impostazioni › Notifiche: window.__cnIndietro), poi torna alla pagina
     precedente della pila, poi alla Home; dalla Home (o dalla prima pagina del Primo avvio) esce dall'app come prima.
   - Le voci della barra (Home, Progressi) azzerano la pila: Indietro da Progressi torna alla Home.
   - Primo avvio 29c: si apre al posto della Home se non c'è ancora un profilo (e non è già stato fatto/saltato). Con ?nohome no.
   11-11: transizioni della pila (entrata da destra 220 ms, Indietro inverte; tab della barra: dissolvenza 150 ms). Rispettano
   Animazioni Attive/Ridotte/Spente. Nascondi/go verso l'esercizio restano immediati (tempi dei puzzle invariati). */
(function(){
  var A = window.__app; if (!A) return;
  var wrap = document.createElement('div'); wrap.id = 'cnHome';
  wrap.style.cssText = 'position:fixed;inset:0;z-index:2147483000;background:#151D24;overflow:hidden';
  function themeBg(){ try { return (A.prefs && A.prefs.bg === 'bianco') ? '#F1F4F6' : '#151D24'; } catch(e){ return '#151D24'; } }
  function makeFr(){
    var f = document.createElement('iframe'); f.title = 'Home'; f.setAttribute('allow', 'autoplay');
    // 13-11 schermo intero vero (viewport-fit=cover): l'iframe parte sotto la fotocamera/notch; la striscia sopra ha il colore del tema (#cnHome)
    f.style.cssText = 'position:absolute;top:env(safe-area-inset-top,0px);left:env(safe-area-inset-left,0px);border:0;width:calc(100% - env(safe-area-inset-left,0px) - env(safe-area-inset-right,0px));height:calc(100% - env(safe-area-inset-top,0px));display:block;background:' + themeBg() + ';opacity:0;pointer-events:none;z-index:0';
    wrap.appendChild(f); return f;
  }
  var frames = [makeFr(), makeFr()], fi = 0;
  document.body.appendChild(wrap);
  /* 14-11 (Kiko t1938u «striscia bianca in alto»): la striscia sopra l'iframe (zona fotocamera/notch, env(safe-area-inset-top))
     è lo sfondo di #cnHome. Prima si aggiornava solo all'apertura di una pagina: col sole/luna della Home (o da Opzioni) restava
     il colore del tema di partenza (partendo dal giorno: striscia chiara sulla notte). Ora segue subito il tema, nei due versi,
     insieme allo sfondo dei due iframe (niente lampo del colore vecchio alla pagina dopo). */
  function tinta(){
    var c = themeBg();
    if (wrap.style.background !== c) wrap.style.background = c;
    frames.forEach(function(f){ f.style.background = c; });
  }
  try { new MutationObserver(tinta).observe(document.body, {attributes:true, attributeFilter:['data-bg']}); } catch(e){}
  function fr(){ return frames[fi]; }
  function pagina(){ try { return (fr().contentWindow.location.pathname.split('/').pop() || ''); } catch(e){ return ''; } }
  function visibile(){ return !wrap.hidden; }
  var pila = [], cur = '', tornando = false, ROOT = {'home.html':1, 'primo_avvio.html':1}, trans = false;
  var daApp = false;
  function mot(){
    var m = 'attive';
    try {
      var p = A.prefs || {};
      if (p.anim === 'off') m = 'spente';
      else if (p.anim === 'reduced') m = 'ridotte';
      if (m === 'attive' && matchMedia('(prefers-reduced-motion: reduce)').matches) m = 'ridotte';
    } catch(e){}
    return m;
  }
  function langq(){ return (A.prefs && A.prefs.lang === 'en' ? '?lang=en' : ''); }
  function srcOf(pg){ pg = pg || 'home.html'; var q = langq(); return pg + (q && pg.indexOf('?') >= 0 ? '&' + q.slice(1) : q); }
  function rest(f, vis, z){
    f.style.transition = 'none';
    f.style.transform = 'none';
    f.style.opacity = vis ? '1' : '0';
    f.style.pointerEvents = vis ? 'auto' : 'none';
    f.style.zIndex = String(z == null ? (vis ? 2 : 0) : z);
  }
  function load(f, pg){
    return new Promise(function(res){
      var done = function(){ f.removeEventListener('load', done); res(); };
      f.addEventListener('load', done);
      f.src = srcOf(pg);
    });
  }
  function raf(){ return new Promise(function(r){ requestAnimationFrame(function(){ requestAnimationFrame(r); }); }); }
  function wait(ms){ return new Promise(function(r){ setTimeout(r, ms); }); }
  function afterPress(fn){
    if (mot() !== 'attive'){ fn(); return; }
    var t0 = (window.__cnEffetti && __cnEffetti.pointerDownAt) || 0;
    var now = (typeof performance !== 'undefined' ? performance.now() : Date.now());
    if (!t0 || now - t0 > 500){ fn(); return; }
    var delay = Math.max(0, Math.min(90 - (now - t0), 120));
    if (delay > 0) setTimeout(fn, delay); else fn();
  }
  function animateIn(next, prev, mode, reverse){
    wrap.style.background = themeBg();
    var m = mot();
    if (m === 'spente'){ rest(next, true, 2); rest(prev, false, 0); return Promise.resolve(); }
    var fadeOnly = mode === 'fade' || m === 'ridotte';
    if (fadeOnly){
      rest(prev, true, 1);
      next.style.transition = 'none'; next.style.transform = 'none'; next.style.opacity = '0';
      next.style.zIndex = '3'; next.style.pointerEvents = 'none';
      return raf().then(function(){
        next.style.transition = 'opacity 150ms ease'; next.style.opacity = '1';
        return wait(150);
      }).then(function(){ rest(next, true, 2); rest(prev, false, 0); });
    }
    if (reverse){
      rest(next, true, 1); rest(prev, true, 3);
      return raf().then(function(){
        prev.style.transition = 'transform 220ms ease-out, opacity 220ms ease-out';
        prev.style.transform = 'translateX(28px)'; prev.style.opacity = '0';
        return wait(220);
      }).then(function(){ rest(next, true, 2); rest(prev, false, 0); });
    }
    rest(prev, true, 1);
    next.style.transition = 'none'; next.style.transform = 'translateX(28px)'; next.style.opacity = '0';
    next.style.zIndex = '3'; next.style.pointerEvents = 'none';
    return raf().then(function(){
      next.style.transition = 'transform 220ms ease-out, opacity 220ms ease-out';
      next.style.transform = 'translateX(0)'; next.style.opacity = '1';
      return wait(220);
    }).then(function(){ rest(next, true, 2); rest(prev, false, 0); });
  }
  function blankOther(){
    var o = frames[1 - fi];
    try { o.style.transition = 'none'; o.src = 'about:blank'; } catch(e){}
  }

  function carica(pg, barra, fromBack, instant){
    if (trans && !instant) return;
    var name = (pg || 'home.html').split('?')[0].split('#')[0];
    if (!fromBack){
      if (barra){ daApp = false; pila = name === 'home.html' ? [] : ['home.html']; tornando = true; }
      else if (cur && cur !== name && !ROOT[name]) { /* pila gestita sotto */ }
    }
    if (!fromBack && !instant){
      if (barra) pila = (name === 'home.html') ? [] : ['home.html'];
      else if (cur && cur !== name && cur !== 'blank') pila.push(cur);
    }
    var next = frames[1 - fi], prev = frames[fi];
    trans = true;
    var start = function(){
      load(next, pg).then(function(){
        var mode = (barra || instant) ? 'fade' : 'slide';
        if (instant){ rest(next, true, 2); rest(prev, false, 0); return; }
        return animateIn(next, prev, mode, !!fromBack);
      }).then(function(){
        fi = 1 - fi;
        cur = name;
        tornando = false;
        trans = false;
        blankOther();
      }).catch(function(){ trans = false; });
    };
    if (instant || fromBack || barra) start(); else afterPress(start);
  }

  function mostra(pg){
    if (!visibile() && !ROOT[pg || 'home.html']){ daApp = true; pila = []; cur = ''; }
    wrap.style.background = themeBg();
    wrap.hidden = false; document.documentElement.classList.add('cnhome-on');
    // prima apertura o ritorno dall'esercizio: senza transizione della pila (restituisce subito l'esercizio o la Home)
    var next = fr();
    trans = true;
    load(next, pg || 'home.html').then(function(){
      rest(next, true, 2);
      cur = pagina() || (pg || 'home.html').split('?')[0].split('#')[0];
      if (ROOT[cur]){ pila = []; }
      trans = false;
    });
  }
  function apri(pg, barra){ if (barra){ daApp = false; pila = (pg === 'home.html' ? [] : ['home.html']); tornando = true; }
    if (!visibile()){ mostra(pg); return; }
    carica(pg, !!barra, false, false);
  }
  function interno(){ try { return !!(fr().contentWindow.__cnPuoTornare && fr().contentWindow.__cnPuoTornare()); } catch(e){ return false; } }
  function indietro(){
    if (!visibile()) return;
    try { if (fr().contentWindow.__cnIndietro && fr().contentWindow.__cnIndietro()) return; } catch(e){}
    if (pila.length){ var t = pila.pop(); tornando = true; carica(t, false, true, false); return; }
    if (daApp){ nascondi(); return; }
    if (!ROOT[pagina()]) carica('home.html', true, true, false);
  }
  function puoTornare(){ return interno() || pila.length > 0 || daApp || !ROOT[pagina()]; }
  function nascondi(){
    daApp = false; pila = []; cur = ''; trans = false;
    wrap.hidden = true; document.documentElement.classList.remove('cnhome-on');
    frames.forEach(function(f){ try { f.src = 'about:blank'; rest(f, false, 0); } catch(e){} });
    fi = 0;
    try { window.focus(); document.body.focus(); } catch(e){}
  }
  /* blocco 3 (11-11): partita col bot lanciata da una pagina (Gioca, Le tue partite): si ricorda da dove, per tornarci
     (Indietro dalla partita, «Cambia avversario», chiusura dell'analisi). Senza ricordo: pagina Gioca come voce della barra. */
  var ritorno = null;
  function ritorna(pg, pilaR){
    var r = pg ? {pg:pg, pila:pilaR || ['home.html']} : (ritorno || {pg:'gioca.html', pila:['home.html']});
    ritorno = null;
    wrap.style.background = themeBg();
    wrap.hidden = false; document.documentElement.classList.add('cnhome-on');
    daApp = false; pila = r.pila.slice();
    var next = fr(); trans = true;
    load(next, r.pg).then(function(){ rest(next, true, 2); cur = r.pg.split('?')[0]; trans = false; });
  }
  function osservaAnalisi(){
    var ap = document.getElementById('anPage'); if (!ap) return;
    var mo = new MutationObserver(function(){ if (ap.hidden){ mo.disconnect(); if (!visibile() && !(window.CNBot && CNBot.isOpen())) ritorna(); } });
    mo.observe(ap, {attributes:true, attributeFilter:['hidden']});
  }
  /* blocco 4 (11-11): esercizio (Tattica, Puzzle Random, Esercizio del giorno, Ripasso) aperto da una pagina: si ricorda da dove
     (pagina e pila), così la freccia ← dell'esercizio e Indietro tornano lì (Studia, Tattica, Home, Salvati…). Senza ricordo: Home. */
  var ritornoEs = null;
  function tornaEs(){
    try { if (A.UI && A.UI.closeMore) A.UI.closeMore(); } catch(e){}
    var r = ritornoEs;
    if (r && r.pg && !ROOT[r.pg.split('?')[0]]){ ritorna(r.pg, r.pila); return; }
    mostra(r && r.pg ? r.pg : 'home.html');
  }
  function go(g, bot){
    // blocco 5 (11-11): Analisi è una pagina della barra (schema 22 A); da lì si apre la Scacchiera di analisi o una partita commentata (22b)
    if (g === 'analisi' || g === 'tab3'){ apri('analisi.html', true); return; }
    // un motore alla volta: l'analisi di una partita continua mentre si gira fra le pagine, si mette in pausa (salvata) se si apre un esercizio o una partita
    if (!/^(anlibera|anpartita|botanalizza)$/.test(g)) try { if (window.CNAnalisiPartita && CNAnalisiPartita.busy()) CNAnalisiPartita.cancel(); } catch(e){}
    if (/^(bot|anlibera$|anpartita$)/.test(g)) ritorno = {pg:(cur || pagina() || 'gioca.html'), pila:pila.slice()};
    else if (visibile() && !/^(analisi|tab3|profilo|set)$/.test(g)){ var pq = ''; try { var l = fr().contentWindow.location; pq = l.pathname.split('/').pop() + (l.search || ''); } catch(e){}
      ritornoEs = {pg:(pq || cur || 'home.html'), pila:pila.slice()}; }
    /* 14-11 (Kiko t1940u): per l'analisi si apre la pagina SOTTO la Home ancora visibile e la Home sfuma solo quando #anPage è
       pronta (doppio rAF + 120 ms), come all'avvio: prima nascondi() scopriva per un fotogramma l'esercizio che sta sotto. */
    if (/^(anlibera|anpartita|botanalizza)$/.test(g) && visibile()){
      var okA = false;
      try {
        if (g === 'botanalizza') okA = !!(window.CNBot && CNBot.analizzaRec(bot));
        else if (g === 'anlibera') okA = !!(window.CNAnalisi && (CNAnalisi.open(), true));
        else { var qA = window.__cnAnReq; window.__cnAnReq = null; okA = !!(qA && window.CNAnalisi && CNAnalisi.open(qA) !== false); }
      } catch(eA){ okA = false; }
      if (!okA){ ritorna(); return; }
      var ridA = document.documentElement.classList.contains('cn-ferme');
      requestAnimationFrame(function(){ requestAnimationFrame(function(){
        function fineA(){ nascondi(); wrap.style.transition = ''; wrap.style.opacity = ''; setTimeout(osservaAnalisi, 0);
          if (g === 'anlibera' && bot === 'pos') setTimeout(function(){ try { var t = document.querySelector('#anPage .anp-txt'); if (t){ t.scrollIntoView({block:'center'}); t.focus({preventScroll:true}); } } catch(e){} }, 60); }
        if (ridA){ fineA(); return; }
        wrap.style.transition = 'opacity 120ms ease'; wrap.style.opacity = '0'; setTimeout(fineA, 130);
      }); });
      return;
    }
    nascondi();
    setTimeout(function(){
      try {
        if (g === 'continua'){ if (window.__percorso && __percorso.go) __percorso.go(); return; }
        if (g === 'ripasso'){ if (window.__stats && __stats.startReview) __stats.startReview(); return; }
        if (g === 'gioca' || g === 'tab2'){ if (window.CNBot) CNBot.open(bot); return; }
        if (g === 'botstart'){ if (window.CNBot) CNBot.start(); return; }
        if (g === 'botriprendi'){ if (window.CNBot) CNBot.riprendi(); return; }
        if (g === 'botrivincita'){ if (window.CNBot) CNBot.rivincita(bot); return; }
        if (g === 'botanalizza'){ if (window.CNBot && CNBot.analizzaRec(bot)) setTimeout(osservaAnalisi, 0); else ritorna(); return; }
        if (g === 'anlibera'){ if (window.CNAnalisi){ CNAnalisi.open(); setTimeout(osservaAnalisi, 0);
          if (bot === 'pos') setTimeout(function(){ try { var t = document.querySelector('#anPage .anp-txt'); if (t){ t.scrollIntoView({block:'center'}); t.focus({preventScroll:true}); } } catch(e){} }, 60); } else ritorna(); return; }
        if (g === 'anpartita'){ var q = window.__cnAnReq; window.__cnAnReq = null; if (q && window.CNAnalisi && CNAnalisi.open(q) !== false) setTimeout(osservaAnalisi, 0); else ritorna(); return; }
        if (g === 'profilo' || g === 'set'){ if (A.openSettings) A.openSettings(); return; }
        if (g === 'es'){ var n = +bot; if (n && A.loadEx) A.loadEx(n); return; }
        // blocco 4: Puzzle Random (pz, pzrip = ripasso dei puzzle, pzfav = un puzzle salvato) ed Esercizio del giorno
        if (g === 'pz'){ if (window.CNPuzzle) CNPuzzle.open(bot); return; }
        if (g === 'pzrip'){ if (window.CNPuzzle) CNPuzzle.ripasso(); return; }
        if (g === 'pzid'){ if (window.CNPuzzle) CNPuzzle.openId(bot); return; }
        if (g === 'giorno'){ if (window.CNGiorno) CNGiorno.apri(); return; }
        if (g === 'tattica'){ if (window.CNB4) CNB4.apriTattica(bot); return; }
      } catch(e){}
    }, 0);
  }
  window.CNHome = {go:go, ritorna:ritorna, tornaEs:tornaEs, ritornoEs:function(){ return ritornoEs; }, mostra:mostra, nascondi:nascondi, visibile:visibile, apri:apri, indietro:indietro, pagina:pagina, pila:function(){ return pila.slice(); }, daApp:function(){ return daApp; },
    esterno:function(u){ try { window.open(u, '_blank', 'noopener'); } catch(e){} }};
  var U = window.UI, prev = U && U.modalOpen;
  function altroAperto(){ try { return !!(prev && prev()); } catch(e){ return false; } }
  if (U && prev){ U.modalOpen = function(){ return altroAperto() || (visibile() ? puoTornare() : true); }; }
  window.addEventListener('keydown', function(ev){
    if (ev.key !== 'Escape') return;
    if (visibile()){ if (puoTornare()){ ev.preventDefault(); ev.stopImmediatePropagation(); indietro(); } return; }
    if (altroAperto()) return;
    if (document.querySelector('#sidebar.open')) return;
    ev.preventDefault(); ev.stopImmediatePropagation(); tornaEs();   // blocco 4: torna da dove si era arrivati all'esercizio
  }, true);
  var sheet = document.getElementById('moreSheet'), grp = sheet && sheet.querySelector('.ms-anp');
  if (grp){ var it = document.createElement('button'); it.type = 'button'; it.className = 'ms-item'; it.dataset.a = 'home';
    it.innerHTML = '<svg class="lu" viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + ((window.LUCIDE || {})['v2-home'] || '') + '</svg><span>Home<small>Pagina iniziale, progressi e premi</small></span>';
    grp.insertBefore(it, grp.firstChild);
    it.addEventListener('click', function(){ setTimeout(function(){ try { if (A.UI && A.UI.closeMore) A.UI.closeMore(); } catch(e){} mostra('home.html'); }, 0); });
  }
  document.addEventListener('cnp:reset', function(){ try { localStorage.removeItem('chessnodeplay-partite-bot-v1'); localStorage.removeItem('chessnodeplay-bot-incorso-v1'); } catch(e){} });
  if (window.__agg) window.__agg.openCredits = function(){ apri('info.html'); };
  function primoAvvio(){ try { return !localStorage.getItem('chessnodeplay-profilo-v1') && !localStorage.getItem('chessnodeplay-primoavvio-v1'); } catch(e){ return false; } }
  if (!/[?&]nohome\b/.test(location.search)) mostra(primoAvvio() ? 'primo_avvio.html' : 'home.html'); else wrap.hidden = true;
})();
