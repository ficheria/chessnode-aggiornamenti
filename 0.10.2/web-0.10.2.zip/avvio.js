/* Avvio Chess Node (solo moderna): una volta per sessione, ~5 s, si salta con tocco/clic/tasto.
   Musica: avvio_intro.ogg|mp3 (4,9 s, app_tools/suoni.py --selezione, suoni di suoni_nuovi/selezione (blocco 2, 26/10): mossa su "Studia.",
   presa su "Analizza.", matto su "Migliora."; colpi a 1,30/1,90/2,50 s). play() diretto: se il browser lo rifiuta, niente
   musica e nessun avviso. Rispetta Suoni spenti, volume e "Musica di avvio" (prefs.introMusic) delle Impostazioni.
   APK (alla prossima ricostruzione): WebView setMediaPlaybackRequiresUserGesture(false) perché parta da sola. */
(function(){
  var a = document.getElementById('cnAvvio'); if (!a) return;
  var k = 'cn-avvio', forza = /[?&]avvio=1/.test(location.search);
  // sotto automazione (test) l'avvio non deve coprire la pagina; per vederlo: ?avvio=1
  if (navigator.webdriver && !forza) { a.remove(); return; }
  /* 14-11 (Kiko: «lampo strano, per un attimo il vecchissimo logo, non c'è più Studia Analizza Migliora»):
     la Home (#cnHome, home_app.js) si apre SOTTO l'avvio (z-index più alto in stile.css) e l'avvio sfuma solo quando la Home
     è pronta. Se l'avvio è già stato visto in questa sessione resta un velo blu notte senza scritte fino alla Home:
     mai la vecchia pagina dell'esercizio (☰ ♞ Chess Node) che prima si vedeva un attimo. */
  function homePronta(){
    var w = document.getElementById('cnHome');
    if (/[?&]nohome\b/.test(location.search)) return true;   // senza Home: niente da aspettare (se la Home non arriva: tempo massimo)
    if (!w) return false;
    if (w.hidden) return true;
    var f = w.querySelectorAll('iframe');
    for (var i = 0; i < f.length; i++) if (f[i].style.opacity === '1') return true;
    return false;
  }
  function quandoPronta(fn, max){
    var t = performance.now();
    (function giro(){ if (homePronta() || performance.now() - t > max) fn(); else setTimeout(giro, 40); })();
  }
  try {
    if (!forza && sessionStorage.getItem(k)) {
      a.classList.add('velo');
      quandoPronta(function(){ a.classList.add('via', 'veloce'); setTimeout(function(){ a.remove(); }, 220); }, 3000);
      return;
    }
    sessionStorage.setItem(k, '1');
  } catch(e){}
  var rm = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  var t0 = performance.now(), done = false, attesa = false, au = null, st = window.__avvio = {t0: t0, rm: rm, audio: 'no', skipped: false};
  if (rm) a.classList.add('ridotto');
  var p = {}; try { p = JSON.parse(localStorage.getItem('chessnodeplay-prefs-v1')) || {}; } catch(e){}
  if (p.sound !== false && p.introMusic !== false) {
    try {
      au = new Audio();
      au.src = au.canPlayType('audio/ogg; codecs="opus"') ? 'avvio_intro.ogg' : 'avvio_intro.mp3';
      au.volume = p.volume == null ? 0.7 : Math.max(0, Math.min(1, p.volume));
      st.audio = 'avvio';
      var pr = au.play();
      if (pr && pr.then) pr.then(function(){
        st.audio = 'suona';
        // allinea i colpi alle parole se la riproduzione è partita in ritardo
        var off = (performance.now() - t0) / 1000;
        if (!rm && off > 0.06 && off < 1.15) { try { au.currentTime = off; } catch(e){} }
      }, function(){ st.audio = 'rifiutato'; au = null; });
    } catch(e){ au = null; st.audio = 'errore'; }
  }
  function fadeAudio(){
    if (!au) return; var x = au, v = x.volume, n = 0;
    var t = setInterval(function(){ n++; try { x.volume = Math.max(0, v * (1 - n / 6)); } catch(e){} if (n >= 6){ clearInterval(t); try { x.pause(); } catch(e){} } }, 25);
  }
  function fine(veloce){
    if (done) return;
    // a fine animazione aspetta la Home (al massimo 2,5 s in più, telefoni lenti) così sotto non si vede altro
    if (!veloce && !attesa && !homePronta()){ attesa = true; quandoPronta(function(){ fine(false); }, 2500); return; }
    done = true;
    ['pointerdown','keydown'].forEach(function(t){ window.removeEventListener(t, salta, true); });
    if (veloce) fadeAudio();
    if (rm) { a.remove(); return; }
    a.classList.add('via'); if (veloce) a.classList.add('veloce');
    setTimeout(function(){ a.remove(); }, veloce ? 220 : 620);
  }
  function salta(e){ st.skipped = true; if (e && e.cancelable) e.preventDefault(); if (e) e.stopPropagation(); fine(true); }
  ['pointerdown','keydown'].forEach(function(t){ window.addEventListener(t, salta, true); });
  setTimeout(function(){ fine(false); }, rm ? 1500 : 4400);
  st.salta = function(){ salta(null); };
})();
