/* Grande aggiornamento, blocco 3 (11-11): collegamento fra l'app e cn_premi.js v3 (da_integrare/premi_v3_08-11, file invariato).
   - UNA sola istanza (window.CNPremiApp), creata dopo stats.js e progressi.js: alla prima apertura migra in silenzio i vecchi dati
     (coppe e trofei con le loro date: 21 date nei dati di Kiko), poi è l'unico che assegna i premi.
   - Il vecchio assegnatore di coppe (progressi.js check/celebrate, #cupToast) è dismesso: progressi.js guarda CNPremiApp e non assegna più.
   - Eventi dell'esercizio (cnp:*) → eventi dei premi, con ripasso:true per gli esercizi del Ripasso (o già dovuti) e argomento 'tattica'.
     Tempo attivo (stats.js) → evento 'tempo'. Partite col bot (cnbot:fine da bot.js) → 'partita_finita' SOLO per le partite normali
     (senza handicap e non di allenamento), con id della partita (conta una volta sola) e livello 1-5.
   - UN solo canale di festa: i trofei della serie restano il toast «Tris!» di stats.js (nessun doppione); «Ripassato!» lo mostra già
     la carta dell'esercizio (esercizio_v6.js); le coppe nuove escono nel toast della serie (zona libera v6, mai sopra la scacchiera),
     una alla volta, solo il livello più alto; a fine partita col bot una riga nel pannello finale.
   - Le pagine dentro la Home (Premi, Progressi, Home) leggono window.parent.CNPremiApp. Nessuna rete. */
(function(){
  'use strict';
  var A = window.__app, S = window.__stats;
  if (typeof CNPremi === 'undefined') return;
  var OPZ = {attivi:['tattica', 'bot'], contenuti:{bot:{livelli:5}}};
  var ORDINE_BOT = ['chessnote', 'paola', 'nerd', 'serena', 'maestro'];
  var coda = [], occupato = false, ultimi = [];
  /* blocco 3b (11-11): premi extra (premi_extra.js, oggi il 4° Speciale «Rimonta») passati come catalogo: cn_premi.js resta invariato */
  var EXTRA = window.CN_PREMI_EXTRA || [], ICO_SPE = window.CN_PREMI_ICONE || {};
  var P = CNPremi.crea({catalogo:EXTRA, attivi:OPZ.attivi, contenuti:OPZ.contenuti, onSblocco:function(l){ sblocchi(l); },
    onErrore:function(e){ try { console.warn('cn_premi: salvataggio', e && (e.message || e)); } catch(x){} }});

  /* ---------- feste: una sola, la più alta ---------- */
  var MET = ['bronzo', 'argento', 'oro'];
  function sblocchi(lista){
    ultimi = lista.slice();
    lista.forEach(function(s){
      if (!s.piuAlto || !s.primaVolta) return;
      if (s.id === 'tattica_serie' || s.id === 'ripassato') return;   // già festeggiati da stats.js / esercizio_v6.js
      coda.push(s);
    });
    try { document.dispatchEvent(new CustomEvent('cnpremi:sblocco', {detail:lista})); } catch(e){}
    if (window.CNBot && CNBot.isOpen && CNBot.isOpen()) return;          // a fine partita: riga nel pannello (vedi sotto)
    pompa();
  }
  function titolo(s){
    if (s.stile === 'speciale') return 'Premio speciale · ' + s.nome_it;
    return 'Coppa ' + (['di bronzo', 'd\'argento', 'd\'oro'][s.indice] || '') + ' · ' + s.nome_it.replace(/ ?(bronzo|argento|oro)$/i, '');
  }
  function nomeFam(s){ try { var e = P.elenco(s.argomento)[0].premi.filter(function(p){ return p.id === s.id; })[0]; return e ? e.nome_it : ''; } catch(e){ return ''; } }
  function pompa(){
    if (occupato || !coda.length) return;
    var t = document.getElementById('streakToast'); if (!t){ coda.length = 0; return; }
    occupato = true;
    var wait = t.hidden ? 700 : 3800;                                     // dopo un eventuale «Tris!»
    setTimeout(function(){
      var s = coda.shift();
      if (!s){ occupato = false; return; }                               // blocco 3b: la coda può essersi svuotata (festa passata al pannello di fine partita)
      var fam = nomeFam(s) || s.nome_it;
      var met = s.stile === 'speciale' ? 'speciale' : MET[s.indice] || '';
      var icn = s.stile === 'speciale' ? (ICO_SPE[icona(s.id)] && (window.LUCIDE || {})[ICO_SPE[icona(s.id)]] ? ICO_SPE[icona(s.id)] : 'v2-medaglia') : 'v2-premi';
      t.innerHTML = '<div class="st-medal pm-' + met + '">' + ((window.LUCIDE || {})[icn] ? '<svg class="lu" viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="1.65" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + LUCIDE[icn] + '</svg>' : '') + '</div>' +
        '<div class="st-txt"><b>' + esc(s.stile === 'speciale' ? 'Premio speciale!' : 'Coppa ' + ['di bronzo', 'd\'argento', 'd\'oro'][s.indice] + ' · ' + fam) + '</b><span>' + esc(s.obiettivo_it || s.testo_it || '') + '</span></div>';
      t.dataset.premio = s.id + ':' + s.indice;
      t.hidden = false; void t.offsetWidth; t.classList.remove('show'); void t.offsetWidth; t.classList.add('show');
      try { A && A.Sound && A.Sound.play('brilliant', 0); } catch(e){}
      window.__premiFeste = (window.__premiFeste || []).concat([s.id + ':' + s.indice]);
      clearTimeout(t._t); t._t = setTimeout(function(){ t.classList.remove('show'); setTimeout(function(){ if (!t.classList.contains('show')) t.hidden = true; }, 400); occupato = false; pompa(); }, 4200);
    }, wait);
  }
  function icona(id){ var e = EXTRA.filter(function(p){ return p.id === id; })[0]; return e ? e.icona : null; }
  function esc(s){ return String(s == null ? '' : s).replace(/[&<>"']/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }

  /* ---------- esercizi (stessi eventi che legge stats.js) ---------- */
  var cur = null;   // {n, c, a2, sol, err}
  function invia(ev){ try { return P.registraEvento(ev) || []; } catch(e){ return []; } }
  function inRipasso(){ try { var a = S && S.attempt && S.attempt(); return !!(a && (a.rev || a.due)); } catch(e){ return false; } }
  document.addEventListener('cnp:load', function(ev){ var d = ev.detail || {}; if (d.c === 'pz' || d.n >= 100000){ cur = null; return; }   // blocco 4: Puzzle Random non manda eventi «tattica» (coppe Puzzle non attive)
    cur = {n:d.n, c:d.c, a2:false, sol:false, err:0, rip:false}; setTimeout(function(){ if (cur && cur.n === d.n) cur.rip = inRipasso(); }, 0); });
  function base(){ return {argomento:'tattica', esercizio:cur.n, tema:cur.c, capitolo:cur.c, ripasso:cur.rip || inRipasso()}; }
  document.addEventListener('cnp:mistake', function(){ if (!cur) return; cur.err++; var e = base(); e.tipo = 'esercizio_sbagliato'; invia(e); });
  ['show', 'giveup'].forEach(function(k){ document.addEventListener('cnp:' + k, function(){ if (!cur || cur.sol) return; cur.sol = true; var e = base(); e.tipo = 'soluzione_vista'; invia(e); }); });
  document.addEventListener('cnp:hint', function(ev){
    if (!cur || cur.a2) return;                                           // 14-11 (Kiko t1936u): conta già il 1° aiuto
    cur.a2 = true; var e = base(); e.tipo = 'aiuto2_usato'; invia(e);
  });
  document.addEventListener('cnp:solved', function(ev){
    var d = ev.detail || {}; if (!cur || cur.n !== d.n || cur.fatto) return;
    cur.fatto = true;
    var sol = cur.sol || !!d.shown, err = Math.max(cur.err, d.errors || 0);
    var e = base(); e.tipo = 'esercizio_risolto'; e.primoColpo = !cur.a2 && !sol && !err; e.aiuto2 = cur.a2; e.soluzioneVista = sol; e.errori = err;
    invia(e);
  });
  document.addEventListener('cnp:reset', function(){ try { P.azzeraProgressi(); } catch(e){} });

  /* ---------- tempo attivo (Impegno, Costanza) ---------- */
  var tot0 = null;
  function tempo(){
    try { var t = S && S.data && S.data().time ? S.data().time.total || 0 : null; if (t == null) return;
      if (tot0 == null || t < tot0){ tot0 = t; return; }
      var dt = t - tot0; if (dt >= 1000){ tot0 = t; invia({tipo:'tempo', argomento:'generale', ms:dt}); } } catch(e){}
  }
  tempo(); setInterval(tempo, 15000);
  window.addEventListener('pagehide', function(){ tempo(); try { P.salvaOra(); } catch(e){} });
  document.addEventListener('visibilitychange', function(){ if (document.hidden){ tempo(); try { P.salvaOra(); } catch(e){} } });

  /* ---------- partite col bot ---------- */
  document.addEventListener('cnbot:fine', function(ev){
    var r = ev.detail || {}; if (!r.id || r.handicap || r.allenamento) return;   // handicap e allenamento: fuori dai premi
    var liv = ORDINE_BOT.indexOf(r.bot) + 1; if (!liv) return;
    // blocco 3b: rimonta = vinta dopo essere stato sotto di almeno 3 punti di materiale (premi_extra.js, calcolata dalle mosse della partita)
    var rim = false; try { rim = r.esito === 'v' && !!(window.CNRimonta && CNRimonta.calcola(r.sans, r.fen || null, r.colore)); } catch(e){ rim = false; }
    var l = invia({tipo:'partita_finita', argomento:'bot', id:r.id, livello:liv, risultato:r.esito === 'v' ? 'vittoria' : r.esito === 'p' ? 'pareggio' : 'sconfitta',
      senzaAnnullare:true, senzaAiuti:true, piuForte:false, rimonta:rim});
    var vis = l.filter(function(s){ return s.piuAlto && s.primaVolta; });
    if (!vis.length) return;
    coda = coda.filter(function(s){ return vis.indexOf(s) < 0; });
    setTimeout(function(){
      var box = document.querySelector('#botPage .bop-result'); if (!box) return;
      var s = vis[vis.length - 1], fam = nomeFam(s) || s.nome_it;
      box.insertAdjacentHTML('afterbegin', '<p class="bop-premio">Nuovo premio: <b>' + esc(s.stile === 'speciale' ? s.nome_it : 'coppa ' + ['di bronzo', 'd\'argento', 'd\'oro'][s.indice] + ' · ' + fam) + '</b></p>');
      try { A && A.Sound && A.Sound.play('brilliant', 0); } catch(e){}
      window.__premiFeste = (window.__premiFeste || []).concat([s.id + ':' + s.indice]);
    }, 0);
  });

  /* ---------- lettura per le pagine (Home 27c, Premi 27b, Progressi) ---------- */
  function contatori(){
    var c = {oro:0, argento:0, bronzo:0, speciali:0, totale:0, trofei:0};
    try { P.elenco('tutti').forEach(function(g){ g.premi.forEach(function(p){
      if (p.categoria === 'speciali'){ if (p.presi){ c.speciali++; c.totale++; } return; }
      if (p.serie_storica){ c.trofei += p.presi; c.speciali += p.presi; c.totale += p.presi; return; }   // come prima in Home: i trofei della serie contano fra gli speciali
      if (p.ripetibile) return;
      p.livelli.forEach(function(L, i){ if (L.stato === 'preso'){ c[['bronzo', 'argento', 'oro'][i] || 'oro']++; c.totale++; } });
    }); }); } catch(e){}
    return c;
  }
  window.CNPremiApp = {istanza:function(){ return P; }, OPZ:OPZ, contatori:contatori, ultimi:function(){ return ultimi.slice(); }, pompa:pompa};
})();
