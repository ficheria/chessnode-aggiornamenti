/* Chess Node – aggiunte 28/10/2026 (approvate da Kiko 28/10 19:36)
   1) Invita un amico (versione semplice: condivisione Android, niente server, nessun dato raccolto)
   2) icona del turno = Re bianco/nero (al posto del quadratino)
   5) pulsante «Prova vibrazione»
   6) finestra «Informazioni e crediti» (fonte: LICENZE.md)
   Le icone dell'interfaccia sono il set v2 di Chess Node. */
(function(){
  'use strict';
  var A = window.__app || {};
  var L = window.LUCIDE || {};
  function $(id){ return document.getElementById(id); }
  function svg(n, s){ s = s || 20; return L[n] ? '<svg class="lu ag-i" viewBox="0 0 24 24" width="' + s + '" height="' + s + '" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' + L[n] + '</svg>' : ''; }
  function toast(t){ try { if (A.UI && A.UI.toast) return A.UI.toast(t); } catch(e){} }
  function cap(){ var C = window.Capacitor; return C && C.isNativePlatform && C.isNativePlatform() ? C : null; }
  function plugin(n){ var C = cap(); if (!C) return null; var p = C.Plugins && C.Plugins[n]; if (!p && C.registerPlugin) try { p = C.registerPlugin(n); } catch(e){} return p || null; }

  /* ---------- 2) icona del turno: il Re del nostro set di pezzi ---------- */
  function kings(){
    var P = window.PIECES || {}, s = (window.cnPezzi && window.cnPezzi()) || P.chessnode || P[Object.keys(P)[0]] || {};
    var r = document.documentElement.style;
    if (s.wK) r.setProperty('--ag-kw', 'url("' + s.wK + '")');
    if (s.bK) r.setProperty('--ag-kb', 'url("' + s.bK + '")');
  }
  kings(); window.__cnKings = kings;
  // titolo leggibile anche dagli screen reader sull'indicatore della consegna
  function labelTask(){
    var sd = document.querySelector('#task .side'); if (!sd || sd.getAttribute('role')) return;
    var b = sd.classList.contains('b'); sd.setAttribute('role', 'img'); sd.setAttribute('aria-label', 'Muove il ' + (b ? 'Nero' : 'Bianco')); sd.title = 'Muove il ' + (b ? 'Nero' : 'Bianco');
  }
  var tk = $('task'); if (tk) new MutationObserver(labelTask).observe(tk, {childList:true});

  /* ---------- 1) Invita un amico ---------- */
  var URL = 'https://play.google.com/store/apps/details?id=it.chessnode.play';
  var MSG = 'Mi sto allenando a scacchi con Chess Node: 1000 esercizi di tattica con l\'istruttore, completamente gratuito. Provala anche tu!';
  function copy(txt){
    var all = (txt || MSG) + '\n' + URL;
    function ok(){ toast('Messaggio e link copiati: incollali dove vuoi'); }
    function old(){
      try { var t = document.createElement('textarea'); t.value = all; t.setAttribute('readonly', ''); t.style.cssText = 'position:fixed;left:-9999px;top:0';
        document.body.appendChild(t); t.select(); var r = document.execCommand('copy'); document.body.removeChild(t);
        if (r) ok(); else toast('Link: ' + URL); } catch(e){ toast('Link: ' + URL); }
    }
    try { if (navigator.clipboard && navigator.clipboard.writeText){ navigator.clipboard.writeText(all).then(ok, old); return; } } catch(e){}
    old();
  }
  // blocco 2 (10-11): «Sfida un amico» dal menu dell'esercizio = stesso invito del 28/10 con davanti «Riesci a risolvere il n. 342?» (L.852)
  function invite(pre){
    window.__agInvite = (window.__agInvite || 0) + 1;
    var TXT = (typeof pre === 'string' && pre ? pre + ' ' : '') + MSG;
    var SH = plugin('Share');
    if (SH && SH.share){
      // il plugin Android aggiunge l'url dopo il testo con uno spazio: lo mettiamo noi, a capo
      try { var r = SH.share({title:'Chess Node', text:TXT + '\n' + URL, dialogTitle:'Invita un amico'});
        if (r && r.catch) r.catch(function(e){ if (!/cancel/i.test(String(e && (e.message || e)))) copy(TXT); }); } catch(e){ copy(TXT); }
      return 'capacitor';
    }
    if (navigator.share){
      try { navigator.share({title:'Chess Node', text:TXT, url:URL}).catch(function(e){ if (!e || e.name !== 'AbortError') copy(TXT); }); } catch(e){ copy(TXT); }
      return 'web';
    }
    copy(TXT); return 'copy';
  }

  /* ---------- 6) Informazioni e crediti ---------- */
  function a(href, t){ return '<a href="' + href + '" target="_blank" rel="noopener">' + (t || href.replace(/^https?:\/\//, '')) + '</a>'; }
  function lic(file, t){ return '<button type="button" class="ag-lic" data-f="' + file + '">' + svg('book-open', 18) + '<span>' + t + '</span></button>'; }
  var dlg = null;
  function buildCredits(){
    dlg = document.createElement('div'); dlg.id = 'creditsDlg'; dlg.className = 'modal agmodal'; dlg.hidden = true;
    dlg.setAttribute('role', 'dialog'); dlg.setAttribute('aria-modal', 'true'); dlg.setAttribute('aria-labelledby', 'creditsT');
    dlg.innerHTML = '<div class="modalbox agbox">' +
      '<div class="drawerhead"><h2 id="creditsT">Informazioni e crediti</h2><button type="button" class="icon ag-x" aria-label="Chiudi">' + svg('x', 22) + '</button></div>' +
      '<div class="ag-app"><img src="logo_cn.png" alt="" width="48" height="48"><div><b>Chess Node</b><span id="agVer">1000 esercizi di tattica</span></div></div>' +
      '<section><h3>' + svg('images', 18) + 'Illustrazioni</h3><p>Illustrazioni (istruttori e icona) create con Grok Imagine.</p></section>' +
      '<section><h3>' + svg('target', 18) + 'Esercizi</h3><p>Puzzle dal database pubblico di Lichess, ' + a('https://database.lichess.org/#puzzles', 'database.lichess.org') + ', licenza <b>CC0 1.0</b> (pubblico dominio). Spiegazioni scritte per questa app.</p></section>' +
      '<section><h3>' + svg('cpu', 18) + 'Motore di analisi</h3><p><b>Stockfish 17.1</b> (versione leggera, WebAssembly) è un <b>programma separato</b>, distribuito senza modifiche con licenza <b>GNU GPL v3</b>; la GPL vale solo per il motore, non per il resto dell\'app. Codice sorgente: ' +
        a('https://github.com/official-stockfish/Stockfish', 'github.com/official-stockfish/Stockfish') + ' e ' + a('https://github.com/nmrugg/stockfish.js', 'github.com/nmrugg/stockfish.js') + ' (versione WebAssembly usata).</p>' +
        '<div class="ag-lics">' + lic('engine/STOCKFISH-COPYING.txt', 'Licenza GPL v3') + lic('engine/STOCKFISH-AUTHORS.txt', 'Autori di Stockfish') + '</div></section>' +
      '<section><h3>' + svg('volume-2', 18) + 'Suoni</h3><p>Suono della mossa: Kenney, «Casino Audio» (' + a('https://kenney.nl', 'kenney.nl') + '), licenza <b>CC0 1.0</b>. Presa, scacco, errore, risolto, matto, arrocco, promozione e musica di avvio: registrazioni e suoni originali fatti per Chess Node.</p></section>' +
      '<section><h3>' + svg('pencil', 18) + 'Caratteri</h3><p>Inter, Outfit e JetBrains Mono, licenza <b>SIL Open Font License 1.1</b>.</p>' +
        '<div class="ag-lics">' + lic('fonts/Inter-OFL.txt', 'Inter') + lic('fonts/Outfit-OFL.txt', 'Outfit') + lic('fonts/JetBrainsMono-OFL.txt', 'JetBrains Mono') + '</div></section>' +
      '<section><h3>' + svg('list', 18) + 'Librerie</h3><ul>' +
        '<li>chess.js di Jeff Hlywa, <b>BSD-2-Clause</b></li>' +
        '<li>JSZip 3.10.2 (con pako), usata con licenza <b>MIT</b></li>' +
        '<li>gifenc 1.0.3 di Matt DesLauriers, <b>MIT</b></li>' +
        '<li>Icone Lucide 1.60.0, <b>ISC</b> (alcune da Feather, <b>MIT</b>)</li>' +
        '<li>Capacitor e i suoi plugin (app, vibrazione, condivisione, file, promemoria) di Ionic, <b>MIT</b>; text-to-speech di Capacitor Community, <b>MIT</b></li>' +
        '</ul><div class="ag-lics">' + lic('lib/chess.js-LICENSE.txt', 'chess.js') + lic('lib/jszip-LICENSE.txt', 'JSZip') + lic('lib/gifenc-LICENSE.txt', 'gifenc') + '</div></section>' +
      '<section><h3>' + svg('heart', 18) + 'Chess Node</h3><p>Interfaccia, codice e pezzi «Chess Node»: © Chess Node, tutti i diritti riservati.</p></section>' +
      '<div class="ag-txt" hidden><div class="ag-txth"><b></b><button type="button" class="ag-txtx">' + svg('arrow-left', 18) + '<span>Indietro</span></button></div><pre></pre></div>' +
      '</div>';
    document.body.appendChild(dlg);
    var box = dlg.querySelector('.agbox'), txt = dlg.querySelector('.ag-txt');
    dlg.addEventListener('click', function(ev){
      if (ev.target === dlg || ev.target.closest('.ag-x')){ closeCredits(); return; }
      if (ev.target.closest('.ag-txtx')){ txt.hidden = true; box.classList.remove('ag-reading'); try { dlg.querySelector('.ag-x').focus({preventScroll:true}); } catch(e){} return; }
      var b = ev.target.closest('.ag-lic'); if (!b) return;
      var f = b.dataset.f; txt.querySelector('b').textContent = b.textContent; txt.querySelector('pre').textContent = 'Caricamento…';
      txt.hidden = false; box.classList.add('ag-reading'); box.scrollTop = 0; try { txt.querySelector('.ag-txtx').focus({preventScroll:true}); } catch(e){}
      fetch(f).then(function(r){ if (!r.ok) throw 0; return r.text(); }).then(function(t){ txt.querySelector('pre').textContent = t; })
        .catch(function(){ txt.querySelector('pre').textContent = 'Testo non disponibile (file ' + f + ').'; });
    });
    document.addEventListener('keydown', function(ev){ if (ev.key === 'Escape' && dlg && !dlg.hidden){ ev.preventDefault(); ev.stopImmediatePropagation(); closeCredits(); } }, true);
    // versione vera dell'APK (nome.js, @capacitor/app); nel browser «web»
    if (window.__cnVersion) window.__cnVersion(function(v){ if (v && v !== 'web' && $('agVer')) $('agVer').textContent = 'Versione ' + v + ' · 1000 esercizi di tattica'; });
  }
  // tasto Indietro di Android (android.js) e scorciatoie di app.js guardano UI.modalOpen(): ci aggiungiamo i crediti
  try { var U = window.UI; if (U && U.modalOpen && !U.__agWrap){ var mo = U.modalOpen; U.modalOpen = function(){ return (dlg && !dlg.hidden) || mo(); }; U.__agWrap = 1; } } catch(e){}
  var lastF = null;
  function openCredits(){
    if (!dlg) buildCredits();
    lastF = document.activeElement;
    var txt = dlg.querySelector('.ag-txt'); txt.hidden = true; dlg.querySelector('.agbox').classList.remove('ag-reading');
    dlg.hidden = false; void dlg.offsetWidth; dlg.classList.add('open');
    var x = dlg.querySelector('.ag-x'); try { x.focus({preventScroll:true}); } catch(e){}
  }
  function closeCredits(){
    if (!dlg || dlg.hidden) return;
    dlg.classList.remove('open'); dlg.hidden = true;
    if (lastF && lastF.focus) try { lastF.focus({preventScroll:true}); } catch(e){}
  }

  function sfidaTxt(){ var n = 0; try { n = window.__app.state.ex.n; } catch(e){} return n ? 'Riesci a risolvere il n. ' + n + '?' : ''; }
  /* ---------- voci nel foglio «Altro» ---------- */
  var sheet = $('moreSheet');
  if (sheet){
    var card = sheet.querySelector('.ms-card'), close = sheet.querySelector('.ms-close');
    var g = document.createElement('div'); g.className = 'ms-group ms-ag';
    g.innerHTML = '<button type="button" class="ms-item" data-a="sfida">' + svg('share-2') + '<span>Sfida un amico<small id="agSfidaN">Riesci a risolvere questo esercizio?</small></span></button>' +
      '<button type="button" class="ms-item" data-a="invite">' + svg('user-plus') + '<span>Invita un amico<small>Manda il link dell\'app su WhatsApp, Telegram…</small></span></button>' +
      '<button type="button" class="ms-item" data-a="credits">' + svg('info') + '<span>Informazioni e crediti<small>Licenze, Stockfish, esercizi Lichess</small></span></button>';
    if (card && close) card.insertBefore(g, close);
    // il foglio si chiude da solo (layout.js) per le voci che non conosce; noi facciamo l'azione
    g.addEventListener('click', function(ev){
      var b = ev.target.closest('.ms-item'); if (!b) return;
      if (b.dataset.a === 'invite') setTimeout(invite, 0);
      else if (b.dataset.a === 'sfida') setTimeout(function(){ invite(sfidaTxt()); }, 0);
      else if (b.dataset.a === 'credits') setTimeout(function(){ window.__agg.openCredits(); }, 0);   // blocco 2: pagina Info e crediti 30 (home_app.js)
    });
    function sfidaLbl(){ var e = $('agSfidaN'), t = sfidaTxt(); if (e && t) e.textContent = '«' + t + '»'; }
    document.addEventListener('cnp:load', sfidaLbl); sfidaLbl();
  }

  /* ---------- profilo (Impostazioni › Aspetto › Il tuo profilo) ---------- */
  function placeProfile(){
    var ps = $('profSet'); if (!ps || $('agInviteP')) return;
    var row = document.createElement('div'); row.className = 'btnrow ag-row';
    row.innerHTML = '<button type="button" id="agInviteP" class="ag-btn">' + svg('user-plus', 18) + '<span>Invita un amico</span></button>';
    ps.appendChild(row);
    $('agInviteP').onclick = invite;
  }
  placeProfile();

  /* ---------- Impostazioni › Dati: Informazioni e crediti ---------- */
  var pd = $('pane-data');
  if (pd && !$('agCredBtn')){
    var h = document.createElement('h3'); h.textContent = 'Informazioni';
    var r2 = document.createElement('div'); r2.className = 'btnrow ag-row';
    r2.innerHTML = '<button type="button" id="agCredBtn" class="ag-btn">' + svg('info', 18) + '<span>Informazioni e crediti</span></button>' +
      '<button type="button" id="agInviteD" class="ag-btn">' + svg('user-plus', 18) + '<span>Invita un amico</span></button>';
    pd.appendChild(h); pd.appendChild(r2);
    $('agCredBtn').onclick = function(){ window.__agg.openCredits(); };   /* ritocchi blocco 2: anche dal cassetto la pagina Info 30 (Indietro torna qui) */ $('agInviteD').onclick = invite;
  }

  /* ---------- 5) Prova vibrazione ---------- */
  var vb = $('vibraOn'), vrow = vb && vb.closest('.lookrow');
  if (vrow && !$('vibraTest')){
    var t = document.createElement('button'); t.type = 'button'; t.id = 'vibraTest'; t.className = 'small ag-btn';
    t.innerHTML = svg('vibrate', 18) + '<span>Prova vibrazione</span>';
    vrow.appendChild(t);
    t.onclick = function(){
      var V = window.__cnVibra;
      if (V && V.test){ var ok = V.test(); if (!ok) toast('Questo dispositivo non può vibrare'); else if (!V.isOn()) toast('Vibrazione di prova: per sentirla negli esercizi accendi «attiva»'); }
    };
  }

  window.__agg = {invite:invite, openCredits:openCredits, closeCredits:closeCredits, MSG:MSG, URL:URL};
})();
