/* Grande aggiornamento, blocco 3b (11-11): premi aggiunti al catalogo di cn_premi.js v3 SENZA toccare il file (resta identico, md5 e731d05a…).
   Si passano con CNPremi.crea({catalogo: CN_PREMI_EXTRA}) sia nell'app (premi_app.js) sia nella pagina Premi aperta da sola (premi.js).
   4° premio Speciale «Rimonta» (scelta di Kiko, LISTA 11-11): vinci una partita contro un bot dopo essere stato sotto di almeno
   3 punti di materiale (P=1, C=3, A=3, T=5, D=9) dal tuo lato. Contano SOLO le partite normali (niente handicap né allenamento: lo filtra
   premi_app.js) e la stessa partita conta una volta sola (id).
   NO REGALARE NIENTE: lo svantaggio si misura DOPO ogni tua mossa (così a metà di uno scambio, quando riprendi subito, non conta) e deve
   durare almeno 3 tue mosse di fila (così un sacrificio seguito da una combinazione vincente non è una «rimonta»).
   Nessuna rete, nessun segreto. */
(function(){
  'use strict';
  var VAL = {p:1, n:3, b:3, r:5, q:9, k:0};
  var SOTTO = 3, MOSSE = 3;
  function materiale(g, me){ var d = 0; g.board().forEach(function(r){ r.forEach(function(q){ if (q) d += (q.color === me ? 1 : -1) * VAL[q.type]; }); }); return d; }
  /* true se, dopo almeno MOSSE tue mosse di fila, eri sotto di SOTTO punti o più. sans = mosse SAN, fen0 = FEN iniziale (o null), me = 'w'|'b' */
  function rimonta(sans, fen0, me){
    if (typeof Chess === 'undefined' || !Array.isArray(sans) || (me !== 'w' && me !== 'b')) return false;
    var g; try { g = new Chess(fen0 || undefined); } catch(e){ return false; }
    var fila = 0, peggiore = 0;
    for (var i = 0; i < sans.length; i++){
      var mv; try { mv = g.move(sans[i]); } catch(e){ mv = null; }
      if (!mv) return false;                                   // partita non rigiocabile: nel dubbio niente premio
      if (mv.color !== me) continue;
      var d = materiale(g, me); if (d < peggiore) peggiore = d;
      if (d <= -SOTTO){ if (++fila >= MOSSE) return true; } else fila = 0;
    }
    return false;
  }
  var testo = 'Vinci una partita dopo essere stato sotto di almeno 3 punti di materiale';
  window.CN_PREMI_EXTRA = [{
    id:'speciale_rimonta', argomento:'bot', categoria:'speciali', tipo:'speciale', stile:'speciale', icona:'rimonta', verificabile:true, origine_soglie:'regola',
    soglie:[1], nome_it:'Rimonta', nome_en:'Comeback', descrizione_it:testo, descrizione_en:'Win a game after being at least 3 points of material down',
    unita_it:'vittorie', unita_en:'wins', obiettivo_it:testo, obiettivo_en:'Win a game after being at least 3 points of material down',
    livelli:[{chiave:'speciale', nome_it:'Rimonta', nome_en:'Comeback', titolo_it:'Rimonta', titolo_en:'Comeback',
      testo_it:'Hai vinto una partita dopo essere stato sotto di almeno 3 punti di materiale!', testo_en:'You won a game after being at least 3 points of material down!'}],
    regola:{base:'conteggio', conta:{tipo:'partita_finita', risultato:'vittoria', rimonta:true}}
  }];
  window.CNRimonta = {calcola:rimonta, SOTTO:SOTTO, MOSSE:MOSSE};
  window.CN_PREMI_ICONE = {rimonta:'v2-rimonta'};   // icona del medaglione (gli altri speciali: v2-medaglia)
})();
