/* Grande aggiornamento, blocco 3 (11-11): pagina Premi, schema 27b (anteprime/blocco27_premi), dati da cn_premi.js v3.
   P1 intestazione (Indietro, «Premi», «N premi ottenuti · M speciali») · P2 PROSSIMO PREMIO (sempre raggiungibile: prossimi(), mai «in arrivo»)
   · P3 carosello argomenti (scelto verde; argomenti non pronti sbiaditi) · P4 famiglie: icona, nome, descrizione, 3 coppe (piene se prese),
   barra verde sottile + «valore / soglia»; Serie: 6 trofei storici a parte; «In arrivo» grigio col lucchetto · P5 Speciali: medaglioni
   col bordo oro, lucchetto se non presi, «N di M · una volta sola» · P6 foglio della coppa (come si ottiene, ottenuto il …) · barra (Progressi).
   Dentro l'app legge l'UNICA istanza (window.parent.CNPremiApp); aperta da sola usa una copia in sola lettura (non scrive mai). */
(function(){
  'use strict';
  var C = window.CNP, ic = C.ic, esc = C.esc;
  var PA = null; try { PA = window.parent !== window && window.parent.CNPremiApp; } catch(e){ PA = null; }
  var P = PA ? PA.istanza() : null;
  if (!P && window.CNPremi){
    var ar = {getItem:function(k){ return localStorage.getItem(k); }, setItem:function(){}, removeItem:function(){}};
    P = CNPremi.crea({catalogo:window.CN_PREMI_EXTRA || [], attivi:['tattica', 'bot'], contenuti:{bot:{livelli:5}}, archivio:ar, ritardoSalvataggio:0});   // blocco 3b: + Rimonta
  }
  var Q = new URLSearchParams(location.search);
  var vista = {arg:Q.get('arg') || 'tattica', foglio:null};
  var root = document.getElementById('pg');
  var ICO = {costanza:'v2-giorno', impegno:'v2-tempo', traguardi:'v2-premi', lacuna:'v2-tema', ripassato:'v2-ripasso',
    tattica_risoluzione:'v2-corretto', tattica_precisione:'v2-precisione', tattica_serie:'v2-serie', tattica_ripasso:'v2-ripasso',
    bot_livelli:'v2-bot', bot_pulite:'v2-bot'};
  var ICO_ARG = {generale:'v2-premi', tattica:'v2-tattica', finali:'v2-finali', aperture:'v2-aperture', strategia:'v2-strategia', trappole:'v2-minaccia', puzzle_caso:'v2-tattica', bot:'v2-bot'};
  var MET = ['Bronzo', 'Argento', 'Oro'];
  var MESI = ['gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre'];
  function dataIt(d){ if (!d) return ''; var q = d.split('-'); return (+q[2]) + ' ' + MESI[+q[1] - 1] + ' ' + q[0]; }
  /* blocco 3b: «il 2 novembre» ma «l'11 / l'8 / l'1 novembre»; breve per i medaglioni (4 in fila): «l'11 nov» (+ anno se non è quest'anno) */
  function art(d){ var g = +String(d).split('-')[2]; return (g === 1 || g === 8 || g === 11) ? 'l\'' : 'il '; }
  function dataBreve(d){ if (!d) return ''; var q = d.split('-'); return art(d) + (+q[2]) + ' ' + MESI[+q[1] - 1].slice(0, 3) + (q[0] !== String(new Date().getFullYear()) ? ' ' + q[0] : ''); }
  function num(x){ return String(x).replace('.', ','); }
  function icona(p){ return ICO[p.id] || ICO_ARG[p.argomento] || 'v2-premi'; }
  var ICO_SPE = window.CN_PREMI_ICONE || (function(){ try { return window.parent.CN_PREMI_ICONE || {}; } catch(e){ return {}; } })();
  function iconaSpe(p){ var n = p && p.icona && ICO_SPE[p.icona]; return n && (window.LUCIDE || {})[n] ? n : 'v2-medaglia'; }   // blocco 3b: Rimonta ha la sua
  function tutti(){ try { return P ? P.elenco('tutti') : []; } catch(e){ return []; } }
  function conti(G){
    var c = {tot:0, spe:0};
    G.forEach(function(g){ g.premi.forEach(function(p){
      if (p.categoria === 'speciali'){ if (p.presi){ c.tot++; c.spe++; } return; }
      if (p.serie_storica){ c.tot += p.presi; c.spe += p.presi; return; }
      if (p.ripetibile) return;   // Ripassato: conta le volte nella sua card, non fra i premi (come i contatori della Home)
      c.tot += p.presi;
    }); });
    return c;
  }
  function coppa(p, L, i){
    var on = L.stato === 'preso';
    return '<button class="pr-cup l' + (i + 1) + (on ? ' on' : '') + '" data-p="' + esc(p.id) + '" data-i="' + i + '" aria-label="' + esc(p.nome_it + ' – ' + MET[i] + (on ? ', presa' : ', da prendere')) + '">' + ic('v2-premi', 20) + '</button>';
  }
  function progresso(p){
    var L = p.livelli.filter(function(x){ return x.stato === 'da_prendere'; })[0];
    if (!L || !L.progresso) return p.completo ? '<div class="pr-fp"><span class="pr-bar g"><i style="width:100%"></i></span><span>Completo</span></div>' : '';
    var g = L.progresso;
    return '<div class="pr-fp"><span class="pr-bar g"><i style="width:' + Math.round(g.frazione * 100) + '%"></i></span><span>' + esc(num(g.valore) + ' / ' + num(g.di) + (p.livelli[0] && /%$/.test(g.testo_it || '') ? '%' : '')) + '</span></div>' +
      (g.nota_it ? '<p class="nota" style="margin:4px 0 0">' + esc(g.nota_it) + '</p>' : '');
  }
  function famiglia(p){
    if (p.stato === 'in_arrivo'){
      return '<div class="card pr-off"><span class="pr-ic" style="background:var(--s3);color:var(--muted)">' + ic('v2-bloccato', 20) + '</span><b>' + esc(p.nome_it) + '<small class="nota" style="display:block;margin:2px 0 0;font-weight:500">' +
        esc(p.motivo_in_arrivo === 'non_verificabile' ? 'Non ancora verificabile' : p.motivo_in_arrivo === 'contenuti' ? 'Contenuti in arrivo' : 'Sezione in arrivo') + '</small></b><span class="arr">In arrivo</span></div>';
    }
    var h = '<div class="card pr-f"><div class="pr-fh"><span class="pr-ic">' + ic(icona(p), 22) + '</span><span class="pr-ft"><b>' + esc(p.nome_it) + '</b><small>' + esc(p.descrizione_it) + '</small></span>';
    if (p.serie_storica){
      h += '</div><div class="pr-tr">' + p.livelli.map(function(L, i){ return '<span class="' + (L.stato === 'preso' ? 'on' : '') + '" title="' + esc(L.titolo_it || L.nome_it) + '">' + esc((L.nome_it || '').replace(/!$/, '')) + '</span>'; }).join('') + '</div>' + progresso(p);
    } else if (p.ripetibile){
      h += '<span class="pr-cups"><span class="pr-cup' + (p.volte ? ' l3 on' : '') + '">' + ic('v2-ripasso', 18) + '</span></span></div><p class="nota" style="margin:8px 0 0">' + (p.volte ? 'Preso ' + p.volte + (p.volte === 1 ? ' volta' : ' volte') : 'Ancora nessuno') + '</p>';
    } else {
      h += '<span class="pr-cups">' + p.livelli.map(function(L, i){ return coppa(p, L, i); }).join('') + '</span></div>' + progresso(p);
    }
    return h + '</div>';
  }
  function speciali(G){
    var sp = []; G.forEach(function(g){ g.premi.forEach(function(p){ if (p.categoria === 'speciali') sp.push(p); }); });
    var presi = sp.filter(function(p){ return p.presi; }).length;
    return '<div class="pr-shd"><h2>Speciali</h2><span>' + presi + ' di ' + sp.length + ' · una volta sola</span></div><div class="pr-sp">' + sp.map(function(p){
      var on = !!p.presi;
      return '<button class="card pr-me' + (on ? '' : ' no') + '" data-p="' + esc(p.id) + '" data-i="0"><span class="pr-md">' + ic(iconaSpe(p), 28) + (on ? '' : '<span class="lk">' + ic('v2-bloccato', 14) + '</span>') + '</span>' +
        '<b>' + esc(p.nome_it) + '</b><small>' + esc(on ? 'Preso ' + dataBreve(p.livelli[0].data) : p.stato === 'in_arrivo' ? 'In arrivo' : 'Da prendere') + '</small></button>'; }).join('') + '</div>';
  }
  function prossimo(){
    var n = []; try { n = P ? P.prossimi(1, 'tutti') : []; } catch(e){}
    if (!n.length) return '';
    var x = n[0], mancano = x.mancano_it ? x.mancano_it.replace(/^manca(no)? /, '') : num(x.mancano);
    return '<div class="card pr-next"><span class="pr-ic" style="width:52px;height:52px">' + ic(ICO[x.id] || ICO_ARG[x.argomento] || 'v2-premi', 26) + '</span><span class="pr-nt"><small>Prossimo premio</small>' +
      '<b>' + esc(nomePremio(x.id) + (x.stile === 'speciale' ? '' : ' – ' + (MET[x.indice] || ''))) + '</b>' +
      '<span>Ancora ' + esc(mancano + (x.unita_it ? ' ' + x.unita_it : '')) + '</span><span class="pr-bar"><i style="width:' + Math.round(x.frazione * 100) + '%"></i></span></span></div>';
  }
  var cacheNomi = null;
  function nomePremio(id){ if (!cacheNomi){ cacheNomi = {}; tutti().forEach(function(g){ g.premi.forEach(function(p){ cacheNomi[p.id] = p.nome_it; }); }); } return cacheNomi[id] || id; }
  function disegna(){
    cacheNomi = null;
    var G = tutti(), c = conti(G);
    var h = C.header('Premi') + '<p class="pr-sub">' + c.tot + (c.tot === 1 ? ' premio ottenuto' : ' premi ottenuti') + ' · ' + c.spe + (c.spe === 1 ? ' speciale' : ' speciali') + '</p>';
    if (!P){ root.innerHTML = h + '<p class="tx">I premi non sono disponibili.</p>' + C.bar(4); return; }
    h += prossimo();
    h += '<div class="pt-chips pr-chips" role="tablist">' + G.map(function(g){
      var on = g.argomento === vista.arg;
      return '<button class="pt-chip' + (on ? ' on' : '') + (g.stato === 'in_arrivo' ? ' arr2' : '') + '" role="tab" aria-selected="' + on + '" data-arg="' + g.argomento + '">' + esc(g.nome_it) + '</button>'; }).join('') + '</div>';
    var g = G.filter(function(x){ return x.argomento === vista.arg; })[0] || G[0];
    var fam = g.premi.filter(function(p){ return p.categoria !== 'speciali'; });
    h += '<div class="pr-shd"><h2>' + esc(g.nome_it) + '</h2><span>' + fam.length + (fam.length === 1 ? ' famiglia' : ' famiglie') + '</span></div>';
    if (g.stato === 'in_arrivo') h += '<p class="nota" style="margin:-4px 2px 10px">Sezione in arrivo: i suoi premi si accendono quando la sezione esiste davvero.</p>';
    h += '<div class="pr-fam">' + (fam.length ? fam.map(famiglia).join('') : '<p class="nota">Nessuna famiglia di coppe: qui ci sono solo premi speciali.</p>') + '</div>';
    h += speciali(G);
    root.innerHTML = h + C.bar(4);
    var on = root.querySelector('.pr-chips .on'); if (on){ var sc = on.parentNode; if (on.offsetLeft + on.offsetWidth > sc.clientWidth - 8) sc.scrollLeft = on.offsetLeft - 16; }
  }
  /* P6 foglio della coppa */
  function foglio(id, i){
    var p = null; tutti().forEach(function(g){ g.premi.forEach(function(x){ if (x.id === id) p = x; }); });
    if (!p) return; var L = p.livelli[i] || p.livelli[0];
    var o = document.createElement('div'); o.className = 'cn-ov';
    var tit = p.categoria === 'speciali' ? p.nome_it : p.nome_it + ' – ' + (MET[i] || '');
    o.innerHTML = '<div class="cn-sheet pr-sheet" role="dialog" aria-modal="true"><div class="pr-cupbig"><span class="pr-cup l' + (p.categoria === 'speciali' ? 3 : i + 1) + (L.stato === 'preso' ? ' on' : '') + '" style="width:44px;height:44px">' + ic(p.categoria === 'speciali' ? iconaSpe(p) : 'v2-premi', 24) + '</span><h2 style="margin:0">' + esc(tit) + '</h2></div>' +
      '<h3>Come si ottiene</h3><p class="tx">' + esc(L.obiettivo_it ? L.obiettivo_it.charAt(0).toUpperCase() + L.obiettivo_it.slice(1) : p.descrizione_it) + '.</p>' +
      (L.stato === 'preso' ? '<h3>Ottenuto</h3><p class="tx" style="color:var(--acc-text);font-weight:700">' + (L.data ? (art(L.data) === 'il ' ? 'Il ' : 'L\'') + dataIt(L.data) : 'Sì') + '</p>' :
        L.stato === 'in_arrivo' ? '<p class="nota">In arrivo: l\'app non lo può ancora verificare.</p>' :
        (L.progresso ? '<h3>A che punto sei</h3><p class="tx">' + esc(L.progresso.testo_it) + ' · ' + esc(L.progresso.mancano_it) + '</p>' : '')) +
      '<div class="bts"><button class="btn sec" data-chiudi>Chiudi</button></div></div>';
    document.body.appendChild(o);
    function chiudi(){ o.remove(); vista.foglio = null; }
    vista.foglio = chiudi;
    o.addEventListener('click', function(ev){ if (ev.target === o || ev.target.closest('[data-chiudi]')) chiudi(); });
  }
  C.onBack = function(){ if (vista.foglio){ vista.foglio(); return true; } return false; };
  C.canBack = function(){ return !!vista.foglio; };
  root.addEventListener('click', function(ev){
    var t = ev.target.closest('button'); if (!t) return;
    if (t.dataset.arg){ vista.arg = t.dataset.arg; disegna(); return; }
    if (t.dataset.p){ foglio(t.dataset.p, +t.dataset.i || 0); return; }
  });
  disegna();
  window.__premi = {vista:vista, disegna:disegna};
})();
