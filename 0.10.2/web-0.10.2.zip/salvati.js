/* I MIEI SALVATI 19b (grande aggiornamento, blocco 2, 10-11). Schema: anteprime/blocco19_salvati/schema_salvati_19b_*, NOTE_SALVATI.md.
   Biblioteca semplice: ricerca · Tutti / Da ripassare / Raccolte (seconda fase, grigia) · 6 categorie · 3 livelli
   (categoria → argomenti con salvati → contenuti) · nota personale modificabile e ricercabile · Rimuovi dai salvati con Annulla.
   Dati: gli esercizi salvati SONO i preferiti dell'app (chessnodeplay-fav-v1, stessa stellina/segnalibro); note e «da ripassare»
   in chessnodeplay-salvati-v1 = {v:1, el:{'ex-189':{nota:'', rip:false, t:ms}}} (riferimento stabile: tipo + numero).
   Oggi si possono salvare solo gli esercizi: le altre 5 categorie restano vuote (grigie) finché i contenuti non avranno il segnalibro.
   Blocco 4 (11-11): anche i puzzle di Puzzle Random (categoria Puzzle e tattica, argomento «Puzzle Random», archivio del puzzle) e le
   partite salvate col tocco lungo in «Le tue partite» (categoria Partite e analisi, argomento «Partite con i bot», partite_dati.js salvata:true).
   Riferimento stabile: ex-<numero>, pz-<id Lichess>, pt-<id partita>. ?cat=…&arg=… apre direttamente categoria e argomento. */
(function(){
  'use strict';
  var C = window.CNP, ic = C.ic, esc = C.esc, A = C.A;
  var SK = 'chessnodeplay-salvati-v1', FK = 'chessnodeplay-fav-v1';
  var BOOK = window.BOOK || {chapters:[], ex:[]}, byN = {}, chById = {};
  BOOK.ex.forEach(function(e){ byN[e.n] = e; }); BOOK.chapters.forEach(function(c){ chById[c.id] = c; });
  var meta = C.rd(SK) || {}; if (!meta.el) meta = {v:1, el:{}};
  function favs(){ try { if (A && A.favs) return A.favs().slice(); } catch(e){} return (C.rd(FK) || []).filter(function(n){ return byN[n]; }); }
  function toggle(n){ if (A && A.toggleFav){ A.toggleFav(n); return; } var f = favs(), i = f.indexOf(n); if (i >= 0) f.splice(i, 1); else { f.push(n); f.sort(function(a, b){ return a - b; }); } C.wr(FK, f); }
  function key(n){ n = String(n); return /^\d+$/.test(n) ? 'ex-' + n : n; }
  function m(n){ return meta.el[key(n)] || {}; }
  function setM(n, k, v){ var kk = key(n), o = meta.el[kk] = meta.el[kk] || {t:Date.now()}; o[k] = v; if (!o.nota && !o.rip) delete meta.el[kk]; C.wr(SK, meta); }
  var PZ = null; try { PZ = window.parent !== window && window.parent.CNPuzzle || null; } catch(e){ PZ = null; }
  var PT = window.CNPartite || null;
  function fenPartita(r){ try { var g = new Chess(r.fen0 || r.fen || undefined); (r.sans || []).forEach(function(x){ g.move(x); }); return g.fen(); } catch(e){ return ''; } }
  var CAT = [['tattica', 'Puzzle e tattica', 'v2-tattica'], ['finali', 'Finali', 'v2-finali'], ['aperture', 'Aperture', 'v2-aperture'],
    ['strategia', 'Strategia', 'v2-strategia'], ['partite', 'Partite e analisi', 'v2-analizza'], ['corsi', 'Corsi', 'book-open']];
  function items(){
    var out = favs().map(function(n){ var e = byN[n], c = chById[e.c] || {name:''}; return {k:'ex-' + n, id:n, n:n, tipo:'ex', cat:'tattica', arg:e.c, argN:c.name, tit:'Esercizio n. ' + n, fen:e.fen, nota:m(n).nota || '', rip:!!m(n).rip}; });
    if (PZ) PZ.favs().forEach(function(id){ var i = PZ.info(id); if (!i) return; var k = 'pz-' + id;
      out.push({k:k, id:id, tipo:'pz', cat:'tattica', arg:'pz', argN:'Puzzle Random', tit:'Puzzle ' + i.r, fen:PZ.fenDi(id), nota:m(k).nota || '', rip:!!m(k).rip}); });
    if (PT) PT.tutte().filter(function(r){ return r.salvata; }).slice().reverse().forEach(function(r){ var k = 'pt-' + r.id, b = PT.BOT[r.bot] || ['Bot'];
      out.push({k:k, id:r.id, tipo:'pt', cat:'partite', arg:'bot', argN:'Partite con i bot', tit:PT.esito(r) + ' con ' + b[0], sub:PT.quando(r), fen:fenPartita(r), nota:m(k).nota || '', rip:!!m(k).rip, flip:r.colore === 'b', an:!!(r.sans && r.sans.length)}); });
    return out;
  }
  function argNome(k){ return k === 'pz' ? 'Puzzle Random' : k === 'bot' ? 'Partite con i bot' : (chById[k] || {}).name || k; }
  function argIco(k){ return k === 'pz' ? 'v2-casuale' : k === 'bot' ? 'v2-bot' : 'v2-cap-' + k; }
  function delId(it){ return it.tipo === 'ex' ? it.n : it.k; }
  function apriAttr(it){ return it.tipo === 'pz' ? 'data-go="pzid" data-arg="' + esc(it.id) + '"' : it.tipo === 'pt' ? (it.an ? 'data-an="' + esc(it.id) + '"' : 'data-anno="1"') : 'data-go="es" data-n="' + it.n + '"'; }
  var vista = {tab:'tutti', cat:null, arg:null, el:null, q:''};
  var root = document.getElementById('pg');

  function riga(it){
    return '<div class="sv-it card" data-k="' + esc(it.k) + '"><button class="sv-op" ' + apriAttr(it) + '>' + (it.flip ? C.mb(it.fen, 56).replace('class="mb', 'class="mb sv-flip') : C.mb(it.fen, 56)) +
      '<span class="sv-t"><b>' + esc(it.tit) + '</b><small>' + esc(it.sub ? it.argN + ' · ' + it.sub : it.argN) + (it.rip ? ' · da ripassare' : '') + '</small>' + (it.nota ? '<i>' + esc(it.nota) + '</i>' : '') + '</span></button>' +
      '<button class="sv-bm" data-del="' + esc(delId(it)) + '" aria-label="Rimuovi dai salvati">' + ic('bookmark', 22) + '</button>' +
      '<button class="sv-mn" data-el="' + esc(delId(it)) + '" aria-label="Nota e opzioni">' + ic('ellipsis', 22) + '</button></div>'; }
  function disegna(){
    var its = items(), h = '';
    if (vista.el){   // dettaglio: nota personale e azioni
      var it = its.filter(function(x){ return x.k === key(vista.el); })[0];
      if (!it){ vista.el = null; return disegna(); }
      h = C.header(it.tit, it.argN) + '<div class="card sv-det">' + C.mb(it.fen, 150) + '<div class="sv-dt"><button class="btn" ' + apriAttr(it) + '>' + ic(it.tipo === 'pt' ? 'v2-analizza' : 'play', 20) + (it.tipo === 'pt' ? 'Analizza la partita' : it.tipo === 'pz' ? 'Apri il puzzle' : 'Apri l\'esercizio') + '</button></div></div>' +
        '<h2>La tua nota</h2><textarea id="svNota" class="inp sv-nota" maxlength="400" placeholder="Scrivi un promemoria per te…">' + esc(it.nota) + '</textarea>' +
        '<p class="nota">La nota è personale, si può modificare e si trova con la ricerca.</p>' +
        '<div class="lst" style="margin-top:16px">' +
          '<button class="rw" role="switch" aria-checked="' + it.rip + '" data-rip="' + esc(delId(it)) + '"><span class="ri">' + ic('v2-ripasso', 20) + '</span><span class="rt"><b>Da ripassare</b><small>Una tua scelta: non è il ripasso automatico</small></span><span class="sw"></span></button>' +
          (it.nota ? '<button class="rw" data-delnota="' + esc(delId(it)) + '"><span class="ri">' + ic('pencil-off', 20) + '</span><span class="rt"><b>Elimina nota</b><small>Elimina solo il testo personale</small></span></button>' : '') +
          '<button class="rw" data-del="' + esc(delId(it)) + '"><span class="ri">' + ic('bookmark', 20) + '</span><span class="rt"><b>Rimuovi dai salvati</b><small>Resta nel corso originale</small></span></button>' +
          '<div class="rw off" aria-disabled="true"><span class="ri">' + ic('list', 20) + '</span><span class="rt"><b>Rimuovi dalla raccolta</b><small>Raccolte: seconda fase</small></span><span class="arr">In arrivo</span></div></div>';
      root.innerHTML = h + C.bar(-1);
      var ta = document.getElementById('svNota'), tN = 0;
      ta.addEventListener('input', function(){ clearTimeout(tN); var v = ta.value; tN = setTimeout(function(){ setM(it.k, 'nota', v.trim()); }, 300); });
      ta.addEventListener('change', function(){ setM(it.k, 'nota', ta.value.trim()); });
      return;
    }
    h = C.header(vista.arg ? argNome(vista.arg) : vista.cat ? CAT.filter(function(c){ return c[0] === vista.cat; })[0][1] : 'I miei salvati', vista.cat ? '' : 'La tua biblioteca personale.');
    if (!vista.cat){
      h += '<label class="sv-cerca">' + ic('search', 20) + '<input id="svQ" type="search" placeholder="Cerca contenuti e note…" value="' + esc(vista.q) + '" autocomplete="off"></label>' +
        '<div class="seg sv-tabs" role="tablist"><button role="tab" data-tab="tutti" aria-checked="' + (vista.tab === 'tutti') + '">Tutti</button><button role="tab" data-tab="rip" aria-checked="' + (vista.tab === 'rip') + '">Da ripassare</button>' +
        '<button class="off" disabled>Raccolte<small>seconda fase</small></button></div>';
    }
    var q = vista.q.trim().toLowerCase();
    if (!vista.cat && q){
      var tr = its.filter(function(it){ return (it.tit + ' ' + it.argN + ' ' + it.nota).toLowerCase().indexOf(q) >= 0; });
      h += '<h3>Risultati</h3>' + (tr.length ? tr.map(riga).join('') : '<p class="nota">Nessun salvato trovato.</p>');
    } else if (!vista.cat && vista.tab === 'rip'){
      var rr = its.filter(function(it){ return it.rip; });
      h += '<h3>Da ripassare</h3>' + (rr.length ? rr.map(riga).join('') : '<p class="nota">Niente da ripassare. Apri un salvato e segna «Da ripassare»: è una tua scelta, separata dal ripasso automatico.</p>');
    } else if (!vista.cat){
      h += '<h3>Categorie</h3><div class="sv-cats">' + CAT.map(function(c){ var n = its.filter(function(it){ return it.cat === c[0]; }).length;
        return '<button class="card sv-cat' + (n ? '' : ' vuota') + '"' + (n ? ' data-cat="' + c[0] + '"' : ' aria-disabled="true"') + '><span class="ri">' + ic(c[2], 24) + '</span><b>' + c[1] + '</b><span class="n">' + n + '</span></button>'; }).join('') + '</div>' +
        '<p class="nota">Le categorie si popolano quando salvi contenuti: esercizi e puzzle col segnalibro accanto alle mosse, partite col tocco lungo in «Le tue partite». Finali, aperture, strategia e corsi arriveranno con le loro sezioni.</p>';
    } else if (!vista.arg){
      var args = {}; its.forEach(function(it){ if (it.cat === vista.cat) (args[it.arg] = args[it.arg] || []).push(it); });
      var ks = Object.keys(args);
      h += ks.map(function(k){ return '<button class="card sv-cat" data-arg="' + k + '"><span class="ri">' + ic(argIco(k), 22) + '</span><b>' + esc(argNome(k)) + '</b><span class="n">' + args[k].length + '</span></button>'; }).join('') +
        '<p class="nota">Solo gli argomenti con almeno un salvato.</p>';
    } else {
      h += its.filter(function(it){ return it.cat === vista.cat && it.arg === vista.arg; }).map(riga).join('');
    }
    root.innerHTML = h + C.bar(-1);
    var inp = document.getElementById('svQ');
    if (inp) inp.addEventListener('input', function(){ vista.q = inp.value; var pos = inp.selectionStart; disegna(); var n = document.getElementById('svQ'); n.focus(); try { n.setSelectionRange(pos, pos); } catch(e){} });
  }
  // togli/rimetti un salvato di qualsiasi tipo (esercizio: preferiti dell'app · puzzle: archivio del puzzle · partita: partite_dati.js)
  function cambia(k, on){
    k = key(k);
    if (/^ex-/.test(k)){ var n = +k.slice(3), has = favs().indexOf(n) >= 0; if (has !== on) toggle(n); return; }
    if (/^pz-/.test(k) && PZ){ var id = k.slice(3); if (PZ.isFavId(id) !== on) PZ.toggleFav(id); return; }
    if (/^pt-/.test(k) && PT){ PT.salva(k.slice(3), on); }
  }
  function rimuovi(n){
    var k = key(n), it = items().filter(function(x){ return x.k === k; })[0]; cambia(k, false);
    if (vista.el != null && key(vista.el) === k) vista.el = null;
    if (vista.arg && !items().some(function(x){ return x.arg === vista.arg; })){ vista.arg = null; if (!items().some(function(x){ return x.cat === vista.cat; })) vista.cat = null; }
    disegna();
    C.toast('Rimosso dai salvati' + (it ? ' · ' + it.argN : ''), function(){ cambia(k, true); disegna(); });
  }
  root.addEventListener('click', function(ev){
    var t;
    if ((t = ev.target.closest('[data-del]'))){ ev.preventDefault(); rimuovi(t.dataset.del); return; }
    if ((t = ev.target.closest('[data-el]'))){ vista.el = key(t.dataset.el); disegna(); window.scrollTo(0, 0); return; }
    if ((t = ev.target.closest('[data-an]'))){ if (C.P && C.P.go) C.P.go('botanalizza', t.dataset.an); else C.toast('L\'analisi si apre dentro l\'app.'); return; }
    if ((t = ev.target.closest('[data-anno]'))){ C.toast('Partita di prima dell\'aggiornamento: le mosse non sono state salvate.'); return; }
    if ((t = ev.target.closest('[data-cat]'))){ vista.cat = t.dataset.cat; vista.q = ''; disegna(); window.scrollTo(0, 0); return; }
    if ((t = ev.target.closest('.sv-cat[data-arg]'))){ vista.arg = t.dataset.arg; disegna(); window.scrollTo(0, 0); return; }
    if ((t = ev.target.closest('[data-tab]'))){ vista.tab = t.dataset.tab; disegna(); return; }
    if ((t = ev.target.closest('[data-rip]'))){ var n = key(t.dataset.rip), v = !m(n).rip; setM(n, 'rip', v); disegna(); C.toast(v ? 'Segnato da ripassare' : 'Tolto da ripassare'); return; }
    if ((t = ev.target.closest('[data-delnota]'))){ var k = key(t.dataset.delnota), old = m(k).nota; setM(k, 'nota', ''); disegna(); C.toast('Nota eliminata', function(){ setM(k, 'nota', old); disegna(); }); return; }
    if (ev.target.closest('.vuota')){ C.toast('Ancora nessun salvato qui'); }
  });
  // Indietro: dettaglio → elenco → argomenti → categorie → pagina precedente
  C.canBack = function(){ return !!(vista.el || vista.arg || vista.cat || vista.q); };
  C.onBack = function(){ if (vista.el) vista.el = null; else if (vista.arg) vista.arg = null; else if (vista.cat) vista.cat = null; else vista.q = ''; disegna(); return true; };
  // il tasto Indietro dell'intestazione segue la stessa regola
  root.addEventListener('click', function(ev){ if (ev.target.closest('[data-back]') && C.canBack()){ ev.stopImmediatePropagation(); C.onBack(); } }, true);
  if (/[?&]vuoto\b/.test(location.search) === false && /[?&]demo\b/.test(location.search) && !favs().length){ [189, 342, 12].forEach(function(n){ if (byN[n]) toggle(n); }); setM(189, 'nota', 'Ricorda: prima di muovere, controlla gli scacchi del Nero.'); setM(342, 'rip', true); }
  // blocco 4: ?cat=tattica&arg=pz (dalla pagina Puzzle Random / Tattica: «Preferiti») apre direttamente lì
  (function(){ var Q = new URLSearchParams(location.search), c = Q.get('cat'), a = Q.get('arg');
    if (c && CAT.some(function(x){ return x[0] === c; })){ var its = items().filter(function(x){ return x.cat === c; });
      if (its.length){ vista.cat = c; if (a && its.some(function(x){ return x.arg === a; })) vista.arg = a; } } })();
  // da pagina d'ingresso: Indietro dall'argomento torna subito alla pagina che l'ha aperta
  var diretto = !!vista.cat;
  C.canBack = function(){ if (diretto && !vista.el && !vista.q) return false; return !!(vista.el || vista.arg || vista.cat || vista.q); };
  disegna();
  window.__salvati = {items:items, vista:function(){ return vista; }};
})();
