/* PRIMO AVVIO 29c (grande aggiornamento, blocco 2, 10-11). Approvato da Kiko 08-11 10:11 con i testi DEFINITIVI (LISTA L.843-846):
   3 schermate tutte saltabili, nessuna animazione per ora (la scacchiera di pagina 1 è ferma), niente barra in basso, niente Google.
   (1) Benvenuto: logo + Chess Node, scacchiera, motto, descrizione, «Gratis, senza abbonamenti.», Inizia.
   (2) Facciamola tua: nome, livello, istruttore, obiettivo. (3) Profili facoltativi Lichess/Chess.com + salvataggio sul telefono.
   Chi salta entra subito e si allena gratis; i risultati restano sul telefono. Il livello è solo un punto di partenza.
   Salva: profilo dell'app (nome), istruttore (__coach.setChar), chessnodeplay-account-v1 (livello, obiettivo, lichess, chesscom)
   e chessnodeplay-primoavvio-v1 (fatto / saltato) così non ricompare. */
(function(){
  'use strict';
  var C = window.CNP, esc = C.esc, root = document.getElementById('pg'), PW = C.inApp ? window.parent : null;
  root.classList.add('pa');
  var st = {p:1, nome:'', livello:'principiante', ist:'chessnote', obiettivo:'divertirmi', lichess:'', chesscom:''};
  var m = /[?&]p=(\d)/.exec(location.search); if (m) st.p = Math.max(1, Math.min(3, +m[1]));
  var ISTR = [['chessnote', 'Chess Node'], ['paola', 'Paola'], ['nerd', 'Luca'], ['serena', 'Nadia'], ['maestro', 'Prof']];
  function seg(k, opts){ return '<div class="seg g2" role="radiogroup">' + opts.map(function(o){ return '<button role="radio" data-k="' + k + '" data-v="' + o[0] + '" aria-checked="' + (st[k] === o[0]) + '">' + o[1] + '</button>'; }).join('') + '</div>'; }
  function testa(){ return '<div class="pa-top"><span class="pa-dots" aria-label="Pagina ' + st.p + ' di 3">' + [1, 2, 3].map(function(i){ return '<i class="' + (i === st.p ? 'on' : '') + '"></i>'; }).join('') + '</span><button class="pa-salta" data-salta>Salta</button></div>'; }
  function pagina(){
    var h = testa();
    if (st.p === 1) h += '<div class="pa-logo"><img alt="" src="logo_cn.png"><span class="cn-word">Chess <i>Node</i><u>.</u></span></div>' +
      '<h1 class="pa-h1">Benvenuto!</h1><div class="pa-board">' + C.mb('r1bqkb1r/pppp1ppp/2n2n2/4p3/2B1P3/5N2/PPPP1PPP/RNBQK2R', 232) + '</div>' +
      '<p class="motto pa-motto"><span class="m1">Studia.</span> <span class="m2">Analizza.</span> <span class="m3">Migliora.</span></p>' +
      '<p class="tx">Chess Node è un progetto indipendente per imparare e migliorare negli scacchi.</p>' +
      '<p class="tx">Segui corsi tematici, allenati con centinaia di esercizi, sfida i nostri bot e scopri i tuoi punti forti e deboli grazie all\'<b>analisi approfondita delle tue partite</b>, con spiegazioni chiare e consigli personalizzati.</p>' +
      '<p class="tx pa-gratis">Gratis, senza abbonamenti.</p>' +
      '<div class="pa-cta"><button class="btn" data-avanti>Inizia</button></div>';
    else if (st.p === 2) h += '<h1 class="pa-h1">Facciamola tua</h1>' +
      '<label class="ip-l">Come ti chiami?<input class="inp" id="paNome" maxlength="24" placeholder="Il tuo nickname" value="' + esc(st.nome) + '" autocomplete="off" autocapitalize="words" spellcheck="false"></label>' +
      '<h3>Il tuo livello</h3>' + seg('livello', [['principiante', 'Principiante'], ['intermedio', 'Intermedio'], ['avanzato', 'Avanzato'], ['esperto', 'Esperto']]) +
      '<p class="nota">È solo un punto di partenza: lo aggiorniamo mentre ti alleni</p>' +
      '<h3>Il tuo istruttore</h3><div class="pa-ist">' + ISTR.map(function(x){ return '<button data-k="ist" data-v="' + x[0] + '" aria-checked="' + (st.ist === x[0]) + '"><img alt="" src="istruttori/tondi/' + x[0] + '.webp"><span>' + x[1] + '</span></button>'; }).join('') + '</div>' +
      '<h3>Il tuo obiettivo</h3>' + seg('obiettivo', [['divertirmi', 'Divertirmi'], ['tattica', 'Migliorare in tattica'], ['tornei', 'Prepararmi ai tornei'], ['basi', 'Imparare le basi']]) +
      '<div class="pa-cta"><button class="btn" data-avanti>Avanti</button></div>';
    else if (st.p === 4) h += '<h1 class="pa-h1">Analizzale ora?</h1>' +   /* 14-11 (Kiko t1947u) */
      '<div class="card pa-lock">' + C.ic('v2-importa', 22) + '<p>Scarichiamo le tue partite pubbliche degli ultimi 12 mesi' + (st.lichess ? ' da Lichess (' + esc(st.lichess) + ')' : '') + (st.lichess && st.chesscom ? ' e' : '') + (st.chesscom ? ' da Chess.com (' + esc(st.chesscom) + ')' : '') + ' e le analizziamo sul telefono, solo con l\'app aperta. Puoi mettere in pausa quando vuoi.</p></div>' +
      '<p class="nota">Il tuo quadro comparirà in Home, nella scheda «Il tuo gioco».</p>' +
      '<div class="pa-cta"><button class="btn" data-analizza>Sì, analizzale ora</button><button class="pa-dopo" data-dopo>Più tardi</button></div>';
    else h += '<h1 class="pa-h1">Collega i tuoi profili (facoltativo)</h1>' +
      '<label class="ip-l">Lichess username<input class="inp" id="paLi" maxlength="30" placeholder="Nome utente Lichess" value="' + esc(st.lichess) + '" autocomplete="off" autocapitalize="off" spellcheck="false"></label>' +
      '<label class="ip-l">Chess.com username<input class="inp" id="paCc" maxlength="25" placeholder="Nome utente Chess.com" value="' + esc(st.chesscom) + '" autocomplete="off" autocapitalize="off" spellcheck="false"></label>' +
      '<p class="nota">Solo partite pubbliche, nessuna password</p>' +
      '<div class="card pa-lock">' + C.ic('v2-bloccato', 22) + '<p>I tuoi progressi restano salvati su questo telefono. Puoi esportarli quando vuoi da Impostazioni.</p></div>' +
      '<p class="nota pa-err" id="paErr" hidden>Controlla il nome utente: solo lettere, numeri, - e _.</p>' +
      '<div class="pa-cta"><button class="btn" data-fine>Entra in Chess Node</button><button class="pa-dopo" data-salta>Salta, lo faccio dopo</button></div>';
    root.innerHTML = h; window.scrollTo(0, 0);
  }
  function leggi(){ var n = document.getElementById('paNome'), li = document.getElementById('paLi'), cc = document.getElementById('paCc');
    if (n) st.nome = n.value.trim().slice(0, 24); if (li) st.lichess = li.value.trim(); if (cc) st.chesscom = cc.value.trim(); }
  function valido(u){ return !u || /^[A-Za-z0-9_-]{2,30}$/.test(u); }
  function fine(saltato){
    leggi();
    var a = C.rd('chessnodeplay-account-v1') || {};
    if (!saltato || st.p > 1){ a.livello = st.livello; a.obiettivo = st.obiettivo; }
    if (!saltato){ if (st.lichess) a.lichess = st.lichess; if (st.chesscom) a.chesscom = st.chesscom; }
    C.wr('chessnodeplay-account-v1', a);
    var prof = {nome:st.nome, genere:'n', auto:true, pezzo:'p', colore:'tema'};
    try { if (PW && PW.__profilo){ prof.genere = PW.__profilo.guess(st.nome); PW.__profilo.save(prof); } else C.wr('chessnodeplay-profilo-v1', prof); } catch(e){ C.wr('chessnodeplay-profilo-v1', prof); }
    if (!saltato || st.p > 1){ try { if (PW && PW.__coach && PW.__coach.setChar){ C.ctl('coachOn', 'on'); PW.__coach.setChar(st.ist); } else C.setPref('coachChar', st.ist); } catch(e){} }
    C.wr('chessnodeplay-primoavvio-v1', {v:1, t:Date.now(), saltato:!!saltato, pagina:st.p});
    if (PW && PW.CNHome) PW.CNHome.apri('home.html', true); else location.href = 'home.html';
  }
  root.addEventListener('click', function(ev){
    var t;
    if ((t = ev.target.closest('[data-k]'))){ leggi(); st[t.dataset.k] = t.dataset.v; var y = window.scrollY; pagina(); window.scrollTo(0, y); return; }
    if (ev.target.closest('[data-avanti]')){ leggi(); st.p++; pagina(); return; }
    if (ev.target.closest('[data-fine]')){ leggi(); if (!valido(st.lichess) || !valido(st.chesscom)){ document.getElementById('paErr').hidden = false; return; } if (st.lichess || st.chesscom){ st.p = 4; pagina(); return; } fine(false); return; }
    if (ev.target.closest('[data-analizza]')){ try { var X = PW && PW.__cnap; if (X && X.avviaCollega) X.avviaCollega({lichess:st.lichess || '', chesscom:st.chesscom || ''}); } catch(e){} fine(false); return; }
    if (ev.target.closest('[data-dopo]')){ fine(false); return; }
    if (ev.target.closest('[data-salta]')) fine(true);
  });
  root.addEventListener('keydown', function(ev){ if (ev.key === 'Enter' && ev.target.id === 'paNome') ev.target.blur(); });
  // Indietro: pagina 3 → 2 → 1; dalla pagina 1 esce dall'app (come la Home)
  C.canBack = function(){ return st.p > 1; };   // 4 (Analizzale ora?) → 3
  C.onBack = function(){ leggi(); st.p--; pagina(); return true; };
  pagina();
})();
