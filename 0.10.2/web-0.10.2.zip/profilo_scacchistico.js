/* Il mio profilo scacchistico — profilo provvisorio (testi approvati 09-11 23:50) e scheda (schema 31). */
(function (W) {
  'use strict';
  var C = W.CNP, root = document.getElementById('pg');
  if (!C || !root) return;
  root.classList.add('ps');

  var TX = {
    etichetta: 'Profilo provvisorio',
    primo: [
      'Questo profilo è provvisorio. È fatto sulle tue prime partite, così hai già un quadro.',
      'L’analisi profonda continua. Il tempo dipende da quante partite hai e da quanto è lunga la tua storia sui siti.',
      'Ti avvisiamo quando c’è qualcosa di nuovo: a quel punto vale la pena ricontrollare.'
    ],
    inCorsoTitolo: 'Analisi in corso',
    inCorsoSotto: 'Il profilo che vedi è ancora provvisorio.',
    avviso1: 'L’analisi avviene sul tuo dispositivo e può consumare batteria e scaldarlo. Puoi metterla in pausa in ogni momento.',
    avviso2: 'Sul telefono può continuare anche a schermo spento. Se spegni il telefono, si ferma e riprende da dove era rimasta, senza rifare il lavoro già finito. Sul computer si ferma se chiudi la pagina o spegni il PC.',
    genialiInCorso: 'La ricerca delle mosse geniali non è ancora finita. Non significa che non ce ne siano.',
    vuoto: 'Non ci sono ancora abbastanza partite tue analizzate per un quadro. Collega Lichess o Chess.com qui sotto e tocca «Analizza le mie partite».'
  };
  var PERIODI = [['1s', '1 settimana'], ['1m', '1 mese'], ['6m', '6 mesi'], ['1a', '1 anno'], ['tutto', 'Tutto']];
  var periodo = 'tutto';
  var TEMI = { pezzo_indifeso: 'Pezzo indifeso', forchetta: 'Forchetta', inchiodatura: 'Inchiodatura', infilata: 'Infilata', matto_non_visto: 'Matto non visto', scoperta: 'Attacco di scoperta', difesa: 'Difesa' };
  var FASI = { apertura: 'Apertura', mediogioco: 'Mediogioco', finale: 'Finale' };
  var FIN = { torre: 'Torre', pedoni: 'Pedoni', misti: 'Misti', pezzi_leggeri: 'Pezzi leggeri', donna: 'Donna' };

  function cnap(){ try { return (W.parent && W.parent.__cnap) || W.__cnap; } catch (e) { return W.__cnap; } }
  function app(){ try { return (W.parent && W.parent.__app) || W.__app; } catch (e) { return W.__app; } }
  function esc(s){ return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function pc(x){ return x == null ? '—' : String(x).replace('.', ',') + '%'; }
  function ic(n, s){ return C.ic ? C.ic(n, s || 20) : ''; }

  function statoPassate(){
    var x = cnap();
    return (x && typeof x.statoPassate === 'function') ? x.statoPassate() : { provvisorio: true, inCorso: false, inPausa: false, storiaFinita: false, genialiComplete: false };
  }

  function intestazione(st){
    var h = C.header('Il mio profilo scacchistico');
    h += '<section class="st-card" id="psStato">';
    // 14-11: anche in pausa resta il blocco «Analisi in corso» col tasto Riprendi (prima, in pausa, il tasto spariva)
    if ((st.inCorso || st.inPausa) && !st.storiaFinita){
      h += '<h2 class="an-h2">' + esc(TX.inCorsoTitolo) + '</h2>';
      h += '<p class="ps-tx">' + esc(TX.inCorsoSotto) + '</p>';
      h += '<div class="ps-avviso"><p class="ps-tx">' + esc(TX.avviso1) + '</p><p class="ps-tx">' + esc(TX.avviso2) + '</p></div>';
      h += '<div class="ps-azioni"><button type="button" class="btn an-cta" data-az="' + (st.inPausa ? 'riprendi' : 'pausa') + '">' + (st.inPausa ? 'Riprendi' : 'Metti in pausa') + '</button></div>';
    } else if (st.provvisorio && !st.storiaFinita){
      h += '<span class="ps-lab">' + esc(TX.etichetta) + '</span>';
      TX.primo.forEach(function (p) { h += '<p class="ps-tx">' + esc(p) + '</p>'; });
    }
    h += '</section>';
    return h;
  }

  function chipsPeriodo(){
    return '<div class="ps-chips" role="radiogroup" aria-label="Periodo">' + PERIODI.map(function (x) {
      return '<button type="button" role="radio" data-per="' + x[0] + '" aria-checked="' + (periodo === x[0]) + '">' + esc(x[1]) + '</button>';
    }).join('') + '</div>';
  }

  function interpretazione(p, st){
    var pochi = !p || p.pochiDati, txt;
    if (!p || !p.copertura || p.copertura.analizzate === 0) txt = TX.vuoto;
    else if (pochi) txt = 'Pochi dati per un giudizio: questo è solo un primo quadro, da prendere con prudenza.';
    else txt = 'Un quadro delle tue partite analizzate, con i punti che i dati confermano. Dove i dati non bastano, non inventiamo un giudizio.';
    var av = '', A = app(), nome = 'chessnote';
    try { if (A && A.prefs && A.prefs.coach) nome = A.prefs.coach; } catch (e) {}
    try { if (W.parent && W.parent.__coach && W.parent.__coach.char) nome = W.parent.__coach.char() || nome; } catch (e2) {}
    av = '<span class="ps-av" aria-hidden="true">' + ic('v2-profonda', 28) + '</span>';
    return '<section class="st-card"><div class="ps-coach">' + av + '<p>' + esc(txt) + '</p></div></section>';
  }

  function fonte(p){
    if (!p || !p.copertura) return '';
    var t = p.copertura.testo || '', siti = [];
    try {
      var pr = p.risultati && p.risultati.perSito;
      if (pr) Object.keys(pr).forEach(function (k) {
        var n = pr[k] && (pr[k].partite || pr[k].n || pr[k].totale);
        if (n) siti.push((k === 'chesscom' ? 'Chess.com' : k === 'lichess' ? 'Lichess' : k === 'file' ? 'Importate' : k) + ' · ' + n);
      });
    } catch (e) {}
    return '<p class="ps-src">' + esc(t) + (siti.length ? ' · ' + siti.join(' · ') : '') + '</p>';
  }

  function listaTemi(titolo, voci, campo){
    if (!voci || !voci.length) return '<section class="st-card"><h2 class="an-h2">' + esc(titolo) + '</h2><p class="ps-vuoto">Pochi dati per questa sezione.</p></section>';
    return '<section class="st-card"><h2 class="an-h2">' + esc(titolo) + '</h2><ul class="ps-list">' + voci.map(function (v) {
      var nome = TEMI[v.tema] || v.tema, testo = v[campo] || v.testo || '';
      return '<li><span class="ri">' + ic('v2-precisione', 18) + '</span><div><b>' + esc(nome) + '</b><div>' + esc(testo) + '</div></div></li>';
    }).join('') + '</ul></section>';
  }


  function precisioneFase(p, k){
    if (k === 'mediogioco' && p.tecnica && p.tecnica.mediogioco && p.tecnica.mediogioco.precisione)
      return p.tecnica.mediogioco.precisione.valore;
    if (k === 'finale' && p.tecnica && p.tecnica.finali){
      var arr = p.tecnica.finali, acc = 0, n = 0;
      (Array.isArray(arr) ? arr : []).forEach(function (f) {
        if (f.precisione && f.precisione.valore != null && !f.pochiDati){ acc += f.precisione.valore; n++; }
      });
      return n ? Math.round(10 * acc / n) / 10 : null;
    }
    if (k === 'apertura' && p.tecnica && p.tecnica.aperture){
      var rows = [].concat((p.tecnica.aperture.bianco || []), (p.tecnica.aperture.nero || [])), acc2 = 0, n2 = 0;
      rows.forEach(function (r) {
        if (r.precisionePrimeMosse && r.precisionePrimeMosse.valore != null && !r.pochiDati){ acc2 += r.precisionePrimeMosse.valore; n2++; }
      });
      return n2 ? Math.round(10 * acc2 / n2) / 10 : null;
    }
    return null;
  }

  function bloccoFasi(p){
    var h = '<section class="st-card"><h2 class="an-h2">Precisione per fase</h2><div class="ps-fasi">';
    ['apertura', 'mediogioco', 'finale'].forEach(function (k) {
      var v = precisioneFase(p, k);
      h += '<div><b>' + (v != null ? pc(v) : '—') + '</b><span>' + esc(FASI[k]) + '</span></div>';
    });
    return h + '</div></section>';
  }

  function tattica(p){
    var t = p && p.tecnica && p.tecnica.tattica;
    if (!t) return '';
    var deboli = (t.temi || []).filter(function (x) { return x.confermato; }).slice(0, 5);
    var forti = (t.puntiForti || []).slice(0, 3);
    var h = listaTemi('Punti forti', forti, 'testo');
    h += '<section class="st-card"><h2 class="an-h2">Da migliorare</h2>';
    if (deboli.length){
      h += '<ul class="ps-list">';
      deboli.forEach(function (x) {
        var cap = x.capitolo, nome = TEMI[x.tema] || x.tema;
        h += '<li><span class="ri">' + ic('v2-minaccia', 18) + '</span><div><b>' + esc(nome) + '</b><div>' + esc(x.consiglio || (x.errori + ' occasioni mancate su ' + x.occasioni)) + '</div>';
        if (cap && cap.id) h += '<button type="button" class="ps-lnk" data-cap="' + esc(cap.id) + '">Allenati su questo</button>';
        h += '</div></li>';
      });
      h += '</ul>';
    } else {
      h += '<p class="ps-vuoto">' + esc(t.testo || 'Pochi dati per questa sezione.') + '</p>';
    }
    return h + '</section>';
  }

  function vps(r){
    var t = r.vinte + r.patte + r.perse;
    if (!t) return '';
    return '<div class="ps-vps" aria-hidden="true"><i class="v" style="width:' + (100 * r.vinte / t) + '%"></i><i class="p" style="width:' + (100 * r.patte / t) + '%"></i><i class="s" style="width:' + (100 * r.perse / t) + '%"></i></div>';
  }

  function aperture(p){
    var a = p && p.tecnica && p.tecnica.aperture;
    if (!a) return '';
    var h = '<section class="st-card"><h2 class="an-h2">Aperture</h2>';
    [['Bianco', a.bianco], ['Nero', a.nero]].forEach(function (pair) {
      h += '<h3 class="an-h2" style="font-size:16px">' + pair[0] + '</h3>';
      if (!pair[1] || !pair[1].length){ h += '<p class="ps-vuoto">Nessuna apertura identificata.</p>'; return; }
      pair[1].slice(0, 8).forEach(function (r) {
        var nome = r.nome || r.eco || '';
        h += '<div class="ps-ap"><b>' + esc(nome) + (r.eco && r.nome && r.nome !== r.eco ? ' · ' + esc(r.eco) : '') + '</b>' + vps(r) +
          '<small>' + r.partite + (r.partite === 1 ? ' partita' : ' partite') + (r.pochiDati ? ' · Pochi dati' : (r.percentualeVittorie != null ? ' · ' + pc(r.percentualeVittorie) + ' vinte' : '')) + '</small></div>';
      });
    });
    if (a.uscitaDallaTeoria && a.uscitaDallaTeoria.testo) h += '<p class="ps-vuoto">' + esc(a.uscitaDallaTeoria.testo) + '</p>';
    return h + '</section>';
  }

  function finali(p){
    var f = p && p.tecnica && p.tecnica.finali;
    if (!f || !f.length) return '<section class="st-card"><h2 class="an-h2">Finali</h2><p class="ps-vuoto">Pochi dati.</p></section>';
    var h = '<section class="st-card"><h2 class="an-h2">Finali</h2><ul class="ps-list">';
    f.forEach(function (x) {
      var nome = FIN[x.tipo] || x.tipo;
      h += '<li><span class="ri">' + ic('v2-tempo', 18) + '</span><div><b>' + esc(nome) + '</b><div>' +
        (x.pochiDati ? 'Pochi dati' : (x.precisione && x.precisione.valore != null ? 'Precisione ' + pc(x.precisione.valore) : '')) +
        (x.testo && !x.pochiDati ? ' · ' + esc(x.testo) : '') + '</div></div></li>';
    });
    return h + '</ul></section>';
  }

  function mesi(p){
    var m = p && p.mesi, h = '<section class="st-card"><h2 class="an-h2">Evoluzione</h2>';
    if (!m || !m.righe || !m.righe.length) return h + '<p class="ps-vuoto">Pochi dati.</p></section>';
    h += '<ul class="ps-list">';
    m.righe.slice(0, 8).forEach(function (r) {
      h += '<li><div><b>' + esc(r.mese) + '</b><div>' + r.analizzate + ' analizzate' + (r.precisione != null ? ' · precisione ' + pc(r.precisione) : '') + '</div></div></li>';
    });
    h += '</ul>';
    if (m.confronti && m.confronti[0] && m.confronti[0].testo) h += '<p class="ps-vuoto">' + esc(m.confronti[0].testo) + '</p>';
    return h + '</section>';
  }

  function geniali(p, st){
    var g = p && p.galleria, h = '<section class="st-card"><h2 class="an-h2">Le mie mosse geniali</h2>';
    if (!st.genialiComplete && !st.storiaFinita){
      h += '<p class="ps-tx">' + esc(TX.genialiInCorso) + '</p>';
      /* niente «0» come prova che non ce ne sono */
      if (g && g.attuali && g.attuali.length){
        h += '<ul class="ps-list ps-gen">';
        g.attuali.slice(0, 8).forEach(function (x) {
          h += '<li><div><b>' + esc((x.mossa && (x.mossa.san || x.mossa.uci || x.mossa)) || 'Mossa') + '</b><div>' + esc(x.data || '') + (x.avversario ? ' · ' + esc(x.avversario) : '') + '</div></div></li>';
        });
        h += '</ul>';
      }
      return h + '</section>';
    }
    if (!g || !g.attuali || !g.attuali.length) return h + '<p class="ps-vuoto">Nessuna mossa geniale verificata in questo periodo.</p></section>';
    h += '<ul class="ps-list ps-gen">';
    g.attuali.slice(0, 12).forEach(function (x) {
      h += '<li><div><b>' + esc((x.mossa && (x.mossa.san || x.mossa.uci || x.mossa)) || 'Mossa') + '</b><div>' + esc(x.data || '') + (x.avversario ? ' · ' + esc(x.avversario) : '') + '</div></div></li>';
    });
    return h + '</ul></section>';
  }

  function cta(){
    return '<section class="st-card"><button type="button" class="btn an-cta ps-cta" data-az="analizza">Analizza nuove partite</button>' +
      '<p class="ps-vuoto" style="margin-top:8px">L’analisi avviene sul tuo dispositivo.</p></section>';
  }

  async function caricaProfilo(){
    var x = cnap(), CN = x && x.CN, p = null;
    if (CN && CN.profilo && typeof CN.profilo.calcola === 'function'){
      try { p = await CN.profilo.calcola({ periodo: periodo, scope: 'self' }); } catch (e) { p = null; }
    }
    return p;
  }

  async function disegna(){
    var st = statoPassate(), p = await caricaProfilo();
    var h = intestazione(st);
    h += '<section class="st-card">' + chipsPeriodo() + fonte(p) + '</section>';
    h += interpretazione(p, st);
    if (p && p.copertura && p.copertura.analizzate > 0){
      h += tattica(p);
      h += bloccoFasi(p);
      h += aperture(p);
      h += finali(p);
      h += mesi(p);
      h += geniali(p, st);
    }   // 14-11: senza partite il testo «vuoto» lo dice già il fumetto sopra (prima compariva due volte)
    /* 14-11 (Kiko t1947u): senza dati, o mentre l'import/analisi è in corso, il riquadro «Collega i tuoi profili» al posto del vecchio rinvio ad «Analizza me» */
    var stC = W.CNCollega ? W.CNCollega.stato() : null, conCp = W.CNCollega && (!(p && p.copertura && p.copertura.analizzate > 0) || (stC && stC.fase !== 'fatto' && stC.fase !== 'mai'));
    if (conCp) h += '<section class="st-card cp" id="cpProf"></section>';
    h += cta();
    root.innerHTML = h + (C.bar ? C.bar() : '');
    if (conCp) W.CNCollega.monta(document.getElementById('cpProf'), { modo: 'pagina' });
  }

  root.addEventListener('click', function (ev) {
    var t, x = cnap();
    if ((t = ev.target.closest('[data-per]'))){ periodo = t.dataset.per; disegna(); return; }
    if ((t = ev.target.closest('[data-az]'))){
      var az = t.dataset.az;
      if (az === 'pausa' && x && x.pausaAnalisi) x.pausaAnalisi();
      if (az === 'riprendi' && x && x.riprendiAnalisi) x.riprendiAnalisi();
      if (az === 'analizza'){
        if (C.P && C.P.apri) C.P.apri('analisi.html');
        else if (C.vai) C.vai('analisi.html');
      }
      if (az === 'pausa' || az === 'riprendi') disegna();
      return;
    }
    if ((t = ev.target.closest('[data-cap]'))){
      try {
        if (W.parent && W.parent.CNHome && W.parent.CNHome.apri) W.parent.CNHome.apri('sezione.html?c=' + encodeURIComponent(t.dataset.cap));
        else if (C.vai) C.vai('sezione.html?c=' + encodeURIComponent(t.dataset.cap));
      } catch (e) {}
    }
  });

  disegna();
  W.addEventListener('pageshow', function () { disegna(); });
  // 14-11: se l'analisi cambia stato mentre la pagina è aperta (passata finita, storia finita), si aggiorna da sola
  function firma(st){ return [!!st.inCorso, !!st.inPausa, !!st.storiaFinita, !!st.provvisorio, !!st.genialiComplete, st.passata].join(); }
  var ultimaFirma = firma(statoPassate());
  setInterval(function () {
    if (document.hidden) return;
    var f = firma(statoPassate());
    if (f !== ultimaFirma){ ultimaFirma = f; disegna(); }
  }, 4000);
})(window);
