/* ChessNodePlay Frecce V5 - modulo autonomo. SVG geometria dall'app V5.
   Licenza: come il progetto che lo integra. Non sostituisce app.js.
   COPIA «stile Chess Node» (anteprima 09-11): asta più sottile, partenza staccata dal centro
   del pezzo, rastrematura + dissolvenza verso l'origine, colori nostri. Vedi NOTE.md. */
(function(global){'use strict';
var FILES='abcdefgh';
var state={orient:'w'};
function sqXY(sq){
 var f=FILES.indexOf(sq[0]),r=Number(sq[1])-1;
 if(f<0||r<0||r>7) throw Error('Casa non valida: '+sq);
 return [state.orient==='w'?f+.5:7-f+.5,state.orient==='w'?7-r+.5:r+.5];
}
function f3(x){ return x.toFixed(3); }
/* STILE: misure in lato casa. L'originale V5: width .18, head .27/.16, opacità .75, partenza dal centro. */
var STYLE={width:.15,startWidth:.09,startGap:.16,headLength:.30,headHalfWidth:.17,tipGap:.06,
  fadeFrom:.40,fadeLen:1.0,opacity:.64};
var COLORS={best:'#4FC3F7',threat:'#DB4F4A',mistake:'#e8590c'};
function arrowRoute(from,to,opt){
  opt=opt||{};
  var p=sqXY(from),q=sqXY(to),dx=q[0]-p[0],dy=q[1]-p[1];
  var route=[p];
  if ((Math.abs(dx)===1 && Math.abs(dy)===2) || (Math.abs(dx)===2 && Math.abs(dy)===1)) {
    route.push(Math.abs(dy)>Math.abs(dx)?[p[0],q[1]]:[q[0],p[1]]);
  }
  route.push(q);
  /* partenza staccata dal centro del pezzo (l'app usa 0.12), punta un filo prima del centro d'arrivo.
     Per l'arrocco (tratto corto, opt.short) partenza e punta un po' più vicine, così l'asta si vede. */
  /* arrocco: punta staccata dal centro del Re (dopo O-O il Re è già sulla casa d'arrivo). */
  var startGap=opt.short?0.08:STYLE.startGap, tipGap=opt.short?0.22:STYLE.tipGap;
  var a=route[0],b=route[1],l=Math.hypot(b[0]-a[0],b[1]-a[1]);
  if(l>1e-5) route[0]=[a[0]+(b[0]-a[0])/l*startGap,a[1]+(b[1]-a[1])/l*startGap];
  var n=route.length,y=route[n-2],z=route[n-1],m=Math.hypot(z[0]-y[0],z[1]-y[1]);
  if(m>1e-5) route[n-1]=[z[0]-(z[0]-y[0])/m*tipGap,z[1]-(z[1]-y[1])/m*tipGap];
  return route;
}
function arrowOutline(points,opt){
  opt=opt||{};
  var width=opt.short?0.22:STYLE.width, startWidth=opt.short?0.14:STYLE.startWidth;
  var headLength=opt.short?0.34:STYLE.headLength, headHalfWidth=opt.short?0.20:STYLE.headHalfWidth, seg=[];
  for(var i=1;i<points.length;i++){
    var a=points[i-1],b=points[i],len=Math.hypot(b[0]-a[0],b[1]-a[1]);
    if(len>1e-5)seg.push({a:a,b:b,u:[(b[0]-a[0])/len,(b[1]-a[1])/len]});
  }
  if(!seg.length)return '';
  var last=seg[seg.length-1],u=last.u,end=last.b,base=[end[0]-u[0]*headLength,end[1]-u[1]*headLength];
  var shaft=[seg[0].a];for(var j=0;j<seg.length-1;j++)shaft.push(seg[j].b);
  if(Math.hypot(base[0]-shaft[shaft.length-1][0],base[1]-shaft[shaft.length-1][1])>1e-5)shaft.push(base);
  var half=width/2;
  function offset(side){
    var ns=[];for(var k=1;k<shaft.length;k++){
      var dx=shaft[k][0]-shaft[k-1][0],dy=shaft[k][1]-shaft[k-1][1],l=Math.hypot(dx,dy);
      ns.push([-dy/l*half*side,dx/l*half*side]);
    }
    return shaft.map(function(pt,i){
      /* rastrematura: all'origine l'asta è larga solo startWidth, poi si allarga lungo il primo tratto */
      if(i===0){var r=startWidth/width;return [pt[0]+ns[0][0]*r,pt[1]+ns[0][1]*r];}
      if(i===shaft.length-1){var n=ns[ns.length-1];return [pt[0]+n[0],pt[1]+n[1]];}
      var n1=ns[i-1],n2=ns[i],vx=n1[0]+n2[0],vy=n1[1]+n2[1],dot=vx*n2[0]+vy*n2[1],scale=Math.abs(dot)>1e-9?half*half/dot:1;
      return [pt[0]+vx*scale,pt[1]+vy*scale];
    });
  }
  var normal=[-u[1],u[0]],left=offset(1),right=offset(-1);
  var contour=left.concat([[base[0]+normal[0]*headHalfWidth,base[1]+normal[1]*headHalfWidth],end,[base[0]-normal[0]*headHalfWidth,base[1]-normal[1]*headHalfWidth]],right.reverse());
  return 'M'+contour.map(function(pt){return f3(pt[0])+','+f3(pt[1]);}).join('L')+'Z';
}

var sequence=0;
function escapeAttr(s){return String(s).replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;');}
function svgArrow(from,to,options){
 options=options||{};
 if(from===to) return '';
 state.orient=options.orient==='b'?'b':'w';
 var route=arrowRoute(from,to,options),d=arrowOutline(route,options);
 var color=COLORS[options.color]||options.color||COLORS.best, opacity=options.opacity==null?(options.short?1:STYLE.opacity):options.opacity;
 var animate=options.short?false:(options.animate!==false), delay=Number(options.delay)||0;
 var n=++sequence, gid='cnp-arrow-fade-'+n;
 /* dissolvenza: gradiente lungo il primo tratto, dall'origine (quasi trasparente) a piena opacità dopo ~1 casa */
 var a=route[0],b=route[1],l=Math.hypot(b[0]-a[0],b[1]-a[1])||1,ux=(b[0]-a[0])/l,uy=(b[1]-a[1])/l;
 var fadeLen=options.short?0.18:STYLE.fadeLen, fadeFrom=options.short?0.85:STYLE.fadeFrom;
 var L=Math.min(fadeLen,l*.55), e=[a[0]+ux*L,a[1]+uy*L], c=escapeAttr(color);
 var grad='<linearGradient id="'+gid+'" gradientUnits="userSpaceOnUse" x1="'+f3(a[0])+'" y1="'+f3(a[1])+'" x2="'+f3(e[0])+'" y2="'+f3(e[1])+'">'+
  '<stop offset="0" stop-color="'+c+'" stop-opacity="'+fadeFrom+'"/><stop offset="1" stop-color="'+c+'" stop-opacity="1"/></linearGradient>';
 var attrs=' d="'+d+'" fill="url(#'+gid+')" opacity="'+opacity+'" data-from="'+from+'" data-to="'+to+'" data-color="'+c+'"';
 if(!animate) return '<defs>'+grad+'</defs><path class="cnp-arrow"'+attrs+' />';
 var id='cnp-arrow-mask-'+n;
 var line='M'+route.map(function(pt){return f3(pt[0])+','+f3(pt[1]);}).join('L');
 return '<defs>'+grad+'<mask id="'+id+'" maskUnits="userSpaceOnUse" x="0" y="0" width="8" height="8">'+
 '<path class="cnp-arrow-reveal" d="'+line+'" fill="none" stroke="white" stroke-width="1" stroke-linecap="butt" pathLength="1" style="animation-delay:'+delay+'ms" />'+
 '</mask></defs><path class="cnp-arrow"'+attrs+' mask="url(#'+id+')" />';
}
function render(svgElement,items,options){
 options=options||{};
 svgElement.setAttribute('viewBox','0 0 8 8');
 svgElement.innerHTML=(items||[]).map(function(item){
   return svgArrow(item.from,item.to,Object.assign({},options,item));
 }).join('');
}
function polygonPoints(from,to,cellSize,orient){
 state.orient=orient==='b'?'b':'w';
 var d=arrowOutline(arrowRoute(from,to));
 var nums=d.match(/-?\d+(?:\.\d+)?/g)||[];
 var points=[];for(var i=0;i<nums.length;i+=2) points.push([Number(nums[i])*cellSize,Number(nums[i+1])*cellSize]);
 return points;
}
global.ChessNodeArrows={svgArrow:svgArrow,render:render,polygonPoints:polygonPoints,STYLE:STYLE,COLORS:COLORS};
})(window);
