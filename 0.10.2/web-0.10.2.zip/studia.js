/* Grande aggiornamento, blocco 4 (11-11): pagina Studia, schema 18b (anteprime/blocco18_studia/schema_studia_18b_*, legenda_studia_18b.txt)
   + scheda «Trappole in apertura · in arrivo» subito dopo Aperture (Kiko).
   Ordine: intestazione (Chess Node. · salvati · impostazioni) e titolo · Il tuo livello + Serie giorni · Continua da qui ·
   Esercizio del giorno (striscia L-D, difficoltà relativa al tuo rating) · Puzzle Random · Tattica · Aperture · Trappole in apertura ·
   Finali (in preparazione) · Strategia · Ripasso errori · I tuoi punti deboli (FUTURO) · barra con Studia attivo.
   Dati veri dall'app (stessa origine): Puzzle rating (CNPuzzle), serie (progressi.js), 1001 (progressi), ripasso (stats.js e puzzle).
   Aperture, Trappole, Finali, Strategia e Punti deboli sono visibili ma non attivi (nessun dato caricato). Nessuna rete. */
(function(){
  'use strict';
  var C = window.CNP, ic = C.ic, esc = C.esc, A = C.A, W = A ? window.parent : null;
  var root = document.getElementById('pg');
  function pz(){ return W && W.CNPuzzle; }
  function gio(){ return W && W.CNGiorno; }
  function libro(){ return (W && W.BOOK) || {chapters:[], ex:[]}; }
  function risolti(){ var p = {}; try { p = A.progress(); } catch(e){} var n = 0; libro().chapters.forEach(function(c){ c.list.forEach(function(e){ if (p[e.n] === 's' || p[e.n] === 'e') n++; }); }); return n; }
  function totale(){ var n = 0; libro().chapters.forEach(function(c){ n += c.list.length; }); return n; }
  function serie(){ try { return W.__progressi.streaks().cur || 0; } catch(e){ return 0; } }
  function ripT(){ try { return W.__stats.todayList().length; } catch(e){ return 0; } }
  function ripP(){ try { return pz().todayList().length; } catch(e){ return 0; } }
  function tile(n){ return '<span class="st-ti">' + ic(n, 26) + '</span>'; }
  function scheda(o){
    var dis = !o.go && !o.pg;
    return '<' + (dis ? 'div' : 'button') + ' class="st-card st-sez' + (dis ? ' st-off' : '') + '"' + (o.pg ? ' data-pg="' + o.pg + '"' : '') + (o.go ? ' data-go="' + o.go + '"' + (o.arg ? ' data-arg="' + o.arg + '"' : '') : '') +
      (dis ? ' aria-disabled="true" data-arr="' + esc(o.t) + '"' : '') + ' data-sez="' + o.id + '">' +
      '<span class="st-sh">' + tile(o.ico) + '<span><b>' + esc(o.t) + '</b><span class="st-stato' + (o.or ? ' or' : '') + '">' + esc(o.stato) + '</span></span>' + (dis ? '' : ic('chevron-right', 20).replace('class="lu"', 'class="lu ch"')) + '</span>' +
      (o.d ? '<p class="st-d">' + esc(o.d) + '</p>' : '') +
      (o.bar != null ? '<span class="st-bar"><i style="width:' + Math.round(o.bar * 100) + '%"></i></span>' : '') +
      (o.bl ? '<span class="st-bl">' + esc(o.bl) + '</span>' : '') + '</' + (dis ? 'div' : 'button') + '>';
  }
  function disegna(){
    var P = pz(), G = gio(), rat = P ? P.rating() : null, prov = P ? P.provvisorio() : true, sr = serie();
    var cont = W && W.CNB4 ? W.CNB4.continua() : {go:'tattica', arg:'cont', sotto:'Ultimo esercizio o percorso'};
    var h = '<header class="st-top"><div class="cn-word">Chess <i>Node</i><u>.</u></div>' +
      '<button class="hd15-b" data-pg="salvati.html" aria-label="I miei salvati">' + ic('bookmark', 24) + '</button>' +
      '<button class="hd15-b" data-pg="impostazioni.html" aria-label="Impostazioni">' + ic('settings', 24) + '</button></header>' +
      '<h1 class="st-h1">Studia</h1>';
    // 2 livello + serie
    h += '<div class="st-due"><div class="st-card" id="stLiv"><span class="st-k">Il tuo livello</span><span class="st-v">' + (rat == null ? '—' : rat) + (prov ? '<small>provvisorio</small>' : '') + '</span></div>' +
      '<div class="st-card" id="stSerie"><span class="st-k">Serie giorni</span><span class="st-v">' + (sr ? ic('flame', 20) : '') + sr + '<small>' + (sr === 1 ? 'giorno' : 'giorni') + '</small></span></div></div>';
    // 3 continua
    h += '<button class="st-cont" id="stCont" data-go="' + cont.go + '"' + (cont.arg ? ' data-arg="' + cont.arg + '"' : '') + '>' + ic('v2-riprendi', 30) + '<span><b>Continua da qui</b><small>' + esc(cont.sotto) + '</small></span>' + ic('chevron-right', 22) + '</button>';
    // 4 esercizio del giorno
    var sett = G ? G.settimana() : [], fattoOggi = G ? G.fatto() : false;
    h += '<div class="st-card st-sez st-sp st-gc"><button class="st-gb" id="stGiorno" data-go="giorno"><span class="st-sh">' + tile('v2-giorno') + '<span><b>Esercizio del giorno</b><span class="st-stato">' + (G ? esc(G.nomeOggi()) : '') + '</span></span>' +
      (fattoOggi ? '<span class="st-fatto">Fatto ✓</span>' : ic('chevron-right', 20).replace('class="lu"', 'class="lu ch"')) + '</span>' +
      '<p class="st-d">Difficoltà relativa al tuo rating</p><span class="st-sett">' + sett.map(function(g){
        return '<span class="st-g' + (g.oggi ? ' oggi' : '') + (g.fatto ? ' fatto' : '') + '">' + g.l + '<small>' + (g.fatto ? '✓' : (g.off > 0 ? '+' : '−') + Math.abs(g.off)) + '</small></span>'; }).join('') + '</span></button>' +
      '<button class="st-pro" data-pg="impostazioni.html#notifiche">Promemoria facoltativo · <u>Impostazioni</u></button></div>';
    // 5 Puzzle Random
    var gioc = P ? P.giocati() : 0;
    h += scheda({id:'pz', ico:'v2-casuale', t:'Puzzle Random', stato:'Pronto', pg:'sezione.html?s=pz',
      d:'Esercizi a difficoltà crescente con temi misti, come in una vera partita: non sai mai cosa ti aspetta.',
      bar:P ? gioc / P.total : 0, bl:P ? gioc + ' giocati · Puzzle rating ' + rat + (prov ? ' (provvisorio)' : '') : ''});
    // 6 Tattica
    var r = risolti(), tot = totale();
    h += scheda({id:'tattica', ico:'v2-tattica', t:'Tattica', stato:'Pronto', pg:'sezione.html?s=tattica', d:libro().chapters.length + ' capitoli · ' + tot + ' esercizi',
      bar:tot ? r / tot : 0, bl:r + ' / ' + tot + ' risolti'});
    // 7-9 in arrivo (visibili ma non attive)
    h += scheda({id:'aperture', ico:'v2-aperture', t:'Aperture', stato:'In arrivo', or:1, d:'Percorso da realizzare', bar:0, bl:'Progresso non ancora disponibile'});
    h += scheda({id:'trappole', ico:'v2-trappole', t:'Trappole in apertura', stato:'In arrivo', or:1, d:'Percorso da realizzare', bar:0, bl:'Progresso non ancora disponibile'});
    h += scheda({id:'finali', ico:'v2-finali', t:'Finali', stato:'In preparazione', or:1, d:'Il corso è in preparazione', bar:0, bl:'Progresso non ancora disponibile'});
    h += scheda({id:'strategia', ico:'v2-strategia', t:'Strategia', stato:'In arrivo', or:1, d:'Percorso da realizzare', bar:0, bl:'Progresso non ancora disponibile'});
    // 10 ripasso errori
    var rt = ripT(), rp = ripP(), rq = 0; try { rq = W.__stats.queue().length + pz().queue().length; } catch(e){}
    h += '<button class="st-card st-sez" id="stRip" data-az="ripasso" data-sez="ripasso"><span class="st-sh">' + tile('v2-ripasso') + '<span><b>Ripasso errori</b><span class="st-stato' + (rt + rp ? ' or' : '') + '">' +
      (rt + rp ? (rt + rp) + ' da ripassare oggi' : 'Da ripassare') + '</span></span>' + ic('chevron-right', 20).replace('class="lu"', 'class="lu ch"') + '</span>' +
      '<p class="st-d">' + (rt + rp ? 'Tattica ' + rt + ' · Puzzle ' + rp : rq ? 'Niente per oggi: il prossimo ripasso torna nei prossimi giorni.' : 'Gli esercizi sbagliati tornano qui dopo 1, 3 e 7 giorni.') + '</p></button>';
    // 11 punti deboli (futuro)
    h += '<div class="st-card st-sez st-off" aria-disabled="true" data-arr="I tuoi punti deboli" data-sez="deboli"><span class="st-sh">' + tile('v2-precisione') + '<span><b>I tuoi punti deboli</b><span class="st-tag">FUTURO</span></span></span>' +
      '<p class="st-d">Allenamento dall\'analisi profonda · Solo consigli affidabili</p></div>';
    root.innerHTML = h + C.bar(1);
  }
  root.addEventListener('click', function(ev){
    var t = ev.target.closest('[data-arr]'); if (t){ C.toast(t.dataset.arr + ': in arrivo.'); return; }
    var r = ev.target.closest('[data-az=ripasso]');
    if (r){
      if (!A || !C.P){ C.toast('Anteprima: il ripasso si apre nell\'app.'); return; }
      if (ripT()) C.P.go('ripasso'); else if (ripP()) C.P.go('pzrip'); else C.toast('Niente da ripassare oggi.');
    }
  });
  window.addEventListener('pageshow', function(ev){ if (ev.persisted) disegna(); });
  disegna();
  window.__studia = {disegna:disegna};
})();
