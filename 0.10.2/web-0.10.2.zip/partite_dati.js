/* Grande aggiornamento, blocco 3 (11-11): dati comuni delle partite con i bot (pagina Gioca 20f, Le tue partite 28, partita col bot).
   Archivio: 'chessnodeplay-partite-bot-v1' (scritto da bot.js, max 500). Voce:
     {id:'p-<ms>', ts, bot, colore:'w'|'b', colorePref:'w'|'b'|'r', orologio, esito:'v'|'p'|'s', motivo, data:'YYYY-MM-DD', semimosse,
      precisione:0-100|null, sans:[...], fen:FEN iniziale (solo con handicap), handicap:null|'p'|'n'|'b'|'r'|'q', allenamento:bool, salvata:bool}
   Le voci vecchie (prima del blocco 3) non hanno id/ts/sans: ricevono un id stabile alla prima lettura, il resto resta com'era.
   Partita in corso (sospesa): 'chessnodeplay-bot-incorso-v1' = {id, bot, me, colorePref, orologio, fen0, sans, clock, handicap, allenamento, avvisato, ts, inizio}.
   «Normali» = senza handicap e non di allenamento: SOLO queste contano per V/P/S, livello stimato e premi. Nessuna rete. */
(function(){
  'use strict';
  var KEY = 'chessnodeplay-partite-bot-v1', KIC = 'chessnodeplay-bot-incorso-v1';
  var BOT = {chessnote:['Chess Node', 900], paola:['Paola', 1150], nerd:['Luca', 1450], serena:['Nadia', 1600], maestro:['Prof', 1900]};
  var ORDINE = ['chessnote', 'paola', 'nerd', 'serena', 'maestro'];
  // blocco 3b (11-11): stile di gioco di ogni bot (scelta di Kiko), solo etichetta qui; la logica è in bot.js (STILI)
  var STILE = {chessnote:'Fantasioso', paola:'Difensivo', nerd:'Aggressivo', serena:'Posizionale', maestro:'Preciso'};
  var TEMPI = [['1', '1'], ['3', '3'], ['3+2', '3+2'], ['5', '5'], ['5+2', '5+2'], ['10', '10'], ['10+5', '10+5'], ['30', '30'], ['no', 'Senza tempo']];
  // handicap: pezzo e casa del lato del bot [nome, articolo «senza», casa col Nero, casa col Bianco]
  var HAND = {p:['Pedone', 'pedone', 'f7', 'f2'], n:['Cavallo', 'cavallo', 'b8', 'b1'], b:['Alfiere', 'alfiere', 'c8', 'c1'], r:['Torre', 'torre', 'a8', 'a1'], q:['Donna', 'donna', 'd8', 'd1']};
  function rd(k){ try { return JSON.parse(localStorage.getItem(k)); } catch(e){ return null; } }
  function wr(k, v){ try { localStorage.setItem(k, JSON.stringify(v)); return true; } catch(e){ return false; } }
  function p2(x){ return ('0' + x).slice(-2); }
  function giorno(d){ return d.getFullYear() + '-' + p2(d.getMonth() + 1) + '-' + p2(d.getDate()); }
  function tutte(){
    var a = rd(KEY); if (!Array.isArray(a)) return [];
    var cambiato = false;
    a.forEach(function(r, i){ if (r && r.bot && !r.id){ r.id = 'v-' + (r.data || 'x') + '-' + i; cambiato = true; } });
    if (cambiato) wr(KEY, a);
    return a.filter(function(r){ return r && r.bot && /^[vps]$/.test(r.esito); });
  }
  function normale(r){ return !r.handicap && !r.allenamento; }
  function normali(){ return tutte().filter(normale); }
  function speciali(){ return tutte().filter(function(r){ return !normale(r); }); }
  function trova(id){ return tutte().filter(function(r){ return r.id === id; })[0] || null; }
  function aggiorna(id, fn){
    var a = rd(KEY); if (!Array.isArray(a)) return null;
    var r = a.filter(function(x){ return x && x.id === id; })[0]; if (!r) return null;
    fn(r); wr(KEY, a); return r;
  }
  function salva(id, on){ return aggiorna(id, function(r){ r.salvata = !!on; if (!on) delete r.salvata; }); }
  function vps(bot){ var o = {v:0, p:0, s:0}; normali().forEach(function(r){ if (!bot || r.bot === bot) o[r.esito]++; }); return o; }
  function incorso(){ var g = rd(KIC); return g && g.bot && BOT[g.bot] && Array.isArray(g.sans) ? g : null; }
  function quando(r){   // «oggi 15:40», «ieri», «5 nov»
    var oggi = giorno(new Date()), ieri = giorno(new Date(Date.now() - 864e5));
    var d = r.ts ? new Date(r.ts) : null, g = d ? giorno(d) : (r.data || '');
    if (g === oggi) return d ? 'oggi ' + p2(d.getHours()) + ':' + p2(d.getMinutes()) : 'oggi';
    if (g === ieri) return 'ieri';
    var M = ['gen', 'feb', 'mar', 'apr', 'mag', 'giu', 'lug', 'ago', 'set', 'ott', 'nov', 'dic'], q = g.split('-');
    if (q.length < 3) return '';
    return (+q[2]) + ' ' + M[+q[1] - 1] + (q[0] !== String(new Date().getFullYear()) ? ' ' + q[0] : '');
  }
  function esito(r){ return r.esito === 'v' ? 'Vittoria' : r.esito === 's' ? 'Sconfitta' : 'Patta'; }
  function risultato(r){ if (r.res) return r.res.replace('1/2-1/2', '½-½'); var w = r.colore === 'w'; return r.esito === 'p' ? '½-½' : ((r.esito === 'v') === w ? '1-0' : '0-1'); }
  function casaHand(h, me){ var x = HAND[h]; return x ? (me === 'b' ? x[3] : x[2]) : ''; }   // il bot ha il colore opposto
  function etichettaHand(h, me){ var x = HAND[h]; return x ? 'Senza ' + x[1] + ' ' + casaHand(h, me) : ''; }
  function tempo(o){ var t = TEMPI.filter(function(x){ return x[0] === o; })[0]; return t ? (o === 'no' ? 'Senza tempo' : t[1] + ' min').replace('+', '+').replace(/^(\d+\+\d+) min$/, '$1') : (o || ''); }
  window.CNPartite = {KEY:KEY, KIC:KIC, BOT:BOT, STILE:STILE, ORDINE:ORDINE, TEMPI:TEMPI, HAND:HAND, tutte:tutte, normali:normali, speciali:speciali, normale:normale,
    trova:trova, salva:salva, aggiorna:aggiorna, vps:vps, incorso:incorso, quando:quando, esito:esito, risultato:risultato, casaHand:casaHand,
    etichettaHand:etichettaHand, tempo:tempo, giorno:giorno};
})();
