/* Chess Node · PRECISIONE di una partita (anteprima 18b, 31/10/2026). Codice e formula NOSTRI.
   Copia di anteprime/blocco10_home/web_preview/precisione.js + (anteprima 20) accMossa/media/VERSIONE esposti: stesso calcolo, nessun cambio di risultato.
   Quando va nell'app: UN solo file precisione.js condiviso da bot e analisi.
   Idea (descritta pubblicamente da più siti): misurare quanta «probabilità di vincere» perde ogni tua mossa rispetto alla migliore.
   1) Stockfish (Worker separato, profondità 10, max 400 ms a posizione) valuta ogni posizione della partita, dal punto di vista del Bianco.
      Il matto vale ±1000 cp; le valutazioni sono limitate a ±1000.
   2) Probabilità di vittoria (curva logistica tipo Elo, scelta nostra): P(cp) = 100 / (1 + 10^(-cp/400))  → 0 cp = 50%, +400 cp ≈ 91%.
   3) Perdita di una mossa = P(prima) − P(dopo) visto da chi muove, minimo 0 (una mossa non può «guadagnare» rispetto alla migliore).
   4) Precisione della mossa = 100 · e^(−0,035 · perdita)   → perdita 2 punti ≈ 93%, 10 ≈ 70%, 20 ≈ 50%, 40 ≈ 25%.
   5) Precisione della partita = media tra media aritmetica e media armonica delle mosse (la media armonica pesa di più gli errori gravi).
   Servono almeno 5 mosse tue; altrimenti la precisione resta vuota (null).
   API: window.CNPrecisione.calcola(startFen, sansArray, colore 'w'|'b', onProgress(0..1)) → Promise<{precisione, mosse:[...]}|null>
        window.CNPrecisione.formula(listaCpBianco, colore) → solo la parte matematica (per test). */
(function(){
  'use strict';
  var DEPTH = 10, MS = 400, CLIP = 1000, K = 0.035, MIN_MOSSE = 5;
  function P(cp){ cp = Math.max(-CLIP, Math.min(CLIP, cp)); return 100 / (1 + Math.pow(10, -cp / 400)); }
  function formula(cpW, colore){   // cpW[i] = valutazione (Bianco) della posizione prima della semimossa i; cpW.length = semimosse + 1
    var acc = [];
    for (var i = 0; i + 1 < cpW.length; i++){
      var muove = i % 2 === 0 ? 'w' : 'b';
      if (muove !== colore || cpW[i] == null || cpW[i + 1] == null) continue;
      var s = colore === 'w' ? 1 : -1, perdita = Math.max(0, P(s * cpW[i]) - P(s * cpW[i + 1]));
      acc.push(100 * Math.exp(-K * perdita));
    }
    if (acc.length < MIN_MOSSE) return null;
    var ar = acc.reduce(function(a, b){ return a + b; }, 0) / acc.length;
    var ha = acc.length / acc.reduce(function(a, b){ return a + 1 / Math.max(b, 1); }, 0);
    return {precisione:Math.round((ar + ha) / 2), mosse:acc.map(Math.round)};
  }
  function calcola(startFen, sans, colore, onProgress){
    if (typeof Chess === 'undefined' || typeof Worker === 'undefined') return Promise.resolve(null);
    var g = new Chess(startFen || undefined), fens = [g.fen()], fine = [null];
    try { for (var i = 0; i < sans.length; i++){ g.move(sans[i]); fens.push(g.fen()); fine.push(g.isCheckmate() ? 'matto' : (g.isGameOver() ? 'patta' : null)); } } catch(e){ return Promise.resolve(null); }
    var w, cpW = [], idx = 0, cur = null;
    return new Promise(function(res){
      var chiudi = function(r){ try { w.terminate(); } catch(e){} res(r); };
      try { w = new Worker('engine/stockfish-lite.js'); } catch(e){ res(null); return; }
      var guard = setTimeout(function(){ chiudi(null); }, 20000 + fens.length * (MS + 600));
      w.onerror = function(){ clearTimeout(guard); chiudi(null); };
      function prossima(){
        while (idx < fens.length && fine[idx]){   // posizioni finali: niente motore
          var nero = fens[idx].split(' ')[1] === 'b';
          cpW.push(fine[idx] === 'matto' ? (nero ? CLIP : -CLIP) : 0); idx++;
        }
        if (onProgress) onProgress(idx / fens.length);
        if (idx >= fens.length){ clearTimeout(guard); chiudi(formula(cpW, colore)); return; }
        cur = null; w.postMessage('position fen ' + fens[idx]); w.postMessage('go depth ' + DEPTH + ' movetime ' + MS);
      }
      w.onmessage = function(ev){
        var line = String(ev.data);
        if (line === 'uciok'){ w.postMessage('setoption name Hash value 16'); w.postMessage('setoption name UCI_LimitStrength value false'); w.postMessage('setoption name Skill Level value 20'); w.postMessage('isready'); }
        else if (line === 'readyok'){ prossima(); }
        else if (line.indexOf('info ') === 0){ var m = line.match(/ score (cp|mate) (-?\d+)/); if (m) cur = m[1] === 'mate' ? (+m[2] > 0 ? CLIP : -CLIP) : +m[2]; }
        else if (line.indexOf('bestmove') === 0){
          var v = cur == null ? null : cur, nero = fens[idx].split(' ')[1] === 'b';
          cpW.push(v == null ? null : (nero ? -v : v)); idx++;
          setTimeout(prossima, 0);
        }
      };
      w.postMessage('uci');
    });
  }
  // Anteprima 20 (31/10): stessi conti esposti a pezzi per «Analizza tutta la partita» (analisi_partita.js), così le due funzioni
  // usano la STESSA formula. VERSIONE va nella chiave dei salvataggi: se la formula cambia, le analisi vecchie si rifanno.
  function accMossa(perdita){ return 100 * Math.exp(-K * Math.max(0, perdita)); }
  function media(acc){
    if (!acc || acc.length < MIN_MOSSE) return null;
    var ar = acc.reduce(function(a, b){ return a + b; }, 0) / acc.length;
    var ha = acc.length / acc.reduce(function(a, b){ return a + 1 / Math.max(b, 1); }, 0);
    return Math.round((ar + ha) / 2);
  }
  window.CNPrecisione = {calcola:calcola, formula:formula, P:P, accMossa:accMossa, media:media, CLIP:CLIP, K:K, MIN_MOSSE:MIN_MOSSE, VERSIONE:'cnp-2'};   // cnp-2 (01/11, anteprima 20b): nell'analisi della partita le mosse di Teoria non contano nella precisione; formula e costante 0,035 invariate
})();
