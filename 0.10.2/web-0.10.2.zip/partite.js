/* Grande aggiornamento, blocco 3 (11-11): «Le tue partite», schema 28 (anteprime/blocco28_partite) con le correzioni approvate (LISTA 08-11 01:40):
   icona a sinistra = SOLO provenienza (bot / importata); la percentuale = partita analizzata (precisione), altrimenti pillola «Analizza»;
   data a destra sotto l'esito; pallino bianco con bordo più scuro sul tema chiaro; lente in stile v2; pressione lunga = menu con «Salva» (blocco 3b), segnalibro piccolo.
   Filtri Tutte / Contro bot / Importate (In arrivo: l'archivio delle importate arriva col blocco 5) / Analizzate. Gruppi Oggi, Questa settimana, mese.
   Tocco su una riga: Analizza (mosse salvate dal blocco 3; le partite più vecchie non hanno le mosse). Aperta da «Vedi tutte» (Gioca). */
(function(){
  'use strict';
  var C = window.CNP, ic = C.ic, esc = C.esc, D = window.CNPartite, P = C.P;
  var vista = {f:'tutte', q:'', cerca:false};
  var root = document.getElementById('pg');
  var MESI = ['gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre'];
  function giornoDi(r){ return r.ts ? D.giorno(new Date(r.ts)) : (r.data || ''); }
  function gruppo(r){
    var g = giornoDi(r), oggi = D.giorno(new Date());
    if (g === oggi) return 'Oggi';
    var t = new Date(g + 'T12:00:00').getTime();
    if (Date.now() - t < 7 * 864e5) return 'Questa settimana';
    var q = g.split('-'); return MESI[+q[1] - 1] + (q[0] !== String(new Date().getFullYear()) ? ' ' + q[0] : '');
  }
  function apertura(r){
    if (r.apertura) { var a = String(r.apertura).replace(/^(la |il |l'|lo )/i, ''); return a.charAt(0).toUpperCase() + a.slice(1); }
    return Math.ceil((r.semimosse || 0) / 2) + ' mosse';
  }
  function riga(r){
    var b = D.BOT[r.bot] || ['Bot', ''];
    var tag = r.allenamento ? '<span class="pt-tag">Allenamento</span>' : r.handicap ? '<span class="pt-tag">' + esc(D.etichettaHand(r.handicap, r.colore)) + '</span>' : '';
    var destra = typeof r.precisione === 'number' ? '<span class="pt-pc">' + String(r.precisione).replace('.', ',') + '%</span>' : '<span class="pt-an">Analizza</span>';
    return '<button class="card pt-row" data-id="' + esc(r.id) + '" aria-label="Partita con ' + esc(b[0]) + ', ' + D.esito(r) + ', ' + esc(D.quando(r)) + '">' +
      '<span class="pt-ti" title="Contro un bot">' + ic('v2-bot', 22) + '</span>' +
      '<img class="pt-av" alt="" src="istruttori/tondi/' + esc(r.bot) + '.webp">' +
      '<span class="pt-t"><b>' + esc(b[0]) + '<span class="pt-elo">' + b[1] + '</span>' + (r.salvata ? '<span class="pt-bm" aria-label="Salvata">' + ic('bookmark', 14) + '</span>' : '') + '</b>' +
        '<small><i class="pt-dot ' + (r.colore === 'b' ? 'b' : 'w') + '" aria-label="' + (r.colore === 'b' ? 'Nero' : 'Bianco') + '"></i><span>' + esc(apertura(r)) + ' · ' + esc(D.tempo(r.orologio)) + '</span></small>' + (tag ? '<small>' + tag + '</small>' : '') + '</span>' +
      '<span class="pt-r"><span class="pt-es ' + r.esito + '">' + D.esito(r) + '</span>' + destra + '<span class="pt-dt">' + esc(D.quando(r)) + '</span></span></button>';
  }
  function elenco(){
    var a = D.tutte().slice().reverse();
    if (vista.f === 'bot') a = a.filter(function(r){ return r.bot; });
    if (vista.f === 'analizzate') a = a.filter(function(r){ return typeof r.precisione === 'number'; });
    var q = vista.q.trim().toLowerCase();
    if (q) a = a.filter(function(r){ var b = D.BOT[r.bot] || ['']; return (b[0] + ' ' + D.esito(r) + ' ' + apertura(r) + ' ' + D.quando(r) + (r.allenamento ? ' allenamento' : '') + (r.salvata ? ' salvata' : '')).toLowerCase().indexOf(q) >= 0; });
    return a;
  }
  function disegna(){
    var a = elenco(), h = '<header class="pg-hd pt-hd"><button class="pg-back" data-back aria-label="Indietro">' + ic('chevron-left', 24) + '</button><h1>Le tue partite</h1>' +
      '<button class="pt-cerca" data-cerca aria-label="Cerca" aria-expanded="' + vista.cerca + '">' + ic('search', 22) + '</button></header>';
    h += '<div class="pt-qbox"' + (vista.cerca ? '' : ' hidden') + '><label class="sv-cerca">' + ic('search', 20) + '<input id="ptQ" type="search" placeholder="Cerca per avversario, esito, apertura…" value="' + esc(vista.q) + '" autocomplete="off"></label></div>';
    h += '<div class="pt-chips" role="tablist">' + [['tutte', 'Tutte'], ['bot', 'Contro bot'], ['imp', 'Importate'], ['analizzate', 'Analizzate']].map(function(c){
      if (c[0] === 'imp') return '<button class="pt-chip off" data-imp aria-disabled="true" title="In arrivo">Importate</button>';
      return '<button class="pt-chip' + (vista.f === c[0] ? ' on' : '') + '" role="tab" aria-selected="' + (vista.f === c[0]) + '" data-f="' + c[0] + '">' + c[1] + '</button>'; }).join('') + '</div>';
    if (!a.length){
      h += '<div class="card pt-vuoto"><p class="tx">' + (vista.q || vista.f !== 'tutte' ? 'Nessuna partita trovata.' : 'Nessuna partita ancora. Gioca contro un bot dalla pagina Gioca.') + '</p></div>';
    } else {
      var g0 = null;
      a.forEach(function(r){ var g = gruppo(r); if (g !== g0){ h += '<h3 class="pt-g">' + esc(g) + '</h3>'; g0 = g; } h += riga(r); });
      h += '<p class="nota">Tieni premuta una partita per aprire il menu e salvarla (o toglierla dai salvati).</p>';
    }
    root.innerHTML = h + C.bar(2);
    var inp = document.getElementById('ptQ');
    if (inp){ inp.addEventListener('input', function(){ vista.q = inp.value; var pos = inp.selectionStart; disegna(); var i2 = document.getElementById('ptQ'); if (i2){ i2.focus(); try { i2.setSelectionRange(pos, pos); } catch(e){} } }); }
  }
  /* pressione lunga (blocco 3b, 11-11, Kiko): ~500 ms col dito fermo apre un MENU piccolo (non salva niente da sola).
     Si salva SOLO toccando «Salva»; un tocco fuori (o Indietro) chiude senza fare nulla; muovere il dito o scorrere annulla la pressione.
     Dopo il salvataggio: toast «Partita salvata · Annulla» per 4 s (Annulla toglie il salvataggio). Vibrazione leggera all'apertura del menu
     (interruttore 'chessnodeplay-vibra-v1'). Le partite salvate restano marcate nell'archivio (salvata:true); la categoria «Partite»
     della pagina Salvati arriva col blocco 4. */
  var lp = null, lpFatto = 0, menu = null;   // lpFatto: ora della pressione lunga, il click che la segue non apre l'analisi
  var LP_MS = 500, LP_MOV = 10;
  function vibra(){
    var V = null; try { V = window.parent && window.parent.__cnVibra; } catch(e){ V = null; }
    if (V && V.buzz){ V.buzz('tic'); return; }
    window.__vibra = window.__vibra || []; window.__vibra.push('tic');
    try { if (localStorage.getItem('chessnodeplay-vibra-v1') !== '0' && navigator.vibrate) navigator.vibrate(12); } catch(e){}
  }
  function salva(id, on){
    var r = D.trova(id); if (!r) return;
    if (on == null) on = !r.salvata;
    D.salva(id, on); disegna();
    C.toast(on ? 'Partita salvata' : 'Tolta dai salvati', function(){ D.salva(id, !on); disegna(); }, 4000);
  }
  function chiudiMenu(){ if (!menu) return false; menu.remove(); menu = null; return true; }
  function apriMenu(id){
    var r = D.trova(id); if (!r) return;
    chiudiMenu();
    var b = D.BOT[r.bot] || ['Bot'];
    var o = document.createElement('div'); o.className = 'cn-ov pt-ov';
    o.innerHTML = '<div class="cn-sheet pt-menu" role="menu" aria-label="Partita con ' + esc(b[0]) + '">' +
      '<p class="pt-mt"><b>Partita con ' + esc(b[0]) + '</b><small>' + D.esito(r) + ' · ' + esc(D.quando(r)) + '</small></p>' +
      '<button class="pt-mi" role="menuitem" data-m="salva">' + ic('bookmark', 20) + (r.salvata ? 'Togli dai salvati' : 'Salva') + '</button>' +
      '<button class="pt-mi sec" role="menuitem" data-m="chiudi">' + ic('chevron-left', 20) + 'Chiudi</button></div>';
    // il dito che ha aperto il menu, quando si alza, non deve né chiuderlo né toccare «Salva»: serve un tocco nuovo
    var armato = false; o.addEventListener('pointerdown', function(){ armato = true; });
    o.addEventListener('click', function(ev){
      if (!armato && ev.detail !== 0) return;
      if (ev.target === o){ chiudiMenu(); return; }
      var m = ev.target.closest('[data-m]'); if (!m) return;
      chiudiMenu();
      if (m.dataset.m === 'salva') salva(id, !r.salvata);
    });
    document.body.appendChild(o); menu = o;
    vibra();
  }
  root.addEventListener('pointerdown', function(ev){
    var r = ev.target.closest('.pt-row'); if (!r) return;
    if (ev.button > 0) return;
    lpFatto = 0; var x = ev.clientX, y = ev.clientY;
    if (lp) clearTimeout(lp.t);
    lp = {id:r.dataset.id, x:x, y:y, t:setTimeout(function(){ lpFatto = Date.now(); lp = null; apriMenu(r.dataset.id); }, LP_MS)};
  });
  function annullaLp(ev){ if (!lp) return; if (ev && ev.type === 'pointermove' && Math.abs(ev.clientX - lp.x) < LP_MOV && Math.abs(ev.clientY - lp.y) < LP_MOV) return; clearTimeout(lp.t); lp = null; }
  root.addEventListener('pointermove', annullaLp); root.addEventListener('pointerup', annullaLp); root.addEventListener('pointercancel', annullaLp);
  window.addEventListener('scroll', function(){ annullaLp(); }, {passive:true});   // scorrere l'elenco non apre mai il menu
  root.addEventListener('contextmenu', function(ev){ if (ev.target.closest('.pt-row')) ev.preventDefault(); });
  root.addEventListener('click', function(ev){
    var t = ev.target.closest('button'); if (!t || t.disabled) return;
    if (t.classList.contains('pt-row')){
      if (lpFatto && Date.now() - lpFatto < 1200){ lpFatto = 0; return; } lpFatto = 0;
      var r = D.trova(t.dataset.id); if (!r) return;
      if (!r.sans || !r.sans.length){ C.toast('Partita di prima dell\'aggiornamento: le mosse non sono state salvate.'); return; }
      if (P && P.go) P.go('botanalizza', r.id); else C.toast('L\'analisi si apre dentro l\'app.');
      return;
    }
    if (t.dataset.f){ vista.f = t.dataset.f; disegna(); return; }
    if (t.hasAttribute('data-imp')){ C.toast('Partite importate: in arrivo.'); return; }
    if (t.hasAttribute('data-cerca')){ vista.cerca = !vista.cerca; if (!vista.cerca) vista.q = ''; disegna(); if (vista.cerca){ var i = document.getElementById('ptQ'); if (i) i.focus(); } return; }
  });
  C.onBack = function(){ if (chiudiMenu()) return true; if (vista.cerca){ vista.cerca = false; vista.q = ''; disegna(); return true; } return false; };
  C.canBack = function(){ return !!menu || vista.cerca; };
  disegna();
  window.__partite = {salva:salva, vista:vista, disegna:disegna, apriMenu:apriMenu, chiudiMenu:chiudiMenu, menuAperto:function(){ return !!menu; }, LP_MS:LP_MS};
})();
