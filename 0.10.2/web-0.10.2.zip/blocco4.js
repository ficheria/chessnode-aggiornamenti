/* Grande aggiornamento · blocco 4 (11-11): collegamenti dell'app per Studia.
   - CNB4.apriTattica(arg): «cont» (Continua: ultimo esercizio non risolto o il successivo), «cap:<id>» (prossimo da fare del capitolo),
     «caso» (un esercizio a caso fra quelli non risolti), un numero (quell'esercizio).
   - CNB4.continua(sez): cosa riprende «Continua da qui» (Studia: l'ultima sezione usata; Tattica; Puzzle Random).
   - CNB4.toastSalva(): dopo il segnalibro dell'esercizio, toast «Esercizio salvato · Annulla» / «Puzzle salvato · Annulla»
     sulla riga delle mosse, mai sopra la scacchiera (stile dei toast del blocco 3).
   - ultima sezione usata in chessnodeplay-studia-v1 {ult:'tattica'|'pz', t}. */
(function(){
  'use strict';
  var A = window.__app; if (!A) return;
  var SKEY = 'chessnodeplay-studia-v1';
  function $(id){ return document.getElementById(id); }
  function rd(){ try { return JSON.parse(localStorage.getItem(SKEY) || 'null') || {}; } catch(e){ return {}; } }
  function wr(o){ try { localStorage.setItem(SKEY, JSON.stringify(o)); } catch(e){} }
  function EX(){ var out = []; (window.BOOK && BOOK.chapters || []).forEach(function(c){ c.list.forEach(function(e){ out.push(e); }); }); return out; }
  function prog(){ try { return A.progress ? A.progress() : JSON.parse(localStorage.getItem('chessnodeplay-progress-v1') || '{}'); } catch(e){ return {}; } }
  function fatto(p, n){ return p[n] === 's' || p[n] === 'e'; }
  function capDi(n){ var e = A.byN && A.byN[n]; return e ? e.c : ''; }
  function nomeCap(c){ var ch = A.chById && A.chById[c]; return ch ? ch.name : ''; }
  function prefsN(){ try { return (JSON.parse(localStorage.getItem('chessnodeplay-prefs-v1') || '{}') || {}).n || 0; } catch(e){ return 0; } }
  // esercizio da cui riprendere la Tattica
  function tatticaCont(){
    var p = prog(), L = EX(), n = prefsN();
    if (n && A.byN[n] && !fatto(p, n)) return n;
    var i = 0; if (n) for (var j = 0; j < L.length; j++) if (L[j].n === n){ i = j + 1; break; }
    for (var k = 0; k < L.length; k++){ var e = L[(i + k) % L.length]; if (!fatto(p, e.n)) return e.n; }
    return n || (L[0] && L[0].n) || 1;
  }
  function capNext(c){
    var ch = A.chById[c]; if (!ch) return 0; var p = prog();
    for (var i = 0; i < ch.list.length; i++) if (!fatto(p, ch.list[i].n)) return ch.list[i].n;
    return ch.list.length ? ch.list[0].n : 0;
  }
  function caso(){ var p = prog(), L = EX().filter(function(e){ return !fatto(p, e.n); }); if (!L.length) L = EX(); return L.length ? L[Math.floor(Math.random() * L.length)].n : 0; }
  function apriTattica(arg){
    var n = 0; arg = arg == null ? 'cont' : String(arg);
    if (arg === 'cont') n = tatticaCont();
    else if (/^cap:/.test(arg)) n = capNext(arg.slice(4));
    else if (arg === 'caso') n = caso();
    else n = +arg;
    if (n && A.byN[n]) A.loadEx(n);
    return n;
  }
  function continua(sez){
    var s = rd(), u = sez || s.ult || 'tattica';
    if (u === 'pz' && window.CNPuzzle) return {sez:'pz', go:'pz', arg:'', titolo:'Puzzle Random', sotto:'Puzzle rating ' + CNPuzzle.rating() + (CNPuzzle.provvisorio() ? ' (provvisorio)' : '')};
    var n = tatticaCont();
    return {sez:'tattica', go:'tattica', arg:'cont', n:n, titolo:'Esercizio ' + n, sotto:'Esercizio ' + n + ' · ' + nomeCap(capDi(n))};
  }
  document.addEventListener('cnp:load', function(ev){
    var d = ev.detail || {}, s = rd();
    var m = window.CNPuzzle && CNPuzzle.modo ? CNPuzzle.modo() : '';
    if (d.c === 'pz'){ if (m !== 'giorno'){ s.ult = 'pz'; s.t = Date.now(); wr(s); } }
    else if (d.n){ s.ult = 'tattica'; s.t = Date.now(); wr(s); }
  });

  // ---------- toast del segnalibro (riga delle mosse; mai sopra la scacchiera) ----------
  var tT = 0, muto = false;
  function posto(t){
    var mv = $('v6Mv'), b = mv && mv.getBoundingClientRect(), W = window.innerWidth;
    var bd = document.getElementById('board'), bb = bd && bd.getBoundingClientRect();
    if (b && b.height > 0){
      t.style.left = Math.max(8, b.left) + 'px'; t.style.width = Math.min(W - 16, b.width) + 'px';
      t.style.top = Math.max(b.top, bb ? bb.bottom + 4 : 0) + 'px'; t.style.height = Math.max(46, b.height) + 'px'; t.style.bottom = 'auto';
    } else {
      var bot = $('v6Bot'), r = bot && bot.getBoundingClientRect();
      t.style.left = '12px'; t.style.right = '12px'; t.style.width = 'auto'; t.style.height = '48px';
      t.style.top = 'auto'; t.style.bottom = (r && r.height ? window.innerHeight - r.top + 8 : 24) + 'px';
    }
  }
  function toast(msg, annulla, ms){
    var old = $('cnB4Toast'); if (old) old.remove(); clearTimeout(tT);
    var t = document.createElement('div'); t.id = 'cnB4Toast'; t.setAttribute('role', 'status');
    t.innerHTML = '<span></span>' + (annulla ? '<button type="button">Annulla</button>' : '');
    t.firstChild.textContent = msg;
    if (annulla) t.querySelector('button').onclick = function(ev){ ev.stopPropagation(); t.remove(); clearTimeout(tT); annulla(); };
    document.body.appendChild(t); posto(t);
    tT = setTimeout(function(){ t.remove(); }, ms || (annulla ? 4000 : 2400));
    return t;
  }
  function toastSalva(){
    if (muto) return;
    var e = A.state && A.state.ex; if (!e) return;
    var on = !!($('favBtn') && $('favBtn').classList.contains('on'));
    var cosa = e.c === 'pz' ? 'Puzzle' : 'Esercizio';
    toast(on ? cosa + ' salvato' : 'Tolto dai salvati', function(){ muto = true; try { $('v6Fav').click(); } finally { muto = false; } }, 4000);
  }
  // le icone v2 arrivano dopo app.js: ridisegno i Capitoli una volta caricate
  setTimeout(function(){ try { document.dispatchEvent(new CustomEvent('cnp:revchange')); } catch(e){} }, 0);
  window.CNB4 = {apriTattica:apriTattica, continua:continua, tatticaCont:tatticaCont, capNext:capNext, toast:toast, toastSalva:toastSalva};
})();
