/* Alternative alle difese: non usate in Chess Node (step 1) */
window.DIFESA={};
