/* Blocco 4 (11-11) · 4.6 Notifiche locali (LISTA 1035-1036, testi approvati anteprime/blocco31_notifiche).
   Solo sul telefono, con @capacitor/local-notifications (MIT): nessun server. Nel browser non fa nulla e non dà errori.
   Regole:
   - al massimo UNA al giorno, mai tra le 21:30 e le 9:00 (ore scegli­bili 9-21, base 18:00);
   - Problema del giorno all'ora scelta, NON se oggi è già fatto;
   - Serie in pericolo (serie ≥ 3 giorni e oggi non hai ancora giocato) PRENDE IL POSTO del problema del giorno;
   - Profilo aggiornato (analisi profonda, blocco 5): solo se c'è una novità e al massimo una ogni 3 giorni; qui c'è solo l'aggancio
     (CNNotifiche.novitaProfilo()) e l'interruttore;
   - assenza: tutti i giorni per 10 giorni, poi una ogni 3 giorni, dopo un mese una a settimana, senza mai smettere
     (programmate per un anno; si ricalcolano a ogni apertura: riaprire l'app riporta al ritmo quotidiano);
   - il permesso si chiede una volta sola, al primo Esercizio del giorno. Niente «ci manchi», niente pubblicità.
   La parte che decide (piano) è pura e provabile: CNNotifiche.piano(ctx). */
(function(){
  'use strict';
  var A = window.__app;
  var KEY = 'chessnodeplay-notifiche-v1', ID0 = 4000, NMAX = 400, ORIZZ = 365, TRE = 3 * 86400000;
  var T = {
    problema:['Il problema del giorno ti aspetta ♟️', 'Trovi la mossa giusta?'],
    serie:['🔥 Serie di %n giorni', 'Basta un esercizio per non perderla.'],
    profilo:['Profilo aggiornato', 'C’è qualcosa di nuovo nel tuo profilo. Dai un’occhiata.'],
    profiloFatto:['Profilo aggiornato', 'Il profilo non è più provvisorio. Dai un’occhiata.']};
  function rd(){ try { return JSON.parse(localStorage.getItem(KEY) || 'null') || {}; } catch(e){ return {}; } }
  function wr(o){ try { localStorage.setItem(KEY, JSON.stringify(o)); } catch(e){} }
  function dk(t){ var d = new Date(t); return d.getFullYear() + '-' + ('0' + (d.getMonth() + 1)).slice(-2) + '-' + ('0' + d.getDate()).slice(-2); }
  function oraOk(h){ h = +h; return isNaN(h) ? 18 : Math.max(9, Math.min(21, Math.round(h))); }
  // giorni dopo l'ultima apertura in cui si può mandare: 0-10 tutti, poi ogni 3 fino a 30, poi ogni 7 (per sempre)
  function giornoAmmesso(d){ return d <= 10 || (d <= 30 ? (d - 10) % 3 === 0 : (d - 30) % 7 === 0); }
  function quietOk(dt){ var m = dt.getHours() * 60 + dt.getMinutes(); return m >= 540 && m < 1290; }   // 9:00 ≤ ora < 21:30

  /* piano(ctx): elenco [{id, at, tipo, title, body, giorno}] — al massimo una per giorno.
     ctx = {now, pref:{problema, serie, profilo, ora}, fattoOggi, giocatoOggi, serie, matto, profilo:{novita, ultima}} */
  function piano(c){
    var now = c.now || Date.now(), p = c.pref || {}, ora = oraOk(p.ora), out = [], base = new Date(now);
    var profDa = (p.profilo !== false && c.profilo && c.profilo.novita) ? Math.max(now, (c.profilo.ultima || 0) + TRE) : Infinity;
    for (var d = 0; d <= ORIZZ; d++){
      if (!giornoAmmesso(d)) continue;
      var at = new Date(base.getFullYear(), base.getMonth(), base.getDate() + d, ora, 0, 0, 0);
      if (at.getTime() <= now + 60000 || !quietOk(at)) continue;
      var n = null;
      // serie in pericolo: oggi se non hai giocato; domani se oggi hai giocato (la serie continua fino a domani sera)
      var sg = d === 0 ? (!c.giocatoOggi && c.serie >= 3) : d === 1 ? (c.giocatoOggi && c.serie >= 3) : false;
      if (p.serie !== false && sg) n = {tipo:'serie', title:T.serie[0].replace('%n', c.serie), body:T.serie[1]};
      else if (profDa <= at.getTime()){ var tf = (c.profilo.tipo === 'completo') ? T.profiloFatto : T.profilo; n = {tipo:'profilo', title:tf[0], body:tf[1]}; profDa = Infinity; }
      else if (p.problema !== false && !(d === 0 && c.fattoOggi))
        n = {tipo:'problema', title:T.problema[0], body:d === 0 && c.matto ? 'Matto in ' + c.matto + ': trovi la mossa?' : T.problema[1]};
      if (!n) continue;
      n.id = ID0 + d; n.at = at.getTime(); n.giorno = dk(at.getTime());
      out.push(n);
    }
    return out;
  }

  // ---------- contesto dall'app ----------
  function pref(){ var n = (A && A.prefs && A.prefs.notifiche) || {}; return {problema:n.problema !== false, serie:n.serie !== false, profilo:n.profilo !== false, ora:n.ora == null ? 18 : n.ora}; }
  function contesto(now){
    now = now || Date.now();
    var k = dk(now), c = {now:now, pref:pref(), fattoOggi:false, giocatoOggi:false, serie:0, matto:0, profilo:null};
    try { c.fattoOggi = !!(window.CNGiorno && CNGiorno.fatto(k)); } catch(e){}
    try { var d = window.__stats.data(), e = d.diary && d.diary[k]; c.giocatoOggi = ((d.time && d.time.days && d.time.days[k]) || 0) >= 60000 || !!(e && e.t > 0); } catch(e){}
    try { c.serie = window.__progressi.streaks().cur || 0; } catch(e){}
    try { var g = window.CNGiorno && rdG()[k]; if (g && window.CNPuzzle) c.matto = CNPuzzle.matto(g.id); } catch(e){}
    var s = rd();
    // una notifica «Profilo aggiornato» già programmata e ormai passata conta come inviata (anche se l'app era chiusa)
    if (s.prof && s.prof.prog && s.prof.prog <= now){ s.prof = {novita:false, ultima:s.prof.prog}; wr(s); }
    if (s.prof) c.profilo = {novita:!!s.prof.novita, ultima:s.prof.ultima || 0, tipo:s.prof.tipo || 'novita'};
    return c;
  }
  function rdG(){ try { return (JSON.parse(localStorage.getItem('chessnodeplay-giorno-v1') || 'null') || {}).g || {}; } catch(e){ return {}; } }

  // ---------- plugin (solo app Android) ----------
  function plug(){ try { var C = window.Capacitor; if (C && C.isNativePlatform && C.isNativePlatform() && C.Plugins && C.Plugins.LocalNotifications) return C.Plugins.LocalNotifications; } catch(e){} return null; }
  var ultimo = [], tmr = 0;
  function pianifica(){ clearTimeout(tmr); tmr = setTimeout(esegui, 400); }
  function esegui(){
    var L = plug(), lista = piano(contesto());
    ultimo = lista;
    var s = rd(), pf = lista.filter(function(n){ return n.tipo === 'profilo'; })[0];
    if (s.prof){ if (pf) s.prof.prog = pf.at; else delete s.prof.prog; wr(s); }
    if (!L) return Promise.resolve(lista);
    var ids = []; for (var i = 0; i <= NMAX; i++) ids.push({id:ID0 + i});
    return Promise.resolve().then(function(){ return L.checkPermissions ? L.checkPermissions() : {display:'granted'}; }).then(function(pm){
      return Promise.resolve(L.cancel({notifications:ids})).catch(function(){}).then(function(){
        if (!pm || pm.display !== 'granted' || !lista.length) return lista;
        return L.schedule({notifications:lista.map(function(n){ return {id:n.id, title:n.title, body:n.body, schedule:{at:new Date(n.at), allowWhileIdle:true},
          smallIcon:'ic_stat_cn', iconColor:'#2D6A4F', extra:{tipo:n.tipo, giorno:n.giorno}}; })}).then(function(){ return lista; });
      });
    }).catch(function(){ return lista; });
  }
  // permesso: una volta sola, al primo Esercizio del giorno
  function primoGiorno(){
    var s = rd(); if (s.chiesto) return Promise.resolve(false);
    var L = plug(); if (!L || !L.requestPermissions) return Promise.resolve(false);   // browser: niente da chiedere
    s.chiesto = Date.now(); wr(s);
    return Promise.resolve(L.requestPermissions()).catch(function(){}).then(function(){ pianifica(); return true; });
  }
  // aggancio per il blocco 5 (analisi profonda): segnala una novità; la notifica parte al più una volta ogni 3 giorni
  function novitaProfilo(o){ var s = rd(); s.prof = s.prof || {}; s.prof.novita = true; if (o && o.tipo) s.prof.tipo = o.tipo; wr(s); pianifica(); }
  function profiloInviato(){ var s = rd(); s.prof = {novita:false, ultima:Date.now()}; wr(s); }

  // tocco sulla notifica: apre l'Esercizio del giorno (problema, serie) o la Home (profilo)
  function ascolta(){
    var L = plug(); if (!L || !L.addListener) return;
    try {
      L.addListener('localNotificationActionPerformed', function(a){
        var x = (a && a.notification && a.notification.extra) || {};
        if (x.tipo === 'profilo'){ profiloInviato(); if (window.CNHome && CNHome.apri) CNHome.apri('profilo_scacchistico.html'); else if (window.CNHome) CNHome.mostra('home.html'); return; }
        if (window.CNHome && CNHome.go) CNHome.go('giorno'); else if (window.CNGiorno) CNGiorno.apri();
      });
      L.addListener('localNotificationReceived', function(n){ var x = (n && n.extra) || {}; if (x.tipo === 'profilo') profiloInviato(); });
    } catch(e){}
  }
  if (A){
    ascolta();
    setTimeout(pianifica, 1500);
    document.addEventListener('visibilitychange', pianifica);
    document.addEventListener('cnp:solved', pianifica);
    document.addEventListener('cnp:reset', function(){ try { localStorage.removeItem(KEY); } catch(e){} pianifica(); });
  }
  window.CNNotifiche = {piano:piano, contesto:contesto, pianifica:pianifica, esegui:esegui, primoGiorno:primoGiorno, novitaProfilo:novitaProfilo,
    ultimo:function(){ return ultimo.slice(); }, giornoAmmesso:giornoAmmesso, plugin:function(){ return !!plug(); }, stato:function(){ return rd(); }, TESTI:T};
})();
