/* Chess Node · «ANALIZZA TUTTA LA PARTITA» (anteprima 20, 31/10/2026) — pannello della scacchiera di analisi.
   LICENZA / PROVENIENZA: la logica di analisi (valutazione veloce di ogni posizione, verifica più profonda multipv 3
   prima di dare un giudizio, salvataggio con ripresa)
   è il codice di Kiko in strumenti/revisione_partite_claude/cn_profilo.js (analizzaUna / analizza), ADATTATO qui alla pagina
   di analisi. Codice proprietario di Kiko / Chess Node, tutti i diritti riservati. Niente codice, costanti o grafica di Lichess
   o di altri siti: probabilità di vittoria e precisione vengono da precisione.js (CNPrecisione, formula NOSTRA).
   Stockfish (GPLv3) resta un programma separato: gira in un SUO Worker (engine/stockfish-lite.js, invariato), parlato via UCI.
   Cosa fa (versione cnp-2, regole r6, 01/11/2026 — anteprima 20c):
   1) passata veloce: ogni posizione a PROFONDITÀ FISSA (standard 17, approfondito 20; hash vuoto a ogni ricerca → risultati
      riproducibili); il matto vale ±1000 cp, tutto è limitato a ±1000;
   2) perdita di una mossa = P(prima) − P(dopo) dal punto di vista di chi muove (0 se è la mossa del motore);
   3) le mosse con perdita veloce > 3 (VERIFICA_DA) si RIVERIFICANO (multipv 3, profondità 21 / 24) prima di chiamarle
      imprecisione (>5) / errore (>10) / svarione (>20), con margine MARGINE_SOGLIA = 2 (al limite → etichetta più leggera)
      (meglio un commento generico che uno sbagliato);
   4) etichette: Teoria (posizione nell'elenco ECO, solo dall'inizio), Mossa forte (!!), Migliore, Ottima (≤2; «equivalente alla
      migliore» se perdita 0 ma non prima scelta), Buona (≤5), Imprecisione, Errore, Svarione;
      dopo la mossa ≥ 75% (CHIARO, anche ≥ 90%) → al massimo Imprecisione; prima della mossa ≤ 10% (PERSA, proposta) → nessun
      giudizio negativo; Mossa forte = unica mossa che riporta ≥ 40% chi era ≤ 20% prima della mossa avversaria;
      livelli Standard e Approfondito, risultati salvati per livello;
   4b) (r6, DECISO Kiko 01/11 «sono d'accordo su questi 2 punti») MOSSA OBBLIGATA: se nella posizione c'è UNA sola mossa legale
      l'etichetta è «Mossa obbligata» (□, grigio neutro), mai un giudizio negativo, niente verifica, e NON entra nella precisione
      (non c'era scelta: contarla 100% sarebbe un regalo, contarla negativa un errore);
   4c) (r6, DECISO Kiko 01/11) RICONTROLLO in Standard: ogni giudizio negativo (Imprecisione / Errore / Svarione) uscito dalla verifica
      a profondità 21 si rifà con la stessa procedura a profondità 24 (= verifica dell'Approfondito) PRIMA di mostrarlo; vale il
      risultato più profondo (può diventare più leggero, più grave o sparire);
   5) precisione Bianco / Nero = CNPrecisione.media(100·e^(−0,035·perdita)) SENZA le mosse di Teoria, minimo 5 mosse.
   Annulla: manda «stop» al motore e il controllo è fatto a ogni passo (anche in verifica). Si salva a ogni posizione:
   chiudi o ricarica e poi «Riprendi». Chiave: chessnodeplay-analisi-partita-v3 (la -v1 senza «partita» è lo stato della scacchiera). */
(function(){
  'use strict';
  var A = window.__app || {}, CP = window.CNPrecisione;
  var KEY = 'chessnodeplay-analisi-partita-v3', MAXG = 12;   // v2 (01/11): regole r2, livello nella chiave; v3 (01/11 00:24): cnp-2, verifica a profondità fissa
  var KEYLIV = 'chessnodeplay-analisi-livello';             // livello scelto (standard | approfondito)
  // livelli (da cn_profilo; «veloce» escluso: minimo «standard»). ms = passata veloce per posizione; verifica = ms × verif, profondità vdepth, multipv 3.
  // cnp-2 (Kiko 01/11 00:24): ricerche a PROFONDITÀ FISSA (non a tempo) → risultati riproducibili; MAX_MS = solo rete di sicurezza.
  // depth = passata veloce, vdepth = verifica (multipv 3); msPos / msVer = tempi medi misurati in Chrome headless, solo per la stima mostrata.
  // rdepth (r6, DECISO Kiko 01/11): profondità del RICONTROLLO dei giudizi negativi (solo Standard; 24 = stessa verifica dell'Approfondito).
  var LIVELLI = {standard:{depth:17, vdepth:21, rdepth:24, msPos:320, msVer:1300, msRic:3800}, approfondito:{depth:20, vdepth:24, msPos:960, msVer:3800}};   // tarati 01/11: KT 45 s / 139 s
  var MAX_MS = 20000;
  // DECISO Kiko 01/11 00:24 (punto 3): si riverifica ogni mossa con perdita veloce > VERIFICA_DA (prima > 5) per non perdere errori veri.
  var VERIFICA_DA = 3;
  var LIV = (function(){ try { var v = localStorage.getItem(KEYLIV); return LIVELLI[v] ? v : 'standard'; } catch(e){ return 'standard'; } })();
  var SOGLIE = {imp:5, err:10, sva:20}, VINTA = 90;
  // DECISO Kiko 01/11 00:08: se DOPO la mossa chi muove resta chiaramente in vantaggio (≥ CHIARO) il giudizio massimo è Imprecisione.
  // DECISO Kiko 01/11 00:12 (sostituisce «≥ 90% = nessun giudizio»): anche ≥ 90% rallentare la vittoria = Imprecisione al massimo; VINTA (90) resta solo come costante di riferimento, non entra più nei giudizi.
  var CHIARO = 75;            // 75% di probabilità di vittoria ≈ +190 cp
  // PROPOSTO (solo anteprima, da confermare): chi è già perso (≤ PERSA prima della mossa) non riceve giudizi negativi. Per tornare indietro: PROTEZIONE_PERSA = false.
  var PERSA = 10, PROTEZIONE_PERSA = true;
  var PERSA_NEUTRA = true;   // r7b (Kiko 01/11 21:11): chi è già perso senza matto visto non riceve etichette positive. Per tornare a r7: false
  // DECISO Kiko 01/11 00:14: chi è in svantaggio e mantiene il divario = mossa normale (Migliore/Ottima/Buona, nessun giudizio negativo per perdite piccole);
  // «Mossa forte» (prudente): prima della mossa dell'avversario chi muove era ≤ FORTE_PRIMA, la sua mossa è la PRIMA scelta della verifica
  // profonda (multipv 3), dopo la mossa è ≥ FORTE_DOPO, e la seconda scelta vale almeno FORTE_UNICA punti in meno (mossa unica / combinazione).
  // Prudenza in più: la probabilità prima della mossa avversaria si prende dalla sua verifica profonda se c'è, e NON vale
  // la semplice ripresa sulla casa dove l'avversario ha appena mosso (FORTE_NO_RIPRESA: è «unica» ma non è una combinazione).
  var FORTE_PRIMA = 20, FORTE_DOPO = 40, FORTE_UNICA = 10, FORTE_NO_RIPRESA = true;
  // r7 (Kiko 01/11 punto 2): non basta PUNIRE l'errore dell'avversario. Dopo un Errore/Svarione dell'avversario la risposta che cattura o dà scacco
  // (la punizione evidente) NON è Mossa forte (resta Migliore). Per tornare a r6: FORTE_PRUDENTE = false.
  var FORTE_PRUDENTE = true;
  // r7 (Kiko 01/11 punto 1): MATTO CERTO (la verifica profonda vede il matto forzato) → si confrontano le DISTANZE dal matto, non le %.
  // Chi dà matto: mossa più lenta di 1-2 mosse = Buona; di 3 o più (o matto perso) = Imprecisione. Chi subisce: mai etichette positive;
  // la difesa più lunga = nessun giudizio («il matto era già inevitabile»); accorciare di 1-2 mosse = Imprecisione, di 3 o più = Errore.
  // Prudenza: solo con verifica profonda e solo per matti fino a MATTO_MAX mosse (più lunghi: distanze poco sicure → nessun giudizio).
  // Questo vale anche sotto la protezione ≤ 10% (che resta per tutto il resto). Per tornare a r6: MATTO_CERTO = false.
  var MATTO_CERTO = true, MATTO_MAX = 10, MATTO_GRAVE = 3;
  // DECISO Kiko 01/11 00:09: mossa al limite (entro MARGINE_SOGLIA punti SOPRA una soglia) → giudizio più leggero (vale per 2, 5, 10, 20).
  var MARGINE_SOGLIA = 2;
  var REGOLE = 'r7c';   // r7c 01/11 21:15: «nessun giudizio» fuori dalla precisione. Prima: r7b →   // r7b 01/11 21:11: posizione persa senza matto visto → nessun giudizio. Prima: r7 →          // r7 (01/11 20:33, via di Kiko, solo anteprima): matto certo + Mossa forte prudente + risultato progressivo. Prima: r6.          // r6 (01/11, anteprima 20c): mossa obbligata + ricontrollo dei giudizi negativi in Standard. Prima: r5. Cambia le regole → cambia l'hash → le analisi vecchie si rifanno
  var CLS = ['teoria', 'obbligata', 'forte', 'migliore', 'ottima', 'buona', 'imprecisione', 'errore', 'svarione'];
  var SYM = {obbligata:'□', forte:'!!', migliore:'!', ottima:'✓', buona:'✓', imprecisione:'?!', errore:'?', svarione:'??'};
  var BOOK = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 7v14"/><path d="M3 18a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h5a4 4 0 0 1 4 4 4 4 0 0 1 4-4h5a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1h-6a3 3 0 0 0-3 3 3 3 0 0 0-3-3z"/></svg>';

  /* ---------- lingua: italiano; inglese con ?lang=en (o prefs.lang = en) ---------- */
  var EN = (function(){ try { var q = new URLSearchParams(location.search).get('lang'); if (q) return /^en/i.test(q); } catch(e){}
    var p = (A.prefs && A.prefs.lang) || ''; return /^en/i.test(p); })();
  var TX = {
    it:{tit:'Analisi della partita', btn:'Analizza tutta la partita', riprendi:'Riprendi l\'analisi', ric:'Ricomincia', annulla:'Annulla',
        hint:'Il motore valuta ogni mossa sul telefono: circa %s. Puoi annullare quando vuoi e riprendere dopo.',
        vuota:'Gioca o carica una partita (almeno 2 mosse) per analizzarla tutta.', fase1:'Valuto le posizioni: %a di %b', fase2:'Riverifico le mosse dubbie: %a di %b', fase3:'Ricontrollo più a fondo i giudizi negativi: %a di %b',
        stop:'Analisi interrotta: riprendi quando vuoi, il lavoro fatto è salvato.', noeng:'Il motore non è disponibile su questo dispositivo.',
        pausa:'Motore in pausa: sto analizzando tutta la partita.', bianco:'Bianco', nero:'Nero', prec:'Precisione', pochi:'servono almeno 5 mosse giudicate',
        grafico:'Andamento: tocca il grafico per andare a quella mossa', fatta:'Analisi fatta in %s · livello %l · Stockfish sul telefono', livello:'Livello', standard:'Standard', approfondito:'Approfondito',
        teoria:'Teoria', obbligata:'Mossa obbligata', obbligatat:'era l\'unica mossa legale: nessun giudizio e non conta nella precisione.', equiv:'Equivalente alla migliore: il motore sceglieva %m, ma la valutazione è la stessa.', forte:'Mossa forte', fortet:'Prima della mossa dell\'avversario era al %a%; questa mossa la riporta al %d% ed è l\'unica: la seconda scelta del motore valeva %p punti in meno.', migliore:'Migliore', ottima:'Ottima', buona:'Buona', imprecisione:'Imprecisione', errore:'Errore', svarione:'Blunder',
        nogiud:'nessun giudizio: era già persa', decisa:'nessun giudizio: il matto era già inevitabile.', allungato:'Allunga il matto: era più rapido %m (matto in %n).', accorciato:'Accorcia il matto: resisteva di più %m (matto in %n invece di %k).', ricorso:'Ricontrollo in corso: %a di %b · le etichette possono ancora cambiare', meglio:'Il motore preferiva %m (−%p punti di probabilità di vittoria).', mossa:'Mossa',
        sec:'%n s', min:'%n min'},
    en:{tit:'Game analysis', btn:'Analyse the whole game', riprendi:'Resume analysis', ric:'Start over', annulla:'Cancel',
        hint:'The engine checks every move on your phone: about %s. You can cancel any time and resume later.',
        vuota:'Play or load a game (at least 2 moves) to analyse it.', fase1:'Evaluating positions: %a of %b', fase2:'Double-checking doubtful moves: %a of %b', fase3:'Re-checking negative verdicts more deeply: %a of %b',
        stop:'Analysis stopped: resume whenever you like, the work done is saved.', noeng:'The engine is not available on this device.',
        pausa:'Engine paused: analysing the whole game.', bianco:'White', nero:'Black', prec:'Accuracy', pochi:'needs at least 5 judged moves',
        grafico:'Evaluation: tap the graph to jump to that move', fatta:'Analysed in %s · %l level · Stockfish on the phone', livello:'Level', standard:'Standard', approfondito:'Deep',
        teoria:'Book', obbligata:'Only move', obbligatat:'it was the only legal move: no verdict and it does not count for accuracy.', equiv:'As good as the best: the engine chose %m, but the evaluation is the same.', forte:'Strong move', fortet:'Before the opponent\'s move it was %a%; this move brings it back to %d% and it is the only one: the engine\'s second choice was %p points worse.', migliore:'Best', ottima:'Excellent', buona:'Good', imprecisione:'Inaccuracy', errore:'Mistake', svarione:'Blunder',
        nogiud:'no verdict: already lost', decisa:'no verdict: mate could no longer be avoided.', allungato:'It makes the mate longer: %m was faster (mate in %n).', accorciato:'It makes the mate shorter: %m held out longer (mate in %n instead of %k).', ricorso:'Re-checking: %a of %b · labels may still change', meglio:'The engine preferred %m (−%p win-chance points).', mossa:'Move',
        sec:'%n s', min:'%n min'}
  };
  function t(k){ return (EN ? TX.en : TX.it)[k] || TX.it[k] || k; }
  function esc(s){ return String(s == null ? '' : s).replace(/[&<>"']/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }
  function dur(ms){ var s = Math.max(1, Math.round(ms / 1000)); return s < 90 ? t('sec').replace('%n', s) : t('min').replace('%n', Math.round(s / 60)); }
  function hkey(s){ var a = 0x811c9dc5; for (var i = 0; i < s.length; i++) a = Math.imul(a ^ s.charCodeAt(i), 16777619) >>> 0; return a.toString(36); }
  function fkey(fen){ return String(fen).split(' ').slice(0, 4).join(' '); }
  var START = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';

  /* ---------- motore: Worker NOSTRO separato (stessa interfaccia di Engine.analyse) ---------- */
  function Motore(){
    var w = null, ready = null, job = null, morto = false;
    function start(){
      if (ready) return ready;
      ready = new Promise(function(res, rej){
        try { w = new Worker('engine/stockfish-lite.js'); } catch(e){ rej(e); return; }
        var to = setTimeout(function(){ rej(new Error('timeout')); }, 20000);
        // rilievo 12: un errore DOPO l'avvio chiude la ricerca in corso (null) invece di lasciarla appesa per sempre
        w.onerror = function(e){ clearTimeout(to); morto = true; rej(new Error(e.message || 'worker')); if (job){ var j = job; job = null; clearTimeout(j.cane); j.resolve(null); } };
        w.onmessage = function(ev){
          var line = String(ev.data);
          if (line === 'uciok'){ ['setoption name Hash value 16', 'setoption name UCI_LimitStrength value false', 'setoption name Skill Level value 20'].forEach(function(c){ w.postMessage(c); }); w.postMessage('isready'); }
          else if (line === 'readyok' && !w.__r){ w.__r = 1; clearTimeout(to); res(); }
          else onLine(line);
        };
        w.postMessage('uci');
      });
      return ready;
    }
    function onLine(line){
      if (!job) return;
      if (line.indexOf('info ') === 0 && line.indexOf(' pv ') > 0 && line.indexOf('bound') < 0){
        var m = line.match(/ depth (\d+).* multipv (\d+).* score (cp|mate) (-?\d+).* pv (.+)$/) || line.match(/ depth (\d+)().* score (cp|mate) (-?\d+).* pv (.+)$/);
        if (m) job.lines[+(m[2] || 1)] = {depth:+m[1], type:m[3], v:+m[4], pv:m[5].trim().split(' ')};
      } else if (line.indexOf('bestmove') === 0){
        var j = job; job = null; clearTimeout(j.cane); var bm = line.split(' ')[1];
        j.resolve({best:(bm && bm !== '(none)') ? bm : null, lines:Object.keys(j.lines).sort(function(a, b){ return a - b; }).map(function(k){ return j.lines[k]; }), fen:j.fen});
      }
    }
    function analyse(fen, o){
      o = o || {};
      return start().then(function(){ if (morto) return null; return new Promise(function(res){
        if (job){ clearTimeout(job.cane); job.resolve(null); job = null; w.postMessage('stop'); }
        var j = job = {fen:fen, lines:{}, resolve:res};
        // rete di sicurezza: un Worker chiuso dal sistema non manda né bestmove né errore → dopo movetime + 15 s la ricerca vale null
        j.cane = setTimeout(function(){ if (job === j){ job = null; morto = true; try { w.terminate(); } catch(e){} res(null); } }, (o.movetime || 300) + 15000);
        w.postMessage('setoption name MultiPV value ' + (o.multipv || 1));
        if (o.pulisci) w.postMessage('ucinewgame');   // profondità fissa: hash vuoto a ogni ricerca → stesso risultato a ogni prova (anche dopo «Riprendi»)
        w.postMessage('position fen ' + fen);
        w.postMessage('go ' + (o.depth ? 'depth ' + o.depth + ' ' : '') + 'movetime ' + (o.movetime || 300));
      }); });
    }
    function stop(){ if (w && job) w.postMessage('stop'); }
    function quit(){ if (job){ clearTimeout(job.cane); job.resolve(null); job = null; } if (w){ try { w.postMessage('quit'); w.terminate(); } catch(e){} } w = null; ready = null; }
    return {analyse:analyse, stop:stop, quit:quit};
  }
  // adattatore: risultato di Engine.analyse → righe {uci, cp} dal punto di vista di chi muove, cp limitato a ±1000 (matto = ±1000).
  // Risultato null (ricerca sostituita o fermata) → null: chi chiama controlla l'annullamento e, se non annullato, riprova una volta.
  function righe(r){
    if (!r || !r.lines || !r.lines.length) return null;
    return r.lines.filter(Boolean).map(function(l){
      var cp = l.type === 'mate' ? (l.v > 0 ? CP.CLIP : -CP.CLIP) : Math.max(-CP.CLIP, Math.min(CP.CLIP, l.v));
      return {uci:l.pv && l.pv[0], cp:cp, depth:l.depth, mate:l.type === 'mate' ? l.v : null};
    });
  }

  /* ---------- salvataggio con ripresa ---------- */
  function loadAll(){ try { var o = JSON.parse(localStorage.getItem(KEY) || '{}'); return o && o.v === CP.VERSIONE ? o : {v:CP.VERSIONE, g:{}}; } catch(e){ return {v:CP.VERSIONE, g:{}}; } }
  function saveRec(rec){
    var all = loadAll(); rec.ts = Date.now(); all.g[rec.h] = rec;
    var ks = Object.keys(all.g).sort(function(a, b){ return all.g[b].ts - all.g[a].ts; });
    ks.slice(MAXG).forEach(function(k){ delete all.g[k]; });
    try { localStorage.setItem(KEY, JSON.stringify(all)); } catch(e){}
  }
  function getRec(h){ var r = loadAll().g[h]; return r && r.liv === LIV ? r : null; }

  /* ---------- la partita corrente ---------- */
  /* 14-11: la partita rigiocata si ricorda finché non cambiano posizione iniziale e mosse. Prima ogni bottone dell'elenco mosse
     (sym → tag → stato → recNow) la rigiocava tutta con chess.js: ~500 ms a ogni passo Avanti/Indietro e al passaggio
     Riepilogo → Revisione (la dissolvenza non si vedeva, Kiko t1933u). Cambia solo ply, che si aggiorna a ogni chiamata. */
  var memoP = null;
  function partita(){
    var st = window.CNAnalisi && window.CNAnalisi.state(); if (!st) return null;
    var j = st.sans.join(' ');
    if (memoP && memoP.start === st.startFen && memoP.j === j && memoP.liv === LIV){ var o = {}; for (var k in memoP.p) o[k] = memoP.p[k]; o.ply = st.ply; return o; }
    var r = partita0(st);
    memoP = {start:st.startFen, j:j, liv:LIV, p:r};
    return r;
  }
  function partita0(st){
    var c = new Chess(st.startFen), fens = [c.fen()], ucis = [], cols = [];
    for (var i = 0; i < st.sans.length; i++){
      var mv = c.move(st.sans[i]);       // chess.js v1: lancia se illegale; la pagina ha già validato tutta la partita all'import
      ucis.push(mv.from + mv.to + (mv.promotion || '')); cols.push(mv.color); fens.push(c.fen());
    }
    var fine = c.isCheckmate() ? 'matto' : (c.isGameOver() ? 'patta' : null);
    return {start:st.startFen, sans:st.sans, ucis:ucis, cols:cols, fens:fens, fine:fine, ply:st.ply, h:hkey(LIV + '|' + CP.VERSIONE + '|' + REGOLE + '|' + (LIVELLI[LIV].rdepth || '') + '|' + st.startFen + '|' + st.sans.join(' '))};
  }

  /* ---------- analisi (da cn_profilo.analizzaUna, adattata: progress che conta anche le verifiche, ripresa per posizione) ---------- */
  var run = null;   // {ctl, rec, p, eng}
  function win(cp){ return CP.P(cp); }
  function classe(loss){ var M = MARGINE_SOGLIA; return loss > SOGLIE.sva + M ? 'svarione' : loss > SOGLIE.err + M ? 'errore' : loss > SOGLIE.imp + M ? 'imprecisione' : null; }
  // giudizio negativo (regole r3, 01/11 00:12): null = nessun giudizio negativo (resta migliore/ottima/buona)
  function giudizio(loss, wB, wA){
    var c = classe(loss);
    if (!c) return null;
    if (PROTEZIONE_PERSA && wB <= PERSA) return 'nogiud';                              // già persa prima della mossa: niente giudizio negativo
    if (wA >= CHIARO && (c === 'errore' || c === 'svarione')) c = 'imprecisione';   // resta ≥ 75% (anche ≥ 90%): rallentare = al massimo Imprecisione
    return c;                                                                         // vantaggio buttato (< 75% dopo): giudizio pieno
  }
  function stopErr(){ var e = new Error('STOP'); e.code = 'STOP'; return e; }
  function libro(p, eco){   // mosse di teoria: solo dalla posizione iniziale normale. L'elenco ECO ha solo le posizioni CON NOME
    var out = [], last = -1;  // (3.Cc3 della Pirc non c'è, 3…g6 sì): è teoria tutto fino all'ultima posizione con nome, con buchi di al massimo 4 semimosse
    if (fkey(p.start) !== fkey(START) || !eco) return out;
    for (var i = 0; i < p.ucis.length && i - last <= 4; i++) if (eco[fkey(p.fens[i + 1])]) last = i;
    for (var k = 0; k <= last; k++) out.push(k);
    return out;
  }
  async function cerca(eng, ctl, fen, o){
    for (var k = 0; k < 2; k++){
      if (ctl.stop) throw stopErr();
      var r = righe(await eng.analyse(fen, o));
      if (ctl.stop) throw stopErr();
      if (r) return r;
    }
    throw new Error('ENGINE');
  }
  async function analizza(p, rec, ctl, onProg){
    var L = LIVELLI[LIV], eng = run.eng, eco = await window.CNAnalisi.eco();
    var n = p.ucis.length, tPrima = rec.ms || 0, t0 = Date.now();
    function tempo(){ return tPrima + (Date.now() - t0); }
    // unità di lavoro: 1 per posizione veloce, verif per ogni ricerca di verifica (così la barra non resta ferma al 99%)
    function prog(fase, a, b, agg){ var vw = L.msVer / L.msPos, rw = (L.msRic || L.msVer) / L.msPos, tot = (n + 1) + rec.stimaV * vw + (rec.stimaR || 0) * rw, fatto = rec.E.filter(function(x){ return x !== undefined; }).length + rec.vFatte * vw + (rec.rFatte || 0) * rw;
      // blocco 5: la stima delle verifiche arriva dopo la passata veloce → la % non deve mai tornare indietro
      var pc = Math.min(99, Math.round(100 * fatto / Math.max(1, tot))); if (run){ pc = Math.max(pc, run.pmax || 0); run.pmax = pc; }
      onProg({pct:pc, fase:fase, a:a, b:b, agg:agg}); }
    // 1) passata veloce (riparte dalla prima posizione non ancora valutata)
    for (var i = 0; i <= n; i++){
      if (rec.E[i] !== undefined && rec.E[i] !== null) continue;
      if (ctl.stop) throw stopErr();
      var g = new Chess(p.fens[i]);
      if (g.isGameOver()) rec.E[i] = {cp:g.isCheckmate() ? -CP.CLIP : 0, best:null, over:1};   // chi muove ha preso matto / patta
      else { var r = await cerca(eng, ctl, p.fens[i], {movetime:MAX_MS, depth:L.depth, pulisci:1}); rec.E[i] = {cp:r[0].cp, best:r[0].uci, mate:r[0].mate}; }
      rec.ms = tempo(); saveRec(rec); prog('fase1', i + 1, n + 1);
    }
    // 2) candidati e verifica (cn_profilo: classe sulla perdita veloce → verifica profonda multipv 3 → giudizio solo se resta)
    var book = libro(p, eco), M = rec.M || [];
    function veloce(i){ var wB = win(rec.E[i].cp), wA = win(-rec.E[i + 1].cp); return {wB:wB, wA:wA, calo:Math.max(0, wB - wA), loss:p.ucis[i] === rec.E[i].best ? 0 : Math.max(0, wB - wA)}; }   // calo: anche se era la scelta del motore (orizzonte)
    var cand = [];
    // r6: mossa obbligata = una sola mossa legale nella posizione (niente verifica, niente giudizio, fuori dalla precisione)
    var obbl = []; for (var o2 = 0; o2 < n; o2++) obbl.push(new Chess(p.fens[o2]).moves().length === 1);
    function primaAvv(i){ return i > 0 ? 100 - win(rec.E[i - 1].cp) : 50; }   // chi muove in i, PRIMA della mossa dell'avversario (stesso punto di vista)
    function forseForte(i, v){ return i > 0 && primaAvv(i) <= FORTE_PRIMA && v.wA >= FORTE_DOPO - 5 && v.loss <= 2 + MARGINE_SOGLIA; }
    for (var j = 0; j < n; j++){ var v = veloce(j); if (book.indexOf(j) < 0 && !obbl[j] && (v.calo > VERIFICA_DA || forseForte(j, v) || (MATTO_CERTO && rec.E[j].mate && p.ucis[j] !== rec.E[j].best)) && !(rec.V && rec.V[j])) cand.push(j); }   // si riverifica ogni calo veloce > VERIFICA_DA = 3 (anche la scelta del motore: a profondità fissa può non vedere uno stallo / un matto) + le possibili «Mosse forti»
    rec.V = rec.V || {}; rec.stimaV = Object.keys(rec.V).length + cand.length * 1.6; prog('fase2', 0, cand.length);
    // verifica di una mossa a profondità vd (r5, invariata); conta() = contatore delle ricerche fatte (verifica o ricontrollo)
    async function verifica(i2, vd, conta){
      var d1 = await cerca(eng, ctl, p.fens[i2], {movetime:MAX_MS, depth:vd, multipv:3, pulisci:1}); conta();
      var wB2 = win(d1[0].cp), mia = d1.filter(function(x){ return x.uci === p.ucis[i2]; })[0], wA2, d2 = null;
      if (mia) wA2 = win(mia.cp);                                   // la mossa giocata è fra le 3 migliori: stessa ricerca, confronto più pulito
      else if (rec.E[i2 + 1].over) wA2 = win(-rec.E[i2 + 1].cp);
      else { d2 = await cerca(eng, ctl, p.fens[i2 + 1], {movetime:MAX_MS, depth:vd, pulisci:1}); conta(); wA2 = win(-d2[0].cp); }
      var loss2 = p.ucis[i2] === d1[0].uci ? 0 : Math.max(0, wB2 - wA2), bestV = d1[0].uci, wRif = wB2, oriz = 0;
      if (p.ucis[i2] === d1[0].uci && !rec.E[i2 + 1].over && veloce(i2).calo > VERIFICA_DA){
        // ORIZZONTE (cnp-2, r5): è la scelta del motore ma la posizione dopo vale molto meno. Si cerca la posizione dopo alla stessa
        // profondità di verifica e si confronta con la 2ª linea (es. 48…Dxg3 di Evans–Reshevsky: lo stallo si vede solo dopo).
        var d3 = await cerca(eng, ctl, p.fens[i2 + 1], {movetime:MAX_MS, depth:vd, pulisci:1}); conta();
        var wDopo = win(-d3[0].cp), rif = d1.length > 1 ? win(d1[1].cp) : wB2;
        if (giudizio(Math.max(0, rif - wDopo), rif, wDopo)){ loss2 = Math.max(0, rif - wDopo); wA2 = wDopo; wRif = rif; bestV = d1.length > 1 ? d1[1].uci : null; oriz = 1; }
        else wA2 = Math.min(wA2, wDopo);
      }
      var gap = d1.length > 1 ? wB2 - win(d1[1].cp) : 0, pA = rec.V[i2 - 1] ? 100 - rec.V[i2 - 1].wB : primaAvv(i2);
      var ripresa = i2 > 0 && p.ucis[i2].slice(2, 4) === p.ucis[i2 - 1].slice(2, 4);
      var evid = false; if (FORTE_PRUDENTE && i2 > 0){   // r7: punizione evidente = cattura o scacco subito dopo un Errore/Svarione dell'avversario
        var vp = rec.V[i2 - 1], lp = vp ? vp.loss : veloce(i2 - 1).loss;
        try { var cm = new Chess(p.fens[i2]).move({from:p.ucis[i2].slice(0, 2), to:p.ucis[i2].slice(2, 4), promotion:p.ucis[i2][4]}); evid = lp > SOGLIE.err + MARGINE_SOGLIA && !!(cm && (cm.captured || /[+#]/.test(cm.san))); } catch(e){}
      }
      var forte = !oriz && !evid && p.ucis[i2] === d1[0].uci && !(FORTE_NO_RIPRESA && ripresa) && pA <= FORTE_PRIMA && Math.min(wB2, wA2) >= FORTE_DOPO && d1.length > 1 && gap >= FORTE_UNICA;
      // r7 matto certo: mB = distanza della prima scelta; mG = distanza dopo la mossa giocata (stesso punto di vista, contata da prima della mossa)
      var mB = d1[0].mate, mG = null;
      if (mB > 0){ if (mia) mG = mia.mate > 0 ? mia.mate : null; else if (rec.E[i2 + 1].over) mG = new Chess(p.fens[i2 + 1]).isCheckmate() ? 1 : null; else if (d2) mG = d2[0].mate !== null && d2[0].mate < 0 ? 1 - d2[0].mate : null; }
      else if (mB < 0){ if (mia) mG = mia.mate < 0 ? mia.mate : null; else if (d2) mG = d2[0].mate > 0 ? -d2[0].mate : null; }
      return {loss:loss2, wA:wA2, best:bestV, wB:wB2, gap:gap, pA:pA, oriz:oriz, cl:forte ? 'forte' : giudizio(loss2, wRif, wA2), mB:mB, mG:mG, evid:evid ? 1 : 0};
    }
    function contaV(){ rec.vFatte++; }
    for (var c = 0; c < cand.length; c++){
      rec.V[cand[c]] = await verifica(cand[c], L.vdepth, contaV);
      rec.ms = tempo(); saveRec(rec); prog('fase2', c + 1, cand.length);
    }
    // 2b) RICONTROLLO (r6, solo se il livello ha rdepth = Standard): ogni giudizio negativo si rifà a profondità rdepth; vale il risultato
    //     più profondo. Ripresa: le mosse già ricontrollate hanno ric = 1. v1 = giudizio della prima verifica (solo per i test).
    function negativo(x){ return x && /^(imprecisione|errore|svarione)$/.test(x.cl); }
    function aggiorna(){ etichette(p, rec, book, obbl, veloce); saveRec(rec); }
    if (L.rdepth){
      var ric = Object.keys(rec.V).map(Number).sort(function(a, b){ return a - b; }).filter(function(k){ return negativo(rec.V[k]) && !rec.V[k].ric; });
      rec.rFatte = rec.rFatte || 0; rec.stimaR = rec.rFatte + ric.length * 1.6;
      if (ric.length){ aggiorna(); rec.prov = 1; prog('fase3', 0, ric.length, 1); }   // r7 punto 4: etichette subito, poi si aggiornano
      else prog('fase3', 0, 0);
      for (var r3 = 0; r3 < ric.length; r3++){
        var k3 = ric[r3], prima = rec.V[k3], dopo = await verifica(k3, L.rdepth, function(){ rec.rFatte++; });
        dopo.ric = 1; dopo.v1 = {cl:prima.cl, loss:prima.loss, best:prima.best}; rec.V[k3] = dopo;
        rec.ms = tempo(); aggiorna(); prog('fase3', r3 + 1, ric.length, 1);
      }
    }
    // 3) etichette e precisione
    etichette(p, rec, book, obbl, veloce); delete rec.prov; rec.fatto = 1; rec.ms = tempo(); saveRec(rec);
    return rec;
  }
  function etichette(p, rec, book, obbl, veloce){
    var n = p.ucis.length, lab = [], acc = {w:[], b:[]}, cnt = {w:{}, b:{}};
    CLS.forEach(function(k){ cnt.w[k] = 0; cnt.b[k] = 0; });
    for (var m = 0; m < n; m++){
      var q = veloce(m), loss = q.loss, cl = null, best = rec.E[m].best;   // (cl = null: con «var» senza valore resterebbe quello del giro prima)
      if (rec.V[m]){ loss = rec.V[m].loss; best = rec.V[m].best; cl = rec.V[m].cl; }
      if (book.indexOf(m) >= 0) cl = 'teoria';
      else if (obbl[m]){ cl = 'obbligata'; loss = 0; best = p.ucis[m]; }   // r6: unica mossa legale
      else if (!cl) cl = p.ucis[m] === best ? 'migliore' : loss <= 2 + MARGINE_SOGLIA ? 'ottima' : loss <= SOGLIE.imp + MARGINE_SOGLIA ? 'buona' : (giudizio(loss, q.wB, q.wA) || 'buona');
      // r7 punto 1: matto certo (distanze dalla verifica profonda; senza verifica: dalla passata veloce, solo per togliere le etichette positive)
      var vm = rec.V[m], mB = vm && vm.mB !== undefined ? vm.mB : rec.E[m].mate, mt = null;
      if (MATTO_CERTO && mB && cl !== 'teoria' && cl !== 'obbligata'){
        if (mB < 0){                                                      // chi muove subisce il matto
          var dd = vm && vm.mG !== undefined && vm.mG !== null && -mB <= MATTO_MAX ? -vm.mG : null;
          if (dd !== null && dd < -mB){ cl = -mB - dd >= MATTO_GRAVE ? 'errore' : 'imprecisione'; mt = {acc:1, n:dd, k:-mB}; }
          else if (!/^(imprecisione|errore|svarione)$/.test(cl)){ cl = 'nogiud'; mt = {decisa:1}; }
        } else if (vm && vm.mB > 0 && p.ucis[m] !== vm.best && mB <= MATTO_MAX && !/^(imprecisione|errore|svarione)$/.test(cl)){   // chi dà matto e lo allunga
          var dg = vm.mG === null || vm.mG === undefined ? 99 : vm.mG - mB;
          if (dg >= MATTO_GRAVE) { cl = 'imprecisione'; mt = {all:1, n:mB}; } else if (dg >= 1) { cl = 'buona'; mt = {all:1, n:mB}; }
        }
      }
      // r7b (Kiko 01/11 21:11): già persa (≤ PERSA prima della mossa) e il motore NON vede il matto → niente etichetta positiva (nessun giudizio)
      if (PERSA_NEUTRA && PROTEZIONE_PERSA && !mB && cl !== 'teoria' && cl !== 'obbligata' && cl !== 'nogiud' && !/^(imprecisione|errore|svarione)$/.test(cl) && (vm && vm.wB !== undefined ? vm.wB : q.wB) <= PERSA) cl = 'nogiud';
      if (cl !== 'nogiud') cnt[p.cols[m]][cl]++;
      if (cl !== 'teoria' && cl !== 'obbligata' && cl !== 'nogiud') acc[p.cols[m]].push(CP.accMossa(loss));   // cnp-2: la Teoria non conta nella precisione; r6: neanche la mossa obbligata; r7c (Kiko 01/11 21:15): neanche «nessun giudizio» (meno di 5 mosse contate → «—»)
      var lb = {cl:cl, loss:Math.round(loss * 10) / 10, best:best};
      if (cl === 'ottima' && lb.loss === 0 && best && best !== p.ucis[m]) lb.eq = 1;   // perdita 0 ma non prima scelta: «equivalente alla migliore»
      if (mt && mt.decisa) lb.decisa = 1;
      if (mt && mt.all) lb.allunga = mt.n;
      if (mt && mt.acc) { lb.accorcia = mt.n; lb.mk = mt.k; }
      if (cl === 'forte') { lb.pA = Math.round(rec.V[m].pA); lb.wA = Math.round(rec.V[m].wA); lb.gap = Math.round(rec.V[m].gap); }
      lab.push(lb);
    }
    rec.lab = lab; rec.cnt = cnt; rec.prec = {w:CP.media(acc.w), b:CP.media(acc.b)};
  }

  /* ---------- interfaccia ---------- */
  var cache = null;   // {h, rec} della partita mostrata
  function box(){ var r = window.CNAnalisi && window.CNAnalisi.root(); return r && r.querySelector('.anp-apa'); }
  function recNow(){ var p = partita(); if (!p) return null; if (!cache || cache.h !== p.h) cache = {h:p.h, rec:getRec(p.h)}; return {p:p, rec:cache.rec}; }
  function busy(){ return !!run; }
  function prov(){ return !!(run && run.rec && run.rec.prov && run.rec.lab); }   // r7 punto 4: etichette provvisorie durante il ricontrollo
  function start(fresh){
    if (run && !run.ctl.stop) return;
    var p = partita(); if (!p || p.ucis.length < 2) return;
    if (run){ var vec = run; run = null; try { vec.eng.quit(); } catch(e){} }   // rilievo 13: quella vecchia stava già fermandosi (Annulla / altra partita): si chiude subito, resta salvata per «Riprendi»
    var rec = !fresh && getRec(p.h);
    if (!rec || rec.fatto && fresh) rec = null;
    rec = rec || {h:p.h, liv:LIV, v:CP.VERSIONE, start:p.start, n:p.ucis.length, E:[], V:{}, vFatte:0, stimaV:Math.round(p.ucis.length * 0.25), ms:0};
    rec.vFatte = Object.keys(rec.V || {}).length;   // (riprendendo: le verifiche salvate contano come fatte)
    var ctl = {stop:false};
    run = {ctl:ctl, rec:rec, p:p, eng:Motore(), prog:{pct:0, fase:'fase1', a:0, b:p.ucis.length + 1}, err:''};
    cache = {h:p.h, rec:rec};
    try { window.CNAnalisi.live(); } catch(e){}      // la pagina mette in pausa l'analisi dal vivo (un motore alla volta)
    draw();
    analizza(p, rec, ctl, function(pr){ if (run && run.ctl === ctl){ var era = prov(); run.prog = pr; if (pr.agg){ if (!era) draw(); else aggProv(); try { window.CNAnalisi.moves(); } catch(e){} } else drawProg(); } }).then(function(){
      fine(ctl, '');
    }, function(e){ fine(ctl, e && e.code === 'STOP' ? 'stop' : 'noeng'); });
  }
  function fine(ctl, err){
    if (!run || run.ctl !== ctl) return;
    var tenuta = !err && run.rec && run.rec.fatto ? {h:run.p.h, rec:run.rec} : null;   // rilievo 17: se il salvataggio non è entrato (spazio pieno) il risultato resta almeno visibile
    run.eng.quit(); run = null; lastErr = err; cache = tenuta;
    try { window.CNAnalisi.moves(); } catch(e){}
    draw();
    try { window.CNAnalisi.live(); } catch(e){}      // riprende l'analisi dal vivo
  }
  var lastErr = '';
  function cancel(){ if (!run) return; run.ctl.stop = true; try { run.eng.stop(); } catch(e){} var c = run.ctl; setTimeout(function(){ fine(c, 'stop'); }, 1500); }

  function pctOf(rec, n){ if (!rec) return 0; var e = (rec.E || []).filter(function(x){ return x; }).length; return Math.min(99, Math.round(100 * e / (n + 1 + (rec.stimaV || 0) * 3) + 0)); }
  function drawProg(){
    var b = box(); if (!b || !run) return;
    var f = b.querySelector('.apa-fill'), l = b.querySelector('.apa-pl'), pr = run.prog;
    if (f) f.style.width = pr.pct + '%';
    if (l) l.textContent = t(prov() ? 'ricorso' : pr.fase).replace('%a', pr.a).replace('%b', pr.b) + ' · ' + pr.pct + '%';
    var bar = b.querySelector('.apa-bar'); if (bar) bar.setAttribute('aria-valuenow', pr.pct);
  }
  // blocco 2 (10-11, L.853): durante il caricamento dell'analisi una frase verificata (data/citazioni.js), la stessa per tutta l'analisi
  var fraseI = -1;
  function frase(){ var C = window.CITAZIONI || []; if (!C.length) return ''; if (fraseI < 0) fraseI = Math.floor(Math.random() * C.length);
    var c = C[fraseI % C.length]; return '<p class="apa-frase"><i>«' + esc(c.it) + '»</i> <span>— ' + esc(c.a) + '</span></p>'; }
  function draw(){
    var b = box(); if (!b) return;
    var x = recNow(); if (!x) return;
    var p = x.p, rec = x.rec, h = '<h3>' + esc(t('tit')) + '</h3>';
    if (run){
      h += '<div class="apa-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><i class="apa-fill"></i></div>' +
           '<div class="apa-row"><span class="apa-pl anp-mu"></span><button type="button" class="anp-btn apa-x" data-x="annulla">' + esc(t('annulla')) + '</button></div>';
      h += frase();   // blocco 2 (10-11): frase del giorno durante l'attesa (L.853)
      var pv = prov() && rec && rec.lab && rec === run.rec;   // rilievo 18: etichette provvisorie solo se la partita mostrata è quella in analisi
      if (pv) h += risultati(p, rec, 1);
      b.innerHTML = h; b.querySelector('.apa-x').onclick = cancel; if (pv) b.classList.add('apa-prov'); drawProg(); if (pv) wire(b, p); return;
    }
    b.classList.remove('apa-prov');
    if (p.ucis.length < 2){ b.innerHTML = h + '<p class="anp-mu">' + esc(t('vuota')) + '</p>'; return; }
    if (rec && rec.fatto){ b.innerHTML = h + sceltaLiv() + risultati(p, rec); wire(b, p); wireLiv(b); return; }
    var stima = stimaMs(p.ucis.length);
    h += sceltaLiv();
    h += (lastErr === 'stop' ? '<p class="anp-mu">' + esc(t('stop')) + '</p>' : lastErr === 'noeng' ? '<p class="anp-mu">' + esc(t('noeng')) + '</p>' : '');
    h += '<div class="anp-row">';
    if (rec && rec.E && rec.E.length) h += '<button type="button" class="anp-btn anp-pri" data-x="go">' + esc(t('riprendi')) + ' (' + pctOf(rec, p.ucis.length) + '%)</button><button type="button" class="anp-btn" data-x="new">' + esc(t('ric')) + '</button>';
    else h += '<button type="button" class="anp-btn anp-pri" data-x="go">' + esc(t('btn')) + '</button>';
    h += '</div><p class="anp-mu apa-hint">' + esc(t('hint').replace('%s', dur(stima))) + '</p>';
    b.innerHTML = h;
    b.querySelector('[data-x=go]').onclick = function(){ lastErr = ''; start(false); };
    wireLiv(b);
    var nb = b.querySelector('[data-x=new]'); if (nb) nb.onclick = function(){ lastErr = ''; start(true); };
  }
  // stima: passata veloce + ricerche di verifica (≈ 0,15 per semimossa) + avvio; tarata 01/11 su Chrome headless (KT standard 45 s, approfondito 139 s)
  function stimaMs(n){ var L = LIVELLI[LIV]; return (n + 1) * L.msPos + n * 0.25 * L.msVer + 3000; }
  function sceltaLiv(){
    return '<div class="apa-liv" role="radiogroup" aria-label="' + esc(t('livello')) + '"><span class="anp-mu">' + esc(t('livello')) + '</span>' +
      Object.keys(LIVELLI).map(function(k){ return '<button type="button" role="radio" aria-checked="' + (k === LIV) + '" class="apa-lv' + (k === LIV ? ' on' : '') + '" data-l="' + k + '">' + esc(t(k)) + '</button>'; }).join('') + '</div>';
  }
  function wireLiv(b){
    [].forEach.call(b.querySelectorAll('.apa-lv'), function(x){ x.onclick = function(){
      if (run || x.dataset.l === LIV) return;
      LIV = x.dataset.l; try { localStorage.setItem(KEYLIV, LIV); } catch(e){}
      cache = null; lastErr = ''; try { window.CNAnalisi.moves(); } catch(e){} draw();
    }; });
  }
  function graf(p, rec){
    var W = 300, H = 84, n = p.ucis.length, pts = rec.E.map(function(e, i){
      var cpW = (p.fens[i].split(' ')[1] === 'w' ? 1 : -1) * e.cp; return [i * W / n, H * (1 - win(cpW) / 100)]; });
    var line = pts.map(function(q, i){ return (i ? 'L' : 'M') + q[0].toFixed(1) + ' ' + q[1].toFixed(1); }).join(' ');
    var dots = '';
    rec.lab.forEach(function(l, i){ if (/imprecisione|errore|svarione/.test(l.cl)){ var q = pts[i + 1]; dots += '<circle class="apa-d apa-' + l.cl + '" cx="' + q[0].toFixed(1) + '" cy="' + q[1].toFixed(1) + '" r="3.6"/>'; } });
    var cx = (Math.min(p.ply, n) * W / n).toFixed(1);
    return '<svg class="apa-g" viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="' + esc(t('grafico')) + '">' +
      '<rect class="apa-gb" x="0" y="0" width="' + W + '" height="' + H + '"/>' +
      '<path class="apa-ga" d="' + line + ' L' + W + ' ' + H + ' L0 ' + H + ' Z"/>' +
      '<line class="apa-gm" x1="0" y1="' + H / 2 + '" x2="' + W + '" y2="' + H / 2 + '"/>' +
      '<path class="apa-gl" d="' + line + '"/>' + '<line class="apa-gc" x1="' + cx + '" y1="0" x2="' + cx + '" y2="' + H + '"/>' + dots + '</svg>';
  }
  function aggProv(){ var b = box(), x = recNow(); if (!b || !x || !x.rec) return; var o = b.querySelector('.apa-res'); if (!o) return draw(); o.outerHTML = risultati(x.p, x.rec, 1); wire(b, x.p); drawProg(); }
  function risultati(p, rec, provv){
    function tile(c){ var v = rec.prec[c]; return '<div class="apa-t apa-' + c + '"><small>' + esc(t('prec')) + ' · ' + esc(t(c === 'w' ? 'bianco' : 'nero')) + '</small><b>' + (v == null ? '—' : v + '%') + '</b>' + (v == null ? '<small>' + esc(t('pochi')) + '</small>' : '') + '</div>'; }
    var h = '<div class="apa-res"><div class="apa-ts">' + tile('w') + tile('b') + '</div>';
    h += '<p class="anp-mu apa-gt">' + esc(t('grafico')) + '</p>' + graf(p, rec) + '<p class="apa-now">' + adesso(p, rec) + '</p>';
    h += '<table class="apa-tab"><thead><tr><th></th><th>' + esc(t('bianco')) + '</th><th>' + esc(t('nero')) + '</th></tr></thead><tbody>';
    CLS.forEach(function(k){ var a = rec.cnt.w[k], z = rec.cnt.b[k]; h += '<tr><td>' + icon(k) + esc(t(k)) + '</td><td' + (a ? '' : ' class="z"') + '>' + a + '</td><td' + (z ? '' : ' class="z"') + '>' + z + '</td></tr>'; });
    h += '</tbody></table>';
    if (provv) return h + '</div>';
    h += '<div class="anp-row apa-end"><small class="anp-mu">' + esc(t('fatta').replace('%s', dur(rec.ms || 0)).replace('%l', t(LIV).toLowerCase())) + '</small><button type="button" class="anp-btn" data-x="new">' + esc(t('ric')) + '</button></div></div>';
    return h;
  }
  function uciIt(p, i, uci){   // mossa del motore in notazione dell'app (SAN italiana se c'è)
    try { var c = new Chess(p.fens[i]), m = c.move({from:uci.slice(0, 2), to:uci.slice(2, 4), promotion:uci[4]}); return A.itSan && !EN ? A.itSan(m.san) : m.san; } catch(e){ return uci; }
  }
  function adesso(p, rec){
    var i = p.ply - 1; if (i < 0 || !rec.lab[i]) return '';
    var l = rec.lab[i], san = A.itSan && !EN ? A.itSan(p.sans[i]) : p.sans[i];
    var nm = (new Chess(p.fens[i]).moveNumber ? new Chess(p.fens[i]).moveNumber() : '') + (p.cols[i] === 'w' ? '.' : '…');
    var s = esc(t('mossa')) + ' ' + esc(nm + san) + ': ' + (l.cl === 'nogiud' ? esc(t(l.decisa ? 'decisa' : 'nogiud')) : icon(l.cl) + '<b>' + esc(t(l.cl)) + '</b>');
    if (l.cl === 'obbligata') s += ' ' + esc(t('obbligatat'));
    if (l.eq && l.best) s += ' ' + esc(t('equiv').replace('%m', uciIt(p, i, l.best)));
    if (l.cl === 'forte') s += ' ' + esc(t('fortet').replace('%a', l.pA).replace('%d', l.wA).replace('%p', l.gap));
    if (l.allunga && l.best) s += ' ' + esc(t('allungato').replace('%m', uciIt(p, i, l.best)).replace('%n', l.allunga));
    else if (l.accorcia && l.best) s += ' ' + esc(t('accorciato').replace('%m', uciIt(p, i, l.best)).replace('%n', l.mk).replace('%k', l.accorcia));
    else if (/imprecisione|errore|svarione/.test(l.cl) && l.best) s += ' ' + esc(t('meglio').replace('%m', uciIt(p, i, l.best)).replace('%p', Math.round(l.loss)));
    return s;
  }
  function icon(k){ if (!k || k === 'nogiud') return ''; return '<i class="apa-ic apa-' + k + '" title="' + esc(t(k)) + '" aria-label="' + esc(t(k)) + '">' + ((window.CNIconeMosse && window.CNIconeMosse.svg(k)) || (k === 'teoria' ? BOOK : SYM[k])) + '</i>'; }
  function wire(b, p){
    var g = b.querySelector('.apa-g');
    if (g) g.addEventListener('click', function(e){ var r = g.getBoundingClientRect(); var k = Math.round((e.clientX - r.left) / r.width * p.ucis.length); window.CNAnalisi.go(Math.max(0, Math.min(p.ucis.length, k))); });
    var nb = b.querySelector('[data-x=new]'); if (nb) nb.onclick = function(){ lastErr = ''; start(true); };
  }
  function tag(i){   // icona accanto alla semimossa i nell'elenco mosse
    if (run && !prov()) return '';
    if (i === 0) recNow();            // una volta per elenco: aggiorna la cache se la partita è cambiata (etichette solo della partita analizzata)
    var x = cache; if (!x || !x.rec || !(x.rec.fatto || prov()) || !x.rec.lab) return '';
    return icon(x.rec.lab[i] && x.rec.lab[i].cl);
  }
  var lastH = null;
  function onRender(){
    var x = recNow(); if (!x) return;
    if (x.p.h !== lastH){ lastH = x.p.h; lastErr = ''; if (x.rec && x.rec.fatto){ try { window.CNAnalisi.moves(); } catch(e){} } }
    if (run && !prov()){ drawProg(); return; }
    var b = box(); if (!b) return;
    if (x.rec && (x.rec.fatto || prov()) && b.querySelector('.apa-g')){   // solo il cursore del grafico e la riga «mossa»: niente ridisegno completo a ogni passo
      var g = b.querySelector('.apa-gc'), n = x.p.ucis.length, cx = (Math.min(x.p.ply, n) * 300 / n).toFixed(1);
      g.setAttribute('x1', cx); g.setAttribute('x2', cx); b.querySelector('.apa-now').innerHTML = adesso(x.p, x.rec); return;
    }
    draw();
  }
  // rilievo 13: in stato() un'analisi che si sta fermando (Annulla / altra partita) non conta come «in corso»
  window.CNAnalisiPartita = {start:start, cancel:cancel, busy:busy, tag:tag, onRender:onRender, t:t,
    stato:function(){ var x = recNow(), vivo = !!(run && !run.ctl.stop); return {run:vivo, prov:vivo && prov(), prog:vivo ? run.prog : null, err:lastErr, rec:x && x.rec}; }, MATTO:{certo:MATTO_CERTO, max:MATTO_MAX, grave:MATTO_GRAVE}, FORTE_PRUDENTE:FORTE_PRUDENTE, LIVELLI:LIVELLI, SOGLIE:SOGLIE, CHIARO:CHIARO, MARGINE_SOGLIA:MARGINE_SOGLIA, PERSA:PERSA, PROTEZIONE_PERSA:PROTEZIONE_PERSA, PERSA_NEUTRA:PERSA_NEUTRA, VERIFICA_DA:VERIFICA_DA, MAX_MS:MAX_MS, FORTE:{prima:FORTE_PRIMA, dopo:FORTE_DOPO, unica:FORTE_UNICA, noRipresa:FORTE_NO_RIPRESA},
    livello:function(l){ if (l === undefined) return LIV; if (LIVELLI[l] && !run){ LIV = l; try { localStorage.setItem(KEYLIV, l); } catch(e){} cache = null; draw(); } return LIV; }};
})();
