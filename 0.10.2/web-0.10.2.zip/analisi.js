/* Chess Node · analisi in stile Chess.com (solo versione moderna)
   - giudizio di ogni mossa (!! ! ✓ ?! ? ??) con simbolo sulla casa, elenco mosse e frase
   - «Avanti»: rigioca la mossa annullata, altrimenti Stockfish gioca la sua mossa migliore
   - Suggerimento a tappe: pezzo → casa → freccia
   Riusa le analisi già fatte da app.js (nessun calcolo in più del motore). */
(function(){
  'use strict';
  var A = window.__app; if (!A || !A.ANA) return;
  A.ANA.noArrow = true;                                   // niente freccia automatica: la mostra il suggerimento a tappe
  function $(id){ return document.getElementById(id); }
  function esc(s){ return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;'); }

  var on = false, base = 0, curFen = null;
  var finals = {}, partial = {}, cls = {}, pend = [], redo = [], fwdWait = false, engWait = false, hintWait = false;
  var hint = {fen:null, step:0};
  var nKeys = [], inMove = false;

  var KIND = {
    bb:  {sym:'!!', name:'Brillante'},
    best:{sym:'!',  name:'Migliore'},
    ott: {sym:'!',  name:'Ottima', badge:'best'},
    ok:  {sym:'✓',  name:'Buona'},
    ia:  {sym:'?!', name:'Imprecisione'},
    err: {sym:'?',  name:'Errore'},
    qq:  {sym:'??', name:'Blunder'}
  };
  var VAL = {p:1, n:3, b:3, r:5, q:9, k:100};

  // probabilità di vittoria (0–100) per chi è al tratto: STESSA formula di precisione.js (CNPrecisione.P), cp e matto limitati a ±1000
  function wp(l){
    if (!l) return 50;
    var cp = l.type === 'mate' ? (l.v > 0 ? 1000 : -1000) : Math.max(-1000, Math.min(1000, l.v));
    return window.CNPrecisione ? window.CNPrecisione.P(cp) : 100 / (1 + Math.pow(10, -cp / 400));
  }
  function remember(map, fen, v){ if (!(fen in map)) nKeys.push([map, fen]); map[fen] = v; if (nKeys.length > 400){ var o = nKeys.shift(); delete o[0][o[1]]; } }
  function uciOf(m){ return m.from + m.to + (m.promotion || ''); }
  function sanIt(fen, uci){ try { var m = A.uciToSan(fen, [uci], 1)[0]; return m ? A.itSan(m.san) : uci; } catch(e){ return uci; } }
  function numPrefix(fen){ var p = fen.split(' '); return p[5] + (p[1] === 'w' ? '.' : '...'); }

  // info "prima": risultato finale, oppure l'ultima riga parziale abbastanza profonda
  function beforeInfo(fen){
    var f = finals[fen];
    if (f && f.lines && f.lines[0]) return {line:f.lines[0], best:f.best, lines:f.lines};
    var p = partial[fen];
    if (p && p.depth >= 8 && p.pv && p.pv[0]) return {line:p, best:p.pv[0], lines:[p]};
    return null;
  }

  // sacrificio: dopo la mossa un pezzo (non pedone, non re) di chi ha mosso resta in presa
  function isSacrifice(mv){
    var g = A.game(); if (g.isCheckmate()) return false;
    var me = mv.color, op = me === 'w' ? 'b' : 'w', board = g.board();
    for (var r = 0; r < 8; r++) for (var c = 0; c < 8; c++){
      var p = board[r][c]; if (!p || p.color !== me || p.type === 'p' || p.type === 'k') continue;
      var sq = 'abcdefgh'[c] + (8 - r), att = g.attackers(sq, op); if (!att.length) continue;
      var def = g.attackers(sq, me).length > 0, got = sq === mv.to && mv.captured ? VAL[mv.captured] : 0;
      var minA = Math.min.apply(null, att.map(function(s){ return VAL[g.get(s).type]; }));
      var risk = def ? (minA >= 100 ? 0 : VAL[p.type] - minA) : VAL[p.type];
      if (risk - got >= 2) return true;
    }
    return false;
  }

  function classify(it, wpPlayed){
    var loss = Math.max(0, it.wpBest - wpPlayed), k;
    // soglie decise (5 / 10 / 20) con margine 2: al limite vale l'etichetta più leggera, come analisi_partita.js
    if (it.uci === it.best || loss <= 4) k = (it.sac && wpPlayed >= 45) ? 'bb' : (it.uci === it.best ? 'best' : 'ott');
    else if (loss <= 7) k = 'ok';
    else if (loss <= 12) k = 'ia';
    else if (loss <= 22) k = 'err';
    else k = 'qq';
    var res = {kind:k, loss:loss, bestSan:sanIt(it.fenBefore, it.best), san:A.itSan(it.san), num:numPrefix(it.fenBefore), to:it.to, color:it.color};
    cls[it.key] = res;
    if (A.game().fen() === it.fenAfter){ A.setBadge(it.to, KIND[k].badge || k); if (!inMove) A.rerender(); say(res); }
    renderList();
  }

  function say(res){
    var f = $('feedback'); if (!f) return;
    var K = KIND[res.kind], tail;
    if (res.kind === 'bb') tail = 'sacrificio che funziona!';
    else if (res.kind === 'best') tail = 'è proprio la mossa di Stockfish.';
    else if (res.kind === 'ott') tail = 'quasi come la migliore (' + res.bestSan + ').';
    else tail = 'meglio era ' + res.bestSan + '.';
    f.className = 'feedback info anaverdict k-' + res.kind;
    f.innerHTML = '<span class="avsym">' + K.sym + '</span> <b>' + esc(K.name) + '</b> — ' + esc(res.num + res.san) + ': ' + esc(tail);
  }
  function sayText(t){ var f = $('feedback'); if (!f) return; f.className = 'feedback info anaverdict'; f.innerHTML = esc(t); }

  // ---------- eventi da app.js ----------
  document.addEventListener('cnp:analysis-move', function(ev){
    var d = ev.detail || {}, mv = d.move; if (!mv) return;
    var uci = uciOf(mv), key = d.fenBefore + '|' + uci;
    hint = {fen:null, step:0}; hintWait = false;
    // ramo di redo
    if (redo.length && redo[redo.length - 1].key === key) redo.pop(); else redo = [];
    if (d.src === 'engine'){ fwdWait = false; sayText('Stockfish gioca ' + numPrefix(d.fenBefore) + A.itSan(mv.san) + ' (la sua mossa migliore).'); cls[key] = cls[key] || {kind:'eng', num:numPrefix(d.fenBefore), san:A.itSan(mv.san)}; renderList(); return; }
    if (cls[key] && cls[key].kind !== 'eng'){ A.setBadge(mv.to, KIND[cls[key].kind].badge || cls[key].kind); say(cls[key]); renderList(); return; }
    if (cls[key] && cls[key].kind === 'eng'){ renderList(); return; }
    var b = beforeInfo(d.fenBefore);
    if (!b && d.src === 'redo'){ sayText('Avanti: ' + numPrefix(d.fenBefore) + A.itSan(mv.san) + '.'); renderList(); return; }
    if (!b){ cls[key] = {kind:'nd', num:numPrefix(d.fenBefore), san:A.itSan(mv.san)}; sayText('Mossa ' + numPrefix(d.fenBefore) + A.itSan(mv.san) + ': troppo veloce, Stockfish non aveva ancora finito di pensare.'); renderList(); return; }
    var it = {key:key, uci:uci, best:b.best, wpBest:wp(b.line), fenBefore:d.fenBefore, fenAfter:d.fenAfter, san:mv.san, to:mv.to, color:mv.color, sac:isSacrifice(mv)};
    // la mossa giocata è tra le 3 linee già calcolate: giudizio immediato
    var now = null;
    for (var i = 0; i < b.lines.length; i++) if (b.lines[i].pv && b.lines[i].pv[0] === uci){ now = wp(b.lines[i]); break; }
    if (now === null && A.game().isCheckmate()) now = 100;
    else if (now === null && A.game().isDraw()) now = 50;
    if (now !== null){ inMove = true; try { classify(it, now); } finally { inMove = false; } return; }
    pend.push(it); sayText('Mossa ' + numPrefix(d.fenBefore) + A.itSan(mv.san) + ': Stockfish la sta valutando…'); renderList();
  });
  document.addEventListener('cnp:analysis-undo', function(ev){
    var u = (ev.detail || {}).move; if (!u) return;
    redo.push({key:u.before + '|' + uciOf(u), from:u.from, to:u.to, promo:u.promotion, fen:u.before});
    hint = {fen:null, step:0}; hintWait = false; fwdWait = engWait = false;
    // rimetto il simbolo della mossa precedente
    var h = A.game().history({verbose:true}), l = h[h.length - 1];
    if (l){ var c = cls[l.before + '|' + uciOf(l)]; if (c && KIND[c.kind]) A.setBadge(l.to, KIND[c.kind].badge || c.kind); }
    sayText('Indietro di una mossa.');
    renderList();
  });
  document.addEventListener('cnp:analysis', function(ev){
    var d = ev.detail || {};
    if (!d.on){ if (on){ on = false; redo = []; pend = []; fwdWait = engWait = hintWait = false; hint = {fen:null, step:0}; } var t0 = $('tHint'); if (t0 && t0.dataset.anaOff){ t0.disabled = false; delete t0.dataset.anaOff; } return; }
    if (!on){ on = true; base = A.game().history().length; redo = []; pend = []; renderList(); }
    curFen = d.fen;
    if (d.line && !d.final) remember(partial, d.fen, d.line);
    if (d.final || d.over){
      remember(finals, d.fen, d.over ? {over:true, mate:d.mate} : {lines:d.lines, best:d.best});
      pend = pend.filter(function(it){
        if (it.fenAfter !== d.fen) return true;
        classify(it, d.over ? (d.mate ? 100 : 50) : 100 - wp(d.line));
        return false;
      });
      if (d.fen === A.game().fen()){
        if (fwdWait){ fwdWait = false; if (engWait){ engWait = false; engineMove(); } else forward(); }
        if (hintWait){ hintWait = false; doHint(true); }
      }
    }
    if (d.pending || d.final || d.over) sync();
  });

  // ---------- Avanti / Indietro ----------
  function forward(){
    var A2 = A, g = A2.game(); if (!A2.state.analysis) return; engWait = false;
    var r = redo[redo.length - 1];
    if (r && r.fen === g.fen()){ A2.analysisMove(r.from, r.to, r.promo, 'redo'); return; }
    if (g.isGameOver()){ sayText('La partita è finita: non ci sono altre mosse.'); return; }
    var f = finals[g.fen()];
    if (f && f.best){ A2.analysisMove(f.best.slice(0, 2), f.best.slice(2, 4), f.best[4], 'engine'); return; }
    fwdWait = true; sayText('Stockfish sta pensando alla sua mossa…'); sync();
  }
  // barra spaziatrice: Stockfish gioca SEMPRE la sua mossa migliore dalla posizione mostrata
  // (anche a metà linea: il seguito viene sostituito, come per una mossa fatta a mano)
  function engineMove(){
    var g = A.game(); if (!A.state.analysis || A.state.busy) return;
    if (g.isGameOver()){ sayText('La partita è finita: non ci sono altre mosse.'); return; }
    var f = finals[g.fen()];
    if (f && f.best){ A.analysisMove(f.best.slice(0, 2), f.best.slice(2, 4), f.best[4], 'engine'); return; }
    fwdWait = true; engWait = true; sayText('Stockfish sta pensando alla sua mossa…'); sync();
  }
  function back(){ if (A.state.analysis && A.game().history().length) A.analysisUndo(); }
  // salto a una mossa qualsiasi della linea (k = numero di semimosse giocate dall'inizio dell'esercizio)
  function badgeLast(){
    var h = A.game().history({verbose:true}), l = h[h.length - 1]; A.setBadge(null);
    if (l){ var c = cls[l.before + '|' + uciOf(l)]; if (c && KIND[c.kind]) A.setBadge(l.to, KIND[c.kind].badge || c.kind); }
  }
  function jumpTo(k){
    if (!A.state.analysis) return;
    var h = A.game().history().length;
    k = Math.max(0, Math.min(k, h + redo.length)); if (k === h) return;
    if (k === h - 1){ back(); return; }
    if (k === h + 1){ forward(); return; }
    A.ANA.batch = true;
    try {
      while (A.game().history().length > k) A.analysisUndo();
      while (A.game().history().length < k){ var r = redo[redo.length - 1]; if (!r || r.fen !== A.game().fen()) break; A.analysisMove(r.from, r.to, r.promo, 'redo'); }
    } finally { A.ANA.batch = false; }
    hint = {fen:null, step:0}; hintWait = false; fwdWait = engWait = false;
    badgeLast(); A.ANA.refresh();
    var n = A.game().history().length;
    sayText(n === 0 ? 'Posizione iniziale.' : !redo.length ? 'Fine della linea: «Avanti» fa giocare a Stockfish.' : 'Mossa ' + n + ' della linea.');
    renderList();
  }
  function toStart(){ jumpTo(0); }
  function toEnd(){ jumpTo(A.game().history().length + redo.length); }

  // ---------- suggerimento a tappe ----------
  var PN = {p:'pedone', n:'cavallo', b:'alfiere', r:'torre', q:'donna', k:'re'};
  function doHint(again){
    var g = A.game(), fen = g.fen();
    if (g.isGameOver()){ sayText('La partita è finita.'); return; }
    var f = finals[fen], best = f && f.best;
    if (!best){ var p = partial[fen]; if (p && p.depth >= 10 && p.pv) best = p.pv[0]; }
    if (!best){ hintWait = true; sayText('💡 Un attimo: Stockfish sta ancora pensando…'); return; }
    if (hint.fen !== fen) hint = {fen:fen, step:0};
    if (!again) hint.step = Math.min(3, hint.step + 1); else hint.step = Math.max(1, hint.step);
    var from = best.slice(0, 2), to = best.slice(2, 4), pc = g.get(from), m = {}, arr = [];
    m[from] = 'hint';
    if (hint.step >= 2) m[to] = 'hintto';
    if (hint.step >= 3) arr = [{from:from, to:to, brush:'blue'}];
    A.setMarks(m, arr);
    var who = pc ? PN[pc.type] : 'pezzo';
    if (hint.step === 1) sayText('💡 Aiuto 1/3: muovi il pezzo evidenziato (' + who + ' in ' + from + '). Premi di nuovo per vedere la casa.');
    else if (hint.step === 2) sayText('💡 Aiuto 2/3: ' + who + ' da ' + from + ' a ' + to + '. Premi ancora per la freccia.');
    else sayText('💡 Aiuto 3/3: la mossa migliore è ' + sanIt(fen, best) + '.');
    sync();
  }

  // ---------- intercetto i pulsanti durante l'analisi ----------
  document.addEventListener('click', function(ev){
    if (!A.state.analysis) return;
    var b = ev.target && ev.target.closest && ev.target.closest('#tHint,#anaFwd,#anaStart,#anaEnd,#fPrev,#fNext,#anaPlayed .apm[data-k]');
    if (!b) return;
    ev.preventDefault(); ev.stopPropagation();
    if (b.dataset && b.dataset.k) jumpTo(+b.dataset.k);
    else if (b.id === 'anaStart') toStart();
    else if (b.id === 'anaEnd') toEnd();
    else if (b.id === 'tHint') doHint(false);
    else if (b.id === 'anaFwd' || b.id === 'fNext') forward();
    else if (b.id === 'fPrev') back();
  }, true);
  function spaceKey(e){ return e.key === ' ' || e.key === 'Spacebar' || e.code === 'Space'; }
  function spaceOk(e){
    if (!A.state.analysis || e.ctrlKey || e.metaKey || e.altKey) return false;
    if (e.target && (/INPUT|TEXTAREA|SELECT/.test(e.target.tagName) || e.target.isContentEditable)) return false;
    if ((window.UI && UI.modalOpen && UI.modalOpen()) || (window.DD && DD.isOpen && DD.isOpen())) return false;
    if (e.target && e.target.closest && e.target.closest('.drawer,.modal,.dd-list,.dd,.msheet')) return false;
    return true;
  }
  // niente scorrimento della pagina e niente "clic" sul pulsante che ha il focus
  window.addEventListener('keydown', function(e){
    if (!spaceKey(e) || !spaceOk(e)) return;
    e.preventDefault(); e.stopImmediatePropagation();
    if (!e.repeat) engineMove();
  }, true);
  window.addEventListener('keyup', function(e){ if (spaceKey(e) && spaceOk(e)){ e.preventDefault(); e.stopImmediatePropagation(); } }, true);
  window.addEventListener('keydown', function(e){
    if (!A.state.analysis || e.ctrlKey || e.metaKey || e.altKey) return;
    if (e.target && /INPUT|TEXTAREA|SELECT/.test(e.target.tagName)) return;
    if (['ArrowLeft', 'ArrowRight', 'Home', 'End'].indexOf(e.key) < 0) return;
    if ((window.UI && UI.modalOpen && UI.modalOpen()) || (window.DD && DD.isOpen && DD.isOpen())) return;
    e.preventDefault(); e.stopImmediatePropagation();
    if (e.key === 'ArrowRight') forward(); else if (e.key === 'ArrowLeft') back(); else if (e.key === 'Home') toStart(); else toEnd();
  }, true);

  function sync(){
    var g = A.game(), fb = $('anaFwd'), r = redo[redo.length - 1];
    var canF = A.state.analysis && !g.isGameOver();
    if (fb){ fb.disabled = !canF; fb.classList.toggle('wait', fwdWait); fb.title = r && r.fen === g.fen() ? 'Avanti: rigioca la mossa annullata' : 'Avanti: Stockfish gioca la sua mossa migliore'; }
    var hl = g.history().length, nx = !!(r && r.fen === g.fen());
    if ($('anaStart')) $('anaStart').disabled = !A.state.analysis || !hl;
    if ($('anaUndo')) $('anaUndo').disabled = !A.state.analysis || !hl;
    if ($('anaEnd')) $('anaEnd').disabled = !A.state.analysis || !nx;
    if (A.state.analysis){
      var fp = $('fPrev'), fn = $('fNext'), fh = $('fHint');
      if (fp) fp.disabled = !g.history().length;
      if (fn) fn.disabled = !canF;
      if (fh) fh.disabled = !canF;
    }
    var th = $('tHint'); if (th) th.setAttribute('data-step', A.state.analysis && hint.fen === g.fen() ? hint.step : 0);
    // a partita finita in analisi non c'è aiuto da dare (anche nella fila della concentrazione moderna)
    if (th && A.state.analysis){ th.disabled = !canF; if (!canF) th.dataset.anaOff = '1'; else delete th.dataset.anaOff; }
  }

  // ---------- elenco delle mosse dell'analisi ----------
  function renderList(){
    var el = $('anaPlayed'); if (!el) return;
    var h = A.game().history({verbose:true}), out = [], items = [];
    h.forEach(function(m){ items.push({fen:m.before, uci:uciOf(m), san:A.itSan(m.san), color:m.color}); });
    var cur = items.length;
    // seguito della linea (mosse annullate che «Avanti» rigioca), in grigio
    for (var j = redo.length - 1; j >= 0; j--){ var r = redo[j]; items.push({fen:r.fen, uci:r.key.split('|')[1], san:sanIt(r.fen, r.key.split('|')[1]), color:r.fen.split(' ')[1], fut:true}); }
    items.forEach(function(m, i){
      var c = cls[m.fen + '|' + m.uci], k = c ? c.kind : 'nd', K = KIND[k];
      var num = (m.color === 'w' || i === 0) ? numPrefix(m.fen) : '';
      out.push('<span class="apm k-' + k + (i === cur - 1 ? ' last' : '') + (m.fut ? ' fut' : '') + '" data-k="' + (i + 1) + '" role="button" tabindex="-1" title="' + (K ? esc(K.name) + (c.bestSan && k !== 'best' && k !== 'bb' ? ' · meglio ' + esc(c.bestSan) : '') : k === 'eng' ? 'Mossa di Stockfish' : 'Vai a questa mossa') + '">' +
        (num ? '<i>' + num + '</i>' : '') + esc(m.san) + (K ? '<em>' + K.sym + '</em>' : k === 'eng' ? '<em class="eng">⚙</em>' : '') + '</span>');
    });
    el.innerHTML = out.length ? out.join(' ') : '<span class="apm-empty">Fai una mossa: Stockfish la giudicherà.</span>';
    var last = el.querySelector('.apm.last');
    if (last && last.scrollIntoView){ var t = last.offsetTop - el.offsetTop; if (t < el.scrollTop || t > el.scrollTop + el.clientHeight - 30) el.scrollTop = Math.max(0, t - 20); } else if (!last) el.scrollTop = 0;
    sync();
  }

  // per i test
  window.__analisi = {cls:cls, finals:finals, redo:function(){ return redo; }, wp:wp, forward:forward, engineMove:engineMove, back:back, jumpTo:jumpTo, toStart:toStart, toEnd:toEnd, hint:function(){ return hint; }, isSacrifice:isSacrifice};
})();
