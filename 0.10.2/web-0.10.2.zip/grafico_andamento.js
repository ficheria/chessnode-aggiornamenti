/* Chess Node · Grafico andamento della partita (ANTEPRIMA v3b 12-11 + prova integrata: grafico richiudibile, riepilogo compatto prima delle mosse, icone nuove, fumetto adattivo; solo fuori app).
   Disegno nostro (stile ragnatela dei Progressi). Codice proprietario di Kiko / Chess Node. Niente codice, costanti o grafica di Lichess.
   Regole (LISTA 01-11 e 08-11): solo la partita giocata (mai le varianti); valutazione dal lato del Bianco; matti = tetto fisso;
   pallini con gli STESSI colori delle icone dell'elenco mosse (classi apa-*, prese da CNAnalisiPartitaUI._commenti().lab);
   tocco su un pallino / sul grafico = posizione esatta; cursore sulla mossa attuale; sta sotto la scacchiera, mai sopra. */
(function(){
  'use strict';
  var H = 92, TETTO = 0, uid = 0;            // altezza del disegno in px; i matti vanno al bordo (tetto fisso), il resto resta tra 6% e 94%
  var SEGNA = {imprecisione:1, errore:1, svarione:1, geniale:1, forte:1};
  var CRITICO_GAP = 10, CRITICO_LOSS = 2;    // «momento critico» (proposta): una sola mossa buona (distacco ≥ 10 punti dalla seconda) e trovata (perdita ≤ 2)
  var VAL = {p:0, n:3, b:3, r:5, q:9, k:0};
  var NOMI = {imprecisione:'Imprecisione', errore:'Errore', svarione:'Blunder', geniale:'Geniale', forte:'Mossa forte', critico:'Momento critico'};
  function P(cp){ return window.CNPrecisione ? window.CNPrecisione.P(cp) : 50; }
  function rec(){ try { var s = window.CNAnalisiPartita.stato(); return s && s.rec && s.rec.fatto ? s.rec : null; } catch(e){ return null; } }
  function etichette(){ try { var c = window.CNAnalisiPartitaUI._commenti(); return c && c.lab; } catch(e){ return null; } }
  function partita(){
    var st = window.CNAnalisi.state(), c = new Chess(st.startFen), fens = [c.fen()];
    st.sans.forEach(function(s){ c.move(s); fens.push(c.fen()); });
    return {fens:fens, n:st.sans.length, ply:st.ply};
  }
  function pezzi(fen){   // materiale senza pedoni per colore + donne
    var o = {w:0, b:0, q:0, min0:0}, rows = fen.split(' ')[0].split('/');
    rows.forEach(function(r){ for (var i = 0; i < r.length; i++){ var ch = r[i]; if (/\d/.test(ch)) continue; var t = ch.toLowerCase(); o[ch === t ? 'b' : 'w'] += VAL[t]; if (t === 'q') o.q++; } });
    return o;
  }
  function minoriACasa(fen){   // cavalli e alfieri ancora sulle case di partenza
    var b = new Chess(fen), n = 0;
    [['b1','N','w'],['g1','N','w'],['c1','B','w'],['f1','B','w'],['b8','N','b'],['g8','N','b'],['c8','B','b'],['f8','B','b']].forEach(function(x){ var p = b.get(x[0]); if (p && p.type === x[1].toLowerCase() && p.color === x[2]) n++; });
    return n;
  }
  // fasi (regola nostra, da confermare): l'apertura finisce dopo l'ultima mossa di teoria quando restano al massimo 2 pezzi leggeri a casa, non prima dell'8ª mossa e non dopo la 15ª;
  // il finale inizia quando non ci sono donne e ognuno ha al massimo 13 punti di pezzi, oppure i pezzi in tutto sono ≤ 18 punti
  function fasi(p, lab){
    var lastBook = 0; (lab || []).forEach(function(l, i){ if (l === 'teoria') lastBook = i + 1; });
    var mg = null, fin = null;
    for (var k = Math.max(1, lastBook); k <= p.n; k++){ if ((minoriACasa(p.fens[k]) <= 2 && k >= 16) || k >= 30){ mg = k; break; } }
    for (var j = mg || 1; j <= p.n; j++){ var m = pezzi(p.fens[j]); if ((m.q === 0 && m.w <= 13 && m.b <= 13) || m.w + m.b <= 18){ fin = j; break; } }
    return {mg:mg, fin:fin};
  }
  function y(e, fen){
    var bianco = fen.split(' ')[1] === 'w';
    if (e.mate != null || e.over){ var vinceChiMuove = e.mate != null ? e.mate > 0 : false, vB = bianco ? vinceChiMuove : !vinceChiMuove;
      if (e.over && e.cp === 0) return {y:.5, m:0};
      return {y:vB ? TETTO : 1 - TETTO, m:1}; }
    var w = P((bianco ? 1 : -1) * e.cp);   // probabilità per il Bianco
    return {y:1 - (0.06 + 0.88 * w / 100), m:0};
  }
  function critici(r){
    var out = {}; if (!r || !r.V) return out;
    Object.keys(r.V).forEach(function(k){ var v = r.V[k]; if (v && (v.gap || 0) >= CRITICO_GAP && (v.loss || 0) <= CRITICO_LOSS) out[k] = 1; });
    return out;
  }
  var box = null, W = 0, geo = null, KCH = 'chessnodeplay-grafico-chiuso-v1';
  var CHEV = '<svg class="cng-ch" viewBox="0 0 24 24" width="16" height="16" aria-hidden="true"><path d="m6 15 6-6 6 6" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  function anim(){ var b = document.body.classList; return b.contains('anim-off') ? 'off' : b.contains('anim-reduced') ? 'reduced' : 'normal'; }
  function vediCorrente(){   // stessa regola della 22b: la riga della mossa attuale resta tutta visibile
    var mv = document.querySelector('#anPage .anp-moves'), c = mv && mv.querySelector('.cur'); if (!c) return;
    var row = c.closest('.anp-r') || c, bb = mv.getBoundingClientRect(), rb = row.getBoundingClientRect();
    if (rb.top < bb.top + 2) mv.scrollTop -= Math.ceil(bb.top - rb.top) + 6; else if (rb.bottom > bb.bottom - 2) mv.scrollTop += Math.ceil(rb.bottom - bb.bottom) + 6;
  }
  function apriChiudi(e){
    e.stopPropagation(); var ch = !box.classList.contains('chiuso'), a = anim();
    box.classList.remove('a-normal', 'a-reduced', 'a-off'); box.classList.add('a-' + a);
    box.classList.toggle('chiuso', ch);
    try { localStorage.setItem(KCH, ch ? '1' : '0'); } catch(x){}
    box.querySelector('.cng-bar').tabIndex = ch ? 0 : -1; box.querySelector('.cng-t').tabIndex = ch ? -1 : 0;
    (ch ? box.querySelector('.cng-bar') : box.querySelector('.cng-t')).focus({preventScroll:true});
    var fine = function(){ vediCorrente(); adattaFumetto(); }; setTimeout(fine, a === 'normal' ? 260 : a === 'reduced' ? 140 : 0);
  }
  function esc(s){ return String(s).replace(/[&<>"]/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]; }); }
  function disegna(){
    var root = document.getElementById('anPage'); if (!root || !root.classList.contains('anp-pm')) return;
    if (!box || !root.contains(box)){
      box = document.createElement('section'); box.className = 'cng'; box.setAttribute('aria-label', 'Andamento della partita');
      var mc = root.querySelector('.anp-mc'); mc.parentNode.insertBefore(box, mc);
      box.addEventListener('click', function(e){ if (e.target.closest('[data-t]')) return apriChiudi(e); if (!box.classList.contains('chiuso')) tocco(e); });
      try { if (localStorage.getItem(KCH) === '1') box.classList.add('chiuso'); } catch(e){}
    }
    var r = rec(), lab = etichette();
    if (!r || !lab){ box.hidden = true; return; } box.hidden = false;
    var p = partita(); W = Math.round((box.clientWidth || 368) - 2);   // v3: la scheda ha 1 px di bordo per lato
    var n = p.n, PX = 6, X = function(k){ return PX + k * (W - 2 * PX) / n; }, MID = H / 2;
    var pts = []; for (var k = 0; k <= n; k++){ var e = r.E[k]; pts.push(e ? y(e, p.fens[k]) : {y:.5, m:0}); }
    var Y = function(q){ return q.m ? (q.y < .5 ? 1.5 : H - 1.5) : 3 + q.y * (H - 6); };   // segmenti dritti tra i punti veri: nessuna curva che inventi valori
    var line = pts.map(function(q, k){ return (k ? 'L' : 'M') + X(k).toFixed(1) + ' ' + Y(q).toFixed(1); }).join(' ');
    var f = fasi(p, lab), cr = critici(r), dots = [], g = '', id = 'cng' + (++uid);
    g += '<defs>' +
      '<linearGradient id="' + id + 'n" gradientUnits="userSpaceOnUse" x1="0" y1="0" x2="0" y2="' + H + '"><stop offset="0" class="cng-n0"/><stop offset=".5" class="cng-n1"/><stop offset="1" class="cng-n2"/></linearGradient>' +
      '<linearGradient id="' + id + 'b" gradientUnits="userSpaceOnUse" x1="0" y1="' + H + '" x2="0" y2="0"><stop offset="0" class="cng-b0"/><stop offset=".5" class="cng-b1"/><stop offset="1" class="cng-b2"/></linearGradient>' +
      '<radialGradient id="' + id + 'l" cx=".35" cy=".3" r=".75"><stop offset="0" stop-color="#fff" stop-opacity=".55"/><stop offset=".55" stop-color="#fff" stop-opacity="0"/></radialGradient>' +
      '<filter id="' + id + 'g" x="-1" y="-1" width="3" height="3"><feGaussianBlur stdDeviation="1.6"/></filter>' +
      '<clipPath id="' + id + 'c"><rect x="0" y="0" width="' + W + '" height="' + H + '" rx="11"/></clipPath></defs>';
    g += '<g clip-path="url(#' + id + 'c)">';
    g += '<rect x="0" y="0" width="' + W + '" height="' + H + '" fill="url(#' + id + 'n)"/>';                                  // sopra la linea: meglio il Nero (scuro)
    g += '<path d="' + line + ' L' + W + ' ' + Y(pts[n]).toFixed(1) + ' L' + W + ' ' + H + ' L0 ' + H + ' L0 ' + Y(pts[0]).toFixed(1) + ' Z" fill="url(#' + id + 'b)"/>';   // sotto: meglio il Bianco (chiaro)
    g += '<line class="cng-mid" x1="0" y1="' + MID + '" x2="' + W + '" y2="' + MID + '"/>';
    [f.mg, f.fin].forEach(function(k){ if (k) g += '<line class="cng-fase" x1="' + X(k).toFixed(1) + '" y1="0" x2="' + X(k).toFixed(1) + '" y2="' + H + '"/>'; });
    g += '<path class="cng-l" d="' + line + '"/>';
    var cx = X(Math.min(p.ply, n));
    g += '<line class="cng-c" x1="' + cx.toFixed(1) + '" y1="0" x2="' + cx.toFixed(1) + '" y2="' + H + '"/>';
    var su = '';
    lab.forEach(function(cl, i){
      var c = SEGNA[cl] ? cl : (cr[i] ? 'critico' : null); if (!c) return;
      var q = pts[i + 1], x = X(i + 1), yy = Math.max(5, Math.min(H - 5, Y(q))), on = p.ply === i + 1, rr = on ? 5 : 3.6;
      dots.push({k:i + 1, x:x});
      var d = '<g class="cng-p ' + (c === 'critico' ? 'cng-cr' : 'apa-' + c) + (on ? ' on' : '') + '"><title>' + esc(NOMI[c]) + '</title>' +
        '<circle class="cng-glow" cx="' + x.toFixed(1) + '" cy="' + yy.toFixed(1) + '" r="' + (rr + 1.6) + '" filter="url(#' + id + 'g)"/>' +
        '<circle class="cng-d" cx="' + x.toFixed(1) + '" cy="' + yy.toFixed(1) + '" r="' + rr + '"/>' +
        '<circle cx="' + x.toFixed(1) + '" cy="' + yy.toFixed(1) + '" r="' + rr + '" fill="url(#' + id + 'l)"/></g>';
      if (on) su = d; else g += d;     // il pallino della mossa attuale sopra tutti
    });
    g += su + '</g>';
    var chiuso = box.classList.contains('chiuso');
    box.innerHTML = '<div class="cng-card"><button type="button" class="cng-bar" data-t="1" aria-expanded="false" tabindex="' + (chiuso ? 0 : -1) + '"><span>Andamento della partita</span>' + CHEV + '</button><svg class="cng-g" width="' + W + '" height="' + H + '" viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="Andamento: parte chiara in basso = meglio il Bianco, parte scura in alto = meglio il Nero. Tocca un punto per andare a quella mossa">' + g + '</svg></div>' +
      '<button type="button" class="cng-t" data-t="1" aria-expanded="true" aria-label="Chiudi il grafico" tabindex="' + (chiuso ? -1 : 0) + '"><i></i>' + CHEV + '</button>';
    geo = {n:n, W:W, X:X, PX:PX, dots:dots};
  }
  function tocco(e){
    if (!geo) return; var s = box.querySelector('.cng-g'); if (!s) return;
    var rc = s.getBoundingClientRect(), x = (e.clientX - rc.left) * geo.W / rc.width, best = null;
    geo.dots.forEach(function(d){ var dd = Math.abs(d.x - x); if (dd <= 12 && (!best || dd < best.dd)) best = {k:d.k, dd:dd}; });   // pallino vicino: si va proprio a quella mossa
    var k = best ? best.k : Math.round((x - geo.PX) / (geo.W - 2 * geo.PX) * geo.n);
    window.CNAnalisi.go(Math.max(0, Math.min(geo.n, k)));
    if (window.CNAnalisiRevisione && window.CNAnalisiRevisione.dalGrafico) window.CNAnalisiRevisione.dalGrafico();
  }

  /* ---------- riepilogo PRIMA dell'elenco mosse (v3, Kiko 12-11; v2 era sotto): precisione CNPrecisione già calcolata + conteggi per classe (stesse etichette dell'elenco) ---------- */
  var RIGHE = ['geniale', 'forte', 'migliore', 'ottima', 'buona', 'imprecisione', 'errore', 'svarione'];
  var NOMI2 = {geniale:'Geniale', forte:'Mossa forte', migliore:'Migliore', ottima:'Ottima', buona:'Buona', imprecisione:'Imprecisione', errore:'Errore', svarione:'Blunder', teoria:'Teoria', tranquilla:'Tranquilla', obbligata:'Mossa obbligata', nogiud:'Nessun giudizio'};
  var SYM2 = {geniale:'!!', forte:'!!', migliore:'!', ottima:'✓', buona:'✓', imprecisione:'?!', errore:'?', svarione:'??'};
  function badge(k){ var v = window.CNIconeMosse && window.CNIconeMosse.svg(k); return '<i class="apa-ic apa-' + k + '" title="' + NOMI2[k] + '" aria-label="' + NOMI2[k] + '">' + (v || SYM2[k]) + '</i>'; }   // v3b: icone nuove approvate (icone_mosse_12-11)
  var KRA = 'chessnodeplay-riepilogo-aperto-v1';
  function meta(){ try { return window.CNAnalisiPartitaUI && window.CNAnalisiPartitaUI.__meta || null; } catch(e){ return null; } }
  function riepilogo(){
    var r = rec(), lab = etichette(), mv = document.querySelector('#anPage.anp-pm .anp-moves'); if (!mv) return;
    var old = mv.querySelector('.cnr'); if (!r || !lab || !r.prec){ if (old) old.remove(); return; }
    var M = window.__cngMeta || {}, me = M.me || null, cnt = {w:{}, b:{}}, altro = {};
    lab.forEach(function(cl, i){ var c = i % 2 ? 'b' : 'w'; if (RIGHE.indexOf(cl) >= 0) cnt[c][cl] = (cnt[c][cl] || 0) + 1; else if (cl) altro[cl] = (altro[cl] || 0) + 1; });
    function nGiud(col){
      var n = 0;
      lab.forEach(function(cl, i){
        if ((i % 2 ? 'b' : 'w') !== col) return;
        if (cl && cl !== 'teoria' && cl !== 'obbligata' && cl !== 'nogiud') n++;
      });
      return n;
    }
    function pillElo(col, v){
      var fn = window.CNPunteggioPartita && window.CNPunteggioPartita.stima;
      if (!fn) return '';
      var elo = fn({precisione:v, mosse:nGiud(col)});
      if (elo == null) return '';
      return '<div class="cnr-elo" title="Stima nostra, provvisoria: da ricalibrare con la precisione"><span>' + elo + '</span><small>punteggio partita <i>provvisorio</i></small></div>';
    }
    // 13-11: nome visibile del personaggio (id interni invariati: 'nerd' resta l'id di Luca)
    function nomeBot(id){ var N = {chessnote:'Chess Node', paola:'Paola', nerd:'Luca', serena:'Nadia', maestro:'Prof'}; return N[id] || (String(id).charAt(0).toUpperCase() + String(id).slice(1)); }
    function chi(col, corto){
      var mio = me === col, nome = mio ? 'Tu' : (M.bot ? nomeBot(M.bot) : (col === 'w' ? 'Bianco' : 'Nero')), av = '';
      if (mio && window.__profilo){ try { av = window.__profilo.avatar(window.__profilo.get() || {}, 40); } catch(e){} }
      else if (!mio && M.bot) av = '<img class="cnr-im" alt="" src="istruttori/tondi/' + esc(M.bot) + '.webp">';
      if (!av) av = '<span class="cnr-im cnr-vuoto"></span>';
      var v = r.prec[col];
      if (corto) return '<span class="cnr-cp cnr-' + col + '">' + av + '<b>' + esc(nome) + '</b><em>' + (v == null ? '—' : v + '%') + '</em></span>';
      return '<div class="cnr-pl cnr-' + col + '">' + av + '<b>' + esc(nome) + '</b><small>' + (col === 'w' ? 'Bianco' : 'Nero') + '</small>' +
        '<div class="cnr-acc"><span>' + (v == null ? '—' : v + '%') + '</span><small>precisione</small></div>' + pillElo(col, v) + '</div>';
    }
    var ap = false; try { ap = localStorage.getItem(KRA) === '1'; } catch(e){}
    var cc = '<div class="cnr-corto"><div class="cnr-r1">' + chi('w', 1) + chi('b', 1) + '</div><div class="cnr-r2">' +
      ['imprecisione', 'errore', 'svarione'].map(function(k){ return '<span class="cnr-k apa-' + k + '">' + badge(k) + '<b>' + (cnt.w[k] || 0) + '</b><i class="cnr-dot">·</i><b>' + (cnt.b[k] || 0) + '</b></span>'; }).join('') +
      '<span class="cnr-piu">' + CHEV + '</span></div></div>';
    var h = '<div class="cnr-h">Riepilogo della partita<span class="cnr-meno">' + CHEV + '</span></div><div class="cnr-pls">' + chi('w') + chi('b') + '</div><div class="cnr-tab">';
    RIGHE.forEach(function(k){
      var a = cnt.w[k] || 0, z = cnt.b[k] || 0; if (k === 'forte' && !a && !z) return;   // «Mossa forte» solo se c'è
      h += '<div class="cnr-r apa-' + k + '"><b class="' + (a ? '' : 'z') + '">' + a + '</b><span class="cnr-c">' + badge(k) + '' + NOMI2[k] + '</span><b class="' + (z ? '' : 'z') + '">' + z + '</b></div>';
    });
    var al = Object.keys(altro).map(function(k){ return (NOMI2[k] || k) + ' ' + altro[k]; });
    h += '</div>' + (al.length ? '<p class="cnr-nota">Non contate qui: ' + esc(al.join(' · ')) + '</p>' : '');
    if (!old){ old = document.createElement('section'); old.className = 'cnr'; old.setAttribute('role', 'button'); old.tabIndex = 0;
      old.addEventListener('click', function(){ var a = !old.classList.contains('aperto'); old.classList.toggle('aperto', a); old.setAttribute('aria-expanded', a); try { localStorage.setItem(KRA, a ? '1' : '0'); } catch(e){} });
      old.addEventListener('keydown', function(e){ if (e.key === 'Enter' || e.key === ' '){ e.preventDefault(); old.click(); } }); }
    old.classList.toggle('aperto', ap); old.setAttribute('aria-expanded', ap);
    old.setAttribute('aria-label', 'Riepilogo della partita: tocca per ' + (ap ? 'chiudere' : 'vedere tutto'));
    h = cc + '<div class="cnr-tutto">' + h + '</div>';
    old.innerHTML = h; if (mv.firstChild !== old) mv.insertBefore(old, mv.firstChild);
    if (!mv.__cnrObs){ mv.__cnrObs = new MutationObserver(function(){ if (!mv.querySelector('.cnr')) riepilogo(); }); mv.__cnrObs.observe(mv, {childList:true}); }
  }
  // v3: all'inizio della partita (mossa 0) l'elenco torna in cima, così si vede il riepilogo; dalla 1ª mossa in poi vale lo scorrimento di sempre
  function inCima(){ try { if (window.CNAnalisi.state().ply === 0){ var mv = document.querySelector('#anPage.anp-pm .anp-moves'); if (mv) mv.scrollTop = 0; } } catch(e){} }
  // Prova integrata 12-11: spazio adattivo per il fumetto + segno «altro» se il testo non entra (mai sopra la scacchiera)
  var CHEV2 = '<svg class="cng-ch" viewBox="0 0 24 24" width="12" height="12" aria-hidden="true"><path d="m6 15 6-6 6 6" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  function misureFumetto(bub){
    var cs = getComputedStyle(bub), padT = parseFloat(cs.paddingTop) || 0, padB = parseFloat(cs.paddingBottom) || 0;
    var fs = parseFloat(cs.fontSize) || 14, lh = parseFloat(cs.lineHeight);
    if (!isFinite(lh) || lh <= 0) lh = Math.round(fs * 1.4);
    var bh = bub.querySelector('.anp-bh'), head = 0;
    if (bh){ var m = getComputedStyle(bh); head = bh.getBoundingClientRect().height + (parseFloat(m.marginTop) || 0) + (parseFloat(m.marginBottom) || 0); }
    var bordo = (parseFloat(cs.borderTopWidth) || 0) + (parseFloat(cs.borderBottomWidth) || 0);
    var chrome = padT + padB + head + (cs.boxSizing === 'border-box' ? bordo : 0);
    return {padT:padT, padB:padB, lh:lh, head:head, chrome:chrome};
  }
  function altezzaRigheIntere(bub, maxH){   // altezza massima fatta di righe intere (niente testo tagliato a metà)
    var m = misureFumetto(bub), n = Math.max(1, Math.floor((maxH - m.chrome + 0.01) / m.lh));
    return Math.round(m.chrome + n * m.lh);
  }
  function segniFumetto(bub){
    var fade = bub.querySelector('.anp-bub-fade');
    if (!fade){ fade = document.createElement('span'); fade.className = 'anp-bub-fade'; fade.setAttribute('aria-hidden', 'true'); }
    bub.appendChild(fade);
    var mo = bub.querySelector('.anp-bmore');
    if (!mo){
      mo = document.createElement('span'); mo.className = 'anp-bmore'; mo.setAttribute('aria-hidden', 'true');
      mo.innerHTML = CHEV2 + 'altro';
      if (!bub.__cngMore){ bub.__cngMore = 1; bub.addEventListener('scroll', function(){ segnoAltro(bub); }); }
    }
    bub.appendChild(mo);
    if (!bub.__cngObs){
      bub.__cngObs = new MutationObserver(function(){
        if (!bub.querySelector('.anp-bmore') || !bub.querySelector('.anp-bub-fade')){ segniFumetto(bub); segnoAltro(bub); }
      });
      bub.__cngObs.observe(bub, {childList:true});
    }
  }
  function adattaFumetto(){
    var root = document.getElementById('anPage'); if (!root || !root.classList.contains('anp-pm')) return;
    var bub = root.querySelector('.anp-bub'); if (!bub) return;
    // Schermata B (08b): il fumetto usa la zona --v6ch e può salire nello spazio --v6off (mai verso la scacchiera).
    if (root.classList.contains('anp-rev-b')){
      var coach = root.querySelector('.anp-coach'), top = root.querySelector('.anp-top');
      if (!coach) return;
      bub.style.maxHeight = '';
      var cs = getComputedStyle(coach), pb = parseFloat(cs.paddingBottom) || 0, pt = parseFloat(cs.paddingTop) || 0;
      var avail = coach.clientHeight - pt - pb;
      var tb = top && top.offsetParent ? top.getBoundingClientRect().bottom : 0;
      var maxH = Math.max(avail, Math.floor(coach.getBoundingClientRect().bottom - pb - tb - 8));
      if (maxH > 24) bub.style.maxHeight = altezzaRigheIntere(bub, maxH) + 'px';
      segniFumetto(bub); segnoAltro(bub);
      return;
    }
    bub.style.maxHeight = '';   // prima il massimo di CSS (112 px), poi si scende per righe intere se serve
    var mv = root.querySelector('.anp-moves'), cnr = root.querySelector('.cnr');
    var corto = cnr && cnr.querySelector('.cnr-corto');
    var need = (corto && !cnr.classList.contains('aperto')) ? Math.max(80, corto.offsetHeight + 14) : 80;
    var have = mv ? mv.clientHeight : 0;
    var cap = 112;
    if (mv && have < need) cap = Math.min(cap, bub.getBoundingClientRect().height - (need - have));
    bub.style.maxHeight = altezzaRigheIntere(bub, cap) + 'px';
    segniFumetto(bub);
    segnoAltro(bub);
    requestAnimationFrame(function(){
      if (mv && cnr && !cnr.classList.contains('aperto')){
        var r2 = cnr.querySelector('.cnr-r2'), bb = mv.getBoundingClientRect();
        if (r2 && r2.getBoundingClientRect().bottom > bb.bottom + 1){
          bub.style.maxHeight = altezzaRigheIntere(bub, bub.getBoundingClientRect().height - 1) + 'px';
        }
      }
      segniFumetto(bub);
      segnoAltro(bub);
    });
    setTimeout(function(){ segniFumetto(bub); segnoAltro(bub); }, 50);
  }
  function segnoAltro(bub){
    var mo = bub.querySelector('.anp-bmore'); if (mo) mo.hidden = true;
    var more = bub.scrollHeight - bub.clientHeight - bub.scrollTop > 3;
    if (mo) mo.hidden = !more;
    bub.classList.toggle('anp-bub-piu', more);
  }
  // meta della partita (chi sono io, il bot): presa da CNAnalisi.open
  (function avvolgi(){ var A = window.CNAnalisi; if (!A || A.__cng) return setTimeout(avvolgi, 200);
    var o = A.open; A.open = function(x){ window.__cngMeta = x && x.partita || {}; return o.apply(this, arguments); }; A.__cng = 1; })();
  // aggancio: ridisegno a ogni render della 22b (solo anteprima; nell'app andrà dentro analisi_commenti.js)
  function aggancia(){
    var U = window.CNAnalisiPartitaUI; if (!U || U.__cng) return setTimeout(aggancia, 200);
    var o = U.onRender; U.onRender = function(){ var r = o.apply(this, arguments); try { disegna(); riepilogo(); inCima(); adattaFumetto(); } catch(e){ console.error('cng', e); } return r; }; U.__cng = 1;
  }
  aggancia(); window.addEventListener('resize', function(){ try { disegna(); adattaFumetto(); } catch(e){} });
  window.CNGrafico = {disegna:disegna, riepilogo:riepilogo, adattaFumetto:adattaFumetto, fasi:function(){ var p = partita(); return fasi(p, etichette()); }};
})();
