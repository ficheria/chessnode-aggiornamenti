/* Chess Node · «Collega i tuoi profili» (Kiko t1947u, 14-11). Un solo riquadro riusato in Home, Il tuo gioco / profilo,
   Impostazioni › Profilo e account e fine Primo avvio. La logica vera sta nella pagina principale (analisi/cnap_app.js:
   __cnap.avviaCollega / pausaCollega / riprendiCollega / statoCollega): qui solo disegno, nomi precompilati e avanzamento.
   CNCollega.monta(el, {modo:'home'|'pagina'|'impostazioni'|'primo', onAvviato}) → si aggiorna da solo ogni secondo. */
(function (W) {
  'use strict';
  function cnap(){ try { return (W.parent && W.parent !== W && W.parent.__cnap) || W.__cnap || null; } catch (e) { return W.__cnap || null; } }
  function esc(s){ return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function rd(k){ try { return JSON.parse(localStorage.getItem(k) || 'null'); } catch (e) { return null; } }
  function ic(n, s){ return (W.CNP && W.CNP.ic) ? W.CNP.ic(n, s || 20) : ''; }
  function toast(t){ if (W.CNP && W.CNP.toast) W.CNP.toast(t); }
  var SITO = { lichess: 'Lichess', chesscom: 'Chess.com' };

  function stato(){
    var x = cnap();
    if (x && typeof x.statoCollega === 'function') { try { return x.statoCollega(); } catch (e) {} }
    var a = rd('chessnodeplay-account-v1') || {}, s = rd('chessnodeplay-collega-v1') || {};
    return { fase: s.fase || 'mai', nomi: s.nomi || { lichess: a.lichess || '', chesscom: a.chesscom || '' }, collegati: s.fase === 'analisi' || s.fase === 'fatto', analisi: { fatte: s.fatte || 0, totale: s.totale || 0 }, errori: s.errori || [], mese: s.mese || 0, mesiTot: 12, partite: s.partite || 0, anteprima: true };
  }
  /* visibile in Home solo finché i profili non sono collegati (import finito almeno una volta) */
  function daMostrareInHome(){ return !stato().collegati; }

  function barra(pct){ pct = Math.max(0, Math.min(100, Math.round(pct))); return '<div class="cp-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="' + pct + '"><i style="width:' + pct + '%"></i></div>'; }
  function clessidra(){ return '<span class="cp-cl" aria-hidden="true"><svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M6 3h12M6 21h12M7 3c0 5 10 5 10 9s-10 4-10 9M17 3c0 5-10 5-10 9s10 4 10 9"/></svg></span>'; }

  function corpo(st, o){
    var f = st.fase, h = '';
    if (f === 'import') {
      var nomeS = SITO[st.sito] || 'i siti', pct = 100 * (st.mese || 0) / (st.mesiTot || 12);
      if (st.inPausa) return '<p class="cp-st"><b>In pausa</b> · scaricamento da ' + esc(nomeS) + ' fermo al mese ' + (st.mese || 0) + ' di ' + (st.mesiTot || 12) + '</p>' + barra(pct) +
        '<div class="cp-az"><button type="button" class="btn cp-go" data-cp="riprendi">Riprendi</button></div>';
      return '<p class="cp-st">' + clessidra() + '<span>Scarico le partite da <b>' + esc(nomeS) + '</b> · mese ' + (st.mese || 0) + ' di ' + (st.mesiTot || 12) + (st.partite ? ' · <b class="cp-n">' + st.partite + '</b> partite' : '') + '</span></p>' + barra(pct) +
        '<div class="cp-az"><button type="button" class="btn sec cp-sec" data-cp="pausa">Pausa</button></div>' +
        '<p class="cp-nota">Serve Internet solo per scaricarle. Poi l\'analisi continua sul telefono, solo con l\'app aperta.</p>';
    }
    if (f === 'analisi' || f === 'fatto') {
      var a = st.analisi || {}, tot = a.totale || 0, fa = Math.min(a.fatte || 0, tot), pc = tot ? 100 * fa / tot : 0;
      if (f === 'fatto' || (tot && fa >= tot)) h = '<p class="cp-st cp-ok">' + ic('check', 20) + '<span><b>Profili collegati</b> · ' + fa + ' partite analizzate</span></p>';
      else if (st.inPausa) h = '<p class="cp-st"><b>Analisi in pausa</b> · ' + fa + ' di ' + tot + ' partite</p>' + barra(pc) + '<div class="cp-az"><button type="button" class="btn cp-go" data-cp="riprendi">Riprendi</button></div>';
      else h = '<p class="cp-st">' + clessidra() + '<span>Analizzo le tue partite · <b class="cp-n">' + fa + '</b> di ' + tot + '</span></p>' + barra(pc) +
        '<div class="cp-az"><button type="button" class="btn sec cp-sec" data-cp="pausa">Pausa</button></div><p class="cp-nota">Sul telefono: può consumare batteria e scaldarlo. Riprende da dove era quando riapri l\'app.</p>';
      var n = st.nomi || {};
      h += '<p class="cp-nota">' + [n.lichess ? 'Lichess: ' + esc(n.lichess) : '', n.chesscom ? 'Chess.com: ' + esc(n.chesscom) : ''].filter(Boolean).join(' · ') + '</p>';
      if (o.modo === 'impostazioni' && (f === 'fatto' || (tot && fa >= tot))) h += '<div class="cp-az"><button type="button" class="btn sec cp-sec" data-cp="aggiorna">Cerca partite nuove</button></div>';
      return h;
    }
    /* mai / errore: modulo con i nomi precompilati */
    var nm = st.nomi || {};
    h = '<p class="cp-tx">Importiamo le tue partite pubbliche degli ultimi 12 mesi e le analizziamo sul telefono: punti forti, cosa migliorare, aperture e andamento.</p>' +
      (o.nomiDa ? '<p class="cp-tx">Usa i nomi scritti qui sopra.</p>' : '<label class="ip-l">Lichess username<input class="inp" data-cpn="lichess" maxlength="30" placeholder="Nome utente Lichess" value="' + esc(nm.lichess || '') + '" autocomplete="off" autocapitalize="off" spellcheck="false"></label>' +
      '<label class="ip-l">Chess.com username<input class="inp" data-cpn="chesscom" maxlength="25" placeholder="Nome utente Chess.com" value="' + esc(nm.chesscom || '') + '" autocomplete="off" autocapitalize="off" spellcheck="false"></label>') +
      (f === 'errore' && st.errore ? '<p class="cp-err" role="status">' + esc(st.errore) + '</p>' : '<p class="cp-err" role="status" hidden></p>') +
      '<div class="cp-az"><button type="button" class="btn cp-go" data-cp="avvia">' + ic('v2-importa', 20) + 'Analizza le mie partite</button></div>' +
      '<p class="cp-nota">Solo partite pubbliche, nessuna password. Puoi mettere in pausa quando vuoi.</p>';
    return h;
  }

  function monta(el, o){
    o = o || {};
    if (!el) return null;
    var firma = '';
    function sig(st){ var a = st.analisi || {}; return [st.fase, st.inPausa, st.sito, st.mese, st.partite, a.fatte, a.totale, st.errore].join('|'); }
    function disegna(forza){
      var st = stato(), s = sig(st);
      if (o.modo === 'home' && st.collegati && st.fase === 'fatto') { el.hidden = true; return; }
      if (!forza && s === firma) return;
      /* non ridisegnare mentre l'utente scrive nel modulo */
      if (!forza && el.contains(document.activeElement) && document.activeElement.matches('input') && (st.fase === 'mai' || st.fase === 'errore')) return;
      firma = s; el.hidden = false;
      var testa = o.senzaTitolo ? '' : '<div class="cp-h"><span class="cp-ri">' + ic('v2-importa', 22) + '</span><b>Collega i tuoi profili</b></div>';
      el.innerHTML = testa + corpo(st, o);
    }
    el.classList.add('cp');
    el.addEventListener('click', function (ev) {
      var b = ev.target.closest('[data-cp]'); if (!b) return;
      var x = cnap(), az = b.dataset.cp;
      if (!x || typeof x.avviaCollega !== 'function') { toast('Disponibile nell\'app.'); return; }
      if (az === 'avvia' || az === 'aggiorna') {
        var nomi = { lichess: '', chesscom: '' };
        if (az === 'avvia' && o.nomiDa) nomi = o.nomiDa();
        else if (az === 'avvia') [].forEach.call(el.querySelectorAll('[data-cpn]'), function (i) { nomi[i.dataset.cpn] = i.value.trim(); });
        else nomi = stato().nomi;
        var r = x.avviaCollega(nomi);
        if (!r || !r.ok) { var e = el.querySelector('.cp-err'); if (e) { e.hidden = false; e.textContent = (r && r.testo) || 'Non riesco a partire.'; } return; }
        disegna(true); if (o.onAvviato) o.onAvviato();
      } else if (az === 'pausa') { x.pausaCollega(); disegna(true); }
      else if (az === 'riprendi') { x.riprendiCollega(); disegna(true); }
    });
    disegna(true);
    var t = setInterval(function () { if (!document.body.contains(el)) { clearInterval(t); return; } disegna(false); }, 1000);
    return { aggiorna: function () { disegna(true); } };
  }

  W.CNCollega = { monta: monta, stato: stato, daMostrareInHome: daMostrareInHome };
})(window);
