# Stampo unico delle scacchiere (14-11)

File: `stampo_scacchiera.js` (window.CNStampo) + `stampo_scacchiera.css`. Caricati in `index.html` dopo `condividi.js`.

Decide le cose COMUNI a tutte le scacchiere a tutta pagina, con le misure COPIATE dall'esercizio (esercizio_v6.js `fit()`, layout 08b):

| Pezzo comune | Funzione |
|---|---|
| y di partenza, lato, zona fumetto, area sicura | `CNStampo.misure(W,H)` → `{top, bh, coachH, botH, need, barra:6}`; `CNStampo.allinea({root, zona, wrap, scroll, board, maxLato, latoFisso})` |
| animazioni Attive/Ridotte/Spente | `CNStampo.moto()` → 0 / 1 / 2 |
| menu «⋯» (foglio dal basso come il ⋯ dell'esercizio) | `CNStampo.menu({titolo, voci:[{id,testo,sub,icona}], gruppi:[[...]], scegli(id)})` |
| Condividi (PGN, Immagine, GIF) | `CNStampo.condividi(src, tab)` → `CNShare.open(tab, src)`; `src = {fen0, sans, ply, orient, titolo, sub, etichetta, nome, tags}` |
| Aiuto a 2 livelli | `CNStampo.aiuto({mossa, pezzo, casa, conta, testo})` → `{tocca, azzera, livello, primoColpo}` (1 = pezzo, gratis; 2 = casa, toglie «al primo colpo») |
| premove | `CNStampo.premove` (= premove.js) |

## Nuova scacchiera (es. finali, trappole)

```js
var st = CNStampo.crea('finali', {root: el, zona: '.fz', wrap: '.fw', scroll: '.fs', board: '.fb',
  aiuto: true, valutazione: false, premove: true, condividi: true, motore: false});
st.allinea();                                   // dopo ogni render e al resize
st.menu({titolo: 'Altro', voci: [{id: 'share', testo: 'Condividi', icona: 'share-2'}], scegli: function(id){ ... }});
st.condividi({fen0: fen, sans: mosse, titolo: 'Finale 12'});
var aiuto = CNStampo.aiuto({mossa: function(){ return {from, to, piece}; }, pezzo: ..., casa: ..., conta: ...});
```

Il root riceve le classi `cn-st`, `cn-st-<nome>` e `cn-st-<pezzo>` per i pezzi accesi.

## Chi lo usa

- Scacchiera di analisi libera e analisi della partita (`analisi_pagina.js`): allinea, menu ⋯, Condividi.
- Revisione della partita (`analisi_revisione.js`): misure (`CNAllinea.exTop` = alias di `CNStampo.misure`).
- Puzzle Random (`puzzle_misti.js`): schermata dell'esercizio; Aiuto = `__app.hint`, Condividi dal ⋯ dell'esercizio.
- Partite contro i bot (`bot.js`): allinea, menu ⋯, Condividi (anche a fine partita).
- NON gli esercizi di tattica: «DA FARE CON RISERVA» in LISTA.md (giro a parte, con conferma di Kiko).
