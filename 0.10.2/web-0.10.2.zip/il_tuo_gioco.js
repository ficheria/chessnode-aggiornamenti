/* Chess Node · «Il tuo gioco» — colpo d'occhio (Kiko t1946u/t1948u, 14-11): 3 numeri, 1 punto forte, 1 da migliorare,
   ultimo progresso e grafico mese per mese. Dati VERI dal profilo dell'analisi profonda (CN.profilo.calcola, ambito self);
   nessun numero inventato: se mancano dati, stato vuoto. Tocco → «Il mio profilo scacchistico» (pagina completa).
   CNTuoGioco.riassunto() → Promise<dati|null> · CNTuoGioco.card(dati, stCollega) → HTML del corpo della card. */
(function (W) {
  'use strict';
  var TEMI = { pezzo_indifeso: 'Pezzi indifesi', forchetta: 'Forchette', inchiodatura: 'Inchiodature', infilata: 'Infilate', matto_non_visto: 'Matti non visti', scoperta: 'Attacchi di scoperta', difesa: 'Difesa' };
  var FASI = { apertura: 'Apertura', mediogioco: 'Mediogioco', finale: 'Finale' };
  var MESI = ['gen', 'feb', 'mar', 'apr', 'mag', 'giu', 'lug', 'ago', 'set', 'ott', 'nov', 'dic'];
  function cnap(){ try { return (W.parent && W.parent !== W && W.parent.__cnap) || W.__cnap || null; } catch (e) { return W.__cnap || null; } }
  function esc(s){ return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function num(x, d){ return x == null ? '—' : String(Math.round(x * (d ? 10 : 1)) / (d ? 10 : 1)).replace('.', ','); }
  function meseCorto(ym){ var p = String(ym || '').split('-'); return MESI[(+p[1] || 1) - 1] || ym; }
  function meseLungo(ym){ var L = ['gennaio', 'febbraio', 'marzo', 'aprile', 'maggio', 'giugno', 'luglio', 'agosto', 'settembre', 'ottobre', 'novembre', 'dicembre'], p = String(ym || '').split('-'); return L[(+p[1] || 1) - 1] || ym; }

  function precFase(p, k){
    var t = p.tecnica || {};
    if (k === 'mediogioco') return t.mediogioco && t.mediogioco.precisione && !t.mediogioco.pochiDati ? t.mediogioco.precisione.valore : null;
    var rows = k === 'finale' ? (t.finali || []).map(function (f) { return f.pochiDati ? null : f.precisione && f.precisione.valore; })
      : [].concat((t.aperture && t.aperture.bianco) || [], (t.aperture && t.aperture.nero) || []).map(function (r) { return r.pochiDati ? null : r.precisionePrimeMosse && r.precisionePrimeMosse.valore; });
    rows = rows.filter(function (v) { return v != null; });
    return rows.length ? rows.reduce(function (a, b) { return a + b; }, 0) / rows.length : null;
  }

  function sintesi(p){
    if (!p || !p.copertura) return null;
    var cop = p.copertura, tot = (p.risultati && p.risultati.totale) || {};
    /* mesi: righe per ritmo/sito → una colonna per mese (partite, precisione pesata sulle analizzate) */
    var per = {};
    ((p.mesi && p.mesi.righe) || []).forEach(function (r) {
      var m = per[r.mese] = per[r.mese] || { mese: r.mese, partite: 0, an: 0, accW: 0, accN: 0, inCorso: r.inCorso };
      m.partite += r.partite || 0; m.an += r.analizzate || 0;
      if (r.precisione != null && r.analizzate) { m.accW += r.precisione * r.analizzate; m.accN += r.analizzate; }
    });
    var serie = Object.keys(per).sort().slice(-6).map(function (k) { var m = per[k]; return { mese: k, partite: m.partite, prec: m.accN ? m.accW / m.accN : null, inCorso: m.inCorso }; });
    var aW = 0, aN = 0; Object.keys(per).forEach(function (k) { aW += per[k].accW; aN += per[k].accN; });
    var tat = (p.tecnica && p.tecnica.tattica) || {}, forte = null, debole = null;
    if (tat.puntiForti && tat.puntiForti[0]) { var f0 = tat.puntiForti[0]; forte = { t: TEMI[f0.tema] || f0.tema, s: f0.prese + ' occasioni prese su ' + f0.occasioni }; }
    var deb = (tat.temi || []).filter(function (x) { return x.confermato; })[0];
    if (deb) debole = { t: TEMI[deb.tema] || deb.tema, s: deb.errori + ' occasioni mancate su ' + deb.occasioni, cap: deb.capitolo && deb.capitolo.id };
    if (!p.pochiDati && (!forte || !debole)) {
      var fasi = ['apertura', 'mediogioco', 'finale'].map(function (k) { return { k: k, v: precFase(p, k) }; }).filter(function (x) { return x.v != null; }).sort(function (a, b) { return b.v - a.v; });
      if (fasi.length >= 2) {
        if (!forte) forte = { t: FASI[fasi[0].k], s: 'precisione ' + num(fasi[0].v, 1) + '%' };
        if (!debole) debole = { t: FASI[fasi[fasi.length - 1].k], s: 'precisione ' + num(fasi[fasi.length - 1].v, 1) + '%' };
      }
    }
    var conf = ((p.mesi && p.mesi.confronti) || []).filter(function (c) { return c.esito === 'migliorata' || c.esito === 'peggiorata' || c.esito === 'stabile'; })[0], prog = null;
    if (conf) prog = { su: conf.esito === 'migliorata', giu: conf.esito === 'peggiorata', t: conf.esito === 'stabile' ? 'Precisione stabile in ' + meseLungo(conf.mese) : 'Precisione ' + (conf.differenza > 0 ? '+' : '−') + num(Math.abs(conf.differenza), 1) + ' punti in ' + meseLungo(conf.mese) };
    else if (serie.length) { var u = serie[serie.length - 1]; prog = { t: (u.inCorso ? 'Questo mese: ' : meseLungo(u.mese) + ': ') + u.partite + (u.partite === 1 ? ' partita' : ' partite') }; }
    return { partite: cop.partite || 0, analizzate: cop.analizzate || 0, vittorie: tot.percentualeVittorie, precisione: aN ? aW / aN : null, forte: forte, debole: debole, progresso: prog, serie: serie, pochi: !!p.pochiDati };
  }

  function riassunto(){
    return new Promise(function (ok) {
      var giri = 0;
      (function prova(){
        var x = cnap();
        if (x && x.CN && x.CN.profilo && typeof x.CN.profilo.calcola === 'function') {
          x.CN.profilo.calcola({ periodo: 'tutto', scope: 'self' }).then(function (p) { ok(sintesi(p)); }, function () { ok(null); });
          return;
        }
        if (x && x.stato === 'errore') { ok(null); return; }
        if (++giri > 40) { ok(null); return; }   // ~10 s: archivio non pronto → stato vuoto
        setTimeout(prova, 250);
      })();
    });
  }

  function grafico(serie){
    var w = 132, h = 64, n = serie.length; if (!n) return '';
    var maxP = Math.max.apply(null, serie.map(function (s) { return s.partite; }).concat([1]));
    var bw = Math.min(16, (w - 8) / n - 6), gap = (w - n * bw) / (n + 1), pts = [];
    var precs = serie.map(function (s) { return s.prec; }).filter(function (v) { return v != null; });
    var lo = precs.length ? Math.min.apply(null, precs) - 4 : 0, hi = precs.length ? Math.max.apply(null, precs) + 4 : 1;
    var sv = '<svg class="itg-g" viewBox="0 0 ' + w + ' ' + (h + 12) + '" role="img" aria-label="Partite e precisione negli ultimi mesi">';
    serie.forEach(function (s, i) {
      var x = gap + i * (bw + gap), bh = Math.max(3, (h - 6) * s.partite / maxP);
      sv += '<rect x="' + x.toFixed(1) + '" y="' + (h - bh).toFixed(1) + '" width="' + bw.toFixed(1) + '" height="' + bh.toFixed(1) + '" rx="3"' + (s.inCorso ? ' class="cur"' : '') + '/>';
      sv += '<text x="' + (x + bw / 2).toFixed(1) + '" y="' + (h + 10) + '">' + meseCorto(s.mese) + '</text>';
      if (s.prec != null) pts.push([x + bw / 2, 6 + (h - 18) * (1 - (s.prec - lo) / Math.max(1, hi - lo))]);
    });
    if (pts.length > 1) sv += '<path d="M' + pts.map(function (p) { return p[0].toFixed(1) + ' ' + p[1].toFixed(1); }).join(' L') + '" fill="none"/>';
    pts.forEach(function (p) { sv += '<circle cx="' + p[0].toFixed(1) + '" cy="' + p[1].toFixed(1) + '" r="2.6"/>'; });
    return sv + '</svg>';
  }

  function card(d, stC){
    if (!d || !d.partite) {
      var inCorso = stC && (stC.fase === 'import' || stC.fase === 'analisi');
      return '<div class="itg-vuoto"><svg class="itg-g itg-g0" viewBox="0 0 132 76" aria-hidden="true"><rect x="10" y="40" width="14" height="24" rx="3"/><rect x="34" y="28" width="14" height="36" rx="3"/><rect x="58" y="36" width="14" height="28" rx="3"/><rect x="82" y="16" width="14" height="48" rx="3"/><rect x="106" y="24" width="14" height="40" rx="3"/><path d="M17 34 41 22 65 30 89 10 113 18" fill="none"/></svg>' +
        '<p>' + (inCorso ? 'Sto preparando il tuo quadro: le prime partite stanno arrivando.' : 'Collega Lichess o Chess.com, oppure analizza le tue partite con i bot: qui vedrai numeri e grafici del tuo gioco.') + '</p></div>';
    }
    var h = '<div class="itg-num">' +
      '<div><b>' + d.partite + '</b><span>partite</span></div>' +
      '<div><b>' + (d.vittorie == null ? '—' : num(d.vittorie) + '%') + '</b><span>vittorie</span></div>' +
      '<div><b>' + (d.precisione == null ? '—' : num(d.precisione) + '%') + '</b><span>precisione</span></div></div>';
    var fd = (d.forte || d.debole) ?
      '<p class="itg-f"><i class="su" aria-hidden="true"></i><span><small>Punto forte</small><b>' + esc(d.forte ? d.forte.t : '—') + '</b></span></p>' +
      '<p class="itg-f"><i class="giu" aria-hidden="true"></i><span><small>Da migliorare</small><b>' + esc(d.debole ? d.debole.t : '—') + '</b></span></p>'
      : '<p class="itg-f"><i class="su" aria-hidden="true"></i><span><small>Punti forti e da migliorare</small><b>' + (d.analizzate ? 'Servono più partite analizzate' : 'Dopo l\'analisi delle partite') + '</b></span></p>';
    h += '<div class="itg-mid">' + grafico(d.serie) + '<div class="itg-fd">' + fd + '</div></div>';
    if (d.progresso) h += '<p class="itg-pr' + (d.progresso.su ? ' su' : d.progresso.giu ? ' giu' : '') + '">' + esc(d.progresso.t) + '</p>';
    return h;
  }

  W.CNTuoGioco = { riassunto: riassunto, sintesi: sintesi, card: card, grafico: grafico };
})(window);
