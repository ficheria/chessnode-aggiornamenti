/* Grande aggiornamento, blocco 4 (11-11): pagina d'ingresso di una sezione di Studia, schema 26
   (anteprime/blocco26_ingresso_sezione, legenda_ingresso_26.txt). STESSO MODELLO per tutte le sezioni (?s=tattica | pz | aperture |
   trappole | finali | strategia): cambiano solo titolo, contenuti e icone dei capitoli.
   S1 intestazione: Indietro, titolo, segnalibro (→ I miei salvati), progresso totale con barra sottile.
   S2 «Continua da qui» verde: ultimo esercizio (numero e capitolo) · S3 Ripasso di oggi (numero) + Esercizio del giorno
   S4 elenco capitoli: icona v2, nome, fatti/totale, barra verde chiaro, pallino arancio se c'è qualcosa da ripassare
   S5 Preferiti (numero) + «Esercizio a caso» · N barra con Studia attivo.
   Puzzle Random: i «capitoli» sono i 5 livelli di difficoltà (Principiante → Esperto) e c'è la riga del Puzzle rating.
   Aperture, Trappole, Finali, Strategia: in arrivo (nessun dato caricato), la pagina mostra solo lo stato. */
(function(){
  'use strict';
  var C = window.CNP, ic = C.ic, esc = C.esc, A = C.A, W = A ? window.parent : null;
  var root = document.getElementById('pg');
  var Q = new URLSearchParams(location.search), S = Q.get('s') || 'tattica';
  var NOMI = {tattica:['Tattica', 'v2-tattica'], pz:['Puzzle Random', 'v2-casuale'], aperture:['Aperture', 'v2-aperture'], trappole:['Trappole in apertura', 'v2-trappole'],
    finali:['Finali', 'v2-finali'], strategia:['Strategia', 'v2-strategia']};
  if (!NOMI[S]) S = 'tattica';
  function libro(){ return (W && W.BOOK) || {chapters:[], ex:[]}; }
  function pz(){ return W && W.CNPuzzle; }
  function G(){ return W && W.CNGiorno; }
  function bar(f){ return '<span class="st-bar"><i style="width:' + Math.round(Math.max(0, Math.min(1, f)) * 100) + '%"></i></span>'; }
  function testa(tit, prog, f){
    return '<header class="pg-hd sz-hd"><button class="pg-back" data-back aria-label="Indietro">' + ic('chevron-left', 24) + '</button><h1>' + esc(tit) + '</h1>' +
      '<button class="hd15-b" data-pg="salvati.html" aria-label="I miei salvati">' + ic('bookmark', 24) + '</button></header>' +
      (prog ? '<div class="sz-pr"><b>' + esc(prog) + '</b>' + bar(f) + '</div>' : '');
  }
  function cont(sotto, go, arg){ return '<button class="st-cont" id="szCont" data-go="' + go + '"' + (arg ? ' data-arg="' + arg + '"' : '') + '>' + ic('v2-riprendi', 30) + '<span><b>Continua da qui</b><small>' + esc(sotto) + '</small></span>' + ic('chevron-right', 22) + '</button>'; }
  function due(rip, ripGo){
    var g = G(), fatto = g ? g.fatto() : false;
    return '<div class="sz-two"><button class="st-card" id="szRip" data-az="rip">' + (rip ? '<span class="sz-badge">' + rip + '</span>' : '') + ic('v2-ripasso', 24) + '<b>Ripasso di oggi</b><small>' + (rip ? 'da ripassare' : 'niente oggi') + '</small></button>' +
      '<button class="st-card" id="szGiorno" data-go="giorno">' + (fatto ? '<span class="sz-badge ok">✓</span>' : '') + ic('v2-giorno', 24) + '<b>Esercizio del giorno</b><small>' + (fatto ? 'fatto oggi' : 'nuovo ogni giorno') + '</small></button></div>';
  }
  function riga(o){
    return '<button class="st-card sz-cap" data-go="' + o.go + '" data-arg="' + esc(o.arg) + '" data-cap="' + esc(o.id) + '">' + o.ico +
      '<span><span class="sz-cr"><b>' + esc(o.nome) + '</b><em class="' + (o.tot && o.fatti >= o.tot ? 'tutto' : '') + '">' + o.fatti + '/' + o.tot + '</em></span>' + bar(o.tot ? o.fatti / o.tot : 0) + '</span>' +
      '<i class="sz-dot' + (o.rip ? ' on' : '') + '" aria-label="' + (o.rip ? 'da ripassare' : '') + '"></i></button>';
  }
  function fondo(nFav, favTxt, casoTit, casoTxt, casoGo, casoArg){
    return '<div class="sz-fondo"><button class="st-card" id="szFav" data-pg="salvati.html?cat=' + (S === 'pz' ? 'tattica&arg=pz' : 'tattica') + '">' + ic('bookmark', 22) + '<span><b>Preferiti</b><small>' + nFav + ' ' + favTxt + '</small></span></button>' +
      '<button class="st-card" id="szCaso" data-go="' + casoGo + '" data-arg="' + casoArg + '">' + ic('v2-casuale', 22) + '<span><b>' + casoTit + '</b><small>' + casoTxt + '</small></span></button></div>';
  }
  function liv(k){ var h = '<span class="sz-liv" aria-hidden="true">'; for (var i = 1; i <= 5; i++) h += '<i class="' + (i <= k ? 'on' : '') + '" style="height:' + (4 + i * 3) + 'px"></i>'; return h + '</span>'; }

  function tattica(){
    var p = {}, rev = {}, favs = [];
    try { p = A.progress(); } catch(e){} try { rev = W.__stats.data().rev || {}; } catch(e){} try { favs = A.favs(); } catch(e){}
    var chs = libro().chapters, tot = 0, ris = 0, rows = '';
    chs.forEach(function(c){
      var f = 0, r = 0; c.list.forEach(function(e){ if (p[e.n] === 's' || p[e.n] === 'e') f++; if (rev[e.n]) r++; });
      tot += c.list.length; ris += f;
      rows += riga({id:c.id, nome:c.name, fatti:f, tot:c.list.length, rip:r, go:'tattica', arg:'cap:' + c.id, ico:ic('v2-cap-' + c.id, 24)});
    });
    var co = W && W.CNB4 ? W.CNB4.continua('tattica') : {sotto:''}, rip = 0; try { rip = W.__stats.todayList().length; } catch(e){}
    return testa('Tattica', ris + ' / ' + tot + ' risolti', tot ? ris / tot : 0) + cont(co.sotto, 'tattica', 'cont') + due(rip) +
      '<div class="sz-lh"><h2>Capitoli</h2><span>' + chs.length + ' capitoli</span></div>' + rows +
      fondo(favs.length, favs.length === 1 ? 'esercizio' : 'esercizi', 'Esercizio a caso', 'da tutti i capitoli', 'tattica', 'caso');
  }
  function puzzle(){
    var P = pz(); if (!P) return testa('Puzzle Random') + '<p class="nota">Puzzle non disponibili.</p>';
    var g = P.giocati(), rat = P.rating(), prov = P.provvisorio(), rip = P.todayList().length, nf = P.favs().length;
    var rows = P.bande().map(function(b, i){ return riga({id:b.id, nome:b.nome + ' · ' + (b.da ? (b.a < 9999 ? b.da + '–' + (b.a - 1) : 'da ' + b.da) : 'fino a ' + (b.a - 1)), fatti:b.fatti, tot:b.tot, rip:b.rip, go:'pz', arg:b.id, ico:liv(i + 1)}); }).join('');
    return testa('Puzzle Random', g + ' / ' + P.total + ' giocati', g / P.total) +
      '<p class="sz-sub">Esercizi a difficoltà crescente con temi misti, come in una vera partita: non sai mai cosa ti aspetta.</p>' +
      '<div class="st-card sz-rat" id="szRat"><span><span class="st-k">Puzzle rating</span><span class="st-v">' + rat + (prov ? '<small>provvisorio</small>' : '') + '</span></span>' +
      '<p>Sale quando risolvi, scende quando sbagli. I puzzle si adattano a te.</p></div>' +
      cont('Prossimo puzzle · vicino al tuo rating', 'pz', '') + due(rip) +
      '<div class="sz-lh"><h2>Livelli</h2><span>5 livelli</span></div>' + rows +
      fondo(nf, nf === 1 ? 'puzzle' : 'puzzle', 'Puzzle a caso', 'da tutti i livelli', 'pz', 'caso');
  }
  function arrivo(){
    var n = NOMI[S];
    return testa(n[0], 'Progresso non ancora disponibile', 0) + '<div class="st-card st-off"><span class="st-sh"><span class="st-ti">' + ic(n[1], 26) + '</span><span><b>' + esc(n[0]) + '</b><span class="st-stato or">' +
      (S === 'finali' ? 'In preparazione' : 'In arrivo') + '</span></span></span></div>';
  }
  function disegna(){ root.innerHTML = (S === 'tattica' ? tattica() : S === 'pz' ? puzzle() : arrivo()) + C.bar(1); }
  root.addEventListener('click', function(ev){
    var r = ev.target.closest('[data-az=rip]'); if (!r) return;
    if (!A || !C.P){ C.toast('Anteprima: il ripasso si apre nell\'app.'); return; }
    if (S === 'pz'){ if (pz() && pz().todayList().length) C.P.go('pzrip'); else C.toast('Nessun puzzle da ripassare oggi.'); return; }
    var t = 0; try { t = W.__stats.todayList().length; } catch(e){}
    if (t) C.P.go('ripasso'); else C.toast('Niente da ripassare oggi.');
  });
  window.addEventListener('pageshow', function(ev){ if (ev.persisted) disegna(); });
  disegna();
  window.__sezione = {disegna:disegna, s:S};
})();
