/* Grande aggiornamento, blocco 3 (11-11): pagina Gioca, schema 20f (struttura 20d + avatar tondi 20c).
   anteprime/blocco20_gioca/schema_gioca_20f_*, legenda_gioca_20e.txt, LISTA L.773-793.
   Ordine: header (Gioca + segnalibro → I miei salvati + impostazioni) · Riprendi la partita (SOLO se ce n'è una sospesa) ·
   Scegli il tuo avversario (carosello 5 bot, selezionato ~88 px con anello verde chiaro sottile, «~N stimato», V/P/S sotto) ·
   Colore · Tempo 3x3 (Senza tempo predefinito) · Opzioni avanzate (chiuse, Nessuno) · CTA «Gioca con <nome>» · Le tue partite
   (ultima con Rivincita/Analizza + 2 righe + Vedi tutte) · In arrivo · barra con Gioca attivo.
   Le scelte si salvano in 'chessnodeplay-bot-v1' (le legge bot.js all'avvio della partita). Nessuna rete. */
(function(){
  'use strict';
  var C = window.CNP, ic = C.ic, esc = C.esc, D = window.CNPartite, P = C.P;
  var PK = 'chessnodeplay-bot-v1';
  var pref = C.rd(PK) || {};
  var Q = new URLSearchParams(location.search);
  if (Q.get('bot') && D.BOT[Q.get('bot')]) pref.bot = Q.get('bot');
  if (!D.BOT[pref.bot]) pref.bot = 'chessnote';
  if (['w', 'b', 'r'].indexOf(pref.colore) < 0) pref.colore = 'w';
  if (!D.TEMPI.some(function(t){ return t[0] === pref.orologio; })) pref.orologio = 'no';
  if (!D.HAND[pref.handicap]) pref.handicap = null;
  function salvaPref(){ C.wr(PK, pref); }
  salvaPref();
  var aperte = Q.has('opzioni');
  var root = document.getElementById('pg');

  function avv(id){ return 'istruttori/tondi/' + id + '.webp'; }
  function lanciaBot(azione, arg){
    if (P && P.go){ P.go(azione, arg); return; }
    C.toast('La partita si apre dentro l\'app.');
  }
  function casaTesto(h){ var x = D.HAND[h]; if (!x) return ''; return pref.colore === 'w' ? x[2] : pref.colore === 'b' ? x[3] : x[2] + ' o ' + x[3]; }

  function riprendi(){
    var g = D.incorso(); if (!g || typeof Chess === 'undefined') return '';
    var ch; try { ch = new Chess(g.fen0 || undefined); g.sans.forEach(function(s){ ch.move(s); }); } catch(e){ return ''; }
    var b = D.BOT[g.bot], n = Math.floor(g.sans.length / 2) + 1, d = new Date(g.ts || Date.now());
    var ore = ('0' + d.getHours()).slice(-2) + ':' + ('0' + d.getMinutes()).slice(-2);
    var oggi = D.giorno(new Date()) === D.giorno(d), ieri = D.giorno(new Date(Date.now() - 864e5)) === D.giorno(d);
    var quando = (oggi ? 'oggi ' : ieri ? 'ieri ' : D.quando({ts:g.ts}) + ' ') + ore;
    var fmt = function(ms){ var s = Math.max(0, Math.ceil(ms / 1000)); return Math.floor(s / 60) + ':' + ('0' + s % 60).slice(-2); };
    var bc = g.me === 'w' ? 'b' : 'w';
    var orol = g.clock ? '<span class="gi-rc">Tu ' + fmt(g.clock[g.me]) + ' · ' + esc(b[0]) + ' ' + fmt(g.clock[bc]) + '</span>' : '';
    var extra = [g.handicap ? D.etichettaHand(g.handicap, g.me) : '', g.allenamento ? 'Allenamento' : ''].filter(Boolean).join(' · ');
    return '<button class="card cn-pc gi-rip" data-az="riprendi" aria-label="Riprendi la partita con ' + esc(b[0]) + '">' +
      C.mb(ch.fen(), 92).replace('class="mb', 'class="mb gi-rmb' + (g.me === 'b' ? ' gi-flip' : '')) +
      '<span class="gi-rt"><b>Riprendi la partita</b><span class="gi-rs">' + esc(b[0]) + ' · mossa ' + n + (extra ? ' · ' + esc(extra) : '') + '</span>' + orol +
      '<span class="gi-rd">Ultima mossa: ' + esc(quando) + '</span><span class="gi-go">Continua →</span></span></button>';
  }

  /* 14-11 (Kiko): carosello vero. Tutti i personaggi scorrono (swipe o tocco); quello al centro si ingrandisce nitido,
     quelli ai lati sono più piccoli e appena sfumati; lo scatto morbido lo dà lo scroll-snap. Quando si ferma, il bot al centro
     diventa la scelta (stessa pref 'chessnodeplay-bot-v1' di prima). Attive: zoom pieno · Ridotte: zoom leggero, niente sfocatura · Spente: niente zoom. */
  function carosello(){
    return '<div class="card gi-car"><div class="gi-sc" role="radiogroup" aria-label="Scegli il tuo avversario" tabindex="0">' + D.ORDINE.map(function(id){
      var b = D.BOT[id], on = pref.bot === id;
      return '<button class="gi-bot' + (on ? ' on' : '') + '" role="radio" aria-checked="' + on + '" tabindex="-1" data-bot="' + id + '" aria-label="' + esc(b[0]) + ', livello ~' + b[1] + (D.STILE && D.STILE[id] ? ', ' + esc(D.STILE[id]) : '') + '">' +
        '<span class="gi-zm"><span class="gi-av"><img alt="" src="' + avv(id) + '"></span><b>' + esc(b[0]) + '</b><small>~' + b[1] + ' stimato</small>' +
        (D.STILE && D.STILE[id] ? '<span class="gi-st">' + esc(D.STILE[id]) + '</span>' : '') + '</span></button>';
    }).join('') + '</div></div>';
  }
  function moto(){ var c = document.documentElement.classList; return c.contains('cn-mot-spente') ? 0 : (c.contains('cn-mot-ridotte') || c.contains('cn-ferme')) ? 1 : 2; }
  var zRaf = 0, zFermo = 0, zTocco = null;
  function mezzo(s){ var r = s.getBoundingClientRect(); return r.left + s.clientLeft + s.clientWidth / 2; }
  function zoom(){
    zRaf = 0;
    var s = root.querySelector('.gi-sc'); if (!s) return;
    var m = moto(), cx = mezzo(s), min = m === 2 ? 0.62 : m === 1 ? 0.84 : 1;
    [].forEach.call(s.querySelectorAll('.gi-bot'), function(b){
      var r = b.getBoundingClientRect(), w = r.width || 1, d = Math.abs(r.left + w / 2 - cx) / w; if (d < 0.02) d = 0; d = Math.min(1, d); var k = 1 - d;   // k = 1 al centro, 0 a un posto di distanza
      var z = b.querySelector('.gi-zm'); if (!z) return;
      z.style.transform = min < 1 ? 'scale(' + (min + (1 - min) * k).toFixed(3) + ')' : '';
      z.style.opacity = (0.5 + 0.5 * k).toFixed(3);
      z.style.filter = m === 2 && d > 0 ? 'blur(' + (1.4 * d).toFixed(2) + 'px)' : '';
    });
  }
  function piuVicino(){
    var s = root.querySelector('.gi-sc'); if (!s) return null;
    var cx = mezzo(s), best = null, bd = 1e9;
    [].forEach.call(s.querySelectorAll('.gi-bot'), function(b){ var r = b.getBoundingClientRect(), d = Math.abs(r.left + r.width / 2 - cx); if (d < bd){ bd = d; best = b; } });
    return best;
  }
  function segna(id){   // aggiorna la scelta senza ridisegnare la pagina (il carosello non salta)
    if (!D.BOT[id]) return;
    var cambia = pref.bot !== id; pref.bot = id; if (cambia) salvaPref();
    [].forEach.call(root.querySelectorAll('.gi-bot'), function(b){ var on = b.dataset.bot === id; b.classList.toggle('on', on); b.setAttribute('aria-checked', on); });
    var cta = root.querySelector('.gi-cta'); if (cta) cta.textContent = 'Gioca con ' + D.BOT[id][0];
    var v = root.querySelector('.gi-vps'); if (v) v.outerHTML = vpsRiga();
  }
  function fermo(){ zFermo = 0; var b = piuVicino(); if (zTocco && b && b.dataset.bot !== zTocco) return; zTocco = null; if (b) segna(b.dataset.bot); zoom(); }
  function collega(){
    var s = root.querySelector('.gi-sc'); if (!s || s._cn) return; s._cn = 1;
    s.addEventListener('scroll', function(){
      if (!zRaf) zRaf = requestAnimationFrame(zoom);
      clearTimeout(zFermo); zFermo = setTimeout(fermo, 140);
    }, {passive:true});
    s.addEventListener('pointerdown', function(){ zTocco = null; }, {passive:true});
    s.addEventListener('keydown', function(ev){
      if (ev.key !== 'ArrowLeft' && ev.key !== 'ArrowRight') return; ev.preventDefault();
      var i = D.ORDINE.indexOf(pref.bot) + (ev.key === 'ArrowRight' ? 1 : -1); if (i < 0 || i >= D.ORDINE.length) return;
      segna(D.ORDINE[i]); centra(false);
    });
  }
  function vpsRiga(){
    var o = D.vps(pref.bot), i = D.ORDINE.indexOf(pref.bot) + 1;
    return '<p class="gi-vps">V / P / S: ' + o.v + ' / ' + o.p + ' / ' + o.s + ' · ' + i + ' di ' + D.ORDINE.length + '</p>';
  }
  function scelte(){
    var col = [['w', 'Bianco'], ['b', 'Nero'], ['r', 'Casuale']];
    var h = '<h2 class="gi-h">Colore</h2><div class="gi-grid g3" role="radiogroup" aria-label="Colore">' + col.map(function(c){
      return '<button class="gi-op' + (pref.colore === c[0] ? ' on' : '') + '" role="radio" aria-checked="' + (pref.colore === c[0]) + '" data-col="' + c[0] + '">' + c[1] + '</button>'; }).join('') + '</div>';
    h += '<h2 class="gi-h">Tempo</h2><div class="gi-grid g3" role="radiogroup" aria-label="Tempo">' + D.TEMPI.map(function(t){
      return '<button class="gi-op' + (pref.orologio === t[0] ? ' on' : '') + '" role="radio" aria-checked="' + (pref.orologio === t[0]) + '" data-t="' + t[0] + '">' + esc(t[1]) + '</button>'; }).join('') + '</div>';
    var hn = pref.handicap ? D.HAND[pref.handicap][0] + ' (' + casaTesto(pref.handicap) + ')' : 'Nessuno';
    h += '<div class="card gi-adv' + (aperte ? ' open' : '') + '"><button class="gi-adv-h" aria-expanded="' + aperte + '" data-adv><span class="gi-adv-t"><b>Opzioni avanzate</b><small>Handicap e condizioni speciali</small></span>' +
      '<span class="gi-adv-v">' + esc(hn) + '</span>' + ic('chevron-down', 20).replace('class="lu"', 'class="lu ch"') + '</button>';
    if (aperte){
      h += '<div class="gi-adv-b"><p class="gi-adv-l">Handicap: il bot gioca senza</p><div class="gi-grid g2" role="radiogroup" aria-label="Handicap">' +
        [[null, 'Nessuno']].concat(['p', 'n', 'b', 'r', 'q'].map(function(k){ return [k, D.HAND[k][0] + ' (' + casaTesto(k) + ')']; })).map(function(o){
          var on = (pref.handicap || null) === o[0];
          return '<button class="gi-op' + (on ? ' on' : '') + '" role="radio" aria-checked="' + on + '" data-h="' + (o[0] || '') + '">' + esc(o[1]) + '</button>'; }).join('') + '</div>' +
        '<p class="nota">Partita speciale: la casa è vuota fin dall\'inizio. Statistiche separate: non conta per livello, V/P/S e premi.</p></div>';
    }
    return h + '</div>';
  }
  function partite(){
    var a = D.tutte().slice().reverse();
    var h = '<div class="card gi-pt"><div class="gi-pth"><h2>Le tue partite</h2>' + (a.length ? '<button class="lnk" data-pg="partite.html">Vedi tutte</button>' : '') + '</div>';
    if (!a.length) return h + '<p class="nota gi-vuoto">Nessuna partita ancora: la prima la scegli qui sopra.</p></div>';
    var u = a[0], b = D.BOT[u.bot] || ['Bot'], tag = [u.handicap ? D.etichettaHand(u.handicap, u.colore) : '', u.allenamento ? 'Allenamento' : ''].filter(Boolean).join(' · ');
    h += '<div class="gi-ult"><b class="gi-ut">Ultima · ' + D.esito(u) + ' ' + D.risultato(u) + ' · ' + esc(b[0]) + '</b>' +
      '<small class="gi-us">' + esc(D.quando(u)) + ' · ' + esc(D.tempo(u.orologio)) + (tag ? ' · ' + esc(tag) : '') + '</small>' +
      '<div class="gi-ub"><button class="btn sec gi-sb" data-riv="' + esc(u.id) + '">' + ic('rotate-ccw', 18) + 'Rivincita</button>' +
      '<button class="btn sec gi-sb" data-an="' + esc(u.id) + '"' + (u.sans && u.sans.length ? '' : ' disabled aria-disabled="true"') + '>' + ic('v2-analizza', 18) + 'Analizza</button></div></div>';
    a.slice(1, 3).forEach(function(r){
      var bb = D.BOT[r.bot] || ['Bot'];
      h += '<div class="gi-row"><span class="gi-rn">' + esc(bb[0]) + ' · ' + esc(D.quando(r)) + '</span><span class="gi-re ' + r.esito + '">' + D.esito(r) + '</span>' +
        '<button class="gi-bm' + (r.salvata ? ' on' : '') + '" data-sv="' + esc(r.id) + '" aria-pressed="' + !!r.salvata + '" aria-label="' + (r.salvata ? 'Togli dai salvati' : 'Salva la partita') + '">' + ic('bookmark', 20) + '</button></div>';
    });
    return h + '</div>';
  }
  function inArrivo(){
    return '<div class="card gi-arr"><h2>In arrivo</h2><div class="gi-ar"><span>Sfida un amico</span><span class="arr">In arrivo</span></div>' +
      '<div class="gi-ar"><span>Gioca da una posizione</span><span class="arr">In arrivo</span></div></div>';
  }
  function disegna(){
    var sc = root.querySelector('.gi-sc'), sl = sc ? sc.scrollLeft : null;
    root.innerHTML = '<header class="gi-hd"><h1>Gioca</h1><button class="hd15-b" data-pg="salvati.html" aria-label="I miei salvati">' + ic('bookmark', 24) + '</button>' +
      '<button class="hd15-b" data-pg="impostazioni.html" aria-label="Impostazioni">' + ic('settings', 24) + '</button></header>' +
      riprendi() +
      '<h2 class="gi-h1">Scegli il tuo avversario</h2>' + carosello() + vpsRiga() + scelte() +
      '<button class="btn gi-cta" data-az="gioca">Gioca con ' + esc(D.BOT[pref.bot][0]) + '</button>' +
      partite() + inArrivo() + C.bar(2);
    var s2 = root.querySelector('.gi-sc');
    if (sl != null) s2.scrollLeft = sl;
    collega(); centra(sl == null); zoom();
  }
  function centra(subito){
    var s = root.querySelector('.gi-sc'), b = s && s.querySelector('.gi-bot.on'); if (!b) return;
    var r = b.getBoundingClientRect(), x = s.scrollLeft + (r.left + r.width / 2 - mezzo(s));
    try { s.scrollTo({left:x, behavior:(subito || moto() === 0) ? 'auto' : 'smooth'}); } catch(e){ s.scrollLeft = x; }
    if (subito || moto() === 0) zoom();
  }
  function avvia(){
    salvaPref();
    var g = D.incorso();
    if (g){
      C.conferma('Nuova partita?', 'C\'è una partita sospesa con ' + D.BOT[g.bot][0] + '. Se ne inizi una nuova, quella conta come abbandonata.', 'Inizia la nuova', function(){ lanciaBot('botstart'); });
      return;
    }
    lanciaBot('botstart');
  }
  root.addEventListener('click', function(ev){
    var t = ev.target.closest('button'); if (!t || t.disabled) return;
    if (t.dataset.bot){ zTocco = t.dataset.bot; segna(t.dataset.bot); centra(false); return; }   // 14-11: tocco = scelta subito + scorre al centro
    if (t.dataset.col){ pref.colore = t.dataset.col; salvaPref(); disegna(); return; }
    if (t.dataset.t){ pref.orologio = t.dataset.t; salvaPref(); disegna(); return; }
    if (t.dataset.h != null){ pref.handicap = t.dataset.h || null; salvaPref(); disegna(); return; }
    if (t.hasAttribute('data-adv')){ aperte = !aperte; disegna(); return; }
    if (t.dataset.az === 'gioca'){ avvia(); return; }
    if (t.dataset.az === 'riprendi'){ lanciaBot('botriprendi'); return; }
    if (t.dataset.riv){ lanciaBot('botrivincita', t.dataset.riv); return; }
    if (t.dataset.an){ lanciaBot('botanalizza', t.dataset.an); return; }
    if (t.dataset.sv){ var r = D.trova(t.dataset.sv); if (!r) return; var on = !r.salvata, id = r.id; D.salva(id, on); disegna();   // blocco 3b: stesso toast con Annulla di Le tue partite
      C.toast(on ? 'Partita salvata' : 'Tolta dai salvati', function(){ D.salva(id, !on); disegna(); }, 4000); return; }
  });
  window.addEventListener('pageshow', function(ev){ if (ev.persisted) disegna(); });
  window.addEventListener('resize', function(){ centra(true); });
  disegna();
  window.__gioca = {pref:function(){ return JSON.parse(JSON.stringify(pref)); }, disegna:disegna};
})();
