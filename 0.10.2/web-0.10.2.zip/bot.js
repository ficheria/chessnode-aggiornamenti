/* Chess Node · «Gioca contro un bot» — anteprima 17b, 31/10/2026 (SOLO web_preview, codice originale del progetto).
   - Scacchiera e pezzi dell'app (A.psrc, pieces.js) e colori del tema (--light/--dark, --acc, --s*, --tx*): niente grafica Lichess.
   - Motore: il NOSTRO Stockfish 17.1 Lite nel Worker separato engine/stockfish-lite.js (GPLv3, file invariati, processo a parte).
     Il bot apre un SUO Worker (opzioni di forza separate da quelle dell'analisi) e lo chiude a fine partita.
     Questa build ha UCI_Elo min 1320 max 3190: sotto 1320 (Chess Node ~800, Paola ~1100) si usa Skill Level + tempo/profondità corti.
   - Livello «umano»: con una certa probabilità il bot gioca una mossa non migliore tra le MultiPV (entro una perdita massima)
     oppure, raramente, una mossa legale qualsiasi. Mai istantaneo: attesa casuale per bot (umano.ritardo).
     In un finale stravinto non sbaglia più apposta, così chiude la partita.
   - La scacchiera non è mai coperta: avatar e fumetto SOPRA, orologio/pulsanti/mosse/risultato SOTTO.
   - Tutti i parametri sono in BOT_CONFIG (uno per bot). Tutti e 5 i bot attivi.
   - Taratura 31/10/2026 (anteprime/blocco9_bot/calibrazione.json), partite bot contro bot: Paola batte Chess Node 83%, Luca batte Paola 78%,
     Irina batte Luca 72%, il Prof batte Irina 74%. Stime Elo indicative (ancore Stockfish UCI_Elo a 500 ms/mossa, scala nominale):
     Chess Node ~850-950, Paola ~1100-1200, Luca ~1450, Irina ~1600, Prof ~1800-1900. Le etichette ~800…~2000 restano indicative.
   - Frasi v2 (istruttori/frasi_bot_v2.md, solo testo): riuso delle frasi già registrate, nome dell'apertura una volta per partita
     (data/aperture_eco.json, CC0), «Ops…» dopo una svista certa, «Attenzione…» prima della mossa (solo avvisa:true, secondo motore a piena forza). */
(function(){
  'use strict';
  var A = window.__app;
  if (!A || typeof Chess === 'undefined') return;

  /* ======================= CONFIGURAZIONE DEI 5 BOT (tarata il 31/10/2026) =======================
     motore.skill         Skill Level di Stockfish (0-20). Sotto 20 Stockfish sceglie già da solo mosse più deboli.
     motore.limita        true = UCI_LimitStrength + UCI_Elo (solo se elo >= 1320, minimo di questa build)
     motore.elo           valore UCI_Elo (ignorato se limita=false)
     motore.ms            tempo di calcolo per mossa (movetime, ms)
     motore.prof          profondità massima (depth); null = solo tempo
     motore.multipv       linee candidate da chiedere al motore (servono al livello umano)
     umano.pAlt           probabilità di scegliere una mossa NON migliore tra le MultiPV 2..N
     umano.perditaAlt     perdita massima (centipedoni) accettata per quella mossa alternativa
     umano.pCaso          probabilità di una mossa legale qualsiasi (la «svista»: a volte lascia un pezzo in presa)
     umano.daSemimossa    niente sviste prima di questa semimossa (l'apertura resta normale)
     umano.vedeMatto1     true = se ha matto in 1 lo gioca sempre (niente sviste)
     umano.ritardo        [min, max] ms di attesa totale per mossa (mai istantaneo)
     patta.accettaSotto   accetta la patta se la sua valutazione è sotto questo valore (cp, dal suo punto di vista)
     patta.paritaDopo     ...oppure se |valutazione| < 60 cp dopo questa semimossa
     avvisa               true = «Attenzione…» prima della tua mossa se c'è una minaccia certa (solo bot facili)
     chiacchiera          0..1, quanto spesso commenta prese e scacchi (inizio, fine, patta e sviste: sempre) */
  var BOT_CONFIG = {
    chessnote: {nome:'Chess Node', stile:'fantasioso', elo:800,  stima:900,  chiacchiera:0.7, avvisa:true, attivo:true, descr:'Principiante: gioca volentieri, ogni tanto si distrae',
      motore:{skill:0,  limita:false, elo:null, ms:150, prof:7,  multipv:4},
      umano:{pAlt:0.26, perditaAlt:300, pCaso:0.08, daSemimossa:4, vedeMatto1:true, ritardo:[600, 1800]},
      patta:{accettaSotto:-150, paritaDopo:60}},
    paola:     {nome:'Paola',      stile:'difensivo', elo:1100, stima:1150, chiacchiera:0.7, avvisa:true, attivo:true, descr:'Gioca tranquilla, sbaglia meno',
      motore:{skill:2,  limita:false, elo:null, ms:150, prof:7,  multipv:4},
      umano:{pAlt:0.22, perditaAlt:220, pCaso:0.05, daSemimossa:6, vedeMatto1:true, ritardo:[700, 2000]},
      patta:{accettaSotto:-150, paritaDopo:60}},
    nerd:      {nome:'Luca',       stile:'aggressivo', elo:1400, stima:1450, chiacchiera:0.5, avvisa:true, attivo:true, descr:'Ama la tattica',
      motore:{skill:20, limita:true,  elo:1450, ms:300, prof:null, multipv:3},
      umano:{pAlt:0.07, perditaAlt:120, pCaso:0.01, daSemimossa:10, vedeMatto1:true, ritardo:[800, 2200]},
      patta:{accettaSotto:-120, paritaDopo:70}},
    serena:    {nome:'Nadia',      stile:'posizionale', elo:1700, stima:1600, chiacchiera:0.4, attivo:true, descr:'Solida e precisa',
      motore:{skill:20, limita:true,  elo:1700, ms:500, prof:null, multipv:3},
      umano:{pAlt:0.04, perditaAlt:80,  pCaso:0,    daSemimossa:99, vedeMatto1:true, ritardo:[900, 2400]},
      patta:{accettaSotto:-100, paritaDopo:80}},
    maestro:   {nome:'Prof',       stile:'preciso', elo:2000, stima:1900, chiacchiera:0.45, attivo:true, descr:'Forte: non regala niente',
      motore:{skill:20, limita:true,  elo:2000, ms:800, prof:null, multipv:3},
      umano:{pAlt:0,    perditaAlt:0,   pCaso:0,    daSemimossa:99, vedeMatto1:true, ritardo:[900, 2600]},
      patta:{accettaSotto:-80,  paritaDopo:80}}
  };
  var ORDINE = ['chessnote', 'paola', 'nerd', 'serena', 'maestro'];
  /* blocco 3 (11-11): 9 tempi della pagina Gioca 20f (+ i due vecchi, per le partite già salvate). stima = livello «~N stimato» dello schema 20f
     (taratura 31/10), solo etichetta: il motore non cambia. */
  var OROLOGI = {no:null, '1':{min:1, inc:0}, '3':{min:3, inc:0}, '3+2':{min:3, inc:2}, '5':{min:5, inc:0}, '5+2':{min:5, inc:2}, '10':{min:10, inc:0},
    '10+5':{min:10, inc:5}, '30':{min:30, inc:0}, '10+0':{min:10, inc:0}, '15+10':{min:15, inc:10}};
  var HAND = {p:['pedone', 'f7', 'f2'], n:['cavallo', 'b8', 'b1'], b:['alfiere', 'c8', 'c1'], r:['torre', 'a8', 'a1'], q:['donna', 'd8', 'd1']};
  var FEN0 = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';
  function fenHandicap(h, me){   // il bot ha il colore opposto a «me»: la sua casa resta vuota dall'inizio
    var x = HAND[h]; if (!x) return null;
    var sq = me === 'w' ? x[1] : x[2], g = new Chess(FEN0); g.remove(sq);
    var f = g.fen().split(' ');
    if (h === 'r') f[2] = f[2].replace(me === 'w' ? 'q' : 'Q', '') || '-';
    return f.join(' ');
  }
  function etichettaHand(h, me){ var x = HAND[h]; return x ? 'Senza ' + x[0] + ' ' + (me === 'w' ? x[1] : x[2]) : ''; }
  var ELO_MIN_BUILD = 1320;   // UCI_Elo min di Stockfish 17.1 Lite WASM (letto dal comando «uci» il 31/10/2026)

  /* Frasi del bot in partita (SOLO TESTO, bozza v2 da far rivedere a Kiko: istruttori/frasi_bot_v2.md).
     Stile dei personaggi approvati (istruttori/personaggi_bozza_v2.md): allenatori adulti, forme neutre, nessuna frase da cartone.
     Generiche di proposito: non affermano nulla sulla partita che potrebbe essere falso.
     Le frasi segnate «riuso» sono identiche a quelle già registrate in tts_google/archivio/frasi.json (stesso audio).
     ops = subito dopo una svista certa; attento = minaccia certa prima della tua mossa (solo avvisa:true); apertura = {apertura} con articolo. */
  var FRASI = {
    chessnote: {
      inizio: ["Buona partita! Ricordiamo le basi: sviluppare i pezzi, controllare il centro, arroccare presto.", "Si comincia. Prima di ogni mossa chiediamoci: che cosa minaccia l'avversario?", "Si gioca! Un passo alla volta: oggi l'importante è non lasciare pezzi senza difesa."],
      presa: ["Questo pezzo lo prendiamo noi. Prima di muovere, controlliamo sempre cosa resta senza difesa.", "Presa! Un pezzo senza difesa è sempre un invito.", "Abbiamo catturato. Ora guarda bene: puoi riprendere qualcosa?"],
      persoPezzo: ["Hai catturato un nostro pezzo. Vediamo insieme cosa cambia sulla scacchiera.", "Un pezzo in meno per noi. Ci riorganizziamo, un passo alla volta."],
      scaccoDato: ["Scacco! Ci sono tre modi per pararlo: muovere il Re, coprire, o catturare il pezzo che dà scacco.", "Scacco al tuo Re. Con calma: guarda tutte le risposte possibili prima di scegliere."],
      scaccoRicevuto: ["Scacco a noi! Cerchiamo la risposta più sicura per il nostro Re.", "Ci hai dato scacco. Bella iniziativa: ora pensiamo a difenderci."],
      svista: ["Attenzione: dopo questa mossa qualcosa è rimasto scoperto. Chiediamoci sempre: cosa può prendere l'avversario?", "Capita a chiunque stia imparando. L'importante è accorgersene: adesso sai cosa controllare la prossima volta."],   // riuso: chessnode_esp_01_errore_grave
      pattaSi: ["Va bene, patta accettata. Stretta di mano!", "D'accordo, patta. È stata una bella sfida."],
      pattaNo: ["Grazie, ma preferiamo continuare: la partita ha ancora tanto da dire.", "No, giochiamo ancora un po'. Ci sono ancora idee da provare."],
      annulla: ["Va bene, riproviamo. Stavolta controlliamo prima scacchi, catture e minacce.", "Mossa annullata. Prendiamoci tutto il tempo che serve."],
      abbandono: ["Partita chiusa. Nessun problema: la prossima la giochiamo con più calma.", "Abbandono accettato. Ogni partita insegna qualcosa: diamo un'occhiata all'analisi?"],
      vinceBot: ["Oggi è andata così. Ogni partita persa insegna qualcosa che una vittoria facile non insegna. Ne giochiamo un'altra?", "Partita nostra. Guardiamo l'analisi: capire un errore vale più di dieci partite giocate di corsa."],   // riuso: chessnode_esp_05_sconfitta
      vinceUtente: ["Vittoria, e meritata! Hai giocato con attenzione dalla prima all'ultima mossa.", "Complimenti, la vittoria è tua! Ci concedi la rivincita?", "Partita vinta! Tieni a mente l'ordine che funziona: sviluppare i pezzi, mettere il Re al sicuro, poi attaccare."],   // riuso: chessnode_esp_04_vittoria, chessnode_did_04_vittoria
      patta: ["Patta! Stretta di mano, e grazie della partita.", "Finisce pari. Diamo un'occhiata all'analisi?"],
      ops: ["Ops… guarda bene la scacchiera.", "Uh, attenzione!"],
      attento: ["Attenzione… prima di muovere, guarda cosa minacciano i miei pezzi.", "Occhio: c'è una minaccia sulla scacchiera. Riesci a vederla?"],
      apertura: ["Adesso giochiamo {apertura}: un'apertura classica, che vale la pena conoscere.", "Ecco {apertura}. Gli stessi principi valgono sempre: sviluppo, centro, Re al sicuro."]
    },
    paola: {
      inizio: ["Buona partita. Con calma: sviluppo, centro, Re al sicuro. Il resto viene da sé.", "Cominciamo. Prima di ogni mossa, una domanda sola: che cosa vuole fare l'avversario?", "Si comincia. Una mossa pensata vale più di tre giocate di corsa."],
      presa: ["Prendo questo pezzo. Ti chiedo: era difeso abbastanza?", "Catturo. Prima di lasciare un pezzo da qualche parte, conta sempre attaccanti e difensori."],
      persoPezzo: ["Hai preso un mio pezzo. Ora rifletti: che cosa è cambiato nella posizione?", "Quel pezzo me lo sono lasciato sfuggire. Un buon promemoria anche per me."],
      scaccoDato: ["Scacco. Prima di rispondere, ragiona: quali sono tutte le tue possibilità?", "Scacco al Re. Spostarlo, coprire o catturare: quale ti lascia la posizione migliore?"],
      scaccoRicevuto: ["Scacco. L'iniziativa ti piace, vedo. Vediamo se regge.", "Mi dai scacco. Ricorda però: lo scacco serve solo se migliora la tua posizione."],
      svista: ["Fermiamoci un attimo: dopo questa mossa qualcosa è rimasto senza difesa. Te ne accorgi?", "Questa mossa mi lascia un'occasione. Prima di muovere, chiediti sempre cosa vuole l'avversario.", "Un errore così si fa una volta sola, se lo capiamo bene. Ed è proprio per questo che siamo qui."],   // riuso: paola_esp_01_errore_grave
      pattaSi: ["D'accordo, accetto la patta. Grazie della partita.", "Accetto volentieri. Rivediamo insieme i momenti importanti?"],
      pattaNo: ["No, grazie. C'è ancora qualcosa da giocare: ragioniamoci ancora un po'.", "Preferisco continuare. Una partita va giocata fino in fondo, con pazienza."],
      annulla: ["Va bene, riprova. Questa volta chiediti prima: che cosa minaccia l'avversario?", "Mossa annullata. Ripensaci con calma: negli scacchi la fretta è la peggiore consigliera."],
      abbandono: ["Partita chiusa. Rivediamo il momento decisivo: è il compito più utile di oggi.", "Abbandonare non è un dramma. Riguardiamola con calma, e la prossima andrà meglio."],
      vinceBot: ["Una sconfitta non cancella i progressi. Oggi hai capito qualcosa in più, e la prossima partita lo dimostrerà.", "Ho vinto io. Ora il compito è capire dove è cambiata la partita: l'analisi ti aiuta."],   // riuso: paola_esp_05_sconfitta
      vinceUtente: ["Ottimo lavoro. Hai giocato con calma e con un piano, e il risultato ti dà ragione.", "Complimenti, partita tua. Ecco cosa succede quando si ragiona invece di indovinare.", "Bella vittoria. Sviluppo, sicurezza del Re, poi attacco: quando si segue quest'ordine, i risultati arrivano."],   // riuso: paola_esp_04_vittoria, paola_did_04_vittoria
      patta: ["Patta. Grazie della partita: rivediamola, c'è sempre qualcosa da imparare.", "Finisce in parità. Un compito facile: guarda l'analisi e trova il momento chiave."],
      ops: ["Ops. Fermiamoci un attimo.", "Uh, attenzione a questa."],
      attento: ["Attenzione: prima di muovere, chiediti cosa voglio fare io.", "Un momento. C'è una minaccia sulla scacchiera: cercala con calma."],
      apertura: ["Bene, {apertura}. Un'apertura che insegna molto, giocata con calma.", "Riconosci l'apertura? È {apertura}."]
    },
    nerd: {
      inizio: ["Buona partita! In apertura niente fretta: sviluppa, arrocca, poi si fa sul serio.", "Si parte. Io gioco di tattica, quindi occhio ai pezzi non difesi.", "Ok, si gioca. Due o tre mosse candidate ogni volta, e vediamo chi calcola meglio."],
      presa: ["Pezzo preso. La valutazione si sposta: vediamo come rispondi.", "Questo lo prendo. Prima regola della tattica: i pezzi non difesi spariscono in fretta."],
      persoPezzo: ["Preso. Non era nei miei calcoli: me lo riguardo in analisi.", "Ok, quel pezzo è tuo. Adesso tocca a me ricalcolare."],
      scaccoDato: ["Scacco. Calcola tutte le risposte, non solo la prima che vedi.", "Scacco! Mossa forzante, la mia preferita."],
      scaccoRicevuto: ["Scacco ricevuto. Vediamo se c'è un seguito o è solo rumore.", "Mi dai scacco: giusto, le mosse forzanti vanno guardate per prime."],
      svista: ["Ahia, la valutazione è appena girata a mio favore. Prima di muovere, controlla sempre le minacce.", "Ahia, questa fa male. Ma ogni blunder analizzato è un blunder che non rifarai."],   // riuso: luca_esp_01_errore_grave
      pattaSi: ["Patta accettata. GG!", "Ok, patta. Il grafico dell'analisi ci dirà chi stava meglio."],
      pattaNo: ["No, grazie: c'è ancora da giocare. La posizione non è morta.", "Rifiuto. Secondo i miei calcoli c'è ancora partita."],
      annulla: ["Mossa annullata. Nessun giudizio: ricalcola con calma e scegli di nuovo.", "Ok, si torna indietro. Stavolta metti in fila due o tre candidate prima di decidere."],
      abbandono: ["Abbandono accettato. GG! Uno sguardo al grafico e capisci subito dov'è girata.", "Partita chiusa. Niente tilt: una pausa, l'analisi, e la prossima va meglio."],
      vinceBot: ["GG! Apri l'analisi: il grafico mostra il momento esatto in cui la partita è girata.", "Questa la porto a casa io. Ma una partita analizzata vale doppio: dai un'occhiata.", "Persa, ma niente tilt. Una pausa, uno sguardo all'analisi, e la prossima la giochi meglio."],   // riuso: luca_esp_05_sconfitta
      vinceUtente: ["GG, partita tua! Questa me la riguardo in analisi, per capire dove ho sbagliato.", "GG! Partita giocata con la testa, dall'apertura al finale.", "Vittoria portata a casa. Apri l'analisi e guarda il grafico: vedrai il momento esatto in cui la partita è girata."],   // riuso: luca_esp_04_vittoria, luca_did_04_vittoria
      patta: ["Patta. GG, nessuno dei due ha mollato.", "Finisce pari. Il grafico in analisi sarà interessante."],
      ops: ["Ops… blunder in vista.", "Uh, questa costa."],
      attento: ["Occhio, ho una tattica pronta.", "Attenzione: controlla le mie minacce, prima della tua mossa."],
      apertura: ["Oh, {apertura}! Ho un paio di idee pronte.", "Ok, {apertura}. Teoria nota, adesso si calcola."]
    },
    serena: {
      inizio: ["Buona partita. Gioca preciso.", "Cominciamo. Concentrazione, e nessuna fretta."],   // riuso: irina_esp_08_inizio_tema
      presa: ["Pezzo indifeso. Lo prendo.", "Cattura. Controlla i tuoi pezzi, uno per uno."],
      persoPezzo: ["Concesso. Non succederà di nuovo.", "Preso. Me ne ricorderò."],
      scaccoDato: ["Scacco.", "Scacco. Scegli la risposta più solida."],
      scaccoRicevuto: ["Scacco. Vediamo il seguito.", "Scacco. Annotato."],
      svista: ["Questa mossa concede qualcosa. Chiediti sempre qual è la risposta più fastidiosa.", "Succede anche ai giocatori forti, in torneo. Conta solo non ripeterlo."],   // riuso: irina_esp_01_errore_grave
      pattaSi: ["Patta. Accetto.", "D'accordo. Stretta di mano."],
      pattaNo: ["No. Si gioca.", "Rifiuto. La posizione ha ancora risorse."],
      annulla: ["Annullata. Riguarda la posizione come se fosse la prima volta.", "Va bene. Questa volta calcola fino in fondo."],
      abbandono: ["Abbandono accettato. Riguardala a mente fredda.", "Partita chiusa. La lezione è nell'analisi."],
      vinceBot: ["Partita mia. Riguardala con calma: la lezione è lì.", "Le sconfitte insegnano più delle vittorie, se le analizzi a mente fredda. Riguardala con calma, poi si continua."],   // riuso: irina_esp_05_sconfitta
      vinceUtente: ["Una partita ordinata, dall'inizio alla fine. È così che si vince.", "Hai vinto. Complimenti, sinceri.", "Vittoria meritata. Pezzi coordinati e nessuna concessione: è da lì che nasce ogni attacco."],   // riuso: irina_esp_04_vittoria, irina_did_04_vittoria
      patta: ["Patta. Stretta di mano.", "Pari. Si analizza e si riparte."],
      ops: ["Ops.", "Attenzione."],
      apertura: ["È {apertura}. Conosco bene le sue strutture.", "Ah, {apertura}. Vediamo chi ne conosce meglio le idee."]
    },
    maestro: {
      inizio: ["Accomodati, e buona partita. Senza fretta: gli scacchi premiano chi pensa, non chi corre.", "Cominciamo. Tarrasch diceva che prima del finale gli dèi hanno messo il mediogioco. Vediamo cosa ci riserva.", "Buona partita. Vinca chi commette il penultimo errore, come insegnava Tartakower."],
      presa: ["Prendo, con il tuo permesso. Un pezzo indifeso è un invito che non si rifiuta.", "Cattura. Un pezzo lasciato solo, prima o poi, presenta il conto."],
      persoPezzo: ["Ah, me l'hai preso. Lo ammetto: questo non l'avevo previsto.", "Pezzo perso. Ma nessuno ha mai vinto una partita abbandonando, ricordava Tartakower."],
      scaccoDato: ["Scacco. Calma: le difese migliori si trovano con la testa fresca.", "Scacco al Re. Tra le risposte possibili, cerca quella che migliora la posizione."],
      scaccoRicevuto: ["Scacco a me. Vediamo se dietro c'è un piano, o solo entusiasmo.", "Scacco. Mi piace: chi attacca dà il ritmo alla partita."],
      svista: ["Qui c'era di meglio. Lasker consigliava: quando vedi una buona mossa, cercane una migliore. Vale ancora oggi.", "Niente drammi. Tartakower diceva che vince chi commette il penultimo errore: la partita non è ancora finita."],   // riuso: prof_did_03_occasione_mancata (versione parlata), prof_esp_01_errore_grave
      pattaSi: ["Accetto volentieri. Una stretta di mano, come si usa al circolo.", "Patta, d'accordo. Ci sono partite in cui la pace è la scelta più saggia."],
      pattaNo: ["Ti ringrazio, ma preferisco continuare. La partita ha ancora qualche capitolo da scrivere.", "Non ancora, se permetti. In questa posizione c'è ancora da lavorare."],
      annulla: ["Concesso. Al circolo non si farebbe, ma qui siamo per imparare.", "Mossa annullata. Prima di rifarla, cercane una migliore, come consigliava Lasker."],
      abbandono: ["Abbandono accettato. Capablanca diceva che si impara più da una sconfitta che da molte vittorie.", "Una stretta di mano. Riguardala con la testa fresca: ogni partita ha la sua lezione."],
      vinceBot: ["Tutti i grandi campioni hanno perso migliaia di partite. Quello che conta è cosa ci portiamo via da questa.", "Ho vinto io, questa volta. Apriamo l'analisi: è lì che la sconfitta diventa una lezione."],   // riuso: prof_esp_05_sconfitta
      vinceUtente: ["Complimenti sinceri. Una vittoria così la racconterei volentieri ai ragazzi del circolo.", "Che bella partita. Di quelle che ci si ricorda anche dopo anni.", "Vittoria limpida: ogni pezzo aveva un compito e lo ha svolto. È l'armonia di cui parlano i grandi maestri."],   // riuso: prof_esp_04_vittoria, prof_did_04_vittoria
      patta: ["Patta. Una stretta di mano e grazie: è stata una partita piacevole.", "Finisce in parità. Ogni tanto gli scacchi sanno essere giusti."],
      ops: ["Ops… pazienza.", "Uhm, peccato."],
      apertura: ["Ah, {apertura}. Un'apertura giocata anche dai grandi campioni: vediamo cosa ne facciamo noi.", "Bene, {apertura}. Teoria antica e idee sempre nuove."]
    }
  };
  var ultimaFrase = {};   // bot.situazione -> indice dell'ultima frase detta (mai la stessa due volte di fila)
  /* 0.9.0 (app, 01/11): frasi_bot_v2 ancora da approvare da Kiko → nell'app i bot giocano SENZA frasi (niente «Ops», «Attenzione», nome dell'apertura).
     Per riaccenderle: FRASI_ON = true. */
  var FRASI_ON = false;
  function frase(bot, k){
    if (!FRASI_ON) return '';
    var F = FRASI[bot] || FRASI.chessnote, a = F[k] || FRASI.chessnote[k] || [''], key = bot + '.' + k, i = Math.floor(Math.random() * a.length);
    if (a.length > 1 && i === ultimaFrase[key]) i = (i + 1) % a.length;
    ultimaFrase[key] = i; return a[i];
  }
  function parla(p){ return Math.random() < (G && G.cfg.chiacchiera != null ? G.cfg.chiacchiera : .6) * (p == null ? 1 : p); }   // i commenti minori non a ogni mossa

  /* ======================= utilità ======================= */
  var L = window.LUCIDE || {};
  function svg(n, s){ s = s || 20; return L[n] ? '<svg class="lu" viewBox="0 0 24 24" width="' + s + '" height="' + s + '" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' + L[n] + '</svg>' : ''; }
  function esc(s){ return String(s == null ? '' : s).replace(/[&<>"']/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }
  function it(s){ return A.itSan ? A.itSan(s) : s; }
  function rnd(a, b){ return a + Math.random() * (b - a); }
  function pick(a){ return a[Math.floor(Math.random() * a.length)]; }
  function avatar(id){
    var C = window.ISTRUTTORI && window.ISTRUTTORI.cerchio, p = C && C.personaggi[id];
    return 'istruttori/tondi/' + id + '.webp';   // blocco 1: avatar tondi 20c
  }
  function fmtClock(ms){ ms = Math.max(0, ms); var s = Math.ceil(ms / 1000); if (ms < 10000) return (ms / 1000).toFixed(1).replace('.', ','); return Math.floor(s / 60) + ':' + ('0' + s % 60).slice(-2); }

  /* ======================= motore del bot (Worker separato) ======================= */
  function BotEngine(cfg){
    var w = null, ready = null, job = null, self = this;
    this.start = function(){
      if (ready) return ready;
      ready = new Promise(function(res, rej){
        try { w = new Worker('engine/stockfish-lite.js'); } catch(e){ rej(e); return; }
        var to = setTimeout(function(){ rej(new Error('timeout motore')); }, 20000);
        w.onerror = function(e){ clearTimeout(to); rej(new Error(e.message || 'errore worker')); };
        w.onmessage = function(ev){
          var line = String(ev.data);
          if (line === 'uciok'){
            var m = cfg.motore;
            w.postMessage('setoption name Hash value 16');
            w.postMessage('setoption name Skill Level value ' + m.skill);
            if (m.limita && m.elo >= ELO_MIN_BUILD){ w.postMessage('setoption name UCI_LimitStrength value true'); w.postMessage('setoption name UCI_Elo value ' + m.elo); }
            else w.postMessage('setoption name UCI_LimitStrength value false');
            w.postMessage('setoption name MultiPV value ' + (m.multipv || 1));
            w.postMessage('ucinewgame'); w.postMessage('isready');
          } else if (line === 'readyok' && !w.__r){ w.__r = 1; clearTimeout(to); res(); }
          else onLine(line);
        };
        w.postMessage('uci');
      });
      return ready;
    };
    function onLine(line){
      if (!job) return;
      if (line.indexOf('info ') === 0 && line.indexOf(' pv ') > 0){
        var m = line.match(/ depth (\d+).* multipv (\d+).* score (cp|mate) (-?\d+).* pv (.+)$/);
        if (m) job.lines[+m[2]] = {depth:+m[1], type:m[3], v:+m[4], pv:m[5].trim().split(' ')};
      } else if (line.indexOf('bestmove') === 0){
        var j = job; job = null; var bm = line.split(' ')[1];
        j.res({best:bm && bm !== '(none)' ? bm : null, lines:Object.keys(j.lines).sort(function(a, b){ return a - b; }).map(function(k){ return j.lines[k]; })});
      }
    }
    var coda = Promise.resolve();
    this.think = function(fen){   // una ricerca alla volta: la successiva parte solo dopo il «bestmove» della precedente
      var p = coda.then(function(){ return self.start(); }).then(function(){
        return new Promise(function(res){
          var m = cfg.motore; job = {lines:{}, res:res};
          w.postMessage('position fen ' + fen);
          w.postMessage('go ' + (m.prof ? 'depth ' + m.prof + ' ' : '') + 'movetime ' + m.ms);
        });
      });
      coda = p.catch(function(){}); return p;
    };
    this.stop = function(){ if (job && w) w.postMessage('stop'); };
    this.quit = function(){ if (w){ try { w.terminate(); } catch(e){} } w = null; ready = null; if (job){ var j = job; job = null; j.res(null); } };
  }
  function cpOf(l){ if (!l) return 0; return l.type === 'mate' ? (l.v > 0 ? 100000 - l.v * 100 : -100000 - l.v * 100) : l.v; }

  /* ======================= STILE DEI BOT (blocco 3b, 11-11, scelta di Kiko) =======================
     Il livello NON cambia: lo stile riordina solo le mosse che il motore considera già accettabili (MultiPV dello stesso motore,
     stessa forza). Tolleranza = scarto massimo (cp) dalla mossa che il bot avrebbe giocato; mai mosse peggiori di così.
     Niente stile se c'è un matto in vista (per uno dei due) o se le linee sono troppo poco profonde.
       aggressivo  (Luca):  scacchi, prese, pezzi verso il Re avversario, spinte di pedoni sul lato del Re
       posizionale (Nadia): mosse tranquille, centro e spazio, evita i cambi
       difensivo   (Paola): cambi (se è pari o avanti), arrocco, Re al sicuro, semplificare; niente sacrifici
       fantasioso  (Chess Node): di solito la mossa del motore; ogni tanto (18%) una mossa a sorpresa entro una tolleranza un po' più larga
       preciso     (Prof):  sempre la mossa del motore per il suo livello (nessuno scarto di stile) */
  var STILI = {
    aggressivo:{nome:'Aggressivo', descr:'Cerca scacchi, prese e attacco al Re'},
    posizionale:{nome:'Posizionale', descr:'Mosse tranquille, centro e spazio'},
    difensivo:{nome:'Difensivo', descr:'Cambia volentieri e tiene il Re al sicuro'},
    fantasioso:{nome:'Fantasioso', descr:'Ogni tanto tenta una mossa a sorpresa'},
    preciso:{nome:'Preciso', descr:'Gioca sempre la mossa migliore per il suo livello'}
  };
  var TOLL_STILE = {chessnote:60, paola:50, nerd:40, serena:30, maestro:0};   // cp, cala col livello
  var P_FANTASIA = 0.18, INERZIA = 0.75, MIN_DEPTH_STILE = 4;
  var VALP = {p:1, n:3, b:3, r:5, q:9, k:0};
  function cheb(a, b){ return Math.max(Math.abs(a.charCodeAt(0) - b.charCodeAt(0)), Math.abs(+a[1] - +b[1])); }
  function tratti(fen, uci){
    var g = new Chess(fen), me = g.turn(), opp = me === 'w' ? 'b' : 'w', mv;
    var mat = 0, kOpp = null, kMe = null, pezzi = 0;
    g.board().forEach(function(r){ r.forEach(function(q){ if (!q) return; if (q.type === 'k'){ if (q.color === opp) kOpp = q.square; else kMe = q.square; return; }
      mat += (q.color === me ? 1 : -1) * VALP[q.type]; if (q.type !== 'p') pezzi++; }); });
    try { mv = g.move({from:uci.slice(0, 2), to:uci.slice(2, 4), promotion:uci[4]}); } catch(e){ mv = null; }
    if (!mv) return null;
    var t = {uci:uci, scacco:g.inCheck(), presa:!!mv.captured, vPresa:VALP[mv.captured] || 0, vPezzo:VALP[mv.piece], pezzo:mv.piece,
      arrocco:/[kq]/.test(mv.flags), promo:!!mv.promotion, materiale:mat, mediogioco:pezzi >= 6};
    var risp = g.moves({verbose:true}).filter(function(m){ return m.to === mv.to; });
    t.attaccato = risp.length > 0;
    t.scambio = t.presa && t.attaccato && mv.piece !== 'k' && Math.abs(t.vPresa - t.vPezzo) <= 1;
    t.offreScambio = !t.presa && t.attaccato && risp.some(function(m){ return m.piece !== 'p' && m.piece !== 'k' && Math.abs(VALP[m.piece] - t.vPezzo) <= 1 && t.vPezzo >= 3; });
    t.sacrificio = t.attaccato && mv.piece !== 'k' && t.vPezzo - t.vPresa >= 2;
    var avanti = me === 'w' ? 1 : -1, dr = (+mv.to[1] - +mv.from[1]) * avanti;
    t.indietro = mv.piece !== 'p' && mv.piece !== 'k' && dr < 0;
    t.versoRe = kOpp ? cheb(mv.from, kOpp) - cheb(mv.to, kOpp) : 0;
    t.vicinoRe = kOpp ? cheb(mv.to, kOpp) <= 2 : false;
    t.spintaRe = mv.piece === 'p' && kOpp && Math.abs(mv.to.charCodeAt(0) - kOpp.charCodeAt(0)) <= 1 && dr > 0;
    t.spintaMioRe = mv.piece === 'p' && kMe && Math.abs(mv.to.charCodeAt(0) - kMe.charCodeAt(0)) <= 1 && t.mediogioco;
    var f = mv.to.charCodeAt(0) - 97, r = +mv.to[1];
    t.centro = (f >= 3 && f <= 4 && r >= 4 && r <= 5) ? 2 : (f >= 2 && f <= 5 && r >= 3 && r <= 6) ? 1 : 0;
    t.bordo = (mv.piece === 'n' || mv.piece === 'b') && (f === 0 || f === 7);
    t.reMosso = mv.piece === 'k' && !t.arrocco && t.mediogioco;
    t.tranquilla = !t.presa && !t.scacco;
    return t;
  }
  function punteggioStile(stile, t){
    if (!t) return -99;
    var s = 0;
    if (stile === 'aggressivo'){
      s += (t.scacco ? 2.5 : 0) + (t.presa ? 1.5 : 0) + Math.max(0, t.versoRe) * 0.8 + (t.vicinoRe ? 0.8 : 0) + (t.spintaRe && t.mediogioco ? 1.2 : 0) +
        (t.sacrificio ? 0.4 : 0) - (t.indietro ? 1 : 0) - (t.scambio && !t.scacco ? 0.6 : 0) - (t.reMosso ? 0.8 : 0);
    } else if (stile === 'posizionale'){
      s += (t.tranquilla ? 1.2 : 0) + t.centro * 0.8 + (t.pezzo === 'p' && t.centro ? 0.5 : 0) + (t.arrocco ? 0.8 : 0) -
        (t.scambio ? 1.8 : 0) - (t.offreScambio ? 0.8 : 0) - (t.bordo ? 0.8 : 0) - (t.reMosso ? 0.8 : 0) - (t.sacrificio ? 1.5 : 0);
    } else if (stile === 'difensivo'){
      var pari = t.materiale >= 0;
      s += (t.scambio ? (pari ? 2.2 : 0.4) : 0) + (t.offreScambio && pari ? 1.2 : 0) + (t.arrocco ? 2 : 0) + (t.indietro ? 0.4 : 0) -
        (t.sacrificio ? 2.5 : 0) - (t.spintaMioRe ? 1 : 0) - (t.reMosso ? 0.8 : 0);
    } else if (stile === 'fantasioso'){   // usato solo nel momento «a sorpresa»
      s += (t.sacrificio ? 2 : 0) + (t.scacco ? 1.2 : 0) + (t.bordo ? 0.8 : 0) + (t.spintaRe ? 0.8 : 0) + (t.promo && t.pezzo === 'p' && !/q$/.test(t.uci) ? 1 : 0) + (t.tranquilla ? 0.3 : 0);
    }
    return s;
  }
  /* Ritorna l'uci scelto dallo stile (o quello di partenza). base = mossa che il bot giocherebbe; rnd = numero casuale (prove) */
  function applicaStile(fen, lines, base, cfg, botId, rnd){
    var stile = cfg.stile, toll = TOLL_STILE[botId] != null ? TOLL_STILE[botId] : 0;
    var out = {uci:base, stile:false, motivo:''};
    if (!stile || stile === 'preciso' || !toll || !base || !lines || lines.length < 2){ out.motivo = 'nessuno'; return out; }
    if (lines.some(function(l){ return l.type === 'mate'; })){ out.motivo = 'matto'; return out; }
    var ref = lines.filter(function(l){ return l.pv && l.pv[0] === base; })[0] || lines[0];
    if (!ref || ref.depth < MIN_DEPTH_STILE){ out.motivo = 'profondita'; return out; }
    var refCp = cpOf(ref), r = rnd == null ? Math.random() : rnd;
    if (stile === 'fantasioso'){
      if (r >= P_FANTASIA){ out.motivo = 'normale'; return out; }
      var tf = Math.min(Math.round(toll * 1.6), (cfg.umano && cfg.umano.perditaAlt) || toll);
      var cf = lines.filter(function(l){ return l.pv && l.pv[0] && l.pv[0] !== base && Math.abs(refCp - cpOf(l)) <= tf; })
        .map(function(l){ return {uci:l.pv[0], p:punteggioStile('fantasioso', tratti(fen, l.pv[0])) - Math.max(0, refCp - cpOf(l)) / tf}; })
        .filter(function(c){ return c.p > -50; });
      if (!cf.length){ out.motivo = 'nessuna_sorpresa'; return out; }
      cf.sort(function(a, b){ return b.p - a.p; });
      out.uci = cf[0].uci; out.stile = true; out.motivo = 'sorpresa'; return out;
    }
    var cand = lines.filter(function(l){ return l.pv && l.pv[0] && Math.abs(refCp - cpOf(l)) <= toll; });
    if (!cand.some(function(l){ return l.pv[0] === base; })) cand.unshift(ref);
    var best = null;
    cand.forEach(function(l){
      var u = l.pv[0], t = tratti(fen, u); if (!t) return;
      var p = punteggioStile(stile, t) - 2 * Math.max(0, refCp - cpOf(l)) / toll + (u === base ? INERZIA : 0);
      if (!best || p > best.p) best = {uci:u, p:p};
    });
    if (best && best.uci !== base){ out.uci = best.uci; out.stile = true; out.motivo = 'stile'; } else out.motivo = 'uguale';
    return out;
  }

  /* Livello umano: sceglie la mossa del bot. Ritorna {uci, tipo:'motore'|'alt'|'caso', eval, stile:true se lo stile ha cambiato mossa}.
     blocco 3b: lo stile agisce solo sulla mossa «motore» (tra candidate entro la tolleranza) e sceglie tra le alternative del livello
     umano (che prima erano a caso): le sviste («caso»), le probabilità e le perdite massime del livello restano identiche. */
  function scegli(fen, r, cfg, ply, botId){
    var g = new Chess(fen), legal = g.moves({verbose:true}), u = cfg.umano;
    var lines = (r && r.lines) || [], best = (r && r.best) || (lines[0] && lines[0].pv[0]);
    var ev = lines[0] ? cpOf(lines[0]) : 0;
    if (botId == null){ for (var k in BOT_CONFIG) if (BOT_CONFIG[k] === cfg) botId = k; }
    if (!best){ var m0 = pick(legal); return {uci:m0.from + m0.to + (m0.promotion || ''), tipo:'caso', eval:ev}; }
    if (u.vedeMatto1 && lines[0] && lines[0].type === 'mate' && lines[0].v === 1) return {uci:lines[0].pv[0], tipo:'motore', eval:ev};
    // finale stravinto (avversario con al massimo 2 pezzi oltre al Re, +9 per me): niente sviste, così chiude la partita invece di girare a vuoto
    var suoi = 0; fen.split(' ')[0].split('').forEach(function(ch){ if (/[pnbrq]/i.test(ch) && ((ch === ch.toUpperCase()) !== (g.turn() === 'w'))) suoi++; });
    if (lines[0] && lines[0].pv[0] && ev >= 900 && suoi <= 2) return {uci:lines[0].pv[0], tipo:'motore', eval:ev};
    var x = Math.random();
    if (ply >= u.daSemimossa && x < u.pCaso && legal.length > 1){
      var m = pick(legal); return {uci:m.from + m.to + (m.promotion || ''), tipo:'caso', eval:ev};
    }
    if (x < u.pCaso + u.pAlt && lines.length > 1){
      var top = cpOf(lines[0]), alt = lines.slice(1).filter(function(l){ return l.pv[0] && top - cpOf(l) <= u.perditaAlt; });
      if (alt.length){
        var st = cfg.stile;
        if (st && st !== 'preciso' && st !== 'fantasioso' && alt.length > 1 && Math.random() < 0.6){   // stessa alternativa «umana», scelta col gusto del bot
          var sc = alt.map(function(l){ return {uci:l.pv[0], p:punteggioStile(st, tratti(fen, l.pv[0]))}; }).sort(function(a, b){ return b.p - a.p; });
          return {uci:sc[0].uci, tipo:'alt', eval:ev, stile:true};
        }
        return {uci:pick(alt).pv[0], tipo:'alt', eval:ev};
      }
    }
    var s = applicaStile(fen, lines, best, cfg, botId);
    if (s.stile && legal.some(function(m){ return m.from + m.to + (m.promotion || '') === s.uci; })) return {uci:s.uci, tipo:'motore', eval:ev, stile:true};
    return {uci:best, tipo:'motore', eval:ev};
  }

  /* ======================= stato ======================= */
  var KEY = 'chessnodeplay-bot-v1', KIC = 'chessnodeplay-bot-incorso-v1';
  var pref = {bot:'chessnote', colore:'w', orologio:'no', handicap:null};
  function leggiPref(){
    try { var sv = JSON.parse(localStorage.getItem(KEY) || '{}'); for (var k in sv) if (k in pref) pref[k] = sv[k]; } catch(e){}
    if (!BOT_CONFIG[pref.bot] || !BOT_CONFIG[pref.bot].attivo) pref.bot = 'chessnote';
    if (!(pref.orologio in OROLOGI)) pref.orologio = 'no';
    if (!HAND[pref.handicap]) pref.handicap = null;
  }
  leggiPref();
  function savePref(){ try { localStorage.setItem(KEY, JSON.stringify(pref)); } catch(e){} }

  var G = null;   // partita in corso
  var eng = null, chk = null, tok = 0, tick = null;   // chk = motore di controllo a piena forza (avviso «Attenzione» e valutazione della patta)
  var stats = {motore:0, alt:0, caso:0};

  /* ======================= DOM ======================= */
  var root = null, $ = function(s){ return root.querySelector(s); };
  function build(){
    root = document.createElement('div');
    root.id = 'botPage'; root.className = 'bop'; root.hidden = true;
    root.setAttribute('role', 'dialog'); root.setAttribute('aria-modal', 'true'); root.setAttribute('aria-label', 'Gioca contro un bot');
    root.innerHTML =
      '<header class="bop-top">' +
        '<button type="button" class="bop-ib bop-back" aria-label="Indietro">' + svg('chevron-left', 24) + '</button>' +
        '<div class="bop-tt"><b>Gioca contro un bot</b><small class="bop-sub"></small></div>' +
        '<button type="button" class="bop-ib bop-more" aria-label="Altro: condividi la partita" aria-haspopup="dialog">' + svg('ellipsis', 22) + '</button>' +   // 14-11 stampo: menu ⋯
      '</header>' +
      '<div class="bop-scroll">' +
        /* --- partita (blocco 3, 11-11: la scelta è nella pagina Gioca 20f) --- */
        '<div class="bop-game">' +
          '<div class="bop-lz" aria-hidden="true"></div>' +   // 14-11 stampo: spazio sopra, così la scacchiera parte alla y dell'esercizio
          /* 14-11 ritocco (Kiko): mentre si gioca SOLO avatar grande + fumetto chiaro (componente dello stampo, come l'esercizio) con nome e
             livello del bot e sotto ciò che dice; riga sottile dei catturati appena sopra la scacchiera; sotto solo Abbandona/Patta/Annulla.
             Elenco mosse, Condividi, ⋯ e il resto compaiono a partita finita (classe bop-fine). */
          '<div class="bop-opp cn-st-coach"><span class="cn-st-ava"><img class="bop-av" alt=""></span>' +
            '<div class="bop-who cn-st-bub"><div class="bop-wh"><b class="bop-name cn-st-who"></b><span class="bop-clock bop-clk-bot" hidden></span></div>' +
            '<p class="bop-bubble cn-st-txt" aria-live="polite"></p><span class="bop-tags"></span></div></div>' +
          '<div class="bop-caps"><div class="bop-cap bop-cap-bot" aria-label="Pezzi catturati dal bot"></div><div class="bop-cap bop-cap-me" aria-label="Pezzi catturati da te"></div></div>' +
          '<div class="bop-board" role="grid" aria-label="Scacchiera"></div>' +
          '<div class="bop-me"><span class="bop-you">Tu</span><span class="bop-turn"></span><span class="bop-clock bop-clk-me" hidden></span></div>' +
          '<div class="bop-promo" hidden></div>' +
          '<div class="bop-result" hidden></div>' +
          '<div class="bop-confirm" hidden></div>' +
          '<div class="bop-actions">' +
            '<button type="button" class="bop-btn" data-a="resign">' + svg('square-x', 18) + 'Abbandona</button>' +
            '<button type="button" class="bop-btn" data-a="draw"><b class="bop-half" aria-hidden="true">½</b>Patta</button>' +
            '<button type="button" class="bop-btn" data-a="undo">' + svg('undo-2', 18) + 'Annulla mossa</button>' +
          '</div>' +
          '<p class="bop-nota bop-nota-undo" hidden>Annulla mossa: solo nelle partite senza tempo.</p>' +
          '<section class="bop-card"><h3>Mosse</h3><div class="bop-moves"></div></section>' +
        '</div>' +
      '</div>';
    document.body.appendChild(root);
    $('.bop-back').onclick = back;
    $('.bop-board').addEventListener('click', onBoard);
    $('.bop-board').addEventListener('pointerdown', dragGiu);   // 14-11: trascinamento (mossa normale e premove)
    $('.bop-promo').onclick = function(e){ var b = e.target.closest('[data-pr]'); if (!b || !G || !G.promo) return; var p = G.promo; G.promo = null; $('.bop-promo').hidden = true;
      if (p.pm){ pmFissa(p.from, p.to, b.dataset.pr); return; }   // 13-11: promozione scelta subito per il premove
      userMove({from:p.from, to:p.to, promotion:b.dataset.pr}); };
    $('.bop-actions').onclick = function(e){ var b = e.target.closest('[data-a]'); if (!b || b.disabled || b.getAttribute('aria-disabled') === 'true') return; var a = b.dataset.a;
      if (a === 'resign') ask('Vuoi davvero abbandonare la partita?', 'Abbandona', function(){ finish('bot', 'abbandono'); });
      else if (a === 'draw') offerDraw(); else if (a === 'undo') chiediUndo(); };
    $('.bop-confirm').onclick = function(e){ var b = e.target.closest('[data-c]'); if (!b) return; var f = $('.bop-confirm').__ok; $('.bop-confirm').hidden = true; if (b.dataset.c === 'ok' && f) f(); };
    $('.bop-result').onclick = function(e){ var b = e.target.closest('[data-r]'); if (!b) return; var r = b.dataset.r;
      if (r === 'analizza') analizza(); else if (r === 'rivincita') newGame(true); else if (r === 'nuovo') esci(); else if (r === 'share') condividi(); };
    $('.bop-more').onclick = altro;
    ST = window.CNStampo ? CNStampo.crea('bot', {root:root, zona:'.bop-lz', wrap:'.bop-game', scroll:'.bop-scroll', board:'.bop-board', latoFisso:true,
      aiuto:false, valutazione:false, premove:true, condividi:true, motore:true}) : null;
    window.addEventListener('resize', allinea);
  }
  /* ---------- 14-11 stampo unico: misure, menu ⋯ e Condividi ---------- */
  var ST = null;
  function allinea(){ try { if (ST && root && !root.hidden) ST.allinea(); } catch(e){} }
  function sorgente(){
    if (!G) return null;
    var cfg = G.cfg || BOT_CONFIG[G.bot] || BOT_CONFIG.chessnote, me = 'Tu', bot = cfg.nome + ' (bot)';
    return {fen0:G.fen0 || null, sans:G.chess.history(), orient:G.me === 'b' ? 'b' : 'w',
      tags:{White:G.me === 'w' ? me : bot, Black:G.me === 'w' ? bot : me, Result:G.over ? G.over.res : '*', Event:(G.allenamento ? 'Partita di allenamento contro ' : 'Partita contro ') + cfg.nome},
      titolo:'Tu vs ' + cfg.nome, etichetta:'Partita', sub:G.over ? (G.over.res || '').replace(/1\/2/g, '½') : 'Partita in corso', nome:'chessnode_partita_' + (G.bot || 'bot')};
  }
  function condividi(tab){ var S = sorgente(); if (S && ST) ST.condividi(S, tab || 'pgn'); }
  function altro(){
    if (!window.CNStampo) return;
    CNStampo.menu({titolo:'Partita contro un bot', voci:[{id:'share', testo:'Condividi', sub:'PGN, immagine e GIF', icona:'share-2', disabled:!G}], scegli:function(a){ if (a === 'share') condividi(); }});
  }
  function mostraRoot(){
    if (!root) build();
    try { if (window.CNHome && CNHome.visibile && CNHome.visibile()) CNHome.nascondi(); } catch(e){}
    if (root.hidden) lastF = document.activeElement;
    root.hidden = false; document.documentElement.classList.add('bop-on');
    allinea(); requestAnimationFrame(allinea);
  }

  /* ---------- partita in corso salvata (Riprendi la partita, pagina Gioca) ---------- */
  function salvaIncorso(){
    if (!G || G.over) return;
    var n = G.chess.history().length;
    if (!n){ try { localStorage.removeItem(KIC); } catch(e){} return; }
    var c = null;
    if (G.clock){ c = {w:G.clock.w, b:G.clock.b, inc:G.clock.inc, label:G.clock.label}; }
    try { localStorage.setItem(KIC, JSON.stringify({id:G.id, bot:G.bot, me:G.me, colorePref:G.colorePref, orologio:G.clock ? G.clock.label : 'no', fen0:G.fen0, sans:G.chess.history(),
      clock:c, handicap:G.hand, allenamento:!!G.allenamento, avvisato:!!G.avvisato, ts:G.tsMossa || Date.now(), inizio:G.start.getTime()})); } catch(e){}
  }
  function leggiIncorso(){ try { var g = JSON.parse(localStorage.getItem(KIC)); return g && BOT_CONFIG[g.bot] && Array.isArray(g.sans) ? g : null; } catch(e){ return null; } }
  function togliIncorso(){ try { localStorage.removeItem(KIC); } catch(e){} }
  /* nuova partita sopra una sospesa: quella sospesa conta come abbandonata (la pagina Gioca chiede conferma prima) */
  function chiudiSospesa(){
    var s = leggiIncorso(); if (!s) return;
    togliIncorso();
    if (!s.sans.length) return;
    var g = new Chess(s.fen0 || undefined); try { s.sans.forEach(function(m){ g.move(m); }); } catch(e){}
    registra({id:s.id, bot:s.bot, me:s.me, colorePref:s.colorePref, clockLabel:s.clock ? s.clock.label : 'no', fen0:s.fen0, hand:s.handicap, allenamento:s.allenamento,
      sans:g.history(), start:new Date(s.inizio || Date.now())}, 'bot', 'abbandono');
  }

  /* ---------- partita ---------- */
  function newGame(rivincita, da){
    stopGame();
    var cfg = BOT_CONFIG[pref.bot];
    var col = pref.colore === 'r' ? (Math.random() < .5 ? 'w' : 'b') : pref.colore;
    if (rivincita && G && pref.colore === 'r') col = G.me === 'w' ? 'b' : 'w';   // rivincita a colori invertiti se «Casuale»
    if (da && da.colore) col = da.colore;
    var oc = OROLOGI[pref.orologio], hand = HAND[pref.handicap] ? pref.handicap : null, fen0 = hand ? fenHandicap(hand, col) : null;
    G = {id:'p-' + Date.now(), bot:pref.bot, cfg:cfg, me:col, colorePref:pref.colore, chess:new Chess(fen0 || undefined), fen0:fen0, hand:hand, allenamento:false, avvisato:false,
         sel:null, promo:null, over:null, clock:oc ? {w:oc.min * 60000, b:oc.min * 60000, inc:oc.inc * 1000, last:0, label:pref.orologio} : null,
         lastEval:0, drawBlock:0, thinking:false, start:new Date()};
    togliIncorso();
    avviaVista();
    bubble(neutro('inizio'));
    render(); $('.bop-scroll').scrollTop = 0;
    if (G.clock){ G.clock.last = Date.now(); tick = setInterval(clockTick, 100); }
    if (G.chess.turn() !== G.me) botTurn();
  }
  function avviaVista(){
    var cfg = G.cfg;
    stats = {motore:0, alt:0, caso:0};
    if (!eco) caricaEco();
    eng = new BotEngine(cfg); eng.start().catch(function(){ bubble('Il motore non è disponibile su questo dispositivo.'); });
    mostraRoot();
    $('.bop-result').hidden = true; $('.bop-confirm').hidden = true; $('.bop-promo').hidden = true;
    $('.bop-sub').textContent = cfg.nome + ' · ~' + cfg.stima + ' stimato' + (G.clock ? ' · ' + tempoTxt(G.clock.label) : ' · Senza tempo');
    var av = $('.bop-opp .bop-av'); av.src = avatar(G.bot); $('.bop-name').textContent = cfg.nome + ' · ~' + cfg.stima; $('.bop-name').title = cfg.nome + ' · livello stimato ~' + cfg.stima;   // nel fumetto: nome e livello (il «stimato» resta nell'intestazione)
    $('.bop-you').textContent = 'Tu · ' + (G.me === 'w' ? 'Bianco' : 'Nero');
    $('.bop-clk-bot').hidden = $('.bop-clk-me').hidden = !G.clock;
    $('.bop-game').classList.toggle('bop-tempo', !!G.clock);   // senza tempo la riga «Tu» non serve: niente da mostrare sotto oltre ai 3 tasti
    etichette();
  }
  function tempoTxt(l){ return l === 'no' ? 'Senza tempo' : /\+/.test(l) ? l : l + ' min'; }
  function etichette(){
    var t = [];
    var st = STILI[G.cfg.stile]; if (st) t.push('<i class="bop-tag stile" title="' + esc(st.descr) + '">' + esc(st.nome) + '</i>');   // blocco 3b: stile del bot
    if (G.hand) t.push('<i class="bop-tag hand">' + esc(etichettaHand(G.hand, G.me)) + '</i>');
    if (G.allenamento) t.push('<i class="bop-tag allen">Partita di allenamento</i>');
    $('.bop-tags').innerHTML = t.join('');
    $('.bop-tags').hidden = !t.length;
  }
  /* fumetto neutro (08-11): nessuna frase dei personaggi, solo poche righe neutre */
  function neutro(k){ return {inizio:'Buona partita!', pensa:'Ci penso…', pattaSi:'D\'accordo, patta.', pattaNo:'Preferisco continuare.', riprendi:'Riprendiamo da qui.', fine:'Bella partita! Se vuoi, la analizziamo insieme.'}[k] || ''; }
  function riprendi(){
    var s = leggiIncorso();
    if (!s){ if (window.CNHome && CNHome.ritorna) CNHome.ritorna('gioca.html'); return false; }
    stopGame();
    var cfg = BOT_CONFIG[s.bot], g = new Chess(s.fen0 || undefined);
    try { s.sans.forEach(function(m){ g.move(m); }); } catch(e){}
    G = {id:s.id || 'p-' + Date.now(), bot:s.bot, cfg:cfg, me:s.me, colorePref:s.colorePref || s.me, chess:g, fen0:s.fen0 || null, hand:HAND[s.handicap] ? s.handicap : null,
         allenamento:!!s.allenamento, avvisato:!!s.avvisato, sel:null, promo:null, over:null,
         clock:s.clock ? {w:s.clock.w, b:s.clock.b, inc:s.clock.inc, last:0, label:s.clock.label} : null, lastEval:0, drawBlock:0, thinking:false,
         start:new Date(s.inizio || Date.now()), tsMossa:s.ts};
    avviaVista();
    bubble(neutro('riprendi'));
    render(); $('.bop-scroll').scrollTop = 0;
    if (G.clock){ G.clock.last = Date.now(); tick = setInterval(clockTick, 100); }   // l'orologio era fermo mentre la partita era sospesa
    if (!checkEnd() && G.chess.turn() !== G.me) botTurn();
    return true;
  }
  function start(){
    leggiPref();
    chiudiSospesa();
    G = null;
    newGame();
  }
  function rivincita(id){
    var r = trovaRec(id); leggiPref();
    if (r){
      pref.bot = BOT_CONFIG[r.bot] ? r.bot : pref.bot; pref.orologio = (r.orologio in OROLOGI) ? r.orologio : 'no'; pref.handicap = HAND[r.handicap] ? r.handicap : null;
      pref.colore = r.colorePref || r.colore; savePref();
    }
    chiudiSospesa(); G = null;
    newGame(false, r && pref.colore === 'r' ? {colore:r.colore === 'w' ? 'b' : 'w'} : null);
  }
  function stopGame(){ tok++; precTok++; clearInterval(tick); tick = null; if (eng){ eng.quit(); eng = null; } if (chk){ chk.quit(); chk = null; } }
  function render(){
    if (!G) return;
    var g = G.chess, b = g.board(), flip = G.me === 'b', h = g.history({verbose:true}), last = h[h.length - 1];
    var legal = G.sel ? g.moves({square:G.sel, verbose:true}).map(function(m){ return m.to; }) : [];
    var pmT = (G.pmSel && window.CNPremove && pmAperto()) ? CNPremove.dests(function(q){ return g.get(q); }, G.pmSel) : [];
    var inCheck = g.inCheck(), mateNow = inCheck && g.isCheckmate(), html = '';
    for (var r = 0; r < 8; r++) for (var f = 0; f < 8; f++){
      var rr = flip ? 7 - r : r, ff = flip ? 7 - f : f, sq = 'abcdefgh'[ff] + (8 - rr), p = b[rr][ff];
      var k = ['bop-sq', (rr + ff) % 2 ? 'd' : 'l'];
      if (sq === G.sel) k.push('sel');
      if (last && (sq === last.from || sq === last.to)) k.push('last');
      if (legal.indexOf(sq) >= 0) k.push(p ? 'cap' : 'dot');
      else if (pmT.indexOf(sq) >= 0) k.push('pmdot');
      if (sq === G.pmSel) k.push('pm-sel');
      if (G.pm && (sq === G.pm.from || sq === G.pm.to)) k.push('pm');
      var kc = inCheck && p && p.type === 'k' && p.color === g.turn(), CF = window.CNFx;
      if (kc) k.push('bop-chk', mateNow ? 'mate' : 'check');
      html += '<div class="' + k.join(' ') + '" data-sq="' + sq + '" role="gridcell" aria-label="' + sq + (p ? ' ' + p.color + p.type.toUpperCase() : '') + '">' +
        (f === 0 ? '<i class="bop-co r">' + (8 - rr) + '</i>' : '') + (r === 7 ? '<i class="bop-co f">' + 'abcdefgh'[ff] + '</i>' : '') +
        (kc && CF ? CF.fillHtml(mateNow, g.fen()) : '') +
        (p ? '<img alt="" draggable="false" src="' + A.psrc(p.color + p.type.toUpperCase()) + '">' : '') +
        (mateNow && CF && p && p.type === 'k' ? (p.color === g.turn() ? CF.LOSE : CF.WIN) : '') + '</div>';
    }
    $('.bop-board').innerHTML = html;
    root.classList.toggle('bop-fine', !!G.over);   // 14-11 ritocco: a partita finita compaiono mosse, ⋯, Condividi, Analizza, Rivincita…
    renderMoves(); renderClock(); renderButtons(); renderCatturati();
    var t = $('.bop-turn');
    t.textContent = G.over ? '' : G.thinking ? '' : (g.turn() === G.me ? 'Tocca a te' : '');
  }
  function renderMoves(){
    var s = G.chess.history(), h = '';
    for (var i = 0; i < s.length; i++){ if (i % 2 === 0) h += '<span class="bop-n">' + (i / 2 + 1) + '.</span>'; h += '<span class="bop-m' + (i === s.length - 1 ? ' cur' : '') + '">' + esc(it(s[i])) + '</span>'; }
    var box = $('.bop-moves'); box.innerHTML = h ? '<div class="bop-grid">' + h + '</div>' : '<p class="bop-mu">Nessuna mossa. ' + (G.me === 'w' ? 'Muovi tu: tocca un pezzo e poi la casa.' : 'Muove prima ' + esc(G.cfg.nome) + '.') + '</p>';
    box.scrollTop = box.scrollHeight;
  }
  /* blocco 3: Abbandona, Patta e Annulla mossa sempre visibili; Annulla solo senza tempo (con tempo resta visibile ma spento, con la nota) */
  function renderButtons(){
    var a = $('.bop-actions'), over = !!G.over, n = G.chess.history().length;
    a.hidden = over;
    var u = a.querySelector('[data-a=undo]');
    var noUndo = !!G.clock || !n || (n < 2 && G.me === 'b' && !G.fen0) || G.thinking && n < 2;
    u.disabled = noUndo; u.setAttribute('aria-disabled', String(noUndo));
    $('.bop-nota-undo').hidden = over || !G.clock;
    a.querySelector('[data-a=draw]').disabled = n < 2 || G.drawBlock > n || !!G.valutaPatta;
    a.querySelector('[data-a=resign]').disabled = false;
  }
  /* pezzi catturati con +N (differenza di materiale sulla scacchiera; con l'handicap il vantaggio iniziale si vede subito) */
  var VAL = {p:1, n:3, b:3, r:5, q:9, k:0};
  function renderCatturati(){
    var presi = {w:[], b:[]};   // presi[c] = pezzi catturati DAL colore c
    G.chess.history({verbose:true}).forEach(function(m){ if (m.captured) presi[m.color].push(m.captured); });
    var mat = {w:0, b:0};
    G.chess.board().forEach(function(r){ r.forEach(function(q){ if (q) mat[q.color] += VAL[q.type]; }); });
    var botC = G.me === 'w' ? 'b' : 'w', diff = mat[G.me] - mat[botC];
    var ord = 'qrbnp';
    function riga(c, lead){
      var l = presi[c].slice().sort(function(x, y){ return ord.indexOf(x) - ord.indexOf(y); }), other = c === 'w' ? 'b' : 'w';
      return l.map(function(t){ return '<img alt="" src="' + A.psrc(other + t.toUpperCase()) + '">'; }).join('') + (lead > 0 ? '<b>+' + lead + '</b>' : '');
    }
    $('.bop-cap-me').innerHTML = riga(G.me, diff);
    $('.bop-cap-bot').innerHTML = riga(botC, -diff);
  }
  function renderClock(){
    if (!G.clock) return;
    var bc = $('.bop-clk-bot'), mc = $('.bop-clk-me'), botC = G.me === 'w' ? 'b' : 'w', turn = G.chess.turn();
    bc.textContent = fmtClock(G.clock[botC]); mc.textContent = fmtClock(G.clock[G.me]);
    bc.classList.toggle('run', !G.over && turn === botC); mc.classList.toggle('run', !G.over && turn === G.me);
    mc.classList.toggle('low', G.clock[G.me] < 20000);
  }
  function clockTick(){
    if (!G || !G.clock || G.over) return;
    var now = Date.now(), t = G.chess.turn();
    G.clock[t] -= now - G.clock.last;                    // scorre sempre l'orologio di chi deve muovere
    G.clock.last = now;
    if (G.clock[t] <= 0){
      G.clock[t] = 0;
      var other = t === 'w' ? 'b' : 'w';
      var onlyKing = G.chess.board().every(function(r){ return r.every(function(p){ return !p || p.color !== other || p.type === 'k'; }); });
      if (onlyKing) finish('patta', 'tempo_patta'); else finish(t === G.me ? 'bot' : 'utente', 'tempo');
    }
    renderClock();
  }
  function addInc(color){ if (G.clock){ G.clock[color] += G.clock.inc; } }

  /* 13-11 PREMOVE (premove.js): mentre il bot pensa si tocca un proprio pezzo e poi la casa; case in azzurro discreto.
     Toccando di nuovo una delle due case o una casa non valida si annulla; un altro premove lo sostituisce.
     Appena il bot ha mosso: se è legale si gioca come una mossa normale, altrimenti si annulla in silenzio. */
  function pmAperto(){ return !!(G && !G.over && G.thinking && G.chess.turn() !== G.me && window.CNPremove); }
  function pmGet(q){ return G.chess.get(q); }
  function pmMio(q){ var p = G.chess.get(q); return !!p && p.color === G.me; }
  function pmTocca(sq){
    if (!pmAperto()) return;
    if (G.pm && !G.pmSel && (sq === G.pm.from || sq === G.pm.to)){ G.pm = null; render(); return; }
    if (G.pmSel){
      if (sq === G.pmSel){ G.pmSel = null; render(); return; }
      if (pmMio(sq) && !CNPremove.target(pmGet, G.pmSel, sq)){ G.pmSel = sq; render(); return; }
      var f = G.pmSel; G.pmSel = null;
      var t = CNPremove.target(pmGet, f, sq);
      if (!t){ G.pm = null; render(); return; }
      if (CNPremove.needsPromo(pmGet, f, t)){ G.promo = {from:f, to:t, pm:true}; askPromo(f, t, true); render(); return; }
      pmFissa(f, t); return;
    }
    if (pmMio(sq)){ G.pmSel = sq; render(); return; }
    if (G.pm){ G.pm = null; render(); }
  }
  function pmFissa(f, t, pr){ if (!G || G.over) return; G.pm = {from:f, to:t, promo:pr}; render(); if (!pmAperto()) pmGioca(); }
  function pmGioca(){
    if (!G || !G.pm) return;
    var P = G.pm, gid = G; G.pm = null; G.pmSel = null;
    setTimeout(function(){   // un attimo dopo la mossa del bot, così si vede dove è arrivato
      if (G !== gid || G.over || G.thinking || G.chess.turn() !== G.me){ if (G === gid) render(); return; }
      var mv = CNPremove.legal(G.chess, P);
      if (!mv){ render(); return; }                      // diventata illegale: si annulla in silenzio
      userMove({from:mv.from, to:mv.to, promotion:mv.promotion});
    }, 140);
  }
  /* 14-11 (Kiko t1931u): TRASCINAMENTO oltre ai due tocchi, sia per la mossa normale sia per il premove mentre il bot pensa
     (pronto anche per il sito: Pointer Events = dito, mouse e penna). Un tocco senza spostamento resta un tocco (onBoard).
     Rilasciando su una casa: se tocca a te e la mossa è legale si gioca; se il bot pensa diventa il premove (stesse regole
     dei due tocchi: geometria del pezzo, promozione chiesta subito); altrove si annulla senza errori. */
  var DR = null;
  function sqDa(x, y){ var el = document.elementFromPoint(x, y), q = el && el.closest && el.closest('#botPage .bop-sq'); return q ? q.dataset.sq : null; }
  function dragGiu(e){
    if (!G || G.over || G.promo || (e.button != null && e.button > 0)) return;
    var q = e.target.closest('.bop-sq'); if (!q) return;
    var sq = q.dataset.sq, p = G.chess.get(sq);
    if (!p || p.color !== G.me) return;
    var img = q.querySelector('img'); if (!img) return;
    DR = {from:sq, x:e.clientX, y:e.clientY, id:e.pointerId, on:false, img:img, g:null, w:q.getBoundingClientRect().width};
    window.addEventListener('pointermove', dragMuovi, {passive:false});
    window.addEventListener('pointerup', dragSu);
    window.addEventListener('pointercancel', dragVia);
  }
  function dragMuovi(e){
    if (!DR || e.pointerId !== DR.id) return;
    var dx = e.clientX - DR.x, dy = e.clientY - DR.y;
    if (!DR.on){
      if (dx * dx + dy * dy < 64) return;                 // sotto 8 px è ancora un tocco
      DR.on = true;
      var g = DR.g = DR.img.cloneNode(false), w = DR.w * 1.12;
      g.className = 'bop-drag';
      g.style.cssText = 'position:fixed;left:0;top:0;width:' + w + 'px;height:' + w + 'px;pointer-events:none;z-index:2147483100;will-change:transform;filter:drop-shadow(0 6px 8px rgba(0,0,0,.35))';
      document.body.appendChild(g); DR.img.style.opacity = '.35';
      if (pmAperto()){ G.pmSel = DR.from; render(); DR.img = ($('.bop-sq[data-sq="' + DR.from + '"] img') || DR.img); DR.img.style.opacity = '.35'; }
      else if (!G.thinking && G.chess.turn() === G.me){ G.sel = DR.from; render(); DR.img = ($('.bop-sq[data-sq="' + DR.from + '"] img') || DR.img); DR.img.style.opacity = '.35'; }
    }
    if (e.cancelable) e.preventDefault();
    var w2 = DR.w * 1.12 / 2;
    DR.g.style.transform = 'translate(' + (e.clientX - w2) + 'px,' + (e.clientY - w2 - DR.w * 0.25) + 'px)';
  }
  function dragFine(){
    window.removeEventListener('pointermove', dragMuovi); window.removeEventListener('pointerup', dragSu); window.removeEventListener('pointercancel', dragVia);
    if (DR && DR.g && DR.g.parentNode) DR.g.parentNode.removeChild(DR.g);
    if (DR && DR.img) DR.img.style.opacity = '';
    var d = DR; DR = null; return d;
  }
  function dragVia(){ var d = dragFine(); if (d && d.on && G){ G.sel = null; if (pmAperto()) G.pmSel = null; render(); } }
  function dragSu(e){
    if (!DR || e.pointerId !== DR.id) return;
    var d = dragFine(); if (!d.on || !G || G.over) return;   // tocco semplice: ci pensa il click (onBoard)
    G.dragClick = Date.now();                            // il click che segue il rilascio non deve contare come tocco
    var to = sqDa(e.clientX, e.clientY), f = d.from;
    if (pmAperto()){
      G.pmSel = null;
      var t = to && CNPremove.target(pmGet, f, to);
      if (!t){ render(); return; }
      if (CNPremove.needsPromo(pmGet, f, t)){ G.promo = {from:f, to:t, pm:true}; askPromo(f, t, true); render(); return; }
      pmFissa(f, t); return;
    }
    G.sel = null;
    if (G.thinking || G.chess.turn() !== G.me || !to){ render(); return; }
    var ms = G.chess.moves({square:f, verbose:true}).filter(function(m){ return m.to === to; });
    if (!ms.length){ render(); return; }
    if (ms.some(function(m){ return m.promotion; })){ askPromo(f, to); return; }
    userMove({from:f, to:to});
  }
  function onBoard(e){
    if (!G || G.over) return;
    if (G.dragClick && Date.now() - G.dragClick < 400){ G.dragClick = 0; return; }
    var s0 = e.target.closest('.bop-sq'); if (!s0) return;
    if (G.thinking || G.chess.turn() !== G.me){ pmTocca(s0.dataset.sq); return; }
    var s = s0;
    var sq = s.dataset.sq, g = G.chess;
    if (G.sel){
      var ms = g.moves({square:G.sel, verbose:true}).filter(function(m){ return m.to === sq; });
      if (ms.length){
        if (ms.some(function(m){ return m.promotion; })){ askPromo(G.sel, sq); return; }
        userMove({from:G.sel, to:sq}); return;
      }
    }
    var p = g.get(sq); G.sel = (p && p.color === G.me && G.sel !== sq) ? sq : null; render();
  }
  function askPromo(from, to, pm){
    G.promo = {from:from, to:to, pm:!!pm}; var box = $('.bop-promo');
    box.innerHTML = '<span>Promuovi a:</span>' + ['q','r','b','n'].map(function(t){ return '<button type="button" class="bop-pb" data-pr="' + t + '" aria-label="' + {q:'Donna',r:'Torre',b:'Alfiere',n:'Cavallo'}[t] + '"><img alt="" src="' + A.psrc(G.me + t.toUpperCase()) + '"></button>'; }).join('');
    box.hidden = false;
  }
  function sound(mv){ try { if (A.Sound && A.Sound.play) A.Sound.play(mv.captured ? 'capture' : 'move'); } catch(e){} }
  function userMove(m){
    var mv; try { mv = G.chess.move(m); } catch(e){ mv = null; }
    G.sel = null; if (!mv){ render(); return; }
    addInc(G.me); sound(mv); $('.bop-confirm').hidden = true; G.lastUserMv = mv;
    var ripresa = G.lastBotMv && G.lastBotMv.captured && G.lastBotMv.to === mv.to;   // riprendere dopo uno scambio non è una «presa» da commentare
    if (G.chess.inCheck()){ if (parla()) bubble(frase(G.bot, 'scaccoRicevuto')); }
    else if (mv.captured && !ripresa && !riprendibile(mv.to) && parla()) bubble(frase(G.bot, 'persoPezzo'));   // scambio in corso: niente commento
    annunciaApertura();
    G.tsMossa = Date.now();
    render();
    if (!checkEnd()){ salvaIncorso(); botTurn(); }
  }
  function botTurn(){
    var my = ++tok, g = G.chess, fen = g.fen(), cfg = G.cfg, t0 = Date.now();
    var target = rnd(cfg.umano.ritardo[0], cfg.umano.ritardo[1]);
    if (G.clock){ var left = G.clock[g.turn()]; if (left < 30000) target = Math.min(target, 500); }
    G.thinking = true; render();
    eng.think(fen).then(function(r){
      if (my !== tok || !G || G.over) return;
      var c = scegli(fen, r, cfg, g.history().length, G.bot);
      stats[c.tipo]++; if (c.stile) stats.stile = (stats.stile || 0) + 1; G.lastEval = c.eval;
      var svista = rilevaSvista(r, g.history().length);
      if (svista){ bubble(frase(G.bot, Math.random() < .5 ? 'ops' : 'svista')); G.lastSvista = g.history().length; }   // a volte solo «Ops…», a volte la frase lunga
      // valutazione «dopo la mia mossa» valida solo se gioco proprio la prima linea del motore, cercata ad almeno profondità 6
      G.prevEval = (r && r.lines && r.lines[0] && r.lines[0].pv[0] === c.uci && r.lines[0].depth >= 6) ? clampEv(c.eval) : null;
      var wait = Math.max(0, target - (Date.now() - t0));
      setTimeout(function(){
        if (my !== tok || !G || G.over) return;
        var u = c.uci, mv;
        try { mv = g.move({from:u.slice(0, 2), to:u.slice(2, 4), promotion:u[4]}); } catch(e){ mv = null; }
        if (!mv){ var l = g.moves({verbose:true}); mv = g.move(l[0]); }
        G.thinking = false; addInc(g.turn() === 'w' ? 'b' : 'w'); sound(mv);
        var ripresa = G.lastUserMv && G.lastUserMv.captured && G.lastUserMv.to === mv.to;
        G.lastBotMv = mv;
        if (!svista){                                          // il commento sull'errore resta visibile, niente sovrapposizioni
          if (g.inCheck() && !g.isCheckmate()){ if (parla(1.2)) bubble(frase(G.bot, 'scaccoDato')); }
          else if (mv.captured && !ripresa && !riprendibile(mv.to) && parla()) bubble(frase(G.bot, 'presa'));   // solo pezzi davvero lasciati senza difesa
        }
        if (!G.over && !svista) annunciaApertura();
        G.tsMossa = Date.now();
        render();
        if (!checkEnd()){ salvaIncorso(); avvisoMinaccia(my); if (G.pm) pmGioca(); } else { G.pm = null; G.pmSel = null; }
        if (window.__botTest && window.__botTest.onBotMove) window.__botTest.onBotMove();
      }, wait);
    }, function(){ if (my === tok){ G.thinking = false; bubble('Il motore non è disponibile su questo dispositivo.'); render(); } });
  }
  /* «Svista» di chi gioca: SOLO se il motore vede un salto netto. Confronta la valutazione della mia ultima ricerca
     (posizione dopo la mia mossa, valida solo se ho giocato la prima linea) con quella di adesso, entrambe dal mio punto di vista.
     Soglie prudenti: +250 cp di salto, almeno +150 per me, profondità >= 6, al massimo una volta ogni 8 semimosse. Nel dubbio, silenzio. */
  function riprendibile(sq){ return G.chess.moves({verbose:true}).some(function(m){ return m.to === sq; }); }
  function clampEv(v){ return Math.max(-2000, Math.min(2000, v)); }
  function rilevaSvista(r, ply){   // (usata anche per le frasi brevi «Ops…»)
    if (!G || G.prevEval == null || !r || !r.lines || !r.lines[0] || r.lines[0].depth < 6) return false;
    if (ply - (G.lastSvista || -99) < 8 || ply < 6) return false;
    var now = clampEv(cpOf(r.lines[0]));
    return now - G.prevEval >= 250 && now >= 150 && G.prevEval < 400;
  }
  /* Nome dell'apertura, UNA volta per partita: solo se la posizione attuale (mosse 2-8) è esattamente una voce di data/aperture_eco.json
     (lichess-org/chess-openings, CC0) e la sua famiglia è tra le 30 più comuni qui sotto. Mai se in questa mossa è già comparso un altro commento. */
  var APERTURE = [   // [famiglie ECO in inglese, nome italiano con articolo]
    [['Sicilian Defense'], 'la Siciliana'], [['Ruy Lopez'], 'la Spagnola'], [['French Defense'], 'la Francese'],
    [["Queen's Gambit", "Queen's Gambit Declined", "Queen's Gambit Accepted"], 'il Gambetto di Donna'], [['Italian Game'], "l'Italiana"],
    [['English Opening'], "l'Inglese"], [["King's Gambit", "King's Gambit Accepted", "King's Gambit Declined"], 'il Gambetto di Re'],
    [["King's Indian Defense"], "l'Indiana di Re"], [['Caro-Kann Defense'], 'la Caro-Kann'], [['Nimzo-Indian Defense'], 'la Nimzo-Indiana'],
    [['Dutch Defense'], "l'Olandese"], [['Benoni Defense'], 'la Benoni'], [['Grünfeld Defense'], 'la Grünfeld'], [["Queen's Indian Defense"], "l'Indiana di Donna"],
    [['Alekhine Defense'], "l'Alekhine"], [['Scotch Game'], 'la Scozzese'], [['Slav Defense'], 'la Slava'], [['Semi-Slav Defense', 'Semi-Slav Defense Accepted'], 'la Semi-Slava'],
    [["Petrov's Defense"], 'la Petroff'], [['Four Knights Game'], 'la Partita dei quattro cavalli'], [['Scandinavian Defense'], 'la Scandinava'],
    [['Philidor Defense'], 'la Philidor'], [['Vienna Game', 'Vienna Gambit'], 'la Viennese'], [['Pirc Defense'], 'la Pirc'], [['Modern Defense'], 'la Moderna'],
    [['Catalan Opening'], 'la Catalana'], [['London System'], 'il Sistema Londra'], [["Bishop's Opening"], "l'Apertura d'Alfiere"], [['Réti Opening'], 'la Réti'],
    [['Benko Gambit', 'Benko Gambit Accepted', 'Benko Gambit Declined'], 'il Gambetto Benko']
  ];
  var ecoP = null, eco = null, famIt = {};
  APERTURE.forEach(function(a){ a[0].forEach(function(f){ famIt[f] = a[1]; }); });
  function caricaEco(){
    if (!ecoP) ecoP = fetch('data/aperture_eco.json').then(function(r){ return r.json(); }).then(function(d){ eco = d.voci || {}; }).catch(function(){ eco = {}; });
    return ecoP;
  }
  function nomeApertura(fen){
    if (!eco) return null;
    var v = eco[fen.split(' ').slice(0, 4).join(' ')]; if (!v) return null;
    var fam = String(v[1]).split(':')[0].split(',')[0].trim();   // «Sicilian Defense: Najdorf» → «Sicilian Defense»; «London System, with Be2» → «London System»
    return famIt[fam] || null;
  }
  function annunciaApertura(){
    if (!G || G.apertura || G.over) return;
    var n = G.chess.history().length; if (n < 3 || n > 16) return;   // mosse 2-8
    if (G.bubblePly === n) return;                                   // in questa mossa ha già parlato
    var nome = nomeApertura(G.chess.fen()); if (!nome) return;
    G.apertura = nome; bubble(frase(G.bot, 'apertura').replace('{apertura}', nome));
  }
  /* «Attenzione…» PRIMA della mossa di chi gioca, solo bot con avvisa:true (Chess Node, Paola, Luca).
     Un secondo motore a piena forza confronta: (1) la posizione con la sua mossa migliore e (2) la stessa posizione se passasse il turno (mossa nulla).
     Avvisa solo se è certo: matto in <= 3 minacciato oppure >= 3 pedoni persi se ignora la minaccia, e con la difesa giusta la posizione regge.
     Non dice dove. Al massimo una volta ogni 6 sue mosse, mai se in questo turno ho già commentato, mai sotto scacco. Nel dubbio, silenzio. */
  function avvisoMinaccia(my){
    if (!FRASI_ON || !G || G.over || !G.cfg.avvisa) return;
    var g = G.chess, n = g.history().length, fen = g.fen();
    if (g.turn() !== G.me || g.inCheck() || n < 6 || G.bubblePly === n || n - (G.lastAvviso == null ? -99 : G.lastAvviso) < 12) return;
    var f = fen.split(' '); f[1] = f[1] === 'w' ? 'b' : 'w'; f[3] = '-'; var nul = f.join(' ');
    try { var t = new Chess(nul); if (t.inCheck()) return; } catch(e){ return; }
    if (!chk) chk = new BotEngine({motore:{skill:20, limita:false, elo:null, ms:350, prof:10, multipv:1}});
    var c0 = chk, rP;
    chk.think(fen).then(function(r){ rP = r; return c0.think(nul); }).then(function(rT){
      if (my !== tok || !G || G.over || g.history().length !== n || G.bubblePly === n) return;   // ha già mosso o ho già parlato
      var p = rP && rP.lines && rP.lines[0], q = rT && rT.lines && rT.lines[0];
      if (!p || !q || p.depth < 8 || q.depth < 8) return;
      var evP = cpOf(p), evT = cpOf(q);                                // evP: suo punto di vista, con la mossa migliore; evT: mio, se passasse
      if (p.type === 'mate') return;                                   // matto già in corso (per uno dei due): niente avvisi
      var matto = q.type === 'mate' && q.v > 0 && q.v <= 3;
      // >= 3 pedoni persi ignorando la minaccia, con la difesa giusta la posizione regge (evP > -2) e, ignorandola, non sarebbe più chiaramente meglio (-evT <= +2)
      var materiale = q.type !== 'mate' && evT + evP >= 300 && evP > -200 && evP < 1500 && -evT <= 200;
      if (!matto && !materiale) return;
      G.lastAvviso = n; G.avvisoInfo = {fen:fen, evP:evP, evT:evT, pP:p.pv.slice(0, 4).join(' '), pT:q.pv.slice(0, 4).join(' ')}; bubble(frase(G.bot, 'attento'));
    }).catch(function(){});
  }
  function checkEnd(){
    var g = G.chess;
    if (g.isCheckmate()){ finish(g.turn() === G.me ? 'bot' : 'utente', 'matto'); return true; }
    if (g.isStalemate()){ finish('patta', 'stallo'); return true; }
    if (g.isInsufficientMaterial()){ finish('patta', 'materiale'); return true; }
    if (g.isThreefoldRepetition()){ finish('patta', 'ripetizione'); return true; }
    if (g.isDraw()){ finish('patta', '50mosse'); return true; }
    return false;
  }
  var MOTIVI = {matto:'per scacco matto', abbandono:'per abbandono', tempo:'per tempo scaduto', stallo:'per stallo', materiale:'materiale insufficiente',
    ripetizione:'per triplice ripetizione', '50mosse':'regola delle 50 mosse', accordo:'d\'accordo', tempo_patta:'tempo scaduto, ma non c\'è materiale per vincere'};
  /* Anteprima 18b: registro delle partite con i bot (bot, colore, orologio, esito, data) → statistiche in Home e Progressi.
     Solo partite con almeno una mossa. Max 500 voci (le più vecchie escono). */
  var KEY_PARTITE = 'chessnodeplay-partite-bot-v1';
  /* blocco 3 (11-11): voce con id, ora, mosse (per Analizza e Rivincita dalla pagina Gioca / Le tue partite), FEN iniziale se c'è l'handicap,
     handicap e allenamento (queste due: statistiche separate, fuori da livello, V/P/S e premi). Evento «cnbot:fine» per i premi. */
  function registra(g, chi, motivo){
    try {
      var n = g.sans.length; if (!n) return null;
      var a = JSON.parse(localStorage.getItem(KEY_PARTITE) || '[]'); if (!Array.isArray(a)) a = [];
      var d = new Date(), p2 = function(x){ return ('0' + x).slice(-2); };
      var res = chi === 'patta' ? '1/2-1/2' : ((chi === 'utente') === (g.me === 'w') ? '1-0' : '0-1');
      var rec = {id:g.id, ts:d.getTime(), bot:g.bot, colore:g.me, colorePref:g.colorePref || g.me, orologio:g.clockLabel || 'no', esito:chi === 'utente' ? 'v' : chi === 'bot' ? 's' : 'p', motivo:motivo,
              data:d.getFullYear() + '-' + p2(d.getMonth() + 1) + '-' + p2(d.getDate()), semimosse:n, precisione:null, res:res, sans:g.sans};
      if (g.fen0) rec.fen = g.fen0;
      if (g.hand) rec.handicap = g.hand;
      if (g.allenamento) rec.allenamento = true;
      if (g.apertura) rec.apertura = g.apertura;
      a = a.filter(function(x){ return !x || x.id !== rec.id; });
      a.push(rec);
      if (a.length > 500) a = a.slice(-500);
      localStorage.setItem(KEY_PARTITE, JSON.stringify(a));
      try { document.dispatchEvent(new CustomEvent('cnbot:fine', {detail:JSON.parse(JSON.stringify(rec))})); } catch(e){}
      return rec;
    } catch(e){ return null; }
  }
  function salvaPartita(chi, motivo){
    var rec = registra({id:G.id, bot:G.bot, me:G.me, colorePref:G.colorePref, clockLabel:G.clock ? G.clock.label : 'no', fen0:G.fen0, hand:G.hand, allenamento:G.allenamento,
      apertura:G.apertura || null, sans:G.chess.history(), start:G.start}, chi, motivo);
    togliIncorso();
    if (rec){ G.over.recId = rec.id; G.over.recData = rec; }
  }
  function trovaRec(id){ try { var a = JSON.parse(localStorage.getItem(KEY_PARTITE) || '[]'); return (Array.isArray(a) ? a : []).filter(function(r){ return r && r.id === id; })[0] || null; } catch(e){ return null; } }
  /* precisione (precisione.js): analisi a parte, a fine partita, in un Worker suo → l'interfaccia non si blocca */
  function calcolaPrecisione(){
    var g = G, el = $('.bop-prec'); if (!g || !g.over || !g.over.recId || !window.CNPrecisione || !el) return;
    var my = ++precTok;
    el.hidden = false; el.innerHTML = svg('target', 16) + '<span>Precisione: calcolo in corso…</span>';
    CNPrecisione.calcola(g.fen0 || null, g.chess.history(), g.me, function(p){ if (my === precTok && el.isConnected) el.querySelector('span').textContent = 'Precisione: calcolo in corso… ' + Math.round(p * 100) + '%'; })
      .then(function(r){
        if (my !== precTok) return;
        var v = r ? r.precisione : null;
        try { var a = JSON.parse(localStorage.getItem(KEY_PARTITE) || '[]'), rec = a.filter(function(x){ return x && x.id === g.over.recId; })[0];
          if (rec){ rec.precisione = v; localStorage.setItem(KEY_PARTITE, JSON.stringify(a)); } } catch(e){}
        if (!el.isConnected) return;
        el.innerHTML = v == null ? svg('target', 16) + '<span>Precisione: servono almeno 5 mosse (o motore non disponibile)</span>'
          : svg('target', 16) + '<span>La tua precisione: <b>' + v + '%</b></span>';
      });
  }
  var precTok = 0;
  function finish(chi, motivo){
    if (!G || G.over) return;
    tok++; G.thinking = false; if (eng) eng.stop(); G.pm = null; G.pmSel = null;
    G.over = {chi:chi, motivo:motivo}; clearInterval(tick);
    var res = chi === 'patta' ? '1/2-1/2' : ((chi === 'utente') === (G.me === 'w') ? '1-0' : '0-1');
    G.over.res = res;
    salvaPartita(chi, motivo);   // anteprima 18b: statistiche partite con i bot
    bubble(motivo === 'accordo' ? neutro('pattaSi') : neutro('fine'));   // 14-11 ritocco: il fumetto non resta vuoto a fine partita
    var titolo = chi === 'utente' ? 'Hai vinto!' : chi === 'bot' ? 'Ha vinto ' + G.cfg.nome : 'Patta';
    var ic = chi === 'utente' ? 'trophy' : chi === 'bot' ? 'flame' : 'circle';
    var box = $('.bop-result');
    box.className = 'bop-result ' + (chi === 'utente' ? 'win' : chi === 'bot' ? 'loss' : 'draw');
    box.innerHTML = '<div class="bop-rh">' + svg(ic, 26) + '<div><b>' + esc(titolo) + '</b><small>' + esc(MOTIVI[motivo] || '') + ' · ' + res.replace('1/2', '½').replace('1/2', '½') + ' · ' + G.chess.history().length + ' semimosse</small></div></div>' +
      (G.allenamento ? '<p class="bop-rn">Partita di allenamento: si può analizzare, ma non conta per statistiche, livello e premi.</p>' :
        G.hand ? '<p class="bop-rn">Partita con handicap (' + esc(etichettaHand(G.hand, G.me).toLowerCase()) + '): statistiche separate, non conta per livello, V/P/S e premi.</p>' : '') +
      '<div class="bop-rb"><button type="button" class="bop-btn bop-pri b2" data-r="analizza">' + svg('v2-analizza', 18) + 'Analizza la partita</button>' +
      '<button type="button" class="bop-btn" data-r="rivincita">' + svg('rotate-ccw', 18) + 'Rivincita</button>' +
      '<button type="button" class="bop-btn cn-st-share" data-r="share">' + svg('share-2', 18) + 'Condividi</button>' +   // 14-11 stampo
      '<button type="button" class="bop-btn" data-r="nuovo">Cambia avversario</button></div>';
    box.hidden = false; $('.bop-confirm').hidden = true;
    box.querySelector('.bop-rh').insertAdjacentHTML('afterend', '<p class="bop-prec" hidden></p>'); calcolaPrecisione();
    if (eng){ eng.quit(); eng = null; }
    render();
    // scacco matto 10-11: vittoria per matto = riflesso dorato sui pezzi di chi ha dato matto (niente coriandoli)
    if (motivo === 'matto' && window.CNFx && !(A.prefs && A.prefs.confetti === false) && document.body.classList.contains('anim-normal')){
      var wc = G.chess.turn() === 'w' ? 'b' : 'w', bd = $('.bop-board'), gg = G.chess;
      setTimeout(function(){ if (bd && bd.isConnected) CNFx.sheen(bd, function(sq){ var q = gg.get(sq); return q && q.color === wc; }); }, 180);
    }
  }
  function bubble(t){ if (!root) return; if (!t){ var b0 = $('.bop-bubble'); if (b0) b0.textContent = ''; return; } if (G && t) G.bubblePly = G.chess.history().length; var b = $('.bop-bubble'); b.textContent = t; b.classList.remove('pop'); void b.offsetWidth; b.classList.add('pop'); }
  function ask(q, ok, f, no, avviso){ var c = $('.bop-confirm'); c.classList.toggle('avviso', !!avviso); c.innerHTML = '<p>' + esc(q) + '</p><div class="bop-rb"><button type="button" class="bop-btn bop-danger" data-c="ok">' + esc(ok) + '</button><button type="button" class="bop-btn" data-c="no">' + esc(no || 'Continua a giocare') + '</button></div>'; c.__ok = f; c.hidden = false; }
  /* blocco 3 (08-11): il bot accetta la patta SOLO se la posizione è davvero pari o morta.
     Morta = materiale insufficiente. Pari = motore di controllo a piena forza (profondità >= 10): |valutazione| <= 40 cp, nessun matto,
     e almeno 30 semimosse giocate (in apertura non si «patta» una posizione appena cominciata). Nel dubbio rifiuta. */
  var PATTA_CP = 40, PATTA_MIN = 30;
  function offerDraw(){
    if (!G || G.over || G.valutaPatta) return;
    var g = G.chess, n = g.history().length, my = tok, fen = g.fen();
    if (g.isInsufficientMaterial()){ finish('patta', 'accordo'); return; }
    if (n < PATTA_MIN){ rifiutaPatta(n); return; }
    G.valutaPatta = true; bubble(neutro('pensa')); renderButtons();
    if (!chk) chk = new BotEngine({motore:{skill:20, limita:false, elo:null, ms:600, prof:12, multipv:1}});
    var gg = G;
    chk.think(fen).then(function(r){
      if (G !== gg || G.over) return;
      G.valutaPatta = false;
      var l = r && r.lines && r.lines[0];
      var pari = l && l.depth >= 10 && l.type === 'cp' && Math.abs(l.v) <= PATTA_CP;
      G.pattaInfo = l ? {depth:l.depth, type:l.type, v:l.v} : null;
      if (pari && my === tok && g.history().length === n){ finish('patta', 'accordo'); return; }
      rifiutaPatta(n);
    }, function(){ if (G === gg && !G.over){ G.valutaPatta = false; rifiutaPatta(n); } });
  }
  function rifiutaPatta(n){ G.drawBlock = n + 10; bubble(neutro('pattaNo')); renderButtons(); }
  /* Annulla mossa (08-11): solo senza tempo. Al primo tocco di ogni partita l'avviso; dopo un annullamento la partita è «di allenamento»:
     resta tra le partite, si può analizzare, ma non conta per statistiche, livello stimato e premi. */
  var AVVISO_UNDO = 'Se annulli una mossa, questa partita diventa di allenamento e non verrà valutata nei premi.';
  function chiediUndo(){
    if (!G || G.over || G.clock) return;
    if (G.avvisato || G.allenamento){ undo(); return; }
    ask(AVVISO_UNDO, 'Annulla mossa', function(){ G.avvisato = true; undo(); }, 'Continua senza annullare', true);
  }
  function undo(){
    if (!G || G.over || G.clock) return;
    var n0 = G.chess.history().length; if (!n0) return;
    G.pm = null; G.pmSel = null;
    tok++; if (G.thinking){ G.thinking = false; if (eng) eng.stop(); G.chess.undo(); }
    else { G.chess.undo(); if (G.chess.turn() !== G.me && G.chess.history().length) G.chess.undo(); }
    G.allenamento = true; G.avvisato = true; etichette();
    G.sel = null; G.prevEval = null; G.lastBotMv = G.lastUserMv = null; bubble(''); G.tsMossa = Date.now(); render(); salvaIncorso();
    if (G.chess.turn() !== G.me) botTurn();
  }
  function pgn(){
    return pgnDi({fen0:G.fen0, sans:G.chess.history(), me:G.me, bot:G.bot, start:G.start, clock:G.clock ? G.clock.label : 'no', res:G.over ? G.over.res : '*', hand:G.hand, allenamento:G.allenamento});
  }
  function pgnDi(o){
    var cfg = BOT_CONFIG[o.bot] || BOT_CONFIG.chessnote, g = new Chess(o.fen0 || undefined), d = o.start, me = 'Tu', bot = cfg.nome + ' (bot ~' + cfg.stima + ' stimato)';
    g.setHeader('Event', (o.allenamento ? 'Partita di allenamento contro ' : 'Partita contro ') + cfg.nome + (o.hand ? ' (' + etichettaHand(o.hand, o.me).toLowerCase() + ')' : '')); g.setHeader('Site', 'Chess Node');
    g.setHeader('Date', d.getFullYear() + '.' + ('0' + (d.getMonth() + 1)).slice(-2) + '.' + ('0' + d.getDate()).slice(-2));
    g.setHeader('White', o.me === 'w' ? me : bot); g.setHeader('Black', o.me === 'w' ? bot : me);
    var oc = OROLOGI[o.clock]; if (oc) g.setHeader('TimeControl', oc.min * 60 + (oc.inc ? '+' + oc.inc : ''));
    if (o.fen0){ g.setHeader('SetUp', '1'); g.setHeader('FEN', o.fen0); }
    g.setHeader('Result', o.res || '*');
    o.sans.forEach(function(m){ try { g.move(m); } catch(e){} });
    return g.pgn();
  }
  var viaAnalisi = false;
  function analizza(){
    if (!window.CNAnalisi) return;
    viaAnalisi = true; root.hidden = true;
    var _pgnBot = pgn(), _metaBot = metaPartita(G.bot, G.me, G.over ? G.over.res : '*', G.start ? G.start.getTime() : Date.now(), G.allenamento);
    window.CNAnalisi.open({pgn:_pgnBot, partita:_metaBot});   // blocco 5: partita commentata 22b
    if (_metaBot.me && window.__cnap && typeof window.__cnap.importaMe === 'function'){ try { window.__cnap.importaMe(_pgnBot, { private: true, fileName: 'bot' }); } catch (eImp) {} }
    var ap = document.getElementById('anPage');
    if (ap && !ap.__botObs){ ap.__botObs = 1; new MutationObserver(function(){ if (ap.hidden && viaAnalisi){ viaAnalisi = false; root.hidden = false; document.documentElement.classList.add('bop-on'); } }).observe(ap, {attributes:true, attributeFilter:['hidden']}); }
  }

  function analizzaRec(id){
    var r = trovaRec(id); if (!r || !r.sans || !r.sans.length || !window.CNAnalisi) return false;
    var _pgnBot = pgnDi({fen0:r.fen || null, sans:r.sans, me:r.colore, bot:r.bot, start:new Date(r.ts || Date.now()), clock:r.orologio, res:r.res || '*', hand:r.handicap, allenamento:r.allenamento});
    var _metaBot = metaPartita(r.bot, r.colore, r.res, r.ts, r.allenamento, r.esito);
    window.CNAnalisi.open({pgn:_pgnBot, partita:_metaBot});   // blocco 5: partita commentata 22b
    if (_metaBot.me && window.__cnap && typeof window.__cnap.importaMe === 'function'){ try { window.__cnap.importaMe(_pgnBot, { private: true, fileName: 'bot' }); } catch (eImp) {} }
    return true;
  }
  // blocco 5: dati della partita per la schermata 22b (titolo «Tu vs <bot>», colore dell'utente, esito v/s/p)
  function metaPartita(bot, me, res, ts, all, esito){
    var cfg = BOT_CONFIG[bot] || BOT_CONFIG.chessnote;
    if (!esito && res && res !== '*') esito = res === '1/2-1/2' ? 'p' : ((res === '1-0') === (me === 'w') ? 'v' : 's');
    return {titolo:'Tu vs ' + cfg.nome, me:me, esito:esito || null, fonte:'bot', bot:bot, data:ts || Date.now(), allenamento:!!all};
  }

  /* ---------- apertura / chiusura ---------- */
  var lastF = null;
  /* blocco 3: open() senza partita in corso apre la pagina Gioca 20f (la vecchia schermata di scelta non c'è più) */
  function open(b){
    if (b && BOT_CONFIG[b] && BOT_CONFIG[b].attivo){ pref.bot = b; savePref(); }   // dalla Home (carosello) arriva il bot scelto
    if (G && !G.over){ mostraRoot(); render(); return; }
    if (window.CNHome && CNHome.apri){ CNHome.apri('gioca.html' + (b ? '?bot=' + encodeURIComponent(b) : ''), true); return; }
    if (!root) build();
  }
  /* Indietro: la partita in corso NON è abbandonata, resta sospesa («Riprendi la partita» nella pagina Gioca). Si torna alla pagina di partenza. */
  function back(){
    if (!$('.bop-confirm').hidden){ $('.bop-confirm').hidden = true; return; }
    if (G && !G.over && G.chess.history().length) salvaIncorso();
    esci();
  }
  function esci(){
    close();
    if (window.CNHome && CNHome.ritorna) CNHome.ritorna();
  }
  function close(){
    if (!root || root.hidden) return;
    stopGame(); root.hidden = true; document.documentElement.classList.remove('bop-on');
    if (G && !G.over) G = null;   // sospesa: è nel salvataggio, si riprende da lì
    if (lastF && lastF.focus) try { lastF.focus({preventScroll:true}); } catch(e){}
  }
  function isOpen(){ return !!(root && !root.hidden); }
  try { var U = window.UI; if (U && U.modalOpen && !U.__bopWrap){ var mo = U.modalOpen; U.modalOpen = function(){ return isOpen() || mo(); }; U.__bopWrap = 1; } } catch(e){}
  document.addEventListener('keydown', function(ev){ if (isOpen() && ev.key === 'Escape'){ ev.preventDefault(); ev.stopImmediatePropagation();
    if (window.CNStampo && CNStampo.menuAperto()){ CNStampo.chiudiMenu(); return; } if (window.CNShare && CNShare.isOpen && CNShare.isOpen()){ CNShare.close(); return; } back(); } }, true);

  /* ---------- voce nel foglio «Altro», sotto «Scacchiera di analisi» ---------- */
  var sheet = document.getElementById('moreSheet');
  if (sheet){
    var grp = sheet.querySelector('.ms-anp');
    if (!grp){ var card = sheet.querySelector('.ms-card'), ref = sheet.querySelector('.ms-close'); grp = document.createElement('div'); grp.className = 'ms-group ms-anp'; if (card && ref) card.insertBefore(grp, ref); }
    var it2 = document.createElement('button'); it2.type = 'button'; it2.className = 'ms-item'; it2.dataset.a = 'bot';
    it2.innerHTML = svg('play') + '<span>Gioca contro un bot<small>Sfida gli istruttori: da ~900 a ~1900 (stimato)</small></span>';
    grp.appendChild(it2);
    it2.addEventListener('click', function(){ setTimeout(open, 0); });
  }

  window.CNBot = {open:open, close:close, isOpen:isOpen, config:BOT_CONFIG, STILI:STILI, frasi:FRASI, start:start, riprendi:riprendi, rivincita:rivincita, analizzaRec:analizzaRec,
    OROLOGI:OROLOGI, HAND:HAND, fenHandicap:fenHandicap, AVVISO_UNDO:AVVISO_UNDO,
    // solo per le prove automatiche dell'anteprima
    _t:{ap:function(){ return {eco:eco ? Object.keys(eco).length : null, detta:G && G.apertura, ora:G && nomeApertura(G.chess.fen()), bubblePly:G && G.bubblePly, avviso:G && G.lastAvviso, info:G && G.avvisoInfo, pgn:G && G.chess.history().join(' ')}; },
        state:function(){ return G ? {id:G.id, fen:G.chess.fen(), fen0:G.fen0, hand:G.hand, me:G.me, over:G.over, thinking:G.thinking, n:G.chess.history().length, stats:stats, allenamento:G.allenamento, avvisato:G.avvisato, clock:G.clock ? G.clock.label : null, pattaInfo:G.pattaInfo || null, valutaPatta:!!G.valutaPatta, pm:G.pm ? {from:G.pm.from, to:G.pm.to, promo:G.pm.promo} : null, pmSel:G.pmSel || null} : null; },
        undo:chiediUndo, offerDraw:offerDraw, back:back, finish:function(c, m){ finish(c, m); },
        userMove:function(m){ if (G && !G.over && !G.thinking && G.chess.turn() === G.me) userMove(m); },
        newGame:newGame, setFen:function(f){ if (G && !G.over){ tok++; G.thinking = false; G.chess.load(f); G.sel = null; render(); } }, pgn:function(){ return G ? pgn() : ''; }, BotEngine:BotEngine, scegli:scegli, pref:pref, applicaStile:applicaStile, tratti:tratti, punteggioStile:punteggioStile, TOLL_STILE:TOLL_STILE}};
})();
