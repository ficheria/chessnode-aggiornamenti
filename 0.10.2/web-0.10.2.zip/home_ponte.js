/* blocco 3 (11-11): tab2 e «gioca» aprono la pagina Gioca 20f (gioca.html) invece della vecchia schermata di scelta.
   blocco 2 (10-11): barra nuova (tab0 Home, tab4 Progressi = pagine della Home; tab1-3 = schermate dell'app) e «es» (apre l'esercizio data-n).
   0.9.0 (01/11): ponte fra le pagine Home / Progressi / Statistiche bot (dentro un iframe dell'app) e l'app.
   Fuori dall'app (anteprima aperta da sola) non fa nulla: restano i toast dell'anteprima. */
(function(){
  var P = null; try { P = window.parent !== window && window.parent.CNHome; } catch(e){ P = null; }
  if (!P) return;
  document.documentElement.classList.add('in-app');
  window.addEventListener('click', function(ev){
    var a = ev.target.closest('a[href^="http"]');
    if (a){ ev.preventDefault(); ev.stopPropagation(); P.esterno(a.href); return; }
    var g = ev.target.closest('[data-go]'); if (!g) return;
    var go = g.dataset.go, bot = g.dataset.bot2 || g.dataset.arg || null;
    if (go === 'gioca' && !bot){ var f = document.querySelector('.face.on'); bot = f ? f.dataset.bot : null; }
    if (go === 'tab0' || go === 'tab4'){ ev.preventDefault(); ev.stopPropagation(); if (P.apri) P.apri(go === 'tab0' ? 'home.html' : 'progressi.html', true); return; }
    // blocco 3 (11-11): Gioca è una pagina della barra (schema 20f); dalla Home arriva col bot scelto nel carosello
    if (go === 'tab2' || go === 'gioca'){ ev.preventDefault(); ev.stopPropagation(); if (P.apri) P.apri('gioca.html' + (go === 'gioca' && bot ? '?bot=' + encodeURIComponent(bot) : ''), true); return; }
    // blocco 4 (11-11): Studia è una pagina della barra (schema 18b)
    if (go === 'tab1'){ ev.preventDefault(); ev.stopPropagation(); if (P.apri) P.apri('studia.html', true); return; }
    // blocco 5 (11-11): Analisi è una pagina della barra (schema 22 A)
    if (go === 'tab3' || go === 'analisi'){ ev.preventDefault(); ev.stopPropagation(); if (P.apri) P.apri('analisi.html', true); return; }
    if (go === 'es'){ ev.preventDefault(); ev.stopPropagation(); P.go('es', g.dataset.n); return; }
    var map = {continua:1, ripasso:1, pz:1, pzrip:1, pzid:1, giorno:1, tattica:1, analisi:1, tab3:1, profilo:1, set:1};
    if (!map[go]) return;                       // premi/tab4/dona/noads: comportamento della pagina
    ev.preventDefault(); ev.stopPropagation();
    P.go(go, bot);
  }, true);
  window.addEventListener('keydown', function(ev){ if (ev.key === 'Escape' && P.indietro){ ev.preventDefault(); P.indietro(); } });
})();
