/* Anteprima 18b · bozza PROGRESSI › «Partite con i bot»: risultati divisi per Bianco/Nero, tempo di gioco e bot, con precisione media e andamento.
   Dati veri da 'chessnodeplay-partite-bot-v1' (scritti da bot.js); ?demo=1 = partite di ESEMPIO, segnalate in pagina. */
(function(){
  'use strict';
  var Q = new URLSearchParams(location.search), DEMO = Q.has('demo'), BS = window.CNBotStats, L = window.LUCIDE || {};
  var prefs = {}; try { prefs = JSON.parse(localStorage.getItem('chessnodeplay-prefs-v1')) || {}; } catch(e){}
  var tema = Q.get('tema') || prefs.bg; if (['notte', 'bianco'].indexOf(tema) < 0) tema = 'notte';
  document.body.dataset.bg = tema;
  var EN = (Q.get('lang') || prefs.lang || 'it').indexOf('en') === 0; document.documentElement.lang = EN ? 'en' : 'it';
  var T = EN ? {tit:'Games vs bots', nota:'Results split by colour and time control: see where you improve and what is still hard.', es:'EXAMPLE DATA: invented games, only to show the layout.',
      partite:'games', punti:'points', prec:'avg. accuracy', trend:'Accuracy, last games', col:'By colour', bianco:'White', nero:'Black', tempo:'By time control', bot:'By bot',
      h:['', 'Games', 'W · D · L', 'Points', 'Acc.'], V:'W', P:'D', S:'L', vuoto:'No games yet. Play a bot: here you will see your results with White and Black, for each time control, and your accuracy.', tabs:['Home', 'Study', 'Play', 'Analysis', 'Progress']}
    : {tit:'Partite con i bot', nota:'Risultati divisi per colore e tempo di gioco: per vedere dove migliori e cosa ti mette ancora in difficoltà.', es:'DATI DI ESEMPIO: partite inventate, solo per mostrare la grafica.',
      partite:'partite', punti:'punti', prec:'precisione media', trend:'Precisione, ultime partite', col:'Per colore', bianco:'Bianco', nero:'Nero', tempo:'Per tempo di gioco', bot:'Per bot',
      h:['', 'Partite', 'V · P · S', 'Punti', 'Prec.'], V:'V', P:'P', S:'S', vuoto:'Ancora nessuna partita. Gioca con un bot: qui vedrai i risultati col Bianco e col Nero, per tempo di gioco, e la tua precisione.', tabs:['Home', 'Studia', 'Gioca', 'Analisi', 'Progressi']};
  var OWN = {knight:'<path d="M5.5 21h13"/><path d="M7.5 21v-1.4c0-2.7 1.3-4.5 3.6-5.9l-1.7-1-2.8 1.5c-.9.5-1.9-.1-2-1.1l-.1-1.4 4-4.5-.5-3.2 2.3 1.6c4.6.1 7.7 3.5 7.7 8.6V21"/><circle cx="10.7" cy="8.7" r=".8" fill="currentColor" stroke="none"/>',
    house:'<path d="M3 10.5 12 3l9 7.5"/><path d="M5 9.5V20a1 1 0 0 0 1 1h4v-6h4v6h4a1 1 0 0 0 1-1V9.5"/>', 'graduation-cap':'<path d="M22 10 12 5 2 10l10 5 10-5Z"/><path d="M6 12v5c0 1.2 2.7 3 6 3s6-1.8 6-3v-5M22 10v6"/>',
    microscope:'<path d="M6 18h8M3 22h18M14 22a7 7 0 1 0 0-14h-1"/><path d="M9 14h2M9 12a2 2 0 0 1-2-2V6h6v4a2 2 0 0 1-2 2Z"/><path d="M12 6V3a1 1 0 0 0-1-1H9a1 1 0 0 0-1 1v3"/>', 'chart-line':'<path d="M3 3v16a2 2 0 0 0 2 2h16"/><path d="m19 9-5 5-4-4-3 3"/>',
    'arrow-left':'<path d="m12 19-7-7 7-7M19 12H5"/>'};
  function ic(n, s){ return '<svg class="lu" viewBox="0 0 24 24" width="' + (s || 22) + '" height="' + (s || 22) + '" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (L[n] || OWN[n] || '') + '</svg>'; }
  var d = new Date(), oggi = d.getFullYear() + '-' + ('0' + (d.getMonth() + 1)).slice(-2) + '-' + ('0' + d.getDate()).slice(-2);
  var G = DEMO ? BS.esempio(oggi) : BS.leggi(), all = BS.riassunto(G);
  function pc(x){ return x == null ? '—' : x + '%'; }
  function vps(r){ return r.n ? '<div class="vps"><i class="v" style="width:' + (r.v / r.n * 100) + '%"></i><i class="p" style="width:' + (r.p / r.n * 100) + '%"></i><i class="s" style="width:' + (r.s / r.n * 100) + '%"></i></div>' : '<div class="vps"></div>'; }
  function riga(lab, r){ return '<div class="tr"><span class="n">' + lab + '</span><span class="r">' + r.n + '</span><span class="r">' + (r.n ? '<b class="vv">' + r.v + '</b> · ' + r.p + ' · <b class="ss">' + r.s + '</b>' : '<span class="lo">—</span>') + '</span><span class="r">' + pc(r.punti) + '</span><span class="r">' + pc(r.prec) + '</span></div>'; }
  function head(){ return '<div class="tr h">' + T.h.map(function(x, i){ return '<span' + (i ? ' class="r"' : '') + '>' + x + '</span>'; }).join('') + '</div>'; }
  function colLab(c){ return '<span class="pz ' + c + '" style="display:inline-block;width:12px;height:12px;vertical-align:-1px;margin-right:6px"></span>' + (c === 'w' ? T.bianco : T.nero); }
  function sparkline(list){
    var v = list.filter(function(g){ return typeof g.precisione === 'number'; }).slice(-20).map(function(g){ return g.precisione; });
    if (v.length < 2) return '';
    var W = 300, H = 70, mn = 30, mx = 100, step = W / (v.length - 1), pts = v.map(function(x, i){ return [i * step, H - 6 - (x - mn) / (mx - mn) * (H - 12)]; });
    var avg = []; v.forEach(function(x, i){ var a = v.slice(Math.max(0, i - 4), i + 1); avg.push(a.reduce(function(s, y){ return s + y; }, 0) / a.length); });
    var pa = avg.map(function(x, i){ return (i ? 'L' : 'M') + (i * step).toFixed(1) + ' ' + (H - 6 - (x - mn) / (mx - mn) * (H - 12)).toFixed(1); }).join(' ');
    return '<div class="trend"><div class="lab"><span>' + T.trend + ' (' + v.length + ')</span><span>' + v[v.length - 1] + '%</span></div><svg viewBox="0 0 ' + W + ' ' + H + '" preserveAspectRatio="none" aria-hidden="true">' +
      [50, 75, 100].map(function(y){ var yy = H - 6 - (y - mn) / (mx - mn) * (H - 12); return '<line x1="0" x2="' + W + '" y1="' + yy + '" y2="' + yy + '" stroke="rgba(var(--hair-rgb),.12)" stroke-width="1"/>'; }).join('') +
      pts.map(function(p){ return '<circle cx="' + p[0].toFixed(1) + '" cy="' + p[1].toFixed(1) + '" r="2.6" fill="rgba(var(--hair-rgb),.35)"/>'; }).join('') +
      '<path d="' + pa + '" fill="none" stroke="var(--acc-text)" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" vector-effect="non-scaling-stroke"/></svg></div>';
  }
  var h = '<div class="hm-bgck"></div><header class="sb-hd"><a class="back" href="progressi.html' + location.search + '" aria-label="' + T.tabs[4] + '">' + ic('arrow-left', 20) + '</a><h1>' + T.tit + '</h1></header>' +
    '<p class="sb-note">' + T.nota + '</p>' + (DEMO ? '<div class="banner-es"><i class="tag">' + (EN ? 'example' : 'esempio') + '</i><span>' + T.es + '</span></div>' : '');
  if (!G.length) h += '<div class="card empty" style="margin-top:14px">' + ic('knight', 30) + '<br>' + T.vuoto + '</div>';
  else {
    h += '<section class="card sb-tot"><div class="sb-big"><div><b>' + all.n + '</b><span>' + T.partite + '</span></div><div><b>' + pc(all.punti) + '</b><span>' + T.punti + '</span></div><div><b>' + pc(all.prec) + '</b><span>' + T.prec + '</span></div></div>' +
      vps(all) + '<div class="leg"><span style="--c:var(--acc)">' + all.v + ' ' + T.V + '</span><span style="--c:rgba(var(--hair-rgb),.35)">' + all.p + ' ' + T.P + '</span><span style="--c:#d0574a">' + all.s + ' ' + T.S + '</span></div>' + sparkline(G) + '</section>';
    h += '<div class="sez"><span>' + T.col + '</span></div><div class="duo">' + ['w', 'b'].map(function(c){ var r = BS.riassunto(BS.per(G, 'colore', c));
      return '<div class="card"><h3><span class="pz ' + c + '"></span>' + (c === 'w' ? T.bianco : T.nero) + '</h3>' + vps(r) +
        '<div class="kv"><span>' + T.partite + '</span><b>' + r.n + '</b></div><div class="kv"><span>' + T.V + ' · ' + T.P + ' · ' + T.S + '</span><b>' + r.v + ' · ' + r.p + ' · ' + r.s + '</b></div>' +
        '<div class="kv"><span>' + T.punti + '</span><b>' + pc(r.punti) + '</b></div><div class="kv"><span>' + (EN ? 'accuracy' : 'precisione') + '</span><b>' + pc(r.prec) + '</b></div></div>'; }).join('') + '</div>';
    h += '<div class="sez"><span>' + T.tempo + '</span></div><div class="card tc">' + head() + BS.OROLOGI.map(function(o){ var x = BS.riassunto(BS.per(G, 'orologio', o[0])); return (x.n || o[0] === 'no') ? riga(EN ? o[2] : o[1], x) : ''; }).join('') + '</div>';
    h += '<div class="sez"><span>' + T.bot + '</span></div>' + BS.BOTS.map(function(b){
      var gb = BS.per(G, 'bot', b[0]), r = BS.riassunto(gb); if (!r.n) return '';
      return '<section class="card bt"><div class="bt-h"><img alt="" src="istruttori/tondi/' + b[0] + '.webp"><div class="t"><b>' + b[1] + '</b><span>' + b[2] + ' · ' + r.n + ' ' + T.partite + '</span></div>' +
        '<div class="pc">' + pc(r.punti) + '<small>' + T.punti + '</small></div></div>' + vps(r) + head() +
        riga(colLab('w'), BS.riassunto(BS.per(gb, 'colore', 'w'))) + riga(colLab('b'), BS.riassunto(BS.per(gb, 'colore', 'b'))) +
        BS.OROLOGI.map(function(o){ var x = BS.riassunto(BS.per(gb, 'orologio', o[0])); return x.n ? riga(EN ? o[2] : o[1], x) : ''; }).join('') + '</section>';
    }).join('');
  }
  h += '<nav class="hm-tab">' + [['house', 0], ['graduation-cap', 1], ['knight', 2], ['microscope', 3], ['chart-line', 4]].map(function(t){ return '<a href="' + (t[1] === 0 ? 'home.html' + location.search : t[1] === 4 ? 'progressi.html' + location.search : '#') + '" class="tab' + (t[1] === 4 ? ' on' : '') + '">' + ic(t[0], 23) + T.tabs[t[1]] + '</a>'; }).join('') + '</nav>';
  document.getElementById('sb').innerHTML = h;
})();
