/* Blocco 4 (11-11) · 4.5 Esercizio del giorno (schema Studia 18b, punto 4).
   Un puzzle al giorno dall'archivio Puzzle Random (Lichess CC0), con difficoltà che sale da lunedì a domenica RISPETTO AL TUO
   Puzzle rating: L −200 · M −125 · M −50 · G +25 · V +100 · S +175 · D +250 (proposta 18b approvata).
   - Il giorno segue il calendario locale del telefono (Europe/Rome per Kiko), non blocchi di 24 ore UTC.
   - Il puzzle di oggi si sceglie la prima volta che serve (apertura, Studia, notifica) e resta fisso per tutta la giornata
     (archivio chessnodeplay-giorno-v1), anche se il rating cambia nel frattempo. Scelta ripetibile: stessa data e stesso rating
     danno lo stesso puzzle (casuale «con seme» tra i 14 non giocati più vicini alla difficoltà obiettivo).
   - «Fatto» quando il puzzle del giorno viene risolto (anche con errori o soluzione vista: il giorno è stato giocato).
   - Al primo Esercizio del giorno si chiede, una volta sola, il permesso per le notifiche (notifiche.js; nel browser nulla). */
(function(){
  'use strict';
  var A = window.__app; if (!A) return;
  var KEY = 'chessnodeplay-giorno-v1';
  var OFF = [250, -200, -125, -50, 25, 100, 175];          // indice = getDay() (0 = domenica)
  var LET = ['D', 'L', 'M', 'M', 'G', 'V', 'S'];
  var NOMI = ['Domenica', 'Lunedì', 'Martedì', 'Mercoledì', 'Giovedì', 'Venerdì', 'Sabato'];
  function rd(){ try { var o = JSON.parse(localStorage.getItem(KEY) || 'null'); if (o && typeof o === 'object' && o.g) return o; } catch(e){} return {g:{}}; }
  function wr(o){ try { localStorage.setItem(KEY, JSON.stringify(o)); } catch(e){} }
  function dk(t){ var d = t instanceof Date ? t : new Date(t == null ? Date.now() : t); return d.getFullYear() + '-' + ('0' + (d.getMonth() + 1)).slice(-2) + '-' + ('0' + d.getDate()).slice(-2); }
  function dataDi(k){ var p = k.split('-'); return new Date(+p[0], +p[1] - 1, +p[2], 12); }
  // generatore ripetibile (mulberry32) con seme dalla data
  function seme(s){ var h = 2166136261; for (var i = 0; i < s.length; i++){ h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }
  function rng(s){ var a = seme(s); return function(){ a |= 0; a = a + 0x6D2B79F5 | 0; var t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }
  function offset(k){ return OFF[dataDi(k || dk()).getDay()]; }
  function target(k, rating){ return Math.max(400, Math.min(3000, (rating == null ? rat() : rating) + offset(k))); }
  function rat(){ try { return window.CNPuzzle ? CNPuzzle.rating() : 600; } catch(e){ return 600; } }
  // scelta (senza salvare): per i test e per la striscia della settimana
  function scegli(k, rating){
    var P = window.CNPuzzle; if (!P) return null;
    var t = target(k, rating), i = P.pickNear(t, 0, P.D.length, rng('cn-giorno-' + k + '-' + t));
    return i < 0 ? null : P.D[i][0];
  }
  function oggi(){
    var k = dk(), o = rd(), g = o.g[k];
    if (!g || !g.id){
      var id = scegli(k); if (!id) return null;
      g = o.g[k] = {id:id, t:target(k), r:rat(), fatto:false};
      // tengo solo gli ultimi 60 giorni
      Object.keys(o.g).sort().slice(0, -60).forEach(function(x){ delete o.g[x]; });
      wr(o);
    }
    return g;
  }
  function fatto(k){ var g = rd().g[k || dk()]; return !!(g && g.fatto); }
  function settimana(){
    // lunedì → domenica della settimana corrente: lettera, scostamento, fatto, oggi
    var now = new Date(), d0 = new Date(now.getFullYear(), now.getMonth(), now.getDate() - ((now.getDay() + 6) % 7), 12), o = rd(), out = [];
    for (var j = 0; j < 7; j++){ var d = new Date(d0.getFullYear(), d0.getMonth(), d0.getDate() + j, 12), k = dk(d);
      out.push({k:k, l:LET[d.getDay()], off:OFF[d.getDay()], fatto:!!(o.g[k] && o.g[k].fatto), oggi:k === dk(now), futuro:k > dk(now)}); }
    return out;
  }
  function apri(){
    var g = oggi(); if (!g || !window.CNPuzzle) return false;
    CNPuzzle.openId(g.id, {t:'giorno'});
    try { if (window.CNNotifiche) CNNotifiche.primoGiorno(); } catch(e){}
    return true;
  }
  document.addEventListener('cnpz:solved', function(ev){
    var d = ev.detail || {}, k = dk(), o = rd(), g = o.g[k];
    if (!g || g.id !== d.id || g.fatto) return;
    g.fatto = true; g.ok = !!d.ok; g.quando = Date.now(); wr(o);
    try { if (window.CNNotifiche) CNNotifiche.pianifica(); } catch(e){}
  });
  document.addEventListener('cnp:reset', function(){ try { localStorage.removeItem(KEY); } catch(e){} });
  window.CNGiorno = {apri:apri, oggi:oggi, fatto:fatto, settimana:settimana, scegli:scegli, target:target, offset:offset, OFF:OFF, LET:LET, NOMI:NOMI, dk:dk,
    nomeOggi:function(){ return NOMI[new Date().getDay()]; }};
})();
