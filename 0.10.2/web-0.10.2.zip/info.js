/* INFO E CREDITI 30 (grande aggiornamento, blocco 2, 10-11). Schema approvato: anteprime/blocco30_info/ (Kiko 08-11 10:34) con le
   precisazioni di LISTA (L.849-853, L.921-922): logo ufficiale rotondo con bordino (non la mascotte), motto, versione dell'APK;
   progetto; Sostieni + libro SEPARATI dai crediti; Invita un amico; crediti voce per voce; licenze complete; privacy e contatti.
   Scacchiere a trama NON citate (L.921); pezzi solo «Set di pezzi Chess Node» (L.922).
   Sorpresa dei 5 tocchi sul logo (re + due cavalli → stallo): solo segnaposto, non realizzata (si conta, non succede nulla).
   I crediti sono da RIVERIFICARE sui file realmente inclusi nell'APK prima del lancio. */
(function(){
  'use strict';
  var C = window.CNP, ic = C.ic, esc = C.esc, root = document.getElementById('pg'), vista = /^#(\w+)/.test(location.hash) ? location.hash.slice(1) : '';
  var MAIL = 'chessnode@zohomail.eu', SF = 'https://github.com/official-stockfish/Stockfish', SFJS = 'https://github.com/nmrugg/stockfish.js';
  function vai(id, t, s, ext){ return '<button class="rw" ' + (ext ? 'data-ext="' + ext + '"' : 'data-iv="' + id + '"') + '><span class="rt"><b>' + t + '</b>' + (s ? '<small>' + s + '</small>' : '') + '</span><span class="ch">' + ic(ext ? 'external-link' : 'chevron-right', 18) + '</span></button>'; }
  function cr(t, righe, link){ return '<div class="cr"><b>' + t + '</b>' + righe.map(function(r){ return '<span>' + r + '</span>'; }).join('') + (link || '') + '</div>'; }
  function lk(t, attr){ return '<button class="lnk cr-l" ' + attr + '>' + t + ' ›</button>'; }
  function principale(){
    return C.header('Info e crediti') +
      '<section class="card inf-id"><button class="inf-logo" id="infLogo" aria-label="Logo Chess Node"><img alt="" src="logo_cn.png"></button>' +
        '<div class="cn-word inf-w">Chess <i>Node</i><u>.</u></div><p class="motto"><span class="m1">Studia.</span> <span class="m2">Analizza.</span> <span class="m3">Migliora.</span></p><p class="ver" id="infVer">Versione …</p></section>' +
      '<h2>Il progetto</h2><p class="tx">Chess Node è un progetto indipendente per imparare e migliorare negli scacchi. Esercizi, bot e analisi delle partite, gratis e senza abbonamenti.</p>' +
      '<section class="card inf-sos"><h2>Sostieni Chess Node</h2><p class="tx">Aiutaci a far crescere un progetto indipendente.</p><button class="btn" data-pg="sostieni.html">Sostieni il progetto</button>' +
        '<button class="rw inf-lib" data-ext="' + C.LIBRO + '"><span class="ri">' + ic('v2-libro', 20) + '</span><span class="rt"><b>Il libro: ' + esc(C.TITOLO) + '</b></span><span class="ch">' + ic('chevron-right', 18) + '</span></button></section>' +
      '<div class="lst" style="margin-top:16px"><button class="rw" data-invita><span class="ri">' + ic('v2-invita', 20) + '</span><span class="rt"><b>Invita un amico</b></span><span class="ch">' + ic('chevron-right', 18) + '</span></button></div>' +
      '<h2>Crediti</h2><div class="crs">' +
        cr('Stockfish', ['Motore di analisi · GPL v3, programma separato'], lk('Codice sorgente', 'data-iv="stockfish"')) +
        cr('chess.js', ['Regole degli scacchi · BSD-2']) +
        cr('Set di pezzi Chess Node', []) +
        cr('Wikibooks', ['Testi delle aperture · CC BY-SA 4.0', 'Modifiche: tradotti in italiano e abbreviati da Chess Node'], lk('Autori e pagine usate', 'data-iv="wikibooks"')) +
        cr('Lichess', ['Trasmissioni (partite dei campioni) · CC BY-SA 4.0']) +
        cr('Lichess', ['Nomi delle aperture e puzzle · CC0']) +
        cr('Caratteri', ['Inter, Outfit, JetBrains Mono, Nunito · SIL OFL 1.1']) +
        cr('Voci', ['Generate con sintesi vocale (Google Cloud Text-to-Speech)', 'da verificare prima del lancio']) +
        '<div class="cr">' + lk('Altre librerie e risorse', 'data-iv="altre"') + '</div></div>' +
      '<div class="lst" style="margin-top:16px">' + vai('licenze', 'Licenze complete') + '</div>' +
      '<h2>Privacy e contatti</h2><div class="lst">' +
        '<button class="rw" data-pg="impostazioni.html#privacy"><span class="rt"><b>Gestione dei dati e privacy</b></span><span class="ch">' + ic('chevron-right', 18) + '</span></button>' +
        '<div class="rw off" aria-disabled="true"><span class="rt"><b>Informativa privacy</b><small>Sul sito di Chess Node</small></span><span class="arr">In arrivo</span></div>' +
        '<button class="rw" data-ext="mailto:' + MAIL + '"><span class="rt"><b>Contattaci</b><small>' + MAIL + '</small></span><span class="ch">' + ic('external-link', 18) + '</span></button>' +
        '<button class="rw" data-ext="mailto:' + MAIL + '?subject=' + encodeURIComponent('Segnalazione Chess Node') + '"><span class="rt"><b>Segnala un problema</b></span><span class="ch">' + ic('chevron-right', 18) + '</span></button></div>';
  }
  var LIBS = [
    ['chess.js', 'Jeff Hlywa · BSD-2-Clause', 'lib/chess.js-LICENSE.txt'],
    ['JSZip 3.10.2 (con pako)', 'Stuart Knightley e altri · usata con licenza MIT', 'lib/jszip-LICENSE.txt'],
    ['gifenc 1.0.3', 'Matt DesLauriers · MIT', 'lib/gifenc-LICENSE.txt'],
    ['Frecce (V5)', 'Disegnate per Chess Node', ''],
    ['Icone', 'Set v2 disegnato per Chess Node', ''],
    ['Capacitor e plugin (solo app Android)', 'Ionic · MIT; text-to-speech di Capacitor Community · MIT', ''],
    ['Aggiornamenti dei contenuti (solo app Android)', '@capgo/capacitor-updater 8.54.2 di Cap-go · Mozilla Public License 2.0, usato senza modifiche; codice sorgente su github.com/Cap-go/capacitor-updater', 'lib/capacitor-updater-LICENSE.txt'],
    ['Suono della mossa', 'Kenney, «Casino Audio» · CC0 1.0; gli altri suoni e la musica di avvio sono di Chess Node', ''],
    ['Esercizi', '1.001 esercizi e 10.000 Puzzle Random dal database pubblico dei puzzle di Lichess · CC0 1.0; spiegazioni scritte per Chess Node', ''],
    ['Valutazioni «cloud»', 'API pubblica cloud-eval di Lichess, solo posizioni già in cache', ''],
    ['Istruttori, mascotte e avatar', 'Illustrazioni create per Chess Node con Grok Imagine', ''],
    ['Caratteri', 'Inter, Outfit, JetBrains Mono, Nunito · SIL Open Font License 1.1', 'fonts/Nunito-OFL.txt']];
  function sotto(id){
    if (id === 'stockfish') return ['Stockfish', '<p class="tx">Stockfish 17.1 (versione leggera, WebAssembly) è un <b>programma separato</b>, distribuito senza modifiche con licenza <b>GNU GPL v3</b>. La GPL vale solo per il motore, non per il resto dell\'app.</p>' +
      '<div class="lst">' + vai('', 'Codice sorgente di Stockfish', 'github.com/official-stockfish/Stockfish', SF) + vai('', 'Versione WebAssembly usata', 'github.com/nmrugg/stockfish.js', SFJS) +
      '<button class="rw" data-txt="engine/STOCKFISH-COPYING.txt"><span class="rt"><b>Licenza GPL v3</b></span><span class="ch">' + ic('chevron-right', 18) + '</span></button>' +
      '<button class="rw" data-txt="engine/STOCKFISH-AUTHORS.txt"><span class="rt"><b>Autori di Stockfish</b></span><span class="ch">' + ic('chevron-right', 18) + '</span></button></div>'];
    if (id === 'wikibooks') return ['Wikibooks', '<p class="tx">Testi da Wikibooks, «Chess Opening Theory». Autori: i contributori di Wikibooks (cronologia di ogni pagina). Licenza <b>CC BY-SA 4.0</b>.</p>' +
      '<p class="tx">Modifiche di Chess Node: estratto il primo paragrafo, tolta la formattazione, abbreviato e tradotto in italiano. I testi derivati restano sotto CC BY-SA 4.0, in un file separato (data/wikibooks_aperture.json).</p>' +
      '<div class="lst">' + vai('', 'Licenza CC BY-SA 4.0', 'creativecommons.org', 'https://creativecommons.org/licenses/by-sa/4.0/') + vai('', 'Chess Opening Theory', 'en.wikibooks.org', 'https://en.wikibooks.org/wiki/Chess_Opening_Theory') + '</div>' +
      '<h3>Pagine usate</h3><div id="wbList" class="wb"><p class="nota">Caricamento…</p></div>'];
    if (id === 'altre') return ['Altre librerie e risorse', '<div class="crs">' + LIBS.map(function(l){ return cr(esc(l[0]), [esc(l[1])], l[2] ? lk('Licenza', 'data-txt="' + l[2] + '"') : ''); }).join('') + '</div>'];
    if (id === 'licenze') return ['Licenze complete', '<pre class="lic" id="licTxt">Caricamento…</pre>'];
    if (id === 'testo') return [testo.t, '<pre class="lic" id="licTxt">Caricamento…</pre>'];
    return null;
  }
  var testo = {t:'', f:''}, pila = [];
  function carica(f){ fetch(f).then(function(r){ if (!r.ok) throw 0; return r.text(); }).then(function(t){ var e = document.getElementById('licTxt'); if (e) e.textContent = t; })
    .catch(function(){ var e = document.getElementById('licTxt'); if (e) e.textContent = 'Testo non disponibile (' + f + ').'; }); }
  function disegna(){
    var s = vista && sotto(vista);
    if (!s){ vista = ''; root.innerHTML = principale(); C.versione(function(v){ var e = document.getElementById('infVer'); if (e) e.textContent = v && v !== 'web' ? 'Versione ' + v : 'Versione web (anteprima)'; }); }
    else root.innerHTML = C.header(s[0]) + s[1];
    window.scrollTo(0, 0);
    if (vista === 'licenze') carica('CREDITI.txt');
    if (vista === 'testo') carica(testo.f);
    if (vista === 'wikibooks') fetch('data/wikibooks_aperture.json').then(function(r){ return r.json(); }).then(function(d){
      var v = d.voci || {}, h = Object.keys(v).map(function(k){ var x = v[k]; return x.url ? '<li><button class="lnk" data-ext="' + esc(x.url) + '">' + esc(x.nome_it || x.nome || x.mosse) + '</button> · <button class="lnk" data-ext="' + esc(x.url.replace('/wiki/', '/w/index.php?title=') + '&action=history') + '">autori</button></li>' : ''; }).join('');
      var e = document.getElementById('wbList'); if (e) e.innerHTML = '<p class="nota">' + Object.keys(v).length + ' pagine</p><ul>' + h + '</ul>'; }).catch(function(){ var e = document.getElementById('wbList'); if (e) e.innerHTML = '<p class="nota">Elenco non disponibile.</p>'; });
  }
  function apri(id){ pila.push(vista); vista = id; disegna(); }
  var tocchi = 0, tT = 0;
  root.addEventListener('click', function(ev){
    var t;
    if ((t = ev.target.closest('[data-iv]'))){ apri(t.dataset.iv); return; }
    if ((t = ev.target.closest('[data-txt]'))){ testo = {t:t.closest('.cr') ? t.closest('.cr').querySelector('b').textContent : t.textContent.trim(), f:t.dataset.txt}; apri('testo'); return; }
    if (ev.target.closest('[data-invita]')){ try { if (window.parent.__agg){ window.parent.__agg.invite(); return; } } catch(e){} C.toast('Disponibile nell\'app'); return; }
    if (ev.target.closest('#infLogo')){ clearTimeout(tT); tocchi++; tT = setTimeout(function(){ tocchi = 0; }, 1500); if (tocchi >= 5){ tocchi = 0; /* sorpresa (re + due cavalli → stallo): in arrivo */ } }
  });
  C.canBack = function(){ return !!vista; };
  C.onBack = function(){ vista = pila.pop() || ''; disegna(); return true; };
  root.addEventListener('click', function(ev){ if (ev.target.closest('[data-back]') && vista){ ev.stopImmediatePropagation(); C.onBack(); } }, true);
  disegna();
})();
