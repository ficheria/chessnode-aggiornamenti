/* SOSTIENI CHESS NODE (grande aggiornamento, blocco 2, 10-11; testi di Kiko 10-11 23:39).
   Contributo volontario 2 € / 5 € (non sblocca nulla) e una casella che si apre: «Sblocco della pubblicità per sempre» 10/20/50/100 €
   (in futuro acquisto Google Play legato all'account Google, così resta anche cambiando telefono) + «Ripristina acquisti».
   Per ora TUTTO grigio «In arrivo»: nessun pagamento, nessuna rete, nessun SDK di fatturazione, nessun link PayPal/Ko-fi (regole Play).
   sostieni.html#noads (link «Rimuovi pubblicità» della Home) apre la pagina con la casella già aperta. */
(function(){
  'use strict';
  var C = window.CNP, ic = C.ic, esc = C.esc, root = document.getElementById('pg');
  function prezzo(p){ return '<button class="off" disabled aria-disabled="true">' + ic('v2-dona', 22) + '<b>' + p + ' €</b><span>In arrivo</span></button>'; }
  var aperta = /noads/.test(location.hash);
  root.innerHTML = C.header('Sostieni Chess Node') +
    '<section class="card so-hero"><div class="so-top"><img alt="" src="logo_cn.png"><div><h2 class="so-tit">Aiutaci a far crescere Chess Node</h2>' +
      '<p class="so-sub">Un progetto gratuito, costruito con passione.</p></div></div>' +
      '<p class="tx">Chess Node nasce per rendere lo studio degli scacchi accessibile a tutti, senza abbonamenti. Il tuo sostegno ci aiuta a sviluppare nuovi corsi, esercizi e funzionalità.</p>' +
      '<blockquote class="so-cit">«Chess Node resta gratis per tutti. Con il tuo aiuto può crescere ancora, insieme a chi lo usa.»</blockquote></section>' +
    '<div class="so-caf so-2">' + prezzo(2) + prezzo(5) + '</div>' +
    '<p class="nota">Il contributo non sblocca nulla: l\'app resta uguale e gratis per tutti.</p>' +
    '<div class="card so-acc' + (aperta ? ' open' : '') + '" id="noads">' +
      '<button class="so-acc-h" type="button" aria-expanded="' + aperta + '" aria-controls="soAccB"><span class="ri">' + ic('v2-noads', 20) + '</span>' +
        '<span class="rt"><b>Sblocco della pubblicità per sempre</b><small>Resta sbloccata anche se cambi telefono, con lo stesso account Google.</small></span>' +
        '<span class="ch">' + ic('chevron-down', 20) + '</span></button>' +
      '<div class="so-acc-b" id="soAccB"' + (aperta ? '' : ' hidden') + '><div class="so-caf so-4">' + [10, 20, 50, 100].map(prezzo).join('') + '</div>' +
        '<button class="so-rip" type="button" data-rip>Ripristina acquisti <span class="arr">In arrivo</span></button></div></div>' +
    '<h2>Altri modi per aiutare</h2><div class="lst">' +
      '<button class="rw" data-invita><span class="ri">' + ic('v2-invita', 20) + '</span><span class="rt"><b>Invita un amico</b><small>Manda il link dell\'app</small></span><span class="ch">' + ic('chevron-right', 18) + '</span></button>' +
      '<button class="rw" data-ext="' + C.PLAY + '"><span class="ri">' + ic('star', 20) + '</span><span class="rt"><b>Valuta Chess Node</b><small>Lascia le stelle sul Play Store</small></span><span class="ch">' + ic('external-link', 18) + '</span></button>' +
      '<button class="rw" data-ext="' + C.LIBRO + '"><span class="ri">' + ic('v2-libro', 20) + '</span><span class="rt"><b>Il libro: ' + esc(C.TITOLO) + '</b><small>Altre citazioni sugli scacchi</small></span><span class="ch">' + ic('external-link', 18) + '</span></button></div>';
  var acc = root.querySelector('.so-acc'), accH = acc.querySelector('.so-acc-h'), accB = acc.querySelector('.so-acc-b');
  function apri(v){ acc.classList.toggle('open', v); accB.hidden = !v; accH.setAttribute('aria-expanded', String(v)); }
  root.addEventListener('click', function(ev){
    if (ev.target.closest('.so-acc-h')){ apri(!acc.classList.contains('open')); return; }
    if (ev.target.closest('[data-rip]')){ C.toast('Ripristina acquisti: in arrivo'); return; }
    if (ev.target.closest('[data-invita]')){ try { if (window.parent.__agg){ window.parent.__agg.invite(); return; } } catch(e){} C.toast('Disponibile nell\'app'); }
  });
  if (aperta) setTimeout(function(){ try { acc.scrollIntoView({block:'center'}); } catch(e){} }, 0);
  window.__soApri = apri;
})();
