/* Effetti UI (blocco 2, 11-11, anteprima approvata): pressione su pointerdown, vibrazione 10 ms, classi Animazioni.
   Non tocca tempi dei puzzle né le animazioni della scacchiera. */
(function(){
  'use strict';
  function prefs(){
    try { if (window.__app && __app.prefs) return __app.prefs; } catch(e){}
    try { if (window.parent !== window && window.parent.__app && window.parent.__app.prefs) return window.parent.__app.prefs; } catch(e){}
    try { return JSON.parse(localStorage.getItem('chessnodeplay-prefs-v1')) || {}; } catch(e){ return {}; }
  }
  function mot(){
    var a = 'attive', p = prefs();
    if (p.anim === 'off') a = 'spente';
    else if (p.anim === 'reduced') a = 'ridotte';
    try { if (a === 'attive' && (!p.anim || p.anim === 'normal') && matchMedia('(prefers-reduced-motion: reduce)').matches && !p.anim) a = 'ridotte';
      // se l'utente ha scelto esplicitamente normal, rispetta comunque «riduci movimento» del telefono (come in anteprima)
      if (a === 'attive' && matchMedia('(prefers-reduced-motion: reduce)').matches) a = 'ridotte';
    } catch(e){}
    return a;
  }
  function applyMot(doc){
    doc = doc || document;
    var h = doc.documentElement, m = mot();
    h.classList.remove('cn-mot-attive','cn-mot-ridotte','cn-mot-spente','cn-ferme');
    h.classList.add('cn-mot-' + m);
    if (m !== 'attive') h.classList.add('cn-ferme');
  }
  applyMot();
  window.addEventListener('cn-mot-change', function(){ applyMot(); });

  function markDown(){
    var t = (typeof performance !== 'undefined' ? performance.now() : Date.now());
    window.__cnEffetti.pointerDownAt = t;
    try { if (window.parent !== window && window.parent.__cnEffetti) window.parent.__cnEffetti.pointerDownAt = t; } catch(e){}
  }
  function vibeUi(){
    try {
      if (window.__cnVibra && __cnVibra.ui){ __cnVibra.ui(); return; }
      if (window.parent !== window && window.parent.__cnVibra && window.parent.__cnVibra.ui){ window.parent.__cnVibra.ui(); return; }
    } catch(e){}
  }

  var BTN = 'button.btn:not(.sec):not(.off):not(:disabled), button.b2:not(.off), .v6cards .btn.p:not(:disabled), button.anp-pri:not(:disabled)';   // blocco 5: CTA della Scacchiera di analisi
  var CARD = '.card.c3:not(.off), .card.cn-pc, button.pt-row, .card.c45:not(.off), button.rip-c:not(.off), button.f-row, button.sv-cat:not(.vuota), .sv-op, button.hd15-b, button.ad15-rm, button.so-acc-h, button.st-card, button.st-cont, .st-gc';
  var BAR = 'nav.cn-bar a';
  var CHIP = '.seg button.on:not(.off):not(:disabled), .seg button[aria-checked=true]:not(.off):not(:disabled), .gi-op.on, .pt-chip.on:not(.off), .rvchips button.on';
  var pressEl = null, startX = 0, startY = 0, cancelled = false;

  function targetFrom(ev){
    var t = ev.target && ev.target.closest ? ev.target.closest(BTN + ',' + CARD + ',' + BAR + ',' + CHIP) : null;
    if (!t) return null;
    if (t.matches('.off') || t.getAttribute('aria-disabled') === 'true') return null;
    return t;
  }
  function startPress(el, ev){
    var m = mot();
    pressEl = el; cancelled = false;
    startX = ev.clientX; startY = ev.clientY;
    markDown();
    if (el.matches(BAR) || el.matches(BTN) || el.matches(CHIP)) vibeUi();
    if (m === 'spente') return;
    if (el.matches(BTN)){
      if (m === 'attive') el.classList.add('is-press-btn');
      el.classList.add('is-press-light');
    } else if (el.matches(CHIP)){
      if (m === 'attive') el.classList.add('is-press-btn');
      el.classList.add('is-press-light');
    } else if (el.matches(CARD)){
      if (m === 'attive') el.classList.add('is-press-card');
      if (el.matches('.st-cont')) el.classList.add('is-press-light');
    }
  }
  function endPress(){
    if (!pressEl) return;
    var el = pressEl; pressEl = null;
    el.classList.remove('is-press-btn','is-press-card','is-press-light');
  }

  document.addEventListener('pointerdown', function(ev){
    if (ev.button != null && ev.button !== 0) return;
    var el = targetFrom(ev); if (!el) return;
    startPress(el, ev);
  }, true);
  document.addEventListener('pointermove', function(ev){
    if (!pressEl || cancelled) return;
    var dx = ev.clientX - startX, dy = ev.clientY - startY;
    if (dx * dx + dy * dy > 100){ cancelled = true; endPress(); }
  }, true);
  document.addEventListener('pointerup', function(){ if (pressEl) endPress(); }, true);
  document.addEventListener('pointercancel', function(){ if (pressEl) endPress(); }, true);

  window.__cnEffetti = {applyMot:applyMot, mot:mot, pointerDownAt:0};
})();
