/* Chess Node · HOME 15f (grande aggiornamento, blocco 2, 10-11). Schema approvato: anteprime/blocco15_home_schema/schema_home_15f_*,
   legenda_15f.txt; premi sotto il nome 27c; mascotte un po' più piccola (Kiko 10-11 20:24); banner FINTO di prova (Kiko 10-11 20:22).
   Legge i dati veri dell'app da localStorage; se mancano mostra stati vuoti. ?demo=1 usa dati di ESEMPIO solo in memoria (non scrive nulla).
   Sezioni: 1 intestazione (mascotte animata + «Chess Node.»; foto, nome, premi, Dona, I miei salvati, Impostazioni) · 2 carosello pulsanti ·
   3 carosello schede (Analizza una partita · Il tuo gioco) · 4 Collega i tuoi profili (solo se non collegati) · 5 Scouting (In arrivo) · 6 Riprendi da qui 2×2 · frase del giorno ·
   Sostieni + Invita un amico · 8 banner di prova a fine pagina · 7 barra fissa (pagine.js).
   Niente pubblicità vera: il banner è un riquadro disegnato qui, nessun SDK, nessuna rete. */
(function(){
  'use strict';
  var C = window.CNP, Q = new URLSearchParams(location.search), DEMO = Q.has('demo');
  var rd = C.rd, esc = C.esc, ic = C.ic;
  function pad(n){ return ('0' + n).slice(-2); }
  function dk(t){ var d = new Date(t); return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); }
  var TODAY = dk(Date.now());
  function addD(k, n){ var p = k.split('-'); return dk(new Date(+p[0], p[1] - 1, +p[2] + n).getTime()); }

  /* ---------- dati veri (o di esempio con ?demo=1) ---------- */
  var BOOK = window.BOOK || {chapters:[], ex:[]}, CH = BOOK.chapters, EX = BOOK.ex;
  var progress = rd('chessnodeplay-progress-v1') || {}, st = rd('chessnodeplay-stats-v1') || {};
  var profilo = rd('chessnodeplay-profilo-v1') || {}, anP = rd('chessnodeplay-analisi-v1'), favs = rd('chessnodeplay-fav-v1') || [];
  if (DEMO) (function(){
    progress = {}; st = {diary:{}, time:{days:{}}, rev:{}, cups:{}, badges:{}}; profilo = {nome:'Kiko', pezzo:'n', colore:'tema'};
    var done = {m1:60, m2:94, dbl:31, disa:12, pin:18, skew:6, promo:3}; EX.forEach(function(e){ if (done[e.c] > 0){ progress[e.n] = 's'; done[e.c]--; } });
    [62, 75, 140].forEach(function(n){ st.rev[n] = {s:0, due:TODAY, w:1}; });
    st.cups = {costanza:['2026-10-27', '2026-10-31', '2026-11-08'], traguardi:['2026-10-29', '2026-11-05', null], impegno:['2026-10-31', null, null]};
    st.badges = {3:1, 5:1};
    anP = {startFen:'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1', sans:['e4', 'e5', 'Nf3', 'Nc6', 'Bc4', 'Bc5', 'c3', 'Nf6', 'd4', 'exd4'], ply:10};
    favs = [189, 342];
  })();
  st.rev = st.rev || {}; st.cups = st.cups || {}; st.badges = st.badges || {};
  function isSolved(n){ return progress[n] === 's' || progress[n] === 'e'; }
  var chStat = CH.map(function(c){ var tot = 0, ok = 0, prima = 0; EX.forEach(function(e){ if (e.c === c.id){ tot++; if (isSolved(e.n)) ok++; else if (!prima) prima = e.n; } }); return {id:c.id, name:c.name, tot:tot, ok:ok, prima:prima}; });
  var solvedTot = chStat.reduce(function(a, c){ return a + c.ok; }, 0);
  var due = Object.keys(st.rev).filter(function(n){ var r = st.rev[n]; return r && typeof r.due === 'string' && r.due <= TODAY; }).length;
  var started = chStat.filter(function(c){ return c.ok > 0 && c.ok < c.tot; }).sort(function(a, b){ return b.ok / b.tot - a.ok / a.tot; })[0];
  var cur = started || chStat.filter(function(c){ return c.ok < c.tot; })[0];
  var nuovo = chStat.filter(function(c){ return c !== cur && c.ok === 0 && c.tot; })[0];
  var nome = String(profilo.nome || '').trim();

  /* premi 27c: oro, argento, bronzo (coppe vinte) e speciali (trofei delle serie); i tipi a zero non si vedono */
  var nMet = [0, 0, 0]; Object.keys(st.cups).forEach(function(k){ (st.cups[k] || []).forEach(function(d, i){ if (d && i < 3) nMet[i]++; }); });
  var nSpec = Object.keys(st.badges).filter(function(k){ return st.badges[k]; }).length;
  /* blocco 3 (11-11): dentro l'app i contatori vengono da cn_premi.js (premi_app.js, il solo che assegna i premi); medaglia per gli speciali */
  var PA = null; try { PA = window.parent !== window && window.parent.CNPremiApp; } catch(e){ PA = null; }
  if (PA && !DEMO){ try { var cc = PA.contatori(); nMet = [cc.bronzo, cc.argento, cc.oro]; nSpec = cc.speciali; } catch(e){} }
  var MET = [['oro', nMet[2], 'v2-premi'], ['arg', nMet[1], 'v2-premi'], ['bro', nMet[0], 'v2-premi'], ['spe', nSpec, (window.LUCIDE || {})['v2-medaglia'] ? 'v2-medaglia' : 'v2-serie']];
  var NOMI_MET = {oro:'oro', arg:'argento', bro:'bronzo', spe:'speciali'};
  var premi = MET.filter(function(m){ return m[1] > 0; });

  /* mini scacchiera (scheda «Analizza una partita») */
  var mb = C.mb;   /* ritocchi blocco 2: scacchiera e pezzi scelti (pagine.js) */
  var an = null;
  try { if (anP && Array.isArray(anP.sans) && anP.sans.length && typeof Chess !== 'undefined'){ var g = new Chess(anP.startFen); var ply = Math.min(anP.ply == null ? anP.sans.length : anP.ply, anP.sans.length); for (var i = 0; i < ply; i++) g.move(anP.sans[i]); an = {fen:g.fen(), n:Math.ceil(anP.sans.length / 2)}; } } catch(e){ an = null; }

  /* frase del giorno: cambia ogni giorno, sempre la stessa per tutto il giorno (15 citazioni verificate, data/citazioni.js) */
  var CIT = window.CITAZIONI || [], doy = Math.floor((new Date(TODAY) - new Date(TODAY.slice(0, 4) + '-01-01')) / 864e5);
  var cit = CIT.length ? CIT[(doy + (+Q.get('q') || 0)) % CIT.length] : null;

  /* avatar del profilo: il pezzo scelto */
  var PZ = (window.cnPezzi && window.cnPezzi()) || (window.PIECES && (PIECES.elegante || PIECES.chessnode)) || {};
  var foto = PZ['w' + String(profilo.pezzo || 'p').toUpperCase()];
  var arr = '<span class="arr">In arrivo</span>';

  /* 6 Riprendi da qui: 4 esercizi grandi dai dati veri */
  var rip = [];
  rip.push(cur ? {t:'Continua', s:cur.name + ' · ' + cur.ok + '/' + cur.tot, go:'continua', i:'v2-riprendi'} : {t:'Continua', s:'Tutti i temi completati', go:'continua', i:'v2-riprendi'});
  rip.push(due ? {t:'Ripasso di oggi', s:due === 1 ? '1 esercizio da ripassare' : due + ' esercizi da ripassare', go:'ripasso', i:'v2-ripasso'} : {t:'Ripasso di oggi', s:'Nessun ripasso oggi', off:true, i:'v2-ripasso'});
  rip.push(nuovo && nuovo.prima ? {t:'Nuovo tema', s:nuovo.name, go:'es', n:nuovo.prima, i:'v2-tattica'} : {t:'Nuovo tema', s:'Nessun tema nuovo', off:true, i:'v2-tattica'});
  var ultimoSalv = favs.length ? favs[favs.length - 1] : 0;
  rip.push(ultimoSalv ? {t:'Dai tuoi salvati', s:'Esercizio n. ' + ultimoSalv, go:'es', n:ultimoSalv, i:'bookmark'} : {t:'Dai tuoi salvati', s:'Ancora nessun salvato', pg:'salvati.html', i:'bookmark'});

  var h = '<div class="cn-bgck"></div>' +
  /* 1 intestazione */ '<header class="hd15">' +
    '<div class="hd15-top"><div class="masc" aria-hidden="true"><div class="m-corpo"><img alt="" src="mascotte/corpo.webp"><i class="m-eye l"></i><i class="m-eye r"></i></div><img class="m-corona" alt="" src="mascotte/corona.webp"></div>' +
      '<div class="cn-word hd15-w">Chess <i>Node</i><u>.</u></div>' +
      /* 14-11 (Kiko): interruttore sole/luna, stessa impostazione di Opzioni › Aspetto › Tema (pickEnv), cambio immediato e salvato */
      '<button type="button" class="hd15-tema" data-tema role="switch" aria-checked="' + (document.body.dataset.bg === 'bianco' ? 'false' : 'true') + '" aria-label="Tema scuro">' +
        '<span class="tm-s"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" aria-hidden="true"><circle cx="12" cy="12" r="4.2"/><path d="M12 2.5v2.2M12 19.3v2.2M2.5 12h2.2M19.3 12h2.2M5.3 5.3l1.6 1.6M17.1 17.1l1.6 1.6M5.3 18.7l1.6-1.6M17.1 6.9l1.6-1.6"/></svg></span>' +
        '<span class="tm-l"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 14.5A8 8 0 0 1 9.5 4a8 8 0 1 0 10.5 10.5Z"/></svg></span></button></div>' +
    '<div class="hd15-row">' +
      '<div class="hd15-av">' + (foto ? '<img alt="" src="' + foto + '">' : ic('v2-profilo', 22)) + '</div>' +
      '<div class="hd15-nm"><b>' + esc(nome || 'Ciao!') + '</b>' +
        (premi.length ? '<button class="hd15-pr" data-pg="premi.html" aria-label="Premi: ' + premi.map(function(m){ return m[1] + ' ' + NOMI_MET[m[0]]; }).join(', ') + '">' +
          premi.map(function(m){ return '<span class="pm ' + m[0] + '">' + ic(m[2], 15) + m[1] + '</span>'; }).join('') + '<span class="pm-ch">›</span></button>' : '') + '</div>' +
      '<button class="hd15-b don" data-pg="sostieni.html" aria-label="Sostieni Chess Node">' + ic('heart', 22) + '<small>Dona</small></button>' +
      '<button class="hd15-b" data-pg="salvati.html" aria-label="I miei salvati">' + ic('bookmark', 24) + '</button>' +
      '<button class="hd15-b" data-pg="impostazioni.html" aria-label="Impostazioni">' + ic('settings', 24) + '</button>' +
    '</div></header>' +
  /* 2 carosello pulsanti */ '<div class="car2" role="group" aria-label="Sezioni">' +
    '<button class="b2" data-go="gioca">' + ic('v2-bot', 22) + 'Gioca con i bot</button>' +
    '<button class="b2" data-go="continua">' + ic('v2-studia-c', 22) + 'Studia</button>' +
    '<button class="b2" data-go="analisi">' + ic('v2-analizza', 22) + 'Analisi</button>' +
    /* 14-11 (Kiko): «Problemi» = Puzzle Random, già pronto in Studia (schema 26, sezione.html?s=pz): era rimasto spento con «In arrivo» dallo schizzo del 07-11 */
    '<button class="b2" data-pg="sezione.html?s=pz">' + ic('v2-problemi', 22) + 'Problemi</button>' +
    '<button class="b2" data-pg="progressi.html">' + ic('v2-progressi', 22) + 'Progressi</button></div>' +
  /* 3 carosello schede */ '<div class="car3" role="group" aria-label="Analisi">' +
    '<button class="card c3" data-go="analisi"><div class="c3-h">' + ic('v2-analizza', 22) + '<b>Analizza una partita</b></div>' +
      '<div class="c3-b">' + mb(an ? an.fen : 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR', 108) + '<span>' + (an ? 'Ultima analisi<br><b>' + an.n + ' mosse</b>' : 'Rivedi una partita o una posizione con Stockfish, mossa per mossa.') + '</span></div></button>' +
    /* 14-11 (Kiko t1946u/t1948u): «Il tuo gioco» prende il posto di «Riassunto analisi profonda»: dati veri riempiti sotto (il_tuo_gioco.js) */
    '<button type="button" class="card c3 itg" id="itgCard" data-pg="profilo_scacchistico.html" aria-label="Il tuo gioco: apri il profilo completo"><div class="c3-h"><span>' + ic('v2-riassunto', 22) + '<b>Il tuo gioco</b></span><span class="itg-ch" aria-hidden="true">›</span></div>' +
      '<div class="itg-b"><div class="itg-sk"></div></div></button></div>' +
  /* 14-11 (Kiko t1947u): «Collega i tuoi profili», solo finché non sono collegati (collega_profili.js); card «Analisi profonda» tolta (t1946u) */
  '<section class="card cp" id="cpHome" hidden></section>' +
  /* 5 scouting (avversari) */ '<div class="card c45 off" aria-disabled="true"><span class="ri">' + ic('v2-scouting', 24) + '</span><div><b>Scouting ' + arr + '</b><span>Studia i tuoi avversari: aperture, errori e come prepararti</span></div></div>' +
  /* 6 riprendi da qui */ '<section class="card rip15"><h2>Riprendi da qui</h2><div class="rip-g">' +
    rip.map(function(r){ return '<button class="rip-c' + (r.off ? ' off' : '') + '"' + (r.off ? ' aria-disabled="true"' : r.pg ? ' data-pg="' + r.pg + '"' : ' data-go="' + r.go + '"' + (r.n ? ' data-n="' + r.n + '"' : '')) + '>' +
      '<span class="ri">' + ic(r.i, 20) + '</span><b>' + esc(r.t) + '</b><small>' + esc(r.s) + '</small></button>'; }).join('') + '</div></section>' +
  /* frase del giorno */ (cit ? '<section class="card frase"><h3>Frase del giorno</h3><p><i>«' + esc(cit.it) + '»</i></p><span class="fa">— ' + esc(cit.a) + '</span>' +
    '<a class="lnk" href="' + C.LIBRO + '" target="_blank" rel="noopener">Altre citazioni nel libro ›</a></section>' : '') +
  /* sostieni + invita */ '<div class="fondo"><button class="f-row" data-pg="sostieni.html"><img alt="" src="logo_cn.png"><span>Sostieni Chess Node<small>Gratis, senza abbonamenti: aiutaci a crescere</small></span>' + ic('chevron-right', 18) + '</button>' +
    '<button class="f-row" data-invita>' + '<span class="f-ic">' + ic('v2-invita', 20) + '</span><span>Invita un amico</span>' + ic('chevron-right', 18) + '</button></div>' +
  /* 8 banner di prova (Kiko 10-11): nessuna pubblicità vera */ '<div class="ad15" role="complementary" aria-label="Spazio pubblicitario (prova)"><div class="ad15-b"><b>AD</b><span>Spazio pubblicitario (prova)</span></div>' +
    '<button class="ad15-rm" data-pg="sostieni.html#noads">Rimuovi pubblicità ›</button></div>' +   /* 8a (ritocchi 10-11): link vero, fuori dal riquadro dell'annuncio (regole AdMob), apre Sostieni › Senza pubblicità */
  /* 7 barra fissa */ C.bar(0);
  var root = document.getElementById('home'); root.innerHTML = h;

  /* 14-11: Il tuo gioco (dati veri) + Collega i tuoi profili */
  (function(){
    var cpEl = root.querySelector('#cpHome'), body = root.querySelector('#itgCard .itg-b'), CL = window.CNCollega, TG = window.CNTuoGioco;
    if (CL && cpEl && CL.daMostrareInHome()) CL.monta(cpEl, {modo:'home'});
    if (!TG || !body) return;
    if (!C.inApp && !DEMO){ body.innerHTML = TG.card(null, CL && CL.stato()); return; }
    TG.riassunto().then(function(d){ body.innerHTML = TG.card(d, CL && CL.stato()); });
  })();

  /* 14-11: tema chiaro/notte dalla Home. Stessa strada di Opzioni (A.pickEnv salva in prefs.bg e abbina istruttore/scacchiera) */
  function cambiaTema(t){
    var A = C.A;
    try { if (A && A.pickEnv) A.pickEnv(t); else C.setPref('bg', t); } catch(e){ C.setPref('bg', t); }
    document.body.dataset.bg = t;
    try { if (window.frameElement) window.frameElement.style.background = t === 'bianco' ? '#F1F4F6' : '#151D24'; } catch(e){}
    var b = root.querySelector('[data-tema]'); if (b) b.setAttribute('aria-checked', t === 'bianco' ? 'false' : 'true');
  }
  /* Invita un amico: stesso testo del 28/10 (aggiunte.js, condivisione dell'app o copia) */
  root.addEventListener('click', function(ev){
    if (ev.target.closest('[data-invita]')){ ev.preventDefault(); try { if (window.parent.__agg && window.parent.__agg.invite){ window.parent.__agg.invite(); return; } } catch(e){} C.toast('Invita un amico: disponibile nell\'app.'); return; }
    if (ev.target.closest('[data-tema]')){ ev.preventDefault(); cambiaTema(document.body.dataset.bg === 'bianco' ? 'notte' : 'bianco'); return; }
    var off = ev.target.closest('.off'); if (off){ ev.preventDefault(); C.toast('In arrivo'); return; }
    if (!C.inApp){ var g = ev.target.closest('[data-go]'); if (g && !/^tab[04]$/.test(g.dataset.go)){ ev.preventDefault(); C.toast('Anteprima: si apre «' + g.dataset.go + '» nell\'app.'); } }
  });

  /* ritocchi blocco 2 (10-11, Kiko): puntini sotto i caroselli 2 e 3, uno per ogni fermata dello scorrimento (snap); toccarli scorre lì */
  [].forEach.call(root.querySelectorAll('.car2,.car3'), function(car){
    var d = document.createElement('div'); d.className = 'cdots'; d.setAttribute('aria-hidden', 'true'); car.after(d);
    var stops = [];
    function calcola(){
      var max = car.scrollWidth - car.clientWidth, pad = parseFloat(getComputedStyle(car).paddingLeft) || 0;
      stops = []; [].forEach.call(car.children, function(el){ var x = el.offsetLeft - car.offsetLeft - pad; if (x < max - 4) stops.push(Math.max(0, x)); });
      if (max > 0) stops.push(max); if (!stops.length) stops = [0];
      d.innerHTML = stops.map(function(){ return '<button type="button" tabindex="-1"></button>'; }).join(''); d.hidden = stops.length < 2; segna();
    }
    function segna(){ var x = car.scrollLeft, k = 0; stops.forEach(function(s, i){ if (Math.abs(s - x) < Math.abs(stops[k] - x)) k = i; });
      [].forEach.call(d.children, function(b, i){ b.classList.toggle('on', i === k); }); }
    car.addEventListener('scroll', segna, {passive:true});
    d.addEventListener('click', function(ev){ var b = ev.target.closest('button'); if (!b) return; var i = [].indexOf.call(d.children, b); car.scrollTo({left:stops[i], behavior:C.ridotte ? 'auto' : 'smooth'}); });
    calcola(); window.addEventListener('resize', calcola);
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(calcola);
  });

  /* mascotte animata (come mascotte_anim.html, 15f), ferma con animazioni ridotte/spente o «riduci movimento» del telefono */
  (function(){
    var m = root.querySelector('.masc'), corpo = m.querySelector('.m-corpo'), cor = m.querySelector('.m-corona'), eyes = m.querySelectorAll('.m-eye');
    var k = m.offsetWidth / 340 || 0.16;
    function pose(t){ var a = 2 * Math.PI * t / 8;
      var tilt = 5 * Math.sin(a) + 7 * Math.sin(2 * a) * Math.exp(-Math.pow((t - 5.8) / .8, 2)), bounce = -4 * (1 - Math.cos(2 * a)) / 2;
      corpo.style.transform = 'translateY(' + (bounce * k * 1.6).toFixed(2) + 'px) rotate(' + tilt.toFixed(2) + 'deg)';
      cor.style.transform = 'translateY(' + (bounce * .4 * k * 1.6).toFixed(2) + 'px) rotate(' + (1.8 * Math.sin(a - .23) + .5 * Math.sin(3 * a)).toFixed(2) + 'deg)';
      var sx = 1, sy = 1, dx = 4 * Math.sin(a) * k * 1.6, dy = -3 * Math.sin(2 * a) * k * 1.6;
      [1.35, 5.35].forEach(function(b){ sy *= 1 - .94 * Math.exp(-Math.pow((t - b) / .09, 2)); });
      sy *= 1 - .55 * Math.exp(-Math.pow((t - 3.5) / .4, 2)); sy += .24 * Math.exp(-Math.pow((t - 6.35) / .4, 2)); sx += .09 * Math.exp(-Math.pow((t - 6.35) / .4, 2));
      for (var i = 0; i < eyes.length; i++) eyes[i].style.transform = 'translate(' + dx.toFixed(2) + 'px,' + dy.toFixed(2) + 'px) scale(' + sx.toFixed(3) + ',' + sy.toFixed(3) + ')'; }
    pose(0);
    if (C.ridotte || Q.has('fermo')) return;
    function tick(now){ pose((now / 1000) % 8); requestAnimationFrame(tick); }
    requestAnimationFrame(tick);
  })();
})();
