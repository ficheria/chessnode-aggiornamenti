/* Chess Node · PUNTEGGIO PARTITA STIMATO (anteprima 12-11, schermata A).
   Formula NOSTRA e PROVVISORIA: non è quella di Chess.com né di altri siti.
   Serve a mostrare un numero (tipo 900 / 1200) sotto la precisione, pronto per
   essere ricalibrato insieme alla precisione. Tutte le costanti stanno nel
   blocco qui sotto: per tarare si cambia solo quello.

   Ipotesi (monotona, semplice):
   - Input: precisione di partita già calcolata da CNPrecisione (0–100) e il
     numero di mosse giudicate. L'avversario non entra nel conto (la precisione
     è già individuale).
   - Meno di MIN_MOSSE (5) mosse giudicate → nessun punteggio (null).
   - Curva a potenza: i punti alti (90–100 %) stanno più vicini al tetto di
     quelli medi, in modo strettamente crescente con la precisione.
   - Con poche mosse (da MIN_MOSSE a MOSSE_PIENE-1) il risultato è avvicinato
     un po' al centro (ELO_REF): con pochi dati ci fidiamo meno dell'estremo.
   - Il risultato è arrotondato a ELO_STEP e limitato a [ELO_MIN, ELO_MAX].

   API: window.CNPunteggioPartita.stima({precisione, mosse}) → numero | null
        window.CNPunteggioPartita.COSTANTI  (per i test e la taratura)
*/
(function(){
  'use strict';

  /* ---------- COSTANTI (unico posto da ritoccare in taratura) ---------- */
  var COSTANTI = {
    MIN_MOSSE: 5,     // come CNPrecisione: sotto questa soglia niente punteggio
    ELO_MIN: 600,     // pavimento
    ELO_MAX: 2400,    // tetto
    ELO_REF: 1200,    // centro verso cui si avvicinano le partite corte
    ELO_STEP: 10,     // arrotondamento (aspetto da «stima», non da Elo esatto)
    EXP: 1.6,         // esponente della curva (1 = lineare; >1 premia l'alta precisione)
    MOSSE_PIENE: 20,  // da qui in poi niente avvicinamento al centro
    SHRINK: 0.35      // quanto si avvicina al centro una partita con sole MIN_MOSSE (0–1)
  };
  /* -------------------------------------------------------------------- */

  function stima(opt){
    opt = opt || {};
    var acc = opt.precisione, n = opt.mosse;
    if (acc == null || !isFinite(acc)) return null;
    if (n != null && (!isFinite(n) || n < COSTANTI.MIN_MOSSE)) return null;
    acc = Math.max(0, Math.min(100, +acc));
    var t = Math.pow(acc / 100, COSTANTI.EXP);
    var raw = COSTANTI.ELO_MIN + (COSTANTI.ELO_MAX - COSTANTI.ELO_MIN) * t;
    if (n != null && n < COSTANTI.MOSSE_PIENE){
      var u = (n - COSTANTI.MIN_MOSSE) / Math.max(1, COSTANTI.MOSSE_PIENE - COSTANTI.MIN_MOSSE);
      var w = 1 - COSTANTI.SHRINK * (1 - Math.max(0, Math.min(1, u)));
      raw = COSTANTI.ELO_REF + (raw - COSTANTI.ELO_REF) * w;
    }
    var step = COSTANTI.ELO_STEP || 1;
    var elo = Math.round(raw / step) * step;
    return Math.max(COSTANTI.ELO_MIN, Math.min(COSTANTI.ELO_MAX, elo));
  }

  window.CNPunteggioPartita = {stima:stima, COSTANTI:COSTANTI, VERSIONE:'cpp-1'};
})();
