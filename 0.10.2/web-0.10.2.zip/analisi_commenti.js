/* Chess Node · partita commentata (schermata 22b) — grande aggiornamento, blocco 5 (11-11-2026).
   Usa l'analisi della partita (analisi_partita.js, regole r7c, motore nel suo Worker) e la Scacchiera di analisi (analisi_pagina.js).
   Commenti 14b (LISTA L.703–729):
   - «Blunder» ovunque (mai «Svarione»); 2–3 frasi a rotazione, mai la stessa due volte di fila; «Ops» su circa 1 imprecisione su 3;
   - teoria con i NOMI delle aperture di Kiko (data/aperture_kiko.json: la posizione con nome più profonda vince, poi la famiglia,
     altrimenti «Fin qui teoria.»); mai le mosse;
   - avatar dell'istruttore scelto; la frase di fine partita sullo schermo è IDENTICA a quella che dice la sua voce
     (archivio istruttori: did_04_vittoria / esp_05_sconfitta, campo «parlato»);
   - etichette Geniale (Mossa forte + sacrificio verificato, posizione non già vinta) e Tranquilla (ottima/buona senza cattura né scacco);
   - «MEGLIO UN COMMENTO GENERICO PIUTTOSTO CHE UNO SBAGLIATO»: «Blunder»/«Errore» a parole solo con perdita ben oltre la soglia,
     altrimenti frase generica; frasi in seconda persona («Hai perso un matto», «Qui lasci la teoria») solo sulle mosse dell'utente.
   - voce spenta di base: si ascolta toccando l'avatar (L.950). Il commento scritto resta sempre visibile.
   Voci: audio/analisi/<istruttore>/<lingua>/<chiave>.mp3 (costruite da app_tools/costruisci_analisi_dati.py). Nessuna rete esterna. */
(function(){
  'use strict';
  var A = window.__app;
  if (!A || !window.CNAnalisi || !window.CNAnalisi._int || typeof Chess === 'undefined') return;
  var I = window.CNAnalisi._int;
  var SKEY = 'chessnodeplay-analisi-storico-v1', SMAX = 30;
  var IST = ['chessnote', 'paola', 'maestro', 'nerd', 'serena'];
  var BLUNDER_TESTO = 25, ERRORE_TESTO = 13;          // perdita (punti di probabilità) oltre cui si DICE «Blunder»/«Errore» (soglie 20/10 + margine)
  var GENIALE_SACRIFICIO = 2, VINTA = 90;              // come cnap_classifica (Q03): sacrificio ≥ 2 punti di materiale, non se già vinta
  var NOMI = {it:{teoria:'Teoria', obbligata:'Mossa obbligata', geniale:'Geniale', forte:'Mossa forte', migliore:'Migliore', ottima:'Ottima', buona:'Buona', tranquilla:'Tranquilla', imprecisione:'Imprecisione', errore:'Errore', svarione:'Blunder', nogiud:'Nessun giudizio'},
              en:{teoria:'Book', obbligata:'Only move', geniale:'Brilliant', forte:'Strong move', migliore:'Best', ottima:'Excellent', buona:'Good', tranquilla:'Quiet move', imprecisione:'Inaccuracy', errore:'Mistake', svarione:'Blunder', nogiud:'No verdict'}};
  var SYM = {obbligata:'□', geniale:'!!', forte:'!!', migliore:'!', ottima:'✓', buona:'✓', tranquilla:'=', imprecisione:'?!', errore:'?', svarione:'??'};
  var BOOK = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 7v14"/><path d="M3 18a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h5a4 4 0 0 1 4 4 4 4 0 0 1 4-4h5a1 1 0 0 1 1 1v13a1 1 0 0 1-1 1h-6a3 3 0 0 0-3 3 3 3 0 0 0-3-3z"/></svg>';
  var VAL = {p:1, n:3, b:3, r:5, q:9, k:0};
  var esc = I.esc;
  function lang(){ return I.AP().lingua; }
  function ist(){ var c = null; try { c = window.__coach && window.__coach.charId(); } catch(e){} if (IST.indexOf(c) < 0) c = (A.prefs && IST.indexOf(A.prefs.coachChar) >= 0) ? A.prefs.coachChar : 'chessnote'; return c; }
  function istNome(id){ try { return window.ISTRUTTORI.personaggi[id].nome; } catch(e){ return 'Chess Node'; } }
  function P(cp){ return window.CNPrecisione ? window.CNPrecisione.P(cp) : 50; }

  /* ---------- dati ---------- */
  var D = null, dP = null;
  function dati(){
    if (dP) return dP;
    function j(u){ return fetch(u).then(function(r){ if (!r.ok) throw 0; return r.json(); }).catch(function(){ return null; }); }
    dP = Promise.all([j('data/aperture_kiko.json'), j('data/commenti_frasi.json')]).then(function(r){ D = {ap:r[0], fr:r[1]}; return D; });
    return dP;
  }

  /* ---------- la partita ---------- */
  function partita(){
    var st = window.CNAnalisi.state(), c = new Chess(st.startFen), fens = [c.fen()], ucis = [], cols = [], sans = [], caps = [], chk = [];
    for (var i = 0; i < st.sans.length; i++){ var m = c.move(st.sans[i]); ucis.push(m.from + m.to + (m.promotion || '')); cols.push(m.color); sans.push(m.san); caps.push(!!m.captured); chk.push(/[+#]/.test(m.san)); fens.push(c.fen()); }
    return {start:st.startFen, sans:sans, ucis:ucis, cols:cols, fens:fens, caps:caps, chk:chk, matto:c.isCheckmate(), h:hk(st.startFen + '|' + st.sans.join(' '))};
  }
  function hk(s){ var a = 0x811c9dc5; for (var i = 0; i < s.length; i++) a = Math.imul(a ^ s.charCodeAt(i), 16777619) >>> 0; return a.toString(36); }
  function materiale(fen, col){ var b = new Chess(fen).board(), s = 0; b.forEach(function(r){ r.forEach(function(p){ if (p) s += (p.color === col ? 1 : -1) * VAL[p.type]; }); }); return s; }
  function stato(){ try { return window.CNAnalisiPartita.stato(); } catch(e){ return null; } }
  function recPronto(){ var s = stato(); return s && s.rec && s.rec.lab && (s.rec.fatto || s.prov) ? s.rec : null; }

  /* ---------- etichette (con Geniale e Tranquilla) ---------- */
  function etichetta(p, rec, i){
    var l = rec.lab[i]; if (!l) return null;
    var cl = l.cl, V = rec.V && rec.V[i], E = rec.E;
    if (cl === 'forte' && V && E[i] && i + 2 <= p.fens.length - 1){   // Geniale: sacrificio vero (materiale perso dopo la risposta della partita) e posizione non già vinta
      var col = p.cols[i], m0 = materiale(p.fens[i], col), m2 = materiale(p.fens[Math.min(i + 2, p.fens.length - 1)], col);
      if (m0 - m2 >= GENIALE_SACRIFICIO && P(E[i].cp) < VINTA && (V.gap || 0) >= 10) cl = 'geniale';
    }
    if ((cl === 'ottima' || cl === 'buona') && !p.caps[i] && !p.chk[i] && E[i] && E[i + 1]){   // Tranquilla (Q03): |wB−wA| ≤ 2 e perdita ≤ 2
      var wB = P(E[i].cp), wA = P(-E[i + 1].cp);
      if (Math.abs(wB - wA) <= 2 && (l.loss || 0) <= 2) cl = 'tranquilla';
    }
    return cl;
  }
  function icona(cl){ if (!cl || cl === 'nogiud') return ''; var n = NOMI[lang()][cl] || cl; return '<i class="apa-ic apa-' + cl + '" title="' + esc(n) + '" aria-label="' + esc(n) + '">' + ((window.CNIconeMosse && window.CNIconeMosse.svg(cl)) || (cl === 'teoria' ? BOOK : SYM[cl] || '')) + '</i>'; }

  /* ---------- SAN → mattoncini della voce (stessa grammatica di pezzi_voce.py, 14b) ---------- */
  function sanClip(san, ep){
    var s = san.replace(/[!?]+$/, ''), sc = /[+#]$/.test(s) ? s.slice(-1) : '', base = s.replace(/[+#]$/, ''), out;
    if (base === 'O-O' || base === 'O-O-O') out = ['arrocco_' + (base === 'O-O-O' ? 'lungo' : 'corto')];
    else {
      var m = base.match(/^([KQRBN])?([a-h]?[1-8]?)(x)?([a-h][1-8])(?:=([QRBN]))?$/); if (!m) return [];
      var pz = m[1] || 'P', da = m[1] ? m[2] : '';
      out = da ? ['pz_' + pz + '_da', da.length === 2 ? 'casa_' + da : /[a-h]/.test(da) ? 'col_' + da : 'tra_' + da, m[3] ? 'v_prende' : 'v_muove'] : ['pz_' + pz + '_' + (m[3] ? 'prende' : 'muove')];
      out.push('casa_' + m[4]); if (m[5]) out.push('promo_' + m[5]); if (ep) out.push('enpassant');
    }
    if (sc) out.push(sc === '+' ? 'scacco' : 'matto');
    return out;
  }
  function uciSan(fen, uci){ try { var c = new Chess(fen), m = c.move({from:uci.slice(0, 2), to:uci.slice(2, 4), promotion:uci[4]}); return {san:m.san, ep:m.flags.indexOf('e') >= 0}; } catch(e){ return null; } }

  /* ---------- commenti ---------- */
  var C = {h:null, com:{}, lab:[], fine:null};
  function nomeApertura(p, last){
    var ap = D && D.ap; if (!ap) return -1;
    function k4(f){ return f.split(' ').slice(0, 4).join(' '); }
    for (var k = last + 1; k >= 1; k--){ var x = ap.pos[k4(p.fens[k])]; if (x != null) return x; }
    for (var j = last + 1; j >= 1; j--){ var y = ap.fam[k4(p.fens[j])]; if (y != null) return y; }
    return -1;
  }
  function F(k){ var f = D && D.fr && D.fr.frasi[k]; return f ? {t:{it:f.it, en:f.en}, c:[k]} : null; }
  function costruisci(p, rec, meta){
    var com = {}, lab = [], me = meta && meta.me || null, n = p.ucis.length, rot = {b:0, e:0, g:0, m:0, o:0}, imp = 0, lastOps = -9;
    for (var i = 0; i < n; i++) lab.push(etichetta(p, rec, i));
    function add(i, part){ if (!part) return; (com[i] = com[i] || {i:i, parts:[]}).parts.push(part); }
    function giro(k, base, ch){ var x = rot[k] % 3; rot[k]++; return F(x === 0 ? base : base.replace(/_1$/, '') + '_' + (x + 1)) || F(base); }
    function meglio(i, uci){
      var u = uci && uciSan(p.fens[i], uci); if (!u) return null;
      var x = rot.m % 3; rot.m++; var f = F(['era_meglio', 'meglio_2', 'meglio_3'][x]) || F('era_meglio');
      var itS = A.itSan ? A.itSan(u.san) : u.san;
      return {t:{it:f.t.it + ' «' + itS + '».', en:f.t.en + ' «' + u.san + '».'}, c:f.c.concat(sanClip(u.san, u.ep))};
    }
    // teoria
    var book = -1; for (var b = 0; b < n; b++) if (lab[b] === 'teoria') book = b;
    if (book >= 0){
      var nm = nomeApertura(p, book), ak = nm >= 0 ? D.ap.nomi[nm] : null, ti = F('teoria_inizio');
      if (ak && ti) add(book, {t:{it:ti.t.it + ' ' + ak.it, en:ti.t.en + ' ' + ak.en}, c:['teoria_inizio', 'ak_' + ('00' + nm).slice(-3)], tipo:'teoria'});
      else add(book, F('teoria_sola'));
      if (book + 1 < n) add(book + 1, F(me && p.cols[book + 1] === me ? 'lasci_teoria' : 'fine_teoria'));
    }
    for (var m = 0; m < n; m++){
      var l = rec.lab[m], cl = lab[m], V = rec.V && rec.V[m], mia = !!me && p.cols[m] === me;
      if (!l || cl === 'teoria' || cl === 'obbligata' || cl === 'nogiud') continue;
      // matto perso (solo dalla verifica profonda, solo sulle mosse dell'utente)
      if (mia && V && V.mB > 0 && V.mB <= 5 && (V.mG === null || V.mG === undefined) && p.ucis[m] !== V.best && /imprecisione|errore|svarione/.test(cl)){
        var mp = F('matto_perso'), nn = F('n_' + V.mB);
        if (mp && nn){ add(m, {t:{it:mp.t.it + ' ' + nn.t.it, en:mp.t.en + ' ' + nn.t.en}, c:['matto_perso', 'n_' + V.mB]}); continue; }
      }
      if (l.accorcia && /imprecisione|errore/.test(cl)){ if (cl === 'errore') add(m, giro('e', 'errore_1')); add(m, F('matto_prima')); continue; }
      if (cl === 'svarione'){ add(m, (l.loss || 0) >= BLUNDER_TESTO ? giro('b', 'blunder_1') : giro('g', 'generico_1')); add(m, meglio(m, l.best)); }
      else if (cl === 'errore'){ add(m, (l.loss || 0) >= ERRORE_TESTO ? giro('e', 'errore_1') : giro('g', 'generico_1')); add(m, meglio(m, l.best)); }
      else if (cl === 'imprecisione'){ imp++; if (imp % 3 === 1 && lastOps !== imp - 1){ add(m, giro('o', 'ops_1')); lastOps = imp; } }
      else if (cl === 'forte' || cl === 'geniale') add(m, F('forte'));
    }
    // fine partita: la frase dell'istruttore scelto (testo = voce)
    var fine = null, id = ist();
    if (me && n){
      var es = p.matto ? (p.cols[n - 1] === me ? 'v' : 's') : (meta && meta.esito);
      var fr = D && D.fr && D.fr.fine[id];
      if (fr && (es === 'v' || es === 's')){ var q = es === 'v' ? fr.vittoria : fr.sconfitta; fine = {t:{it:q.it, en:q.en}, c:[es === 'v' ? 'fine_vittoria' : 'fine_sconfitta'], fine:1}; add(n - 1, fine); }
    }
    // gli «errore_1»/«blunder_1»/… → chiavi vere del file (blunder_1..3, errore/errore_2/errore_3, generico/…, ops_1..3)
    return {h:p.h, com:com, lab:lab, fine:fine, ist:id};
  }
  // nomi delle chiavi nel file frasi: errore, errore_2, errore_3 · generico, generico_2, generico_3 · blunder_1..3 · ops_1..3
  var _F = F; F = function(k){ var map = {errore_1:'errore', generico_1:'generico'}; return _F(map[k] || k); };

  /* ---------- voce ---------- */
  var au = null, coda = [], parlaTok = 0;
  function zitto(){ parlaTok++; coda = []; if (au){ try { au.pause(); } catch(e){} au = null; } var r = I.root(); if (r){ var b = r.querySelector('.anp-av'); if (b) b.classList.remove('parla'); } }
  function parla(clips){
    zitto(); if (!clips || !clips.length) return;
    var my = parlaTok, id = C.ist || ist(), L = lang(), r = I.root(), av = r && r.querySelector('.anp-av');
    coda = clips.slice(); if (av) av.classList.add('parla');
    (function next(){
      if (my !== parlaTok) return;
      var k = coda.shift(); if (!k){ if (av) av.classList.remove('parla'); au = null; return; }
      au = new Audio('audio/analisi/' + id + '/' + L + '/' + k + '.mp3');
      au.onended = next; au.onerror = next;
      var pr = au.play(); if (pr && pr.catch) pr.catch(function(){ next(); });
    })();
  }

  /* ---------- storico (pagina Analisi: «Analisi in corso», «Partite analizzate») ---------- */
  function sLeggi(){ try { var o = JSON.parse(localStorage.getItem(SKEY) || '{}'); return Array.isArray(o.g) ? o : {v:1, g:[]}; } catch(e){ return {v:1, g:[]}; } }
  function sScrivi(o){
    o.g.sort(function(a, b){ return (b.agg || 0) - (a.agg || 0); });
    var tenute = [], k = 0; o.g.forEach(function(x){ if (x.salvata || k < SMAX){ tenute.push(x); if (!x.salvata) k++; } }); o.g = tenute;
    try { localStorage.setItem(SKEY, JSON.stringify(o)); } catch(e){}
  }
  function sAgg(h, f){ var o = sLeggi(), x = o.g.filter(function(y){ return y.id === h; })[0]; if (!x) return null; f(x); sScrivi(o); return x; }

  /* ---------- apertura / stato dell'analisi ---------- */
  var U = {meta:null, p:null, poll:0, cf:false};
  function apri(meta){
    U.meta = meta || {}; U.cf = false; C = {h:null, com:{}, lab:[], fine:null, ist:ist()};
    var p = U.p = partita();
    var o = sLeggi(), x = o.g.filter(function(y){ return y.id === p.h; })[0];
    if (!x){ x = {id:p.h}; o.g.push(x); }
    x.titolo = U.meta.titolo || x.titolo || 'Partita'; x.me = U.meta.me || x.me || null; x.esito = U.meta.esito || x.esito || null;
    x.fonte = U.meta.fonte || x.fonte || 'pgn'; x.bot = U.meta.bot || x.bot || null; x.data = U.meta.data || x.data || Date.now();
    x.fen = p.start; x.sans = p.sans; x.n = p.ucis.length; x.agg = Date.now(); x.salvata = !!x.salvata;
    U.meta.me = x.me; U.meta.esito = x.esito; U.meta.titolo = x.titolo;
    // partita salvata con le sue varianti → tornano (se l'utente l'ha tolta dai salvati dall'elenco dei bot, niente varianti)
    var rb = recBot(); if (x.salvata && rb && rb.r && !rb.r.salvata){ x.salvata = false; delete x.var; }
    sScrivi(o);
    ultimeVar = '';
    if (x.salvata && x.var){ ripristinaVarianti(x.var); ultimeVar = JSON.stringify(variantiUtente()); }
    var r = I.root(), img = r.querySelector('.anp-av img'); img.src = 'istruttori/tondi/' + C.ist + '.webp'; r.querySelector('.anp-av').setAttribute('aria-label', 'Ascolta ' + istNome(C.ist));
    dati().then(function(){
      var s = stato();
      if (s && s.rec && s.rec.fatto) pronto();
      else if (s && !s.run && p.ucis.length >= 2) try { window.CNAnalisiPartita.start(false); } catch(e){}
      segui(); I.render();
    });
  }
  function segui(){   // finché l'analisi gira: avanzamento vero nel fumetto e nello storico
    clearInterval(U.poll);
    U.poll = setInterval(function(){
      var s = stato(); if (!s){ clearInterval(U.poll); return; }
      var h = U.p && U.p.h;
      if (s.run && s.prog){ sAgg(h, function(x){ x.pct = s.prog.pct; x.fase = s.prog.fase; x.a = s.prog.a; x.b = s.prog.b; }); if (I.S.mode === 'partita') bolla(); return; }
      clearInterval(U.poll);
      if (s.rec && s.rec.fatto) pronto(); else if (I.S.mode === 'partita') bolla();
    }, 500);
  }
  function pronto(){
    var s = stato(); if (!s || !s.rec || !s.rec.fatto || !U.p) return;
    if (C.h !== U.p.h) C = costruisci(U.p, s.rec, U.meta);
    var me = U.meta && U.meta.me, pr = s.rec.prec || {};
    sAgg(U.p.h, function(x){ x.fatto = 1; x.pct = 100; x.prec = me ? pr[me] : pr.w; x.precW = pr.w; x.precB = pr.b; x.fattaIl = x.fattaIl || Date.now(); });
    if (I.S.mode === 'partita' && window.CNAnalisi.state().sans.join(' ') === U.p.sans.join(' ')){ I.renderMoves(); bolla(); I.banner(); I.drawArrow(); I.drawEval(); }
  }
  function chiudi(){ zitto(); U.cf = false; }

  /* ---------- fumetto dell'istruttore ---------- */
  function k(){ var st = window.CNAnalisi.state(); return st.ply; }
  function numMossa(i){ var f = U.p.fens[i].split(' '); return (+f[5] || 1) + (f[1] === 'w' ? '.' : '…'); }
  function sanV(i){ var s = U.p.sans[i]; return lang() === 'it' && A.itSan ? A.itSan(s) : s; }
  /* Mosse (e O-O / O-O-O) nel fumetto: una sola riga, trattino inseparabile. */
  function anSan(s){
    if (s == null || s === '') return '';
    var t = String(s).replace(/O-O-O/g, 'O\u2011O\u2011O').replace(/O-O/g, 'O\u2011O');
    // fix in the written file: we need actual unicode. we'll post-process.
    return '<span class="anp-san">' + esc(t) + '</span>';
  }
  function testoConSan(s){
    s = String(s || '');
    var re = /O-O-O[+#]?|O-O[+#]?|[KQRBNATCGRD](?:[a-h1-8]?x[a-h][1-8]|[a-h]?[1-8]?[a-h][1-8])(?:=[KQRBNATCGRD])?[+#]?|[a-h]x[a-h][1-8](?:=[KQRBNATCGRD])?[+#]?|[a-h][1-8](?:=[KQRBNATCGRD])?[+#]?/g;
    var out = '', last = 0, m;
    re.lastIndex = 0;
    while ((m = re.exec(s))){
      out += esc(s.slice(last, m.index)) + anSan(m[0]);
      last = m.index + m[0].length;
    }
    return out + esc(s.slice(last));
  }
  function bolla(){
    var r = I.root(); if (!r || !U.p) return;
    var b = r.querySelector('.anp-bub'), s = stato(), L = lang(), h = '';
    var rec = s && s.rec, fatto = rec && rec.fatto, kk = k(), i = kk - 1;
    if (!fatto){
      if (s && s.run){
        var pr = s.prog || {pct:0}, t = '';
        try { t = window.CNAnalisiPartita.t(s.prov ? 'ricorso' : pr.fase).replace('%a', pr.a).replace('%b', pr.b); } catch(e){}
        h = '<p class="anp-bh">' + esc(istNome(C.ist)) + '</p><p>' + (L === 'en' ? 'I\'m analysing the game…' : 'Sto analizzando la partita…') + '</p>' +
          '<div class="apa-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="' + (pr.pct || 0) + '"><i class="apa-fill" style="width:' + (pr.pct || 0) + '%"></i></div>' +
          '<p class="anp-sole">' + esc(t) + ' · ' + (pr.pct || 0) + '%</p>';
      } else if (U.p.ucis.length < 2) h = '<p class="anp-sole">' + (L === 'en' ? 'Too few moves to analyse.' : 'Troppe poche mosse da analizzare.') + '</p>';
      else h = '<p>' + (L === 'en' ? 'The analysis is paused.' : 'L\'analisi è in pausa.') + '</p><button type="button" class="anp-btn anp-pri" data-x="riprendi" style="margin-top:6px">' + (L === 'en' ? 'Resume' : 'Riprendi') + '</button>';
      b.innerHTML = h; return;
    }
    if (C.h !== U.p.h) C = costruisci(U.p, rec, U.meta);
    if (kk === 0){
      var me = U.meta.me, pr2 = rec.prec || {};
      var pv = me ? pr2[me] : null;
      h = '<p class="anp-bh">' + esc(U.meta.titolo || '') + '</p><p>' + (pv != null ? (L === 'en' ? 'Your accuracy: ' : 'La tua precisione: ') + pv + '%. ' : '') +
        (L === 'en' ? 'I comment only the important moves: use › to go through the game.' : 'Commento solo le mosse importanti: usa › per rivedere la partita.') + '</p>';
      b.innerHTML = h; return;
    }
    var cl = C.lab[i], c = C.com[i], nome = NOMI[L][cl] || '', l = rec.lab[i] || {};
    var puo = l.best && l.best !== U.p.ucis[i] && /imprecisione|errore|svarione/.test(cl);
    h = '<p class="anp-bh">' + icona(cl) + '<span>' + esc(numMossa(i) + ' ') + anSan(sanV(i)) + (nome ? ' · ' + esc(nome) : '') + '</span></p>';
    if (puo) h = '<button type="button" class="anp-cf' + (U.cf ? ' on' : '') + '" data-x="cf" aria-pressed="' + U.cf + '">' + (U.cf ? (L === 'en' ? 'Close' : 'Chiudi') : (L === 'en' ? 'Compare' : 'Confronta')) + '</button>' + h;
    if (U.cf && puo){
      var bs = uciSan(U.p.fens[i], l.best), bsT = bs ? (L === 'it' && A.itSan ? A.itSan(bs.san) : bs.san) : '';
      h += '<p class="anp-sole">' + (L === 'en' ? 'Played' : 'Giocata') + ' «' + anSan(sanV(i)) + '» (' + (L === 'en' ? 'orange' : 'arancione') + ') · ' + (L === 'en' ? 'Best' : 'Migliore') + ' «' + anSan(bsT) + '» (' + (L === 'en' ? 'blue' : 'azzurra') + ')</p>';
    } else if (c) h += '<p>' + testoConSan(c.parts.map(function(x){ return x.t[L]; }).join(' ')) + '</p>';
    b.innerHTML = h;
  }
  function azione(x){
    if (x === 'cf'){ U.cf = !U.cf; zitto(); I.conf(U.cf); bolla(); return; }
    if (x === 'riprendi'){ try { window.CNAnalisiPartita.start(false); } catch(e){} segui(); bolla(); }
  }
  function ascolta(){
    var i = k() - 1, c = C.com[i];
    if (au){ zitto(); return; }
    if (c) parla([].concat.apply([], c.parts.map(function(x){ return x.c; })));
  }
  var lastNodo = null;
  function onRender(){
    if (I.S.mode !== 'partita' || !U.p) return;
    var st = window.CNAnalisi.state();
    if (!st.inVariante && st.nodo !== lastNodo){ if (U.cf && !I.S.conf) U.cf = false; zitto(); lastNodo = st.nodo; if (I.AP().voce && C.com[st.ply - 1] && recPronto()) ascolta(); }
    else if (st.inVariante){ zitto(); lastNodo = null; }
    if (!I.S.conf) U.cf = false;
    bolla();
    aggiornaVarSalvate();
    var r = I.root(), sv = r.querySelector('.anp-save'), x = sLeggi().g.filter(function(y){ return y.id === U.p.h; })[0];
    sv.setAttribute('aria-pressed', x && x.salvata ? 'true' : 'false');
  }
  /* ---------- salvataggio con le varianti (Kiko 11-11, dubbio 5) ----------
     Le varianti fatte sulla 22b valgono per la sessione, A MENO CHE l'utente salvi la partita: allora si salvano con lei
     (righe di mosse dalla radice fino a ogni foglia creata dall'utente) e tornano quando la partita salvata si riapre.
     Finché la partita resta salvata, le varianti nuove si aggiungono da sole. «Annulla» toglie il salvataggio E le varianti. */
  function variantiUtente(){
    var T = I.T(), out = [];
    (function giu(n){ n.figli.forEach(function(c){
      if (I.S.orig[c.id] === 'u' && !c.figli.some(function(f){ return I.S.orig[f.id] === 'u'; })){ var l = [], x = c; while (x.padre){ l.unshift(x.uci); x = x.padre; } out.push(l); }
      giu(c); }); })(T.radice);
    return out;
  }
  function ripristinaVarianti(linee){
    var T = I.T(), torna = T.corrente, n0 = 0;
    (linee || []).forEach(function(l){
      var n = T.radice;
      for (var j = 0; j < l.length && n; j++){
        var u = l[j], c = n.figli.filter(function(f){ return f.uci === u; })[0];
        if (!c){ c = T.aggiungiMossa(n, {from:u.slice(0, 2), to:u.slice(2, 4), promotion:u[4]}); if (c) n0++; }
        if (c && !I.isMain(c)) I.S.orig[c.id] = 'u';
        n = c;
      }
    });
    T.vaiA(torna); return n0;
  }
  function recBot(){   // la partita col bot dell'archivio (per marcarla anche in Salvati › Partite)
    if (!U.meta || U.meta.fonte !== 'bot') return null;
    try { var a = JSON.parse(localStorage.getItem('chessnodeplay-partite-bot-v1') || '[]'); return {a:a, r:a.filter(function(r){ return r.ts === U.meta.data && r.bot === U.meta.bot; })[0]}; } catch(e){ return null; }
  }
  function marcaBot(on){ var b = recBot(); if (!b || !b.r) return; if (on) b.r.salvata = true; else delete b.r.salvata; try { localStorage.setItem('chessnodeplay-partite-bot-v1', JSON.stringify(b.a)); } catch(e){} }
  function applicaSalva(on, linee){
    sAgg(U.p.h, function(y){ if (on){ y.salvata = true; if (linee && linee.length) y.var = linee; else delete y.var; } else { y.salvata = false; delete y.var; } });
    marcaBot(on); ultimeVar = JSON.stringify(on ? (linee || []) : []);
  }
  var ultimeVar = '';
  function salva(){
    if (!U.p) return;
    var x = sLeggi().g.filter(function(y){ return y.id === U.p.h; })[0], on = !(x && x.salvata), prima = x && x.var ? x.var.slice() : null;
    applicaSalva(on, on ? variantiUtente() : null);
    var annulla = function(){ applicaSalva(!on, on ? null : prima); onRender(); };
    try {   // stesso toast «Partita salvata · Annulla» dell'app (4 s), sulla notazione: mai sopra la scacchiera
      if (window.CNB4 && CNB4.toast){ var t = CNB4.toast(on ? 'Partita salvata' : 'Tolta dai salvati', annulla, 4000), bd = I.root().querySelector('.anp-board').getBoundingClientRect();
        t.style.zIndex = '1000'; t.style.left = '12px'; t.style.right = '12px'; t.style.width = 'auto'; t.style.height = '48px'; t.style.top = Math.round(bd.bottom + 6) + 'px'; t.style.bottom = 'auto'; }
    } catch(e){}
    onRender();
  }
  function aggiornaVarSalvate(){   // partita salvata: le varianti nuove dell'utente si salvano da sole
    if (!U.p) return;
    var x = sLeggi().g.filter(function(y){ return y.id === U.p.h; })[0]; if (!x || !x.salvata) return;
    var l = variantiUtente(), j = JSON.stringify(l); if (j === ultimeVar) return; ultimeVar = j;
    sAgg(U.p.h, function(y){ if (l.length) y.var = l; else delete y.var; });
  }
  function puoVariante(){ var rec = recPronto(), i = k() - 1; if (!rec || i < 0 || !U.p) return false; var l = rec.lab[i]; return !!(l && l.best && l.best !== U.p.ucis[i] && !/teoria|obbligata/.test(l.cl)); }
  function vediVariante(){
    if (!puoVariante()) return;
    var T = I.T(), cur = T.corrente, i = k() - 1, best = recPronto().lab[i].best;
    T.vaiA(cur.padre);
    if (window.CNAnalisi.normArrocco) best = window.CNAnalisi.normArrocco(cur.padre.fen, best);
    var n1 = window.CNAnalisi.play({from:best.slice(0, 2), to:best.slice(2, 4), promotion:best[4]}, 'm');
    if (!n1){ T.vaiA(cur); I.update(); return; }
    I.S.ritorno = cur.id;                        // «Torna alla partita» riporta qui, esattamente
    I.update();
    if (window.CNAnalisiPartita && window.CNAnalisiPartita.busy()){ vvNodo = null; return; }   // un motore alla volta: solo la mossa migliore
    vvNodo = n1;   // rilievo 14: il seguito arriva dall'analisi dal vivo di questa stessa posizione (VAR_DEPTH), niente seconda ricerca che la interrompe
  }
  var vvNodo = null;
  function onEngine(c){
    var n1 = vvNodo, T = I.T(); if (!n1 || !c || !c.done || c.fen !== n1.fen) return;
    vvNodo = null; if (T.corrente !== n1 || !c.lines || !c.lines[0] || !c.lines[0].pv) return;
    var pv = c.lines[0].pv.slice(0, 5), n = n1;
    for (var q = 0; q < pv.length; q++){
      var u = pv[q], nx = T.aggiungiMossa(n, {from:u.slice(0, 2), to:u.slice(2, 4), promotion:u[4]});
      if (!nx) break; if (!I.S.orig[nx.id]) I.S.orig[nx.id] = 'm'; n = nx;
    }
    T.vaiA(n1); I.render();
  }
  // frecce: Confronta (arancione = giocata, azzurra = migliore); migliore e minaccia nella partita
  function confFen(){ var i = k() - 1; return U.p && i >= 0 ? U.p.fens[i] : null; }
  function confArrows(){
    var rec = recPronto(), i = k() - 1; if (!rec || i < 0) return [];
    var l = rec.lab[i], fen = U.p.fens[i], out = [];
    var giu = U.p.ucis[i], mb = l && l.best;
    if (window.CNAnalisi && CNAnalisi.normArrocco){ giu = CNAnalisi.normArrocco(fen, giu); if (mb) mb = CNAnalisi.normArrocco(fen, mb); }
    out.push({from:giu.slice(0, 2), to:giu.slice(2, 4), color:'mistake'});
    if (mb){
      var fa = window.CNAnalisi.frecciaArrocco && CNAnalisi.frecciaArrocco(fen, mb);
      out.push(fa || {from:mb.slice(0, 2), to:mb.slice(2, 4), color:'best'});
    }
    return out;
  }
  function bestAt(kk){ var rec = recPronto(); if (!rec || !U.p || kk >= U.p.ucis.length) return null; var V = rec.V && rec.V[kk]; return (V && V.best) || (rec.E[kk] && rec.E[kk].best) || null; }
  function evalAt(kk){
    var s = stato(), rec = s && s.rec; if (!rec || !rec.E || !rec.E[kk] || !U.p) return null;
    var e = rec.E[kk], w = U.p.fens[kk].split(' ')[1] === 'w' ? 1 : -1;
    if (e.over) return new Chess(U.p.fens[kk]).isCheckmate() ? {type:'mate', v:-w} : {type:'cp', v:0};
    if (e.mate) return {type:'mate', v:e.mate * w};
    return {type:'cp', v:e.cp * w};
  }
  function minaccia(){   // rossa SOLO se il motore la conferma e solo contro l'utente: la risposta migliore dell'avversario che prende o dà scacco
    var me = U.meta && U.meta.me; if (!me || !U.p) return null;
    var st = window.CNAnalisi.state(), fen = st.fen, side = fen.split(' ')[1]; if (side === me) return null;
    var u = null, forte = false;
    if (!st.inVariante){
      var rec = recPronto(), kk = st.ply; if (!rec || kk >= U.p.ucis.length || !rec.E[kk]) return null;
      u = rec.E[kk].best; forte = rec.E[kk].cp >= 150 || /errore|svarione/.test((rec.lab[kk - 1] || {}).cl || '');
    } else {
      var cur = I.cur(); if (!cur || cur.fen !== fen || !cur.done || !cur.lines[0] || (cur.lines[0].depth || 0) < 16) return null;
      u = cur.lines[0].pv[0]; var v = cur.lines[0], sg = side === 'w' ? 1 : -1;
      forte = v.type === 'mate' ? v.v * sg > 0 : v.v * sg >= 150;
    }
    if (!u || !forte) return null;
    var m = uciSan(fen, u); if (!m || !(/x|\+|#/.test(m.san))) return null;
    return u;
  }
  function nome(cl){ return NOMI[lang()][cl] || cl; }

  window.CNAnalisiPartitaUI = {apri:apri, chiudi:chiudi, onRender:onRender, onEngine:onEngine, tag:function(i){ return recPronto() && U.p && C.h === U.p.h ? icona(C.lab[i]) : (window.CNAnalisiPartita ? window.CNAnalisiPartita.tag(i) : ''); },
    icona:icona, nome:nome, azione:azione, ascolta:ascolta, voce:function(on){ if (!on) zitto(); }, salva:salva, puoVariante:puoVariante, vediVariante:vediVariante,
    confFen:confFen, confArrows:confArrows, bestAt:bestAt, evalAt:evalAt, minaccia:minaccia,
    // per le prove e per la pagina Analisi
    _commenti:function(){ return C; }, _sanClip:sanClip, _etichetta:etichetta, _costruisci:function(p, rec, meta){ return dati().then(function(){ return costruisci(p, rec, meta); }); }, storico:function(){ return sLeggi().g; }, SKEY:SKEY, istruttore:ist};
})();
