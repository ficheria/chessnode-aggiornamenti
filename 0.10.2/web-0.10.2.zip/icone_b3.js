/* Grande aggiornamento, blocco 3 (11-11): 3 icone v2 in più (+ v2-rimonta, blocco 3b), dal set approvato (anteprime/blocco16_icone/set_completo) e dallo schema Premi 27:
   v2-importa = E11 (partite importate), v2-corretto = G20 (Risoluzione), v2-medaglia = medaglia dei premi speciali (build_premi_27, approvata 08-11).
   Stesso formato di icone_v2.js (contenuto dell'<svg> 24x24, tratto 1.65). Si aggiungono allo STESSO oggetto window.LUCIDE. */
(function(){
  var L = window.LUCIDE = window.LUCIDE || {};
  L['v2-importa'] = '<g stroke-width="1.65"><g transform="translate(0.5714 1.0476) scale(0.95238)" stroke-width="1.73250"><path d="M3 5H8M16 5H21V21H3V5M12 2V14M8 10L12 14L16 10"/></g></g>';
  L['v2-corretto'] = '<g stroke-width="1.65"><g transform="translate(0 0) scale(1)" stroke-width="1.65"><path d="M3 12L9 19L21 5"/></g></g>';
  L['v2-medaglia'] = '<g stroke-width="1.65"><path d="M8 3L10 9M16 3L14 9"/><circle cx="12" cy="15" r="6"/><path d="M12 12.5L12.8 14.2L14.6 14.4L13.3 15.6L13.6 17.4L12 16.5L10.4 17.4L10.7 15.6L9.4 14.4L11.2 14.2Z"/></g>';
  // blocco 3b (11-11): v2-rimonta = premio speciale «Rimonta» (linea che scende e poi risale con la freccia; disegno nostro, stesso tratto)
  L['v2-rimonta'] = '<g stroke-width="1.65"><path d="M3 7L8.5 15L12.5 11L20 4"/><path d="M14.5 4H20V9.5"/><path d="M3 20H21"/></g>';
})();
