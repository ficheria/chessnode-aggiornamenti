/* IMPOSTAZIONI 24b (grande aggiornamento, blocco 2, 10-11). Schema: anteprime/blocco24_impostazioni/schema_impostazioni_24b_*, legenda.
   11 categorie + Informazioni in fondo (non numerata). Ogni categoria è una vista interna (Indietro torna all'elenco).
   Le voci che l'app ha già usano gli STESSI controlli di prima (cassetto Impostazioni dell'app, pagine.js → CNP.ctl) o le sue funzioni
   (pickEnv, setTheme, __coach.setChar, __percorso.setGoal, __profilo.save): niente doppioni di logica.
   Le opzioni non ancora pronte sono grigie, tratteggiate e non toccabili («In arrivo»).
   Notifiche (Kiko 10-11 18:35 / 20:24): 3 interruttori + ora (base 18) salvati in prefs.notifiche; la programmazione arriva nel blocco 4.
   Profilo: livello, Elo dichiarato, obiettivo e nomi Lichess/Chess.com in chessnodeplay-account-v1 (il profilo dell'app tiene solo
   nome/genere/pezzo/colore). Nessuna rete, nessuna password. */
(function(){
  'use strict';
  var C = window.CNP, ic = C.ic, esc = C.esc, A = C.A, PW = null;
  try { PW = C.inApp ? window.parent : null; } catch(e){ PW = null; }
  var AK = 'chessnodeplay-account-v1', PRK = 'chessnodeplay-profilo-v1';
  var root = document.getElementById('pg'), vista = /^#(\w+)/.test(location.hash) ? location.hash.slice(1) : '';
  var arr = '<span class="arr">In arrivo</span>';
  function pr(){ return C.prefs(); }
  function acc(){ return C.rd(AK) || {}; }
  function setAcc(k, v){ var a = acc(); a[k] = v; C.wr(AK, a); }
  function prof(){ try { if (PW && PW.__profilo) return PW.__profilo.get() || {}; } catch(e){} return C.rd(PRK) || {}; }
  function saveProf(o){ var p = prof(), n = {nome:p.nome || '', genere:p.genere || 'n', auto:p.auto !== false, pezzo:p.pezzo || 'p', colore:p.colore || 'tema'};
    for (var k in o) n[k] = o[k];
    if (o.nome != null && n.auto){ try { n.genere = PW.__profilo.guess(o.nome); } catch(e){} }
    try { if (PW && PW.__profilo){ PW.__profilo.save(n); return; } } catch(e){} C.wr(PRK, n); }

  /* ---------- pezzi di interfaccia ---------- */
  function tog(k, t, s, on){ return '<button class="rw" role="switch" aria-checked="' + !!on + '" data-t="' + k + '"><span class="rt"><b>' + t + '</b>' + (s ? '<small>' + s + '</small>' : '') + '</span><span class="sw"></span></button>'; }
  function grigio(t, s){ return '<div class="rw off" aria-disabled="true"><span class="rt"><b>' + t + '</b>' + (s ? '<small>' + s + '</small>' : '') + '</span>' + arr + '</div>'; }
  function seg(k, opts, cur, cls){ return '<div class="seg' + (cls ? ' ' + cls : '') + '" role="radiogroup">' + opts.map(function(o){
    return o[2] === 'off' ? '<button class="off" disabled>' + o[1] + ' · In arrivo</button>' : '<button role="radio" data-s="' + k + '" data-v="' + o[0] + '" aria-checked="' + (String(o[0]) === String(cur)) + '">' + o[1] + '</button>'; }).join('') + '</div>'; }
  function blocco(t, html){ return '<h3>' + t + '</h3>' + html; }
  function sel(k, opts, cur){ return '<select class="inp" data-sel="' + k + '">' + opts.map(function(o){ return '<option value="' + esc(o[0]) + '"' + (String(o[0]) === String(cur) ? ' selected' : '') + '>' + esc(o[1]) + '</option>'; }).join('') + '</select>'; }
  function opzioni(id){ if (!PW) return []; var el = PW.document.getElementById(id); return el ? [].map.call(el.options, function(o){ return [o.value, o.textContent]; }) : []; }
  function v(id, def){ var x = C.ctlVal(id); return x == null ? def : x; }

  /* ---------- elenco 24b ---------- */
  var CAT = [
    ['profilo', 'Profilo e account', 'Nome, avatar, Elo facoltativo, Lichess/Chess.com', 'v2-profilo'],
    ['aspetto', 'Aspetto e scacchiera', 'Tema, pezzi, scacchiera, coordinate', 'v2-tema'],
    ['animazioni', 'Animazioni', 'Stile, intensità, velocità, Prova', 'v2-animazioni'],
    ['esercizi', 'Esercizi e allenamento', 'Spiegazione, case controllate, obiettivo', 'v2-tempo'],
    ['istruttore', 'Istruttore', 'Scelta istruttore, voce, festeggiamenti', 'v2-istruttore'],
    ['analisi', 'Analisi', 'Frecce, minaccia, voce e lingua dei commenti', 'v2-analizza'],
    ['audio', 'Audio e lingua', 'Lingua · Voce · Suoni · Vibrazione', 'v2-lingua'],
    ['partite', 'Partite', 'Conferme, ultima mossa, promozione', 'v2-gioca'],
    ['notifiche', 'Notifiche', 'Problema del giorno, serie, profilo', 'v2-notifiche'],
    ['dati', 'Dati e backup', 'Backup esporta/importa, esporta PGN', 'v2-backup'],
    ['privacy', 'Privacy e cancellazione', 'I tuoi dati, cronologia, azzera progressi', 'v2-bloccato']];
  function elenco(){
    return C.header('Impostazioni') + '<div class="lst">' + CAT.map(function(c){
      return '<button class="rw" data-v2="' + c[0] + '"><span class="ri">' + ic(c[3], 20) + '</span><span class="rt"><b>' + c[1] + '</b><small>' + c[2] + '</small></span><span class="ch">' + ic('chevron-right', 18) + '</span></button>'; }).join('') + '</div>' +
      '<div class="lst" style="margin-top:12px"><button class="rw" data-v2="info"><span class="ri">' + ic('info', 20) + '</span><span class="rt"><b>Informazioni</b><small>Versione, crediti, Sostieni, Valuta Chess Node</small></span><span class="ch">' + ic('chevron-right', 18) + '</span></button></div>';
  }
  var PEZZI = [['k', 'Re'], ['q', 'Donna'], ['r', 'Torre'], ['b', 'Alfiere'], ['n', 'Cavallo'], ['p', 'Pedone']];
  var ISTR = [['chessnote', 'Chess Node'], ['paola', 'Paola'], ['nerd', 'Luca'], ['serena', 'Nadia'], ['maestro', 'Prof']];
  function scacchiere(){ return (A && A.THEMES) || [['bosco', 'Bosco', '#efe7d4', '#5f8f74']]; }
  function temaScacc(){ var p = pr(); return p.themeM || 'bosco'; }
  function colori(){ var t = temaScacc(), p = pr(); if (t === 'custom') return [p.lightM || '#efe7d4', p.darkM || '#5f8f74', null];
    var x = scacchiere().filter(function(r){ return r[0] === t; })[0] || scacchiere()[0]; return [x[2], x[3], x[4] || null]; }
  function anteprima(){ var c = colori(), PZ = (window.cnPezzi && window.cnPezzi()) || {}, h = '', fen = 'rnbqkbnr/pppppppp/8/8/4P3/8/PPPP1PPP/RNBQKBNR';
    var r = 0; fen.split('/').forEach(function(row){ var f = 0; row.split('').forEach(function(ch){
      function sq(img){ h += '<div style="background:' + (c[2] ? 'transparent' : (r + f) % 2 ? c[1] : c[0]) + '">' + (img ? '<img alt="" src="' + img + '">' : '') + '</div>'; f++; }
      if (/\d/.test(ch)) for (var i = 0; i < +ch; i++) sq(''); else sq(PZ[(ch === ch.toUpperCase() ? 'w' : 'b') + ch.toUpperCase()]); }); r++; });
    return '<div class="mb ip-prev"' + (c[2] ? ' style="background:url(' + c[2] + ') center/cover"' : '') + '>' + h + '</div>'; }

  function sotto(id){
    var p = pr(), h = '';
    switch (id){
    case 'profilo':
      var pf = prof(), a = acc();
      h = blocco('Il tuo profilo', '<label class="ip-l">Come ti chiami?<input class="inp" id="ipNome" maxlength="24" placeholder="Il tuo nickname" value="' + esc(pf.nome || '') + '" autocomplete="off"></label>') +
        '<p class="nota">Il nome compare ogni tanto nel fumetto dell\'istruttore.</p>' +
        blocco('Avatar', seg('pezzo', PEZZI, pf.pezzo || 'p', 'g3')) +
        blocco('Il tuo livello', seg('livello', [['principiante', 'Principiante'], ['intermedio', 'Intermedio'], ['avanzato', 'Avanzato'], ['esperto', 'Esperto']], a.livello || '', 'g2') +
          '<p class="nota">È solo un punto di partenza: lo aggiorniamo mentre ti alleni.</p>') +
        blocco('Elo dichiarato (facoltativo)', '<input class="inp" id="ipElo" inputmode="numeric" maxlength="4" placeholder="Es. 1200" value="' + esc(a.elo || '') + '">') +
        blocco('Profili collegati (facoltativo)', '<label class="ip-l">Lichess username<input class="inp" id="ipLi" maxlength="30" placeholder="Nome utente Lichess" value="' + esc(a.lichess || '') + '" autocomplete="off" autocapitalize="off" spellcheck="false"></label>' +
          '<label class="ip-l">Chess.com username<input class="inp" id="ipCc" maxlength="25" placeholder="Nome utente Chess.com" value="' + esc(a.chesscom || '') + '" autocomplete="off" autocapitalize="off" spellcheck="false"></label>' +
          '<p class="nota">Solo partite pubbliche, nessuna password. I nomi restano salvati sul telefono.</p>') +
        /* 14-11 (Kiko t1947u): importazione e analisi vere, sotto i nomi */
        '<section class="card cp" id="cpImp"></section>' +
        blocco('Account', '<div class="lst">' + grigio('Accesso e sincronizzazione', 'Dopo il lancio') + '</div>');
      return ['Profilo e account', h];
    case 'aspetto':
      var ts = scacchiere(), tc = temaScacc(), semplici = ts.filter(function(t){ return !t[4]; }), trama = ts.filter(function(t){ return t[4]; });
      var tipo = tc === 'custom' ? 'pers' : trama.some(function(t){ return t[0] === tc; }) ? 'trama' : 'semplice';
      var co = colori(), sets = opzioni('pset');
      /* 14-11 (Kiko): anteprima FISSA in alto (sticky sotto l'intestazione) + due schede «Scacchiera» e «Pezzi»: ogni scelta si vede subito, senza scorrere su */
      var sch = tabAsp === 'pz' ? 'pz' : 'sc';
      h = '<div class="ip-fix"><div class="card ip-pv">' + anteprima() + '</div>' +
        '<div class="ip-tabs" role="tablist" aria-label="Aspetto">' +
          '<button role="tab" id="ipTabSc" data-tab="sc" aria-controls="ipPanSc" aria-selected="' + (sch === 'sc') + '">Scacchiera</button>' +
          '<button role="tab" id="ipTabPz" data-tab="pz" aria-controls="ipPanPz" aria-selected="' + (sch === 'pz') + '">Pezzi</button></div></div>' +
        '<div class="ip-pan" role="tabpanel" id="ipPanSc" aria-labelledby="ipTabSc"' + (sch === 'sc' ? '' : ' hidden') + '>' +
        blocco('Scacchiera', seg('tipo', [['semplice', 'Semplice'], ['trama', 'Con trama'], ['pers', 'Personalizzata']], tipo) +
          '<div class="ip-sc">' + (tipo === 'pers' ? '<label class="rw"><span class="rt"><b>Case chiare</b></span><input type="color" id="ipCl" value="' + co[0] + '"></label><label class="rw"><span class="rt"><b>Case scure</b></span><input type="color" id="ipCd" value="' + co[1] + '"></label>'
            : (tipo === 'trama' ? trama : semplici).map(function(t){ return '<button data-s="theme" data-v="' + t[0] + '" aria-checked="' + (t[0] === tc) + '" aria-label="' + esc(t[1]) + '"><i style="' + (t[4] ? 'background:url(' + t[4] + ') center/cover' : 'background:linear-gradient(135deg,' + t[2] + ' 50%,' + t[3] + ' 50%)') + '"></i><span>' + esc(t[1]) + '</span></button>'; }).join('')) + '</div>') +
        '<div class="lst" style="margin-top:16px">' + grigio('Coordinate') + grigio('Orientamento', 'Auto / Bianco') + '</div>' + '</div>' +
        '<div class="ip-pan" role="tabpanel" id="ipPanPz" aria-labelledby="ipTabPz"' + (sch === 'pz' ? '' : ' hidden') + '>' +
        blocco('Set di pezzi', sets.length ? '<div class="ip-ps">' + sets.map(function(s){ var P = (window.PIECES || {})[s[0]] || {};
          return '<button data-s="pset" data-v="' + s[0] + '" aria-checked="' + (s[0] === (p.psetM || 'elegante')) + '" aria-label="' + esc(s[1]) + '"><img alt="" src="' + (P.wN || '') + '"><img alt="" src="' + (P.bQ || '') + '"><span>' + esc(s[1]) + '</span></button>'; }).join('') + '</div>' : '<p class="nota">Si sceglie dall\'app.</p>') + '</div>' +
        blocco('Tema', seg('bg', [['bianco', 'Chiaro'], ['notte', 'Scuro'], ['auto', 'Auto', 'off']], p.bg === 'bianco' ? 'bianco' : 'notte')) +
        '<button class="btn sec ip-rip" data-az="ripristina">Ripristina impostazioni grafiche</button><p class="nota">Con conferma · non tocca partite, esercizi, progressi o dati.</p>';
      return ['Aspetto e scacchiera', h];
    case 'animazioni':
      h = blocco('Stile', seg('stile', [['classica', 'Classica'], ['altri', 'Altri stili', 'off']], 'classica')) +
        blocco('Intensità', seg('anim', [['normal', 'Normale'], ['reduced', 'Ridotta'], ['off', 'Spenta']], p.anim || 'normal') + '<p class="nota">Indipendente dallo stile. Con «Riduci movimento» del telefono si parte da Ridotta.</p>') +
        '<div class="lst" style="margin-top:16px">' + grigio('Velocità del movimento', 'Lenta · Rapida') + grigio('Prova', 'Apre una mini scacchiera dimostrativa') + '</div>';
      return ['Animazioni', h];
    case 'esercizi':
      var goal = (C.rd('chessnodeplay-obiettivo-v1') || {}).target || 10;
      h = blocco('Velocità della spiegazione', seg('xspeed', [['slow', 'Lenta'], ['normal', 'Normale'], ['fast', 'Veloce']], v('xspeedSel', p.xspeed || 'normal'))) +
        '<div class="lst" style="margin-top:16px">' + tog('xray', 'Case controllate', 'Spiegazione con case rosse e frecce', v('xrayOn', false)) +
          tog('engine', 'Risposta di Stockfish dopo un errore', 'Mostra la risposta dell\'avversario', v('engineOn', false)) +
          tog('keep', 'Frecce all\'esercizio successivo', 'Mantieni frecce e cerchi', v('keepShapes', false)) + '</div>' +
        blocco('Obiettivo di oggi', seg('goal', [[5, '5'], [10, '10'], [20, '20']], goal) + '<p class="nota">Esercizi al giorno. È un obiettivo, non un obbligo.</p>');
      return ['Esercizi e allenamento', h];
    case 'istruttore':
      var on = p.coach !== 'off', ch = p.coachChar && p.coachChar !== 'auto' ? p.coachChar : 'chessnote';
      h = blocco('Istruttore preferito', '<div class="ip-ist">' + ISTR.map(function(x){ return '<button data-s="coach" data-v="' + x[0] + '" aria-checked="' + (on && x[0] === ch) + '"><img alt="" src="istruttori/tondi/' + x[0] + '.webp"><span>' + x[1] + '</span></button>'; }).join('') +
          '<button data-s="coach" data-v="off" aria-checked="' + !on + '"><i class="ip-off">Spento</i><span>Spento</span></button></div>') +
        '<div class="lst" style="margin-top:16px">' + tog('auto', 'Voce istruttore', 'Lettura automatica del compito e del commento', v('autoOn', !!p.auto)) +
          tog('confetti', 'Festeggiamenti', 'Quando risolvi un esercizio', v('confettiOn', p.confetti !== false)) + grigio('Tipo festeggiamento', 'Altri tipi') + '</div>';
      return ['Istruttore', h];
    case 'analisi':   // blocco 5 (11-11): impostazioni vere (prefs.an), le stesse dell'ingranaggio dell'analisi. Tutte spente di base.
      var an = p.an || {};
      h = '<div class="lst">' + tog('an_frecce', 'Frecce', 'Azzurra: la mossa migliore del motore', !!an.frecce) +
          tog('an_minaccia', 'Minaccia', 'Rossa: solo se il motore la conferma contro di te', !!an.minaccia) +
          tog('an_voce', 'Voce dell\'istruttore nei commenti', 'Altrimenti tocca il suo avatar per ascoltare. Il commento scritto resta sempre visibile', !!an.voce) + '</div>' +
        blocco('Lingua dei commenti', seg('an_lingua', [['it', 'Italiano'], ['en', 'English']], an.lingua === 'en' ? 'en' : 'it')) +
        blocco('Internet', '<div class="lst">' + tog('an_cloud', 'Valutazioni pronte di Lichess', 'Solo nella Scacchiera di analisi: si invia la posizione al cloud di Lichess', !!an.cloud) + '</div>' +
          '<p class="nota">Spento: tutto il calcolo avviene sul telefono con Stockfish.</p>');
      return ['Analisi', h];
    case 'audio':
      var voci = opzioni('voiceSel'), vel = opzioni('vrateSel'), sset = opzioni('soundSet');
      h = blocco('Lingua', seg('lang', [['it', 'Italiano'], ['en', 'English', 'off']], 'it')) +
        blocco('Voce', (voci.length ? '<label class="ip-l">Voce dell\'istruttore' + sel('voice', voci, v('voiceSel', '')) + '</label>' : '') + (vel.length ? '<label class="ip-l">Velocità della voce' + sel('vrate', vel, v('vrateSel', '')) + '</label>' : '') +
          '<label class="ip-l">Volume<input type="range" class="ip-rg" data-rg="volume" min="0" max="100" step="5" value="' + esc(v('volume', 80)) + '"></label>') +
        blocco('Suoni', '<div class="lst">' + tog('sound', 'Effetti sonori', '', v('soundOn', true)) + tog('intro', 'Musica di avvio', 'Serve «Effetti sonori» attivo', v('introMusic', false)) + '</div>' +
          (sset.length ? '<label class="ip-l">Set di suoni' + sel('soundSet', sset, v('soundSet', '')) + '</label>' : '')) +
        blocco('Vibrazione', '<div class="lst">' + tog('vibra', 'Vibrazione', 'Un impulso se è giusta, due se è sbagliata. Vale anche per i pulsanti principali e la barra.', v('vibraOn', true)) + '</div>');
      return ['Audio e lingua', h];
    case 'partite':
      h = '<div class="lst">' + grigio('Conferma abbandono') + grigio('Conferma nuova partita') + grigio('Evidenzia l\'ultima mossa') + grigio('Promozione', 'Chiedi sempre / Donna automatica') + '</div>' +
        '<p class="nota">Arrivano con la nuova pagina Gioca (blocco 3).</p>';
      return ['Partite', h];
    case 'notifiche':
      var n = p.notifiche || {}, ora = n.ora == null ? 18 : n.ora, ore = [];
      for (var o = 9; o <= 21; o++) ore.push([o, pad2(o) + ':00']);
      h = '<div class="lst">' + tog('n_problema', 'Problema del giorno', 'Un esercizio nuovo ogni giorno, se non l\'hai già fatto', n.problema !== false) +
          tog('n_serie', 'Serie in pericolo', 'Se la tua serie sta per interrompersi', n.serie !== false) +
          tog('n_profilo', 'Profilo aggiornato', 'Quando l\'analisi delle tue partite ha novità', n.profilo !== false) + '</div>' +
        blocco('Ora del promemoria', sel('n_ora', ore, ora)) +
        '<p class="nota">Al massimo una al giorno · mai tra le 21:30 e le 9:00. Il permesso del telefono si chiede una volta sola, al primo Esercizio del giorno. ' +
        'Notifiche solo sul telefono, senza server: nel browser non arrivano.</p>' + notifStato();
      return ['Notifiche', h];
    case 'dati':
      h = blocco('Backup', '<p class="tx">Salva in un file tutti i tuoi progressi (esercizi, statistiche, serie, salvati, profilo e impostazioni) e ricaricali su questo o su un altro telefono.</p>' +
          '<div class="lst"><button class="rw" data-az="bkExp"><span class="ri">' + ic('download', 20) + '</span><span class="rt"><b>Esporta backup</b></span></button>' +
          '<button class="rw" data-az="bkImp"><span class="ri">' + ic('upload', 20) + '</span><span class="rt"><b>Importa backup</b><small>Sostituisce i dati di questo telefono</small></span></button></div>') +
        blocco('Altro', '<div class="lst">' + grigio('Esporta partite in PGN') + grigio('Sincronizzazione online', 'Dopo il lancio') + '</div>');
      return ['Dati e backup', h];
    case 'privacy':
      h = blocco('I tuoi dati', '<p class="tx">Progressi, salvati, profilo e impostazioni restano su questo telefono. Puoi esportarli quando vuoi da Dati e backup.</p>' +
          '<p class="tx">L\'app usa Internet solo quando lo chiedi tu: per importare le tue partite pubbliche da Lichess o Chess.com (si invia solo il nome utente) e, se le accendi in Impostazioni › Analisi, per le valutazioni già pronte di Lichess nella Scacchiera di analisi (si invia solo la posizione). Le voci sono registrate: nessun dato va a Google.</p>' +
          '<div class="lst"><button class="rw" data-az="bkExp"><span class="ri">' + ic('download', 20) + '</span><span class="rt"><b>Esporta i tuoi dati</b><small>Un file con tutto</small></span></button></div>') +
        blocco('Cancellazione', '<div class="lst"><button class="rw" data-az="cronologia"><span class="ri">' + ic('trash-2', 20) + '</span><span class="rt"><b>Cancella la cronologia delle analisi</b><small>Partite analizzate e ultima posizione</small></span></button>' +
          '<button class="rw" data-az="azzera"><span class="ri">' + ic('v2-azzera', 20) + '</span><span class="rt"><b>Azzera i progressi</b><small>Con conferma, nella schermata degli esercizi</small></span></button></div>');
      return ['Privacy e cancellazione', h];
    case 'info':
      h = '<div class="lst"><div class="rw"><span class="ri">' + ic('info', 20) + '</span><span class="rt"><b>Versione</b></span><span class="rv" id="ipVer">…</span></div>' +
        '<button class="rw" data-pg="info.html"><span class="ri">' + ic('v2-crediti', 20) + '</span><span class="rt"><b>Info e crediti</b><small>Licenze, privacy e contatti</small></span><span class="ch">' + ic('chevron-right', 18) + '</span></button>' +
        '<button class="rw" data-pg="sostieni.html"><span class="ri">' + ic('v2-dona', 20) + '</span><span class="rt"><b>Sostieni Chess Node</b></span><span class="ch">' + ic('chevron-right', 18) + '</span></button>' +
        '<button class="rw" data-ext="' + C.LIBRO + '"><span class="ri">' + ic('v2-libro', 20) + '</span><span class="rt"><b>Il libro: ' + esc(C.TITOLO) + '</b><small>Altre citazioni</small></span><span class="ch">' + ic('external-link', 18) + '</span></button>' +
        '<button class="rw" data-az="invita"><span class="ri">' + ic('v2-invita', 20) + '</span><span class="rt"><b>Invita un amico</b></span><span class="ch">' + ic('chevron-right', 18) + '</span></button>' +
        '<button class="rw" data-ext="' + C.PLAY + '"><span class="ri">' + ic('star', 20) + '</span><span class="rt"><b>Valuta Chess Node</b><small>Lascia le stelle sul Play Store</small></span><span class="ch">' + ic('external-link', 18) + '</span></button></div>';
      /* 14-11 (Kiko t1951u): aggiornamenti senza reinstallare (aggiornamenti.js nella pagina principale) */
      h += blocco('Aggiornamenti', '<div class="lst"><div class="rw"><span class="ri">' + ic('download', 20) + '</span><span class="rt"><b>Versione dei contenuti</b><small id="ipAggSt">…</small></span><span class="rv" id="ipAggVer">…</span></div></div>' +
        '<button type="button" class="btn sec" data-az="aggcontrolla" style="margin-top:12px">Controlla aggiornamenti</button>' +
        '<label class="ip-l" style="margin-top:14px">Indirizzo degli aggiornamenti<input class="inp" id="ipAggUrl" placeholder="https://…/manifest.json" autocomplete="off" autocapitalize="off" spellcheck="false" inputmode="url"></label>' +
        '<p class="nota">Si scaricano solo aggiornamenti firmati da Chess Node; si installano alla prossima apertura dell\'app. Se qualcosa non parte, l\'app torna da sola alla versione precedente.</p>');
      return ['Informazioni', h];
    }
    return null;
  }
  /* aggiornamenti: testo dello stato (dalla pagina principale) */
  function AGG(){ try { return window.parent !== window && window.parent.CNAgg; } catch(e){ return null; } }
  var TESTI_AGG = {nonconfigurato:'Server degli aggiornamenti non ancora impostato', rete:'Server non raggiungibile: riprova più tardi', firma:'Firma non valida: aggiornamento scartato',
    aggiornata:'Hai già la versione più recente', serveapk:'Questa novità richiede la nuova app (APK)', soloapp:'Disponibile nell\'app installata', errore:'Non riuscito: riprova più tardi'};
  function aggTesto(e){ if (!e) return 'Mai controllato'; if (e.e === 'pronta') return 'Versione ' + e.versione + ' pronta: si installa alla prossima apertura'; return (e.testo && e.e === 'errore') ? e.testo : (TESTI_AGG[e.e] || ''); }
  function aggDisegna(){
    var G = AGG(), st = document.getElementById('ipAggSt'), vv = document.getElementById('ipAggVer'), u = document.getElementById('ipAggUrl');
    if (!G){ if (st) st.textContent = 'Disponibile nell\'app installata'; if (vv) vv.textContent = 'web'; return; }
    G.info().then(function(i){
      if (vv) vv.textContent = i.web;
      if (u && document.activeElement !== u) u.value = i.url || '';
      var s = G.stato(), t = aggTesto(i.esito);
      if (s.ripristino) t = 'L\'aggiornamento ' + (s.ripristino.versione || '') + ' non partiva: tornati alla versione precedente';
      else if (s.installata && (!i.esito || i.esito.e === 'aggiornata')) t = 'Aggiornata alla ' + s.installata.versione;
      if (st) st.textContent = t;
    });
  }
  function pad2(n){ return ('0' + n).slice(-2); }
  function disegna(scroll){
    var s = vista && sotto(vista);
    if (!s){ vista = ''; root.innerHTML = elenco(); }
    else root.innerHTML = C.header(s[0]) + s[1];
    var cpI = document.getElementById('cpImp');
    if (cpI && window.CNCollega) window.CNCollega.monta(cpI, {modo:'impostazioni', nomiDa:function(){ var l = document.getElementById('ipLi'), c = document.getElementById('ipCc'); return {lichess:l ? l.value.trim() : '', chesscom:c ? c.value.trim() : ''}; }});
    if (vista === 'info') aggDisegna();
    if (vista === 'info') C.versione(function(x){ var e = document.getElementById('ipVer'); if (e) e.textContent = x && x !== 'web' ? x : 'web (anteprima)'; });
    if (scroll !== false) window.scrollTo(0, 0);
  }
  var tabAsp = 'sc';   // 14-11: scheda aperta in Aspetto (resta uguale quando si ridisegna dopo una scelta)
  function rifai(){ var y = window.scrollY; disegna(false); window.scrollTo(0, y); }
  function tema(id){ document.body.dataset.bg = id; }

  /* ---------- azioni ---------- */
  var TOG = {
    xray:function(x){ C.ctl('xrayOn', x); }, engine:function(x){ C.ctl('engineOn', x); }, keep:function(x){ C.ctl('keepShapes', x); },
    auto:function(x){ C.ctl('autoOn', x) || C.setPref('auto', x); }, confetti:function(x){ C.ctl('confettiOn', x) || C.setPref('confetti', x); },
    sound:function(x){ C.ctl('soundOn', x); }, intro:function(x){ C.ctl('introMusic', x); }, vibra:function(x){ C.ctl('vibraOn', x); },
    an_frecce:function(x){ anPref('frecce', x); }, an_minaccia:function(x){ anPref('minaccia', x); }, an_voce:function(x){ anPref('voce', x); }, an_cloud:function(x){ anPref('cloud', x); },
    n_problema:function(x){ notif('problema', x); }, n_serie:function(x){ notif('serie', x); }, n_profilo:function(x){ notif('profilo', x); }};
  function anPref(k, x){ var o = {}, a = pr().an || {}; for (var q in a) o[q] = a[q]; o[k] = x; C.setPref('an', o); }   // blocco 5
  function notif(k, x){ var n = pr().notifiche || {}; var o = {problema:n.problema !== false, serie:n.serie !== false, profilo:n.profilo !== false, ora:n.ora == null ? 18 : n.ora}; o[k] = x; C.setPref('notifiche', o);
    try { if (window.parent.CNNotifiche) window.parent.CNNotifiche.pianifica(); } catch(e){} }   // blocco 4: si riprogrammano subito
  // blocco 4: prossima notifica programmata (solo nell'app sul telefono)
  function notifStato(){
    var N = null; try { N = window.parent !== window && window.parent.CNNotifiche; } catch(e){ N = null; }
    if (!N || !N.plugin()) return '';
    var l = N.piano(N.contesto()), x = l[0]; if (!x) return '';
    var d = new Date(x.at), g = ['domenica', 'lunedì', 'martedì', 'mercoledì', 'giovedì', 'venerdì', 'sabato'][d.getDay()];
    return '<p class="nota">Prossima: ' + C.esc(x.title) + ' · ' + g + ' ' + pad2(d.getHours()) + ':' + pad2(d.getMinutes()) + '</p>';
  }
  var SEG = {
    pezzo:function(x){ saveProf({pezzo:x}); }, an_lingua:function(x){ anPref('lingua', x); }, livello:function(x){ setAcc('livello', x); },
    bg:function(x){ if (A && A.pickEnv) A.pickEnv(x); else C.setPref('bg', x); tema(x); },
    pset:function(x){ C.ctl('pset', x) || C.setPref('psetM', x); },
    tipo:function(x){ var ts = scacchiere(); if (x === 'pers'){ var c = colori(); C.ctl('cLight', c[0]); C.ctl('cDark', c[1]); if (!A) C.setPref('themeM', 'custom'); return; }
      var t = ts.filter(function(r){ return x === 'trama' ? r[4] : !r[4]; })[0]; if (t) scegliTema(t[0]); },
    theme:function(x){ scegliTema(x); },
    anim:function(x){ C.ctl('animSel', x) || C.setPref('anim', x); C.ridotte = x !== 'normal';
      try { if (window.__cnEffetti && __cnEffetti.applyMot) __cnEffetti.applyMot(); } catch(e){}
      try { if (window.parent.__cnEffetti && window.parent.__cnEffetti.applyMot) window.parent.__cnEffetti.applyMot(); } catch(e){}
      try { window.parent.document.dispatchEvent(new Event('cn-mot-change')); } catch(e){} },
    xspeed:function(x){ C.ctl('xspeedSel', x) || C.setPref('xspeed', x); },
    goal:function(x){ try { if (window.parent.__percorso && window.parent.__percorso.setGoal){ window.parent.__percorso.setGoal(+x); return; } } catch(e){} var g = C.rd('chessnodeplay-obiettivo-v1') || {}; g.target = +x; C.wr('chessnodeplay-obiettivo-v1', g); },
    coach:function(x){ if (x === 'off'){ C.ctl('coachOn', 'off') || C.setPref('coach', 'off'); return; }
      C.ctl('coachOn', 'on') || C.setPref('coach', 'on'); try { if (window.parent.__coach && window.parent.__coach.setChar){ window.parent.__coach.setChar(x); return; } } catch(e){} C.setPref('coachChar', x); }};
  function scegliTema(id){ if (A && A.setTheme) A.setTheme(id); else C.setPref('themeM', id); }
  var SEL = {voice:'voiceSel', vrate:'vrateSel', soundSet:'soundSet'};
  root.addEventListener('click', function(ev){
    var t;
    if ((t = ev.target.closest('[data-v2]'))){ vista = t.dataset.v2; disegna(); return; }
    if ((t = ev.target.closest('[data-t]'))){ var on = t.getAttribute('aria-checked') !== 'true'; t.setAttribute('aria-checked', on); (TOG[t.dataset.t] || function(){})(on); return; }
    if ((t = ev.target.closest('[data-tab]'))){ tabAsp = t.dataset.tab;
      [].forEach.call(root.querySelectorAll('[data-tab]'), function(b){ b.setAttribute('aria-selected', b === t); });
      var pS = document.getElementById('ipPanSc'), pZ = document.getElementById('ipPanPz'); if (pS) pS.hidden = tabAsp !== 'sc'; if (pZ) pZ.hidden = tabAsp !== 'pz';
      var fx = root.querySelector('.ip-fix'); if (fx){ var top = fx.offsetTop - (parseFloat(getComputedStyle(fx).top) || 0); if (window.scrollY > top) window.scrollTo(0, top); }
      return; }
    if ((t = ev.target.closest('[data-s]'))){ SEG[t.dataset.s](t.dataset.v); rifai(); return; }
    if ((t = ev.target.closest('[data-az]'))) azione(t.dataset.az);
  });
  root.addEventListener('change', function(ev){
    var t = ev.target;
    if (t.dataset.sel === 'n_ora') notif('ora', +t.value);
    else if (SEL[t.dataset.sel]) C.ctl(SEL[t.dataset.sel], t.value);
    else if (t.id === 'ipNome') saveProf({nome:t.value.trim().slice(0, 24)});
    else if (t.id === 'ipElo'){ var e = parseInt(t.value, 10); setAcc('elo', e >= 100 && e <= 3500 ? e : ''); if (t.value && !(e >= 100 && e <= 3500)) C.toast('Elo tra 100 e 3500'); }
    else if (t.id === 'ipAggUrl'){ var G2 = AGG(); var v = t.value.trim(); if (v && !/^https:\/\//i.test(v)){ C.toast('Serve un indirizzo https://'); return; } if (G2){ G2.impostaUrl(v); C.toast('Indirizzo salvato'); } }
    else if (t.id === 'ipLi' || t.id === 'ipCc'){ var u = t.value.trim(), ok = !u || /^[A-Za-z0-9_-]{2,30}$/.test(u); if (!ok){ C.toast('Nome utente non valido'); return; } setAcc(t.id === 'ipLi' ? 'lichess' : 'chesscom', u); C.toast('Salvato sul telefono'); }
  });
  root.addEventListener('input', function(ev){
    var t = ev.target;
    if (t.dataset.rg === 'volume') C.ctl('volume', t.value);
    else if (t.id === 'ipCl' || t.id === 'ipCd'){ if (A){ C.ctl(t.id === 'ipCl' ? 'cLight' : 'cDark', t.value); } else { C.setPref(t.id === 'ipCl' ? 'lightM' : 'darkM', t.value); C.setPref('themeM', 'custom'); }
      var pv = root.querySelector('.ip-pv'); if (pv) pv.innerHTML = anteprima(); }
  });
  function azione(a){
    if (a === 'aggcontrolla'){ var G = AGG(), bt = document.querySelector('[data-az=aggcontrolla]'); if (!G){ C.toast('Disponibile nell\'app'); return; }
      var u = document.getElementById('ipAggUrl'); if (u && u.value.trim() !== (G.stato().url || '')){ if (u.value.trim() && !/^https:\/\//i.test(u.value.trim())){ C.toast('Serve un indirizzo https://'); return; } G.impostaUrl(u.value); }
      var st = document.getElementById('ipAggSt'); if (st) st.textContent = 'Controllo in corso…'; if (bt) bt.disabled = true;
      G.controlla().then(function(e){ if (bt) bt.disabled = false; if (G.dimenticaRipristino) G.dimenticaRipristino(); aggDisegna(); if (e && e.e === 'pronta') C.toast('Aggiornamento pronto: riapri l\'app'); },
        function(){ if (bt) bt.disabled = false; aggDisegna(); });
      return; }
    if (a === 'invita'){ try { if (window.parent.__agg){ window.parent.__agg.invite(); return; } } catch(e){} C.toast('Disponibile nell\'app'); return; }
    if (a === 'bkExp'){ if (!clickApp('bkExp')) C.toast('Disponibile nell\'app'); else C.toast('Backup preparato'); return; }
    if (a === 'bkImp'){ C.conferma('Importa backup', 'I dati del file sostituiscono quelli di questo telefono. Poi l\'app si riavvia.', 'Scegli il file', function(){ if (!clickApp('bkImp')) C.toast('Disponibile nell\'app'); }); return; }
    if (a === 'ripristina'){ C.conferma('Ripristina impostazioni grafiche', 'Tema scuro, scacchiera Bosco, pezzi Elegante e animazioni normali. Partite, esercizi, progressi e dati non cambiano.', 'Ripristina', function(){
      SEG.bg('notte'); scegliTema('bosco'); SEG.pset('elegante'); SEG.anim('normal'); rifai(); C.toast('Impostazioni grafiche ripristinate'); }); return; }
    if (a === 'cronologia'){ C.conferma('Cancella la cronologia delle analisi', 'Si cancellano le partite analizzate salvate e l\'ultima posizione della Scacchiera di analisi. Esercizi e progressi restano.', 'Cancella', function(){
      try { localStorage.removeItem('chessnodeplay-analisi-partita-v3'); localStorage.removeItem('chessnodeplay-analisi-v1'); localStorage.removeItem('chessnodeplay-analisi-storico-v1'); } catch(e){} C.toast('Cronologia delle analisi cancellata'); }); return; }
    if (a === 'azzera'){ if (!C.inApp){ C.toast('Disponibile nell\'app'); return; }
      try { window.parent.CNHome.nascondi(); var b = window.parent.document.getElementById('resetProgress'); if (b) b.click(); } catch(e){} }
  }
  function clickApp(id){ if (!C.inApp) return false; try { var b = window.parent.document.getElementById(id); if (!b) return false; b.click(); return true; } catch(e){ return false; } }

  /* Indietro: dalla categoria all'elenco, poi la pagina precedente */
  C.canBack = function(){ return !!vista; };
  C.onBack = function(){ vista = ''; disegna(); return true; };
  root.addEventListener('click', function(ev){ if (ev.target.closest('[data-back]') && vista){ ev.stopImmediatePropagation(); C.onBack(); } }, true);
  disegna();
})();
