/* studio.js — versione moderna: schermate separate di STUDIO (esercizio) e ANALISI.
   Caricato SOLO da index_moderna.html, dopo layout.js.
   - html.anamode durante l'analisi: titolo «Analisi – Esercizio N», pulsante «← Torna all'esercizio»,
     comandi dell'esercizio nascosti, frecce di navigazione dell'analisi al posto di Aiuto/Soluzione/Riprova.
   - telefono / concentrazione: schermata intera con transizione a scorrimento; il tasto Indietro del
     telefono (cronologia del browser) riporta all'esercizio.
   - il ritorno ripristina l'esercizio com'era (app.js: snapStudy/restoreStudy) e riprende il cronometro. */
(function(){
  'use strict';
  var A = window.__app; if (!A) return;
  var root = document.documentElement;
  function $(id){ return document.getElementById(id); }
  function esc(s){ return String(s).replace(/[&<>"]/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]; }); }
  var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)');
  var mqPhone = window.matchMedia('(max-width: 600px)');
  function compact(){ return mqPhone.matches || root.classList.contains('focus'); }

  // ---------- barra «Analisi – Esercizio N» ----------
  var ARROW = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M15 18l-6-6 6-6"/></svg>';
  var top = document.createElement('div');
  top.id = 'anaTop'; top.className = 'anatop'; top.setAttribute('role', 'navigation'); top.setAttribute('aria-label', 'Analisi');
  top.innerHTML = '<button id="anaBack" class="anaback" type="button" title="Torna all\'esercizio, esattamente dove eri (Esc)">' + ARROW +
    '<span class="ab-l">Torna all\'esercizio</span><span class="ab-s">Esercizio</span></button>' +
    '<div class="anattl"><b id="anaTitle">Analisi</b><span id="anaSub"></span></div><span class="anaspacer"></span>';
  function place(){
    // concentrazione (telefono): al posto della barra fBar; altrimenti nella barra in alto, al posto del titolo dell'app
    if (root.classList.contains('focus')){ var fb = $('fBar'); if (fb && top.previousSibling !== fb) fb.parentNode.insertBefore(top, fb.nextSibling); }
    else { var h = document.querySelector('.topbar h1'); if (h && top.previousSibling !== h) h.parentNode.insertBefore(top, h.nextSibling); }
  }
  function title(){
    var e = A.state.ex; if (!e) return;
    var ch = A.chById && A.chById[e.c];
    $('anaTitle').textContent = 'Analisi – Esercizio ' + e.n;
    $('anaSub').textContent = ch ? ch.name : '';
  }

  // ---------- frecce dell'analisi nella fila dei pulsanti ----------
  var nav = document.querySelector('#anaBox .ananav'), navHome = null;
  function moveNav(on){
    var bar = document.querySelector('.actionbar'); if (!nav || !bar) return;
    if (on){
      if (!navHome){ navHome = document.createComment('home:ananav'); nav.parentNode.insertBefore(navHome, nav); }
      bar.insertBefore(nav, bar.firstChild);
    } else if (navHome && navHome.parentNode){ navHome.parentNode.insertBefore(nav, navHome); navHome.parentNode.removeChild(navHome); navHome = null; }
  }

  // ---------- telefono: la spiegazione lunga dell'analisi è richiudibile (chiusa all'inizio) ----------
  var help = document.querySelector('#anaBox .anahelp'), helpTg = null;
  if (help){
    helpTg = document.createElement('button');
    helpTg.type = 'button'; helpTg.id = 'anaHelpTg'; helpTg.className = 'anahelptg small';
    helpTg.setAttribute('aria-expanded', 'false'); helpTg.setAttribute('aria-controls', 'anaHelp');
    help.id = help.id || 'anaHelp';
    helpTg.innerHTML = 'ℹ️ Come funziona <span class="chev" aria-hidden="true">▾</span>';
    help.parentNode.insertBefore(helpTg, help);
    helpTg.addEventListener('click', function(){
      var open = !$('anaBox').classList.contains('helpopen');
      $('anaBox').classList.toggle('helpopen', open);
      helpTg.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
  }
  function helpReset(){ var b = $('anaBox'); if (b) b.classList.remove('helpopen'); if (helpTg) helpTg.setAttribute('aria-expanded', 'false'); }

  // ricalcolo della scacchiera quando la colonna dei capitoli (desktop) sparisce o ritorna
  function relayout(){ setTimeout(function(){ try { window.dispatchEvent(new Event('resize')); } catch(e){} }, 0); }

  // ---------- transizione ----------
  function animOff(){ return (reduce && reduce.matches) || root.classList.contains('noanim') || document.body.dataset.anim === 'off'; }
  function slide(dir){
    if (animOff() || !document.body.animate) return;
    var els, kf;
    if (compact()){
      els = [top, document.querySelector('.layout'), $('fDeck')];
      kf = [{transform:'translateX(' + (dir > 0 ? 34 : -34) + '%)', opacity:0}, {transform:'none', opacity:1}];
    } else {
      els = [document.querySelector('.panel'), top, document.querySelector('.actionbar')];
      kf = [{transform:'translateX(' + (dir > 0 ? 18 : -18) + 'px)', opacity:0}, {transform:'none', opacity:1}];
    }
    els.forEach(function(el){ if (el && el.offsetParent !== null) el.animate(kf, {duration:compact() ? 300 : 220, easing:'cubic-bezier(.2,.8,.2,1)'}); });
  }

  // ---------- cronometro dell'esercizio in pausa durante l'analisi ----------
  // (focus.js conta il tempo su questo esercizio: lo fermo all'ingresso e lo riprendo al ritorno)
  function clock(pause){ var F = window.__focus; if (F && F.pauseClock) try { F.pauseClock(pause); } catch(e){} }

  // ---------- cronologia: Indietro del telefono = torna all'esercizio ----------
  var pushed = false, popSkip = false;
  function pushHist(){ try { if (!(history.state && history.state.cnpana)){ history.pushState({cnpana:1}, ''); pushed = true; } } catch(e){} }
  function popHist(){ if (pushed && history.state && history.state.cnpana){ pushed = false; popSkip = true; try { history.back(); } catch(e){ popSkip = false; } } else pushed = false; }
  window.addEventListener('popstate', function(){
    if (popSkip){ popSkip = false; return; }
    pushed = false;
    if (A.state.analysis) back();
  });

  // ---------- entrata / uscita ----------
  var on = false;
  function enter(){
    on = true; place(); title();
    root.classList.add('anamode');
    root.classList.toggle('anafin', !!(A.state.finished || A.state.shown));
    helpReset(); moveNav(true); clock(true); pushHist(); relayout(); slide(1);
    // il messaggio dell'esercizio («Tocca a te»…) non vale più: benvenuto nell'analisi
    var f = $('feedback');
    if (f){ f.className = 'feedback info anaverdict'; f.innerHTML = '🔍 <b>Analisi libera</b> — muovi i pezzi di entrambi i colori: Stockfish giudica ogni mossa (!!, !, ?!, ?, ??). Con le frecce scorri le mosse.'; }
    try { document.activeElement && document.activeElement.blur && document.activeElement.blur(); } catch(e){}
  }
  function leave(){
    on = false;
    root.classList.remove('anamode', 'anafin');
    moveNav(false); popHist(); relayout();
  }
  document.addEventListener('cnp:analysis', function(ev){
    var d = ev.detail || {};
    if (d.on && !on) enter();
    else if (!d.on && on) leave();
  });
  // ritorno con stato ripristinato (app.js restoreStudy)
  document.addEventListener('cnp:study', function(){ clock(false); slide(-1); });
  // nuovo esercizio (anche dal menu capitoli durante l'analisi): il cronometro riparte da focus.js
  document.addEventListener('cnp:load', function(){ if (on && !A.state.analysis) leave(); });
  document.addEventListener('cnp:focus', function(){ if (on) place(); });

  function back(){ if (A.state.analysis && A.exitAnalysis) A.exitAnalysis(); }
  top.querySelector('#anaBack').addEventListener('click', function(){ back(); });

  // Esc torna all'esercizio, se non c'è un menu o una finestra aperta
  var escBusy = false;
  window.addEventListener('keydown', function(e){
    if (e.key !== 'Escape') return;
    escBusy = !!((window.UI && UI.modalOpen && UI.modalOpen()) || (window.DD && DD.isOpen && DD.isOpen()) ||
      ($('sidebar') && $('sidebar').classList.contains('open')) || ($('moreSheet') && !$('moreSheet').hidden) ||
      ($('fMenu') && !$('fMenu').hidden) || ($('settings') && !$('settings').hidden));
  }, true);
  window.addEventListener('keydown', function(e){
    if (e.key !== 'Escape' || escBusy || e.defaultPrevented || !A.state.analysis) return;
    e.preventDefault(); back();
  });

  place();
  window.__studio = {on:function(){ return on; }, back:back};
})();
