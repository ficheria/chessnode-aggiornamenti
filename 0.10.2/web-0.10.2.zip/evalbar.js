/* Barra di valutazione (stile Chess.com / Lichess) durante «Analizza».
   Caricato SOLO da index_moderna.html, dopo app.js: usa gli eventi 'cnp:analysis'
   emessi da runAnalysis() (stesso motore, nessun secondo Stockfish). */
(function(){
  'use strict';
  var A = window.__app; if (!A) return;
  var root = document.documentElement;

  // ---------- funzioni riutilizzabili (valutazione sempre dal punto di vista del Bianco) ----------
  // l = riga del motore {type:'cp'|'mate', v, depth}, riferita a chi muove nella posizione fen
  function toWhite(l, fen){
    if (!l) return null;
    var s = String(fen || '').split(' ')[1] === 'b' ? -1 : 1;
    return {type:l.type, v:l.v * s, depth:l.depth};
  }
  // percentuale di barra BIANCA (0..100)
  function pct(e){
    if (!e) return 50;
    if (e.type === 'mate') return e.v > 0 ? 100 : e.v < 0 ? 0 : 50;
    var x = 50 + 50 * (2 / (1 + Math.exp(-0.004 * e.v)) - 1);
    return Math.max(4, Math.min(96, x));
  }
  function label(e){
    if (!e) return '';
    if (e.type === 'mate') return 'M' + Math.abs(e.v);
    var a = Math.abs(e.v) / 100;
    return a >= 9.95 ? String(Math.round(a)) : a.toFixed(1);
  }
  function words(e){
    if (!e) return 'Valutazione in corso';
    if (e.type === 'mate') return (e.v > 0 ? 'Il Bianco' : 'Il Nero') + ' dà matto in ' + Math.abs(e.v);
    var a = (Math.abs(e.v) / 100).toFixed(1), who = e.v > 0 ? 'Bianco' : 'Nero';
    if (Math.abs(e.v) < 20) return 'Posizione pari (' + (e.v >= 0 ? '+' : '−') + a + ')';
    return 'Vantaggio ' + who + ': ' + (e.v > 0 ? '+' : '−') + a;
  }
  window.EvalUtil = {toWhite:toWhite, pct:pct, label:label, words:words};

  // ---------- la barra ----------
  var wrap = document.querySelector('.boardwrap'), board = document.getElementById('board');
  if (!wrap || !board) return;
  var bar = document.createElement('div');
  bar.id = 'evalBar'; bar.className = 'evalbar'; bar.setAttribute('role', 'img');
  bar.innerHTML = '<div class="eb-fill"></div><i class="eb-mid"></i><span class="eb-lbl"></span>';
  wrap.insertBefore(bar, board);
  var fill = bar.firstChild, lbl = bar.querySelector('.eb-lbl');
  var cur = null, lastPaint = 0, pendT = 0, shown = false;
  // la stessa quota serve alla barra verticale (altezza) e a quella orizzontale del telefono (--ebp = larghezza)
  function setH(v){ fill.style.height = v; bar.style.setProperty('--ebp', v); }

  function orient(){
    var fl = A.state.orient === 'b';
    bar.classList.toggle('flip', fl);
  }
  function paint(e, final){
    cur = e;
    var p = pct(e), whiteAdv = !e || e.v > 0 || (e.type === 'cp' && e.v === 0);
    if (e && e.type === 'mate' && e.v === 0) whiteAdv = true;
    setH(p.toFixed(2) + '%');
    var t = label(e);
    lbl.textContent = t;
    lbl.className = 'eb-lbl ' + (whiteAdv ? 'w' : 'b') + (t.length > 3 ? ' long' : '');
    bar.classList.toggle('mate', !!(e && e.type === 'mate'));
    bar.classList.toggle('thinking', !final);
    bar.setAttribute('aria-label', words(e));
    bar.title = words(e) + (e && e.depth ? ' · profondità ' + e.depth : '');
    bar.dataset.pct = p.toFixed(1); bar.dataset.label = t;
  }
  function show(on){
    if (on === shown) return;
    shown = on;
    root.classList.toggle('evalon', on);
    if (on){ orient(); if (!cur) paint(null, false); }
    else { cur = null; setH('50%'); lbl.textContent = ''; }
    // la scacchiera cambia grandezza: la modalità concentrazione e il ridimensionamento ricalcolano
    try { window.dispatchEvent(new Event('resize')); } catch(err){}
  }
  document.addEventListener('cnp:analysis', function(ev){
    var d = ev.detail || {};
    if (!d.on){ show(false); return; }
    show(true); orient();
    if (d.over){
      // posizione finale: matto (perde chi deve muovere) oppure patta
      var stm = String(d.fen || '').split(' ')[1];
      paint(d.mate ? {type:'mate', v:0, win:stm === 'w' ? 'b' : 'w'} : {type:'cp', v:0}, true);
      if (d.mate){
        var w = stm === 'b';
        setH(w ? '100%' : '0%');
        lbl.textContent = w ? '1-0' : '0-1'; lbl.className = 'eb-lbl long ' + (w ? 'w' : 'b');
        bar.dataset.pct = w ? '100' : '0'; bar.dataset.label = lbl.textContent;
        bar.title = 'Scacco matto: vince il ' + (w ? 'Bianco' : 'Nero'); bar.setAttribute('aria-label', bar.title);
      } else { lbl.textContent = '½'; bar.dataset.label = '½'; bar.title = 'Patta'; bar.setAttribute('aria-label', 'Patta'); }
      return;
    }
    if (d.line){
      var e = toWhite(d.line, d.fen);
      if (d.final){ clearTimeout(pendT); paint(e, true); return; }
      // aggiornamenti durante la ricerca: niente sobbalzi alle profondità basse, max ~6 al secondo
      if (e.depth < 6 && cur) return;
      var now = Date.now();
      if (now - lastPaint < 160){ clearTimeout(pendT); pendT = setTimeout(function(){ lastPaint = Date.now(); paint(e, false); }, 160); return; }
      lastPaint = now; paint(e, false);
    } else bar.classList.add('thinking');
  });
  // uscita dall'analisi passando a un altro esercizio
  document.addEventListener('cnp:load', function(){ if (!A.state.analysis) show(false); });
  // ruota scacchiera: la barra segue il lato del Bianco
  new MutationObserver(function(){ if (shown) orient(); }).observe(board, {childList:true});
})();
