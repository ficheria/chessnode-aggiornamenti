/* Chess Node · statistiche delle partite con i bot (anteprima 18b). Legge 'chessnodeplay-partite-bot-v1' scritto da bot.js.
   Voce: {bot, colore:'w'|'b', orologio:'no'|'10+0'|'15+10', esito:'v'|'p'|'s', motivo, data:'YYYY-MM-DD', semimosse, precisione:0-100|null}
   esempio(): partite INVENTATE solo per le immagini (?demo=1), sempre segnalate come «dati di esempio». */
(function(){
  'use strict';
  var KEY = 'chessnodeplay-partite-bot-v1';
  /* blocco 3 (11-11): livelli «stimato» dello schema 20f; 9 tempi nuovi; leggi() = SOLO partite normali (senza handicap e non di allenamento):
     quelle speciali stanno in statistiche separate (leggiSpeciali). */
  var BOTS = [['chessnote', 'Chess Node', '~900'], ['paola', 'Paola', '~1150'], ['nerd', 'Luca', '~1450'], ['serena', 'Nadia', '~1600'], ['maestro', 'Prof', '~1900']];
  var OROLOGI = [['no', 'Senza orologio', 'No clock'], ['1', '1', '1'], ['3', '3', '3'], ['3+2', '3+2', '3+2'], ['5', '5', '5'], ['5+2', '5+2', '5+2'], ['10', '10', '10'],
    ['10+5', '10+5', '10+5'], ['30', '30', '30'], ['10+0', '10+0', '10+0'], ['15+10', '15+10', '15+10']];
  function tutte(){ try { var a = JSON.parse(localStorage.getItem(KEY) || '[]'); return Array.isArray(a) ? a.filter(function(r){ return r && r.bot && /^[vps]$/.test(r.esito); }) : []; } catch(e){ return []; } }
  function leggi(){ return tutte().filter(function(r){ return !r.handicap && !r.allenamento; }); }
  function leggiSpeciali(){ return tutte().filter(function(r){ return r.handicap || r.allenamento; }); }
  function esempio(oggi){
    var out = [], seed = 7; function rnd(){ seed = (seed * 16807) % 2147483647; return seed / 2147483647; }
    var p = oggi.split('-'), base = new Date(+p[0], p[1] - 1, +p[2]);
    // [bot, partite, prob. vittoria col Bianco, col Nero, precisione media]
    [['chessnote', 8, .9, .8, 82], ['paola', 12, .7, .45, 76], ['nerd', 9, .55, .35, 71], ['serena', 5, .2, .1, 66], ['maestro', 3, .1, 0, 61]].forEach(function(b){
      for (var i = 0; i < b[1]; i++){
        var col = rnd() < .5 ? 'w' : 'b', pv = col === 'w' ? b[2] : b[3], r = rnd(), clk = ['no', 'no', '10+0', '15+10'][Math.floor(rnd() * 4)];
        var d = new Date(base.getTime() - Math.floor(rnd() * 30) * 864e5);
        out.push({bot:b[0], colore:col, orologio:clk, esito:r < pv ? 'v' : r < pv + .15 ? 'p' : 's', motivo:'matto',
          data:d.getFullYear() + '-' + ('0' + (d.getMonth() + 1)).slice(-2) + '-' + ('0' + d.getDate()).slice(-2), semimosse:40 + Math.floor(rnd() * 60),
          precisione:Math.max(30, Math.min(97, Math.round(b[4] + (rnd() - .5) * 16 + (col === 'w' ? 3 : -3) - (clk === '10+0' ? 4 : 0))))});
      }
    });
    out.sort(function(a, b){ return a.data < b.data ? -1 : a.data > b.data ? 1 : 0; });
    out.push({bot:'paola', colore:'w', orologio:'10+0', esito:'v', motivo:'matto', data:oggi, semimosse:57, precisione:84});   // l'ultima: rivincita con Paola
    return out;
  }
  function riassunto(list){
    var r = {n:list.length, v:0, p:0, s:0, prec:null, np:0};
    var sp = 0; list.forEach(function(g){ r[g.esito]++; if (typeof g.precisione === 'number'){ sp += g.precisione; r.np++; } });
    if (r.np) r.prec = Math.round(sp / r.np);
    r.punti = r.n ? Math.round((r.v + r.p / 2) / r.n * 100) : null;   // % punti fatti (vittoria 1, patta ½)
    return r;
  }
  function per(list, k, val){ return list.filter(function(g){ return g[k] === val; }); }
  window.CNBotStats = {KEY:KEY, BOTS:BOTS, OROLOGI:OROLOGI, leggi:leggi, leggiSpeciali:leggiSpeciali, esempio:esempio, riassunto:riassunto, per:per};
})();
