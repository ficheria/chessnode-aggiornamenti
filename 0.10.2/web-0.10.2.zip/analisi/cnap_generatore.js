/* Chess Node · Analisi profonda · FASE 4 · CNApGeneratore — nascita di un esercizio in cinque passi (A3-01), stati e checkpoint (A3-05),
   invalidazione e rivalidazione (A3-T09). Codice originale Chess Node (09/11/2026).
   Passi: 1 candidato (dall'analisi verificata) → 2 analisi locale → 3 verifica della soluzione (albero) → 4 tema, didattica, 9 controlli
   → 5 pubblicazione locale ATOMICA (esercizio approved + collocazioni nella stessa transazione).
   Stati: candidate → analysing → verifying → approved | rejected | ambiguous | lesson-candidate;
          approved → needs-revalidation → verifying → approved | rejected | ambiguous.  Un booleano «approved» anticipato è vietato.
   «Meglio 3 esercizi validi che 30 discutibili»: nessun numero minimo per partita, nessun riempitivo. */
(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api; else root.CNApGeneratore = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  var VERSIONE = 'cnap-generatore-1';
  var TRANSIZIONI = {
    candidate: ['analysing', 'rejected'],
    analysing: ['analysing', 'verifying', 'rejected', 'ambiguous', 'lesson-candidate', 'candidate'],
    verifying: ['approved', 'rejected', 'ambiguous', 'verifying', 'analysing'],
    approved: ['needs-revalidation'],
    'needs-revalidation': ['verifying', 'analysing'],
    rejected: ['analysing'], ambiguous: ['analysing'], 'lesson-candidate': ['analysing']
  };
  var GRAVITA = { blunder: 3, errore: 2, imprecisione: 1 };

  function crea(d) {
    var A = d.archivio, DB = d.db, So = d.soluzione, K = d.controlli, Chess = d.Chess, U = d.CNApUtil, Cap = d.CNApCapitoli;
    var ora = d.ora || function () { return Date.now(); };
    var biblioteca = d.biblioteca || null, capitoliPresenti = d.capitoliPresenti || null;
    var maxCandidati = d.maxCandidatiPerPartita || 8;
    function versioneRegole() { return [d.CNApControlli.REGOLE, d.CNApControlli.DIDATTICA, d.CNApSoluzione.VERSIONE, VERSIONE].join('|'); }
    function buildMotore() { var m = d.scheduler && d.scheduler.meta && d.scheduler.meta(); return m && m.build || null; }
    function errore(code, msg) { var e = new Error(msg); e.code = code; return e; }

    async function analisiDi(g) {
      if (!g.localAnalysisId) return null;
      var a = await A.tx(['analyses'], 'readonly', function (t) { return t.get('analyses', g.localAnalysisId); });
      return a && a.status === 'complete' ? a : null;
    }

    /* ---------- passo 1: candidati da una partita analizzata (solo mosse dell'UTENTE) ---------- */
    async function candidati(gameId) {
      var g = await A.partita(gameId); if (!g) throw errore('NON_TROVATA', 'Partita non trovata');
      var an = await analisiDi(g); if (!an) return { candidati: [], motivo: 'Partita senza analisi completa valida.' };
      if (!g.userColor) return { candidati: [], motivo: 'Colore dell\'utente sconosciuto.' };
      var nodi = {}; (await A.nodi(gameId)).forEach(function (n) { nodi[n.nodeId] = n; });
      var out = [], visti = {};
      (an.positionResults || []).forEach(function (pr, i) {
        if (pr.side !== g.userColor) return;
        var prima = nodi[pr.nodeIdBefore]; if (!prima) return;
        var li = pr.labelInfo || {}, kind = null, tipo = null;
        if ((pr.label === 'blunder' || pr.label === 'errore') && pr.verified !== false) { kind = 'errore'; tipo = 'tattica'; }
        else if (pr.label === 'geniale' && li.verificata !== false && pr.verified !== false) { kind = 'geniale'; tipo = 'ritrova'; }
        if (!kind) return;
        var prev = i > 0 ? an.positionResults[i - 1] : null;
        var c = { candidateId: 'C-' + U.hash(gameId + '|' + pr.nodeIdBefore + '|' + kind).slice(0, 12), gameId: gameId, nodeId: pr.nodeIdBefore, nodeIdDopo: pr.nodeId, ply: pr.ply - 1,
          startFen: prima.fen, solverColor: g.userColor, kind: kind, tipo: tipo, mossaOriginale: pr.played, mossaGeniale: kind === 'geniale' ? pr.played : null,
          label: pr.label, gravita: GRAVITA[pr.label] || 0, perdita: li.loss || 0, ultimaMossaAvversaria: prev ? prev.played : null, analysisId: an.analysisId, etichettaOrigine: { label: pr.label, verificata: pr.verified !== false && li.verificata !== false } };
        if (visti[c.candidateId]) return; visti[c.candidateId] = 1; out.push(c);
      });
      // occasioni tematiche mancate già sullo stesso nodo: diventano motivo aggiuntivo, non un secondo candidato
      ((an.themes && an.themes.occasioni) || []).forEach(function (o) { if (o.lato === g.userColor && o.esito === 'mancato') out.forEach(function (c) { if (c.nodeId === o.nodeId) (c.occasioni = c.occasioni || []).push(o.tema); }); });
      out.sort(function (a, b) { return (b.gravita - a.gravita) || (b.perdita - a.perdita) || (a.ply - b.ply); });
      return { candidati: out.slice(0, maxCandidati), scartatiPerLimite: Math.max(0, out.length - maxCandidati), analysisId: an.analysisId };
    }

    function exerciseIdDi(c) { return 'P-' + U.hash(c.gameId + '|' + c.nodeId + '|' + c.kind).slice(0, 12); }
    async function leggi(id) { return DB.tx(['exercises'], 'readonly', function (t) { return t.get('exercises', id); }); }
    async function scrivi(ex, nuovoStato, motivo, extra) {
      if (nuovoStato && ex.validationStatus !== nuovoStato) {
        var ok = (TRANSIZIONI[ex.validationStatus] || []).indexOf(nuovoStato) >= 0;
        if (!ok) throw errore('TRANSIZIONE', 'Transizione vietata ' + ex.validationStatus + ' → ' + nuovoStato);
        (ex.history = ex.history || []).push({ da: ex.validationStatus, a: nuovoStato, at: ora(), motivo: motivo || null });
        ex.validationStatus = nuovoStato;
      }
      ex.updatedAt = ora();
      await DB.tx(['exercises'].concat(extra ? ['placements'] : []), 'readwrite', async function (t) {
        await t.put('exercises', ex);
        if (extra) for (var i = 0; i < extra.length; i++) await t.put('placements', extra[i]);
      });
      return ex;
    }

    /* ---------- passi 2–5 per UN candidato; riprende dal checkpoint se interrotto ---------- */
    async function elabora(c, o) {
      o = o || {};
      var id = exerciseIdDi(c), ex = await leggi(id);
      if (ex && ex.validationStatus === 'approved' && ex.validationVersion === versioneRegole() && (!buildMotore() || ex.engineMetadata.build === buildMotore())) return ex;   // idempotente
      if (ex && ex.validationStatus === 'approved') { ex.invalidationReason = ex.invalidationReason || 'versione cambiata'; await scrivi(ex, 'needs-revalidation', ex.invalidationReason); }
      if (ex && /^(rejected|ambiguous|lesson-candidate)$/.test(ex.validationStatus) && !o.riprova && ex.validationVersion === versioneRegole()) return ex;   // non riappare come approvato dopo un riavvio
      if (!ex) {
        ex = { schemaVersion: 1, exerciseId: id, sourceType: 'personale', sourceGameId: c.gameId, sourcePly: c.ply, sourceNodeId: c.nodeId, sourceMoveNodeId: c.nodeIdDopo,
          candidateKind: c.kind, originalMove: c.mossaOriginale, startFen: c.startFen, solverColor: c.solverColor, exerciseType: null, objective: null, acceptedMoves: [], solutionTree: null,
          themeTags: [], difficultyEstimate: null, validationStatus: 'candidate', engineMetadata: null, validationVersion: versioneRegole(), solutionVersion: 0, contentRevision: 1,
          qualityChecks: [], didacticCheck: { status: 'unknown', reason: 'Posizione non ancora analizzata' }, explanation: null, invalidationReason: null, rejectionCode: null,
          posKey: null, sourceRefs: [{ analysisId: c.analysisId, gameId: c.gameId, nodeId: c.nodeId }], createdAt: ora(), history: [], pipeline: { step: 1, candidato: c } };
        await scrivi(ex, null);
      }
      // passo 2 e 3: verifica (il checkpoint è il risultato completo; un'interruzione la ripete da capo, idempotente)
      if (ex.validationStatus !== 'verifying') {
        if (ex.validationStatus !== 'analysing') await scrivi(ex, 'analysing', 'analisi locale');
        ex.pipeline.step = 2;
        var cand = Object.assign({}, c, { tipo: c.tipo });
        var v = await So.verifica(cand, { versione: versioneRegole() });
        if (v.esito === 'lesson-candidate' && c.kind === 'errore') {   // nessun guadagno concreto: forse era una DIFESA mancata (V1: semplice)
          var vd = await So.verifica(Object.assign({}, cand, { tipo: 'difesa' }), { versione: versioneRegole() });
          if (vd.esito !== 'scartato' || vd.codice !== 'no-threat') { v = vd; cand.tipo = 'difesa'; }
        }
        ex.pipeline.verifica = { esito: v.esito, codice: v.codice, motivo: v.motivo, ricerche: v.ricerche, tipo: cand.tipo };
        if (v.esito === 'pending') { ex.pipeline.step = 2; await scrivi(ex, 'analysing', 'in attesa: ' + v.motivo); return ex; }   // resta pendente con checkpoint
        if (v.esito === 'lesson-candidate') { ex.rejectionCode = v.codice; ex.evidence = v.evidenze; await scrivi(ex, 'lesson-candidate', v.motivo); return ex; }
        if (v.esito === 'scartato') { ex.rejectionCode = v.codice; ex.evidence = v.evidenze; await scrivi(ex, 'rejected', v.motivo); return ex; }
        if (v.esito === 'ambiguo') { ex.rejectionCode = v.codice; ex.evidence = v.evidenze; ex.solutionTree = v.albero || null; await scrivi(ex, 'ambiguous', v.motivo); return ex; }
        // costruzione dell'esercizio dal risultato verificato
        var precAccettate = (ex.acceptedMoves || []).slice().sort().join(',');
        ex.exerciseType = cand.tipo === 'difesa' ? 'difesa' : cand.tipo === 'ritrova' ? 'ritrova' : v.obiettivo.tipo === 'matto' ? 'matto' : 'tattica';
        ex.objective = v.obiettivo; ex.solutionTree = v.albero; ex.evidence = v.evidenze; ex.engineMetadata = v.engineMetadata; ex.certification = v.certificazione || null; ex.threat = v.minaccia || null;
        ex.acceptedMoves = v.albero.nodes.filter(function (n) { return n.id === v.albero.rootId; })[0].acceptedMoves.map(function (a) { return a.uci; });
        var nuove = ex.acceptedMoves.slice().sort().join(',');
        if (ex.solutionVersion === 0 || nuove !== precAccettate) { ex.solutionVersion++; ex.explanation = null; }   // la spiegazione segue la versione della soluzione
        ex.posKey = U.hash(d.CNApControlli.fen4(ex.startFen) + '|' + ex.objective.tipo);
        ex.validationVersion = versioneRegole();
        ex.pipeline.step = 3;
        await scrivi(ex, 'verifying', 'albero verificato: controlli');
      }
      // passo 4: tema, difficoltà, spiegazione, nove controlli, filtro didattico
      ex.pipeline.step = 4;
      var tm = K.assegnaTemi(ex); ex.themeTags = tm.themeTags; ex.themeEvidence = tm.themeEvidence;
      ex.difficultyEstimate = K.difficolta(ex);
      if (!ex.explanation || ex.explanation.solutionVersion !== ex.solutionVersion) ex.explanation = K.spiegazione(ex);
      ex.consegna = K.consegna(ex);
      var g = await A.partita(ex.sourceGameId);
      ex.qualityChecks = await K.esegui(ex, { archivio: A, userColor: g && g.userColor, biblioteca: biblioteca, etichettaOrigine: c.etichettaOrigine,
        esercizi: async function (pk) { return DB.tx(['exercises'], 'readonly', function (t) { return t.byIndex('exercises', 'posKey', pk); }); } });
      ex.didacticCheck = K.filtroDidattico(ex, { ultimaMossaAvversaria: c.ultimaMossaAvversaria });
      ex.qualityRevision = ex.contentRevision + '.' + ex.solutionVersion;
      var fail = ex.qualityChecks.filter(function (q) { return q.status === 'fail'; }), unk = ex.qualityChecks.filter(function (q) { return q.status === 'unknown'; });
      if (fail.length) { ex.rejectionCode = codiceDa(fail[0]); await scrivi(ex, 'rejected', 'Controllo ' + fail[0].n + ' non superato: ' + fail[0].reason); return ex; }
      if (unk.length) { ex.rejectionCode = 'unknown-' + unk[0].n; await scrivi(ex, 'ambiguous', 'Controllo ' + unk[0].n + ' senza prova sufficiente: ' + unk[0].reason); return ex; }
      if (ex.didacticCheck.status !== 'pass') { ex.rejectionCode = 'didactic'; await scrivi(ex, 'rejected', 'Filtro didattico: ' + ex.didacticCheck.reason); return ex; }
      // passo 5: pubblicazione locale atomica (versioni correnti + collocazioni)
      if (ex.validationVersion !== versioneRegole()) { await scrivi(ex, 'verifying', 'versione cambiata durante la verifica'); return ex; }
      ex._inApprovazione = true;
      var pl = [{ placementId: 'PL-' + ex.exerciseId + '-personale', exerciseId: ex.exerciseId, kind: 'personal' }].concat(Cap.collocazioni(ex, capitoliPresenti));
      delete ex._inApprovazione;
      ex.pipeline.step = 5; ex.rejectionCode = null; ex.invalidationReason = null; ex.approvedAt = ora();
      await scrivi(ex, 'approved', '9 controlli pass + filtro didattico pass (revisione ' + ex.qualityRevision + ')', pl);
      return ex;
    }
    function codiceDa(q) { return ({ 1: 'unreachable', 2: 'wrong-side', 3: 'illegal', 4: 'alternatives', 5: 'insufficient-defence-coverage', 6: 'promise-not-kept', 7: 'no-theme', 8: 'explanation', 9: 'duplicate' })[q.n]; }

    /* genera per una partita: elabora i candidati in ordine di gravità; ritorna il riepilogo per uscita */
    async function genera(gameId, o) {
      o = o || {};
      var cs = await candidati(gameId), out = { gameId: gameId, candidati: cs.candidati.length, esiti: {}, esercizi: [] };
      for (var i = 0; i < cs.candidati.length; i++) {
        if (o.segnale && (o.segnale.fermo || o.segnale.aborted)) { out.interrotto = true; break; }
        var ex = await elabora(cs.candidati[i], o);
        out.esiti[ex.validationStatus] = (out.esiti[ex.validationStatus] || 0) + 1;
        out.esercizi.push({ exerciseId: ex.exerciseId, stato: ex.validationStatus, codice: ex.rejectionCode, tipo: ex.exerciseType });
      }
      return out;
    }
    /* ripresa dopo riavvio: chi era a metà riparte dal proprio checkpoint, nessuno salta «verifying» */
    async function riprendi(o) {
      var tutti = await DB.tx(['exercises'], 'readonly', function (t) { return t.all('exercises'); }), fatti = [];
      for (var i = 0; i < tutti.length; i++) { var e = tutti[i]; if (/^(candidate|analysing|verifying)$/.test(e.validationStatus)) fatti.push(await elabora(e.pipeline.candidato, o)); }
      return fatti;
    }
    /* nuova versione motore/regole: approved → needs-revalidation (le collocazioni mostrano solo approved correnti) */
    async function invalidaObsoleti(motivo) {
      var tutti = await DB.tx(['exercises'], 'readonly', function (t) { return t.all('exercises'); }), n = 0, vr = versioneRegole(), b = buildMotore();
      for (var i = 0; i < tutti.length; i++) {
        var e = tutti[i]; if (e.validationStatus !== 'approved') continue;
        var vecchio = e.validationVersion !== vr || (b && e.engineMetadata && e.engineMetadata.build && e.engineMetadata.build !== b);
        if (!vecchio && !motivo) continue;
        e.invalidationReason = motivo || (e.validationVersion !== vr ? 'regole cambiate' : 'motore cambiato'); await scrivi(e, 'needs-revalidation', e.invalidationReason); n++;
      }
      return n;
    }
    async function rivalida(exerciseId) { var e = await leggi(exerciseId); if (!e) return null; return elabora(e.pipeline.candidato, { riprova: true }); }
    /* alternativa trovata dal giocatore e risultata equivalente: l'esercizio torna in verifica (estensione dell'albero) */
    async function segnalaAlternativa(exerciseId, info) {
      var e = await leggi(exerciseId); if (!e || e.validationStatus !== 'approved') return e;
      (e.alternativeSegnalate = e.alternativeSegnalate || []).push(Object.assign({ at: ora() }, info));
      e.invalidationReason = 'alternativa equivalente trovata in allenamento: ' + info.uci;
      return scrivi(e, 'needs-revalidation', e.invalidationReason);
    }

    return { candidati: candidati, elabora: elabora, genera: genera, riprendi: riprendi, invalidaObsoleti: invalidaObsoleti, rivalida: rivalida, segnalaAlternativa: segnalaAlternativa,
      versioneRegole: versioneRegole, exerciseIdDi: exerciseIdDi, TRANSIZIONI: TRANSIZIONI };
  }
  return { crea: crea, VERSIONE: VERSIONE, TRANSIZIONI: TRANSIZIONI };
});
