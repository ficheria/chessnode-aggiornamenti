/* Chess Node · Analisi profonda · FASE 1 · CNApImport — passi 1–2 della pipeline (A1-01): sorgente grezza → partita
   normalizzata (contratto Game/Node) oppure diagnostica. Solo calcolo puro ("staging"): nessuna scrittura in archivio.
   Codice originale Chess Node (08/11/2026). Dipendenze iniettate: CNApPgn (già creato), CNApFen, CNApUtil.
   Regole chiave: risultato «*»/assente = sconosciuto (mai patta); conflitto = segnalato, mai sovrascritto; colore dell'utente
   controllato su ENTRAMBI i lati (altrimenti sconosciuto); precisione esterna ≠ analisi locale; varianti non standard escluse. */
(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api; else root.CNApImport = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  var SCHEMA = 1, VALIDAZIONE = 'cnap-rules-1';

  function crea(d) {
    var Pgn = d.CNApPgn, Fen = d.CNApFen, U = d.CNApUtil;
    if (!Pgn || !Fen || !U) throw new Error('CNApImport: servono CNApPgn (istanza), CNApFen, CNApUtil');

    /* ---------- identità forte dal PGN (file scaricati dai siti): Site/Link ---------- */
    function idForteDaHeader(H) {
      var site = H.Site || '', link = H.Link || '', m;
      if ((m = /^https?:\/\/(?:www\.)?lichess\.org\/([A-Za-z0-9]{8})(?:[A-Za-z0-9]{4})?(?:[\/?#].*)?$/.exec(site))) return { source: 'lichess', sourceId: m[1] };
      if ((m = /chess\.com\/(?:game\/)?(live|daily)\/(?:game\/)?(\d+)/.exec(link || site))) return { source: 'chesscom', sourceId: m[1] + '/' + m[2] };
      return null;
    }
    function idChesscomDaUrl(url) { var m = /chess\.com\/(?:game\/)?(live|daily)\/(?:game\/)?(\d+)/.exec(url || ''); return m ? m[1] + '/' + m[2] : null; }

    /* ---------- ritmo (Lichess: tempo stimato = base + 40 × incremento) ---------- */
    function ritmoDaTimeControl(tc) {
      if (!tc || tc === '?') return null;
      if (tc === '-' || /^1\/\d+$/.test(tc)) return 'daily';
      var m = /^(\d+)(?:\+(\d+))?$/.exec(tc); if (!m) return null;
      var t = +m[1] + 40 * (+m[2] || 0);
      return t < 30 ? 'ultrabullet' : t < 180 ? 'bullet' : t < 480 ? 'blitz' : t < 1500 ? 'rapid' : 'classical';
    }

    /* ---------- data: mai inventare un orario da una sola data ---------- */
    function dataDaHeader(H) {
      var dU = H.UTCDate, tU = H.UTCTime;
      if (dU && /^\d{4}\.\d\d\.\d\d$/.test(dU) && tU && /^\d\d:\d\d:\d\d$/.test(tU)) {
        var ms = Date.UTC(+dU.slice(0, 4), +dU.slice(5, 7) - 1, +dU.slice(8, 10), +tU.slice(0, 2), +tU.slice(3, 5), +tU.slice(6, 8));
        return { ms: ms, precisione: 'secondo', fonte: 'UTCDate+UTCTime' };
      }
      var dd = dU || H.Date;
      if (dd && /^\d{4}\.\d\d\.\d\d$/.test(dd)) return { ms: null, giorno: dd.replace(/\./g, '-'), precisione: 'giorno', fonte: dU ? 'UTCDate' : 'Date' };
      if (dd && /^\d{4}\.\d\d\.\?\?$/.test(dd)) return { ms: null, giorno: null, mese: dd.slice(0, 7).replace('.', '-'), precisione: 'mese', fonte: 'Date' };
      if (dd && /^\d{4}\./.test(dd)) return { ms: null, giorno: null, precisione: 'anno', anno: dd.slice(0, 4), fonte: 'Date' };
      return { ms: null, precisione: null, fonte: null };
    }

    /* ---------- risultato (A1-02 §6.3) ---------- */
    function riconciliaRisultato(g, servizio) {
      var fonti = {}, valori = [];
      if (g.risultatoHeader != null) fonti.header = g.risultatoHeader;
      if (g.terminatore != null) fonti.terminatore = g.terminatore;
      if (servizio && servizio.result !== undefined) fonti.servizio = servizio.result === null ? '*' : servizio.result;
      Object.keys(fonti).forEach(function (k) { var v = fonti[k]; if (v && v !== '*' && valori.indexOf(v) < 0) valori.push(v); });
      var esito = g.esitoScacchiera, conflitto = [];
      if (valori.length > 1) conflitto.push('Le fonti dichiarano risultati diversi: ' + Object.keys(fonti).map(function (k) { return k + ' ' + fonti[k]; }).join(', ') + '.');
      if (valori.length === 1 && esito) {
        var v = valori[0];
        if (esito.tipo === 'matto' && v !== (esito.vincitore === 'w' ? '1-0' : '0-1')) conflitto.push('Sulla scacchiera c\'è scacco matto ma il risultato dichiarato è ' + v + '.');
        if (esito.tipo === 'stallo' && v !== '1/2-1/2') conflitto.push('Sulla scacchiera c\'è stallo ma il risultato dichiarato è ' + v + '.');
      }
      if (conflitto.length) return { result: '*', resultStatus: 'conflitto', resultSources: fonti, note: conflitto };
      if (!valori.length) return { result: '*', resultStatus: 'sconosciuto', resultSources: fonti, note: esito && esito.tipo === 'matto' ? ['Risultato non dichiarato; sulla scacchiera c\'è matto (non usato per riempire il risultato).'] : [] };
      return { result: valori[0], resultStatus: 'dichiarato', resultSources: fonti, note: [] };
    }

    /* ---------- colore dell'utente: entrambi i lati, confronto senza maiuscole ---------- */
    function coloreUtente(players, identita) {
      var ids = (identita || []).map(function (x) { return String(x).trim().toLowerCase(); }).filter(Boolean);
      if (!ids.length) return { userColor: null, stato: 'nessuna_identita' };
      var w = players.w && players.w.name ? players.w.name.trim().toLowerCase() : null, b = players.b && players.b.name ? players.b.name.trim().toLowerCase() : null;
      var iw = w != null && ids.indexOf(w) >= 0, ib = b != null && ids.indexOf(b) >= 0;
      if (iw && ib) return { userColor: null, stato: 'ambiguo' };
      if (iw) return { userColor: 'w', stato: 'identificato' };
      if (ib) return { userColor: 'b', stato: 'identificato' };
      return { userColor: null, stato: 'non_presente' };
    }
    function numero(v) { return v != null && v !== '' && v !== '?' && isFinite(+v) ? +v : null; }

    /* ---------- nodi d'archivio: nodeId = gameId:chiave (chiavi stabili del parser) ---------- */
    function nodiArchivio(gameId, g) {
      return g.ordineNodi.map(function (k) {
        var n = g.nodi[k];
        return {
          schemaVersion: SCHEMA, nodeId: gameId + ':' + k, gameId: gameId, parentId: n.parentKey ? gameId + ':' + n.parentKey : null,
          childIds: n.childKeys.map(function (c) { return gameId + ':' + c; }), ply: n.ply, san: n.san, uci: n.uci, fen: n.fen,
          mainLine: n.mainLine, origin: n.key === 'n0' ? 'root' : n.mainLine ? 'played' : 'pgn-variation', savedByUser: true,
          pgnCommentsBefore: n.commentsBefore || [], pgnCommentsAfter: n.commentsAfter || [], nags: n.nags || [],
          sanOriginale: n.sanOriginale || null, commentIds: [], evaluationIds: []
        };
      });
    }

    /* sorgente = {source:'file'|'lichess'|'chesscom'|'interna', sourceId?, publicUrl?, rawPgn, fetchedAt, fileName?, service?, scope, identita[]}
       ritorna {partite:[{game, nodes, sourceRef}], diagnostiche:[...], erroreFile} */
    function prepara(src, o) {
      o = o || {};
      var testo = src.rawPgn, letto = Pgn.leggi(testo), out = { partite: [], diagnostiche: [], erroreFile: letto.errore || null };
      var ora = o.ora != null ? o.ora : Date.now(), batchId = o.batchId || ('B-' + U.hash(String(ora) + (src.fileName || src.source)));
      letto.partite.forEach(function (g, idx) {
        var multi = letto.partite.length > 1;
        if (g.stato !== 'valida') {
          out.diagnostiche.push({
            schemaVersion: SCHEMA, diagId: 'D-' + U.hash(batchId + '|' + idx + '|' + g.rawHash), batchId: batchId, source: src.source, fileName: src.fileName || null,
            indice: idx + 1, riga: g.riga, stato: g.stato, variante: g.variante, rawPgn: g.raw, rawHash: g.rawHash, createdAt: ora,
            headers: g.headers, messaggi: g.diagnostica
          });
          return;
        }
        var H = g.headers, svc = src.service || null;
        // identità forte
        var forte = null;
        if (src.source === 'lichess' || src.source === 'chesscom') forte = { source: src.source, sourceId: src.sourceId };
        else if (src.source === 'interna' && src.sourceId) forte = { source: 'interna', sourceId: src.sourceId };
        var daHeader = idForteDaHeader(H);
        if (!forte && daHeader) forte = daHeader;
        var gameId = forte ? 'G-' + U.hash(forte.source + ':' + forte.sourceId) : 'G-' + U.hash('file:' + g.rawHash);
        // giocatori
        var players = {
          w: { name: (svc && svc.players && svc.players.w && svc.players.w.name) || (H.White && H.White !== '?' ? H.White : null), rating: svc && svc.players && svc.players.w && svc.players.w.rating != null ? svc.players.w.rating : numero(H.WhiteElo) },
          b: { name: (svc && svc.players && svc.players.b && svc.players.b.name) || (H.Black && H.Black !== '?' ? H.Black : null), rating: svc && svc.players && svc.players.b && svc.players.b.rating != null ? svc.players.b.rating : numero(H.BlackElo) }
        };
        var col = coloreUtente(players, src.identita);
        // data
        var data = svc && svc.playedAtMs ? { ms: svc.playedAtMs, precisione: 'secondo', fonte: 'servizio-' + (svc.timeKind || 'orario') } : dataDaHeader(H);
        var playedAt = data.ms != null ? U.isoRoma(data.ms) : null;
        var mese = data.ms != null ? U.meseRoma(data.ms) : data.giorno ? data.giorno.slice(0, 7) : data.mese || null;
        // ritmo
        var tc = (svc && svc.timeControl) || H.TimeControl || null;
        var ritmo = svc && svc.timeClass ? { timeClass: svc.timeClass, fonte: 'servizio' } : (ritmoDaTimeControl(tc) ? { timeClass: ritmoDaTimeControl(tc), fonte: 'stima-da-TimeControl' } : { timeClass: null, fonte: null });
        var ris = riconciliaRisultato(g, svc);
        var apertura = null;
        if (svc && svc.opening && svc.opening.name) apertura = { name: svc.opening.name, eco: svc.opening.eco || null, fonte: src.source, certezza: 'dichiarata-dal-servizio' };
        else if (H.Opening) apertura = { name: H.Opening, eco: H.ECO || null, fonte: 'intestazione-pgn', certezza: 'dichiarata-nel-file' };
        var acc = svc && svc.accuracy && (svc.accuracy.w != null || svc.accuracy.b != null) ? { source: src.source, w: svc.accuracy.w != null ? svc.accuracy.w : null, b: svc.accuracy.b != null ? svc.accuracy.b : null, nota: 'Precisione calcolata dal servizio: non è un\'analisi locale e non si media con le stime Chess Node.' } : null;
        var plies = g.mainLineUci.length;
        var contentKey = U.hash('standard|' + g.startFen + '|' + g.mainLineUci.join(' '));
        var dataIncontro = data.ms != null ? U.dataRoma(data.ms) : data.giorno || null;
        var sourceKey = forte ? forte.source + ':' + forte.sourceId : 'file:' + g.rawHash;
        var revisione = U.hash(g.raw + '|' + U.canon(svc || null));
        var game = {
          schemaVersion: SCHEMA, gameId: gameId,
          sourceRefs: [{ sourceKey: sourceKey, source: forte ? forte.source : src.source, sourceId: forte ? forte.sourceId : g.rawHash, publicUrl: src.publicUrl || (forte && forte.source === 'lichess' ? 'https://lichess.org/' + forte.sourceId : (H.Link || null)) }],
          scopeRefs: [src.scope || 'self'], variant: ((svc && svc.variant === 'fromPosition') || g.startStandard === false) ? 'fromPosition' : 'standard',
          playedAt: playedAt, playedAtMs: data.ms, datePrecision: data.precisione, dateSource: data.fonte, playedDate: dataIncontro, monthRome: mese,
          timeClass: ritmo.timeClass, timeClassSource: ritmo.fonte, timeControl: tc, rated: svc && svc.rated != null ? !!svc.rated : null,
          userColor: col.userColor, userColorState: col.stato, players: players,
          result: ris.result, resultStatus: ris.resultStatus, resultSources: ris.resultSources, resultNotes: ris.note,
          termination: (svc && svc.status) || H.Termination || 'unknown', boardOutcome: g.esitoScacchiera,
          startFen: g.startFen, rawPgn: g.raw, rawHash: g.rawHash, headers: H, headerOrder: g.ordineHeaders, terminator: g.terminatore,
          mainLineUci: g.mainLineUci, mainLineSan: g.mainLineSan, plies: plies, fullMoves: Math.ceil((plies + (Fen.tratto(g.startFen) === 'b' ? 1 : 0)) / 2),
          rootNodeId: gameId + ':n0', modelComplete: g.completo,
          reachability: g.startStandard ? 'replayed-from-standard' : 'unknown',
          archiveState: 'in attesa', opening: apertura, externalAccuracy: acc, localAnalysisId: null,
          contentKey: contentKey, meetingKey: U.hash([players.w.name || '', players.b.name || ''].map(function (x) { return x.toLowerCase(); }).join('|') + '|' + (dataIncontro || '')),
          importWarnings: g.diagnostica.filter(function (x) { return x.livello === 'warning'; }),
          sampling: null, private: !!src.private, createdAt: ora, updatedAt: ora, validationVersion: VALIDAZIONE
        };
        var sourceRec = {
          schemaVersion: SCHEMA, sourceRevKey: sourceKey + '#' + revisione, sourceKey: sourceKey, gameId: gameId, source: game.sourceRefs[0].source, sourceId: game.sourceRefs[0].sourceId,
          publicUrl: game.sourceRefs[0].publicUrl, rawPgn: g.raw, rawHash: g.rawHash, service: svc, fileName: src.fileName || null, indiceNelFile: multi ? idx + 1 : null,
          fetchedAt: src.fetchedAt || ora, revision: revisione, strong: !!forte
        };
        out.partite.push({ game: game, nodes: nodiArchivio(gameId, g), source: sourceRec });
      });
      return out;
    }

    return { prepara: prepara, coloreUtente: coloreUtente, riconciliaRisultato: riconciliaRisultato, ritmoDaTimeControl: ritmoDaTimeControl, idForteDaHeader: idForteDaHeader, idChesscomDaUrl: idChesscomDaUrl, SCHEMA: SCHEMA, VALIDAZIONE: VALIDAZIONE };
  }
  return { crea: crea, VERSIONE: 'cnap-import-1' };
});
