/* Chess Node · Analisi profonda · FASE 1 · CNApRete — rete pubblica controllata (A1-03, A1-C02, regola maestro §3.3–3.4).
   Codice originale Chess Node (08/11/2026). fetch iniettato (web: fetch del browser; Android: adattatore CapacitorHttp qui sotto).
   - SOLO GET verso gli endpoint pubblici elencati nella specifica (lista positiva). Qualsiasi altro URL — compreso cloud-eval di
     Lichess — viene rifiutato PRIMA di partire: nessuna FEN, PGN, profilo o tentativo esce dal dispositivo da questo modulo.
   - Nessuna credenziale, nessun cookie, nessun token: l'unica intestazione è Accept (nessun preflight CORS).
   - Una richiesta alla volta; timeout; annullamento; 429 con Retry-After (o 60 s prudenti) e messaggio «Il servizio chiede una
     pausa»; tentativi limitati; risposta HTML/JSON inatteso = errore, mai successo.
   - NDJSON letto in streaming quando il body è leggibile, riga per riga, ogni riga convalidata; flusso interrotto = «troncato». */
(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api; else root.CNApRete = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  /* Lista positiva: host + prefisso di percorso. Tutto il resto è vietato. */
  var CONSENTITI = [
    { host: 'lichess.org', re: /^\/api\/user\/[^\/?#]+(\/rating-history)?$/ },
    { host: 'lichess.org', re: /^\/api\/games\/user\/[^\/?#]+$/ },
    { host: 'api.chess.com', re: /^\/pub\/player\/[^\/?#]+(\/stats|\/games\/archives|\/games\/\d{4}\/\d{2})?$/ }
  ];
  function consentito(url) {
    var m = /^https:\/\/([^\/?#:]+)(\/[^?#]*)?(\?[^#]*)?$/.exec(String(url || ''));
    if (!m) return false;
    var host = m[1].toLowerCase(), path = m[2] || '/';
    return CONSENTITI.some(function (c) { return c.host === host && c.re.test(path); });
  }

  function err(code, msg, extra) { var e = new Error(msg); e.code = code; if (extra) Object.keys(extra).forEach(function (k) { e[k] = extra[k]; }); return e; }

  function crea(d) {
    var f = d.fetch, ora = d.ora || function () { return Date.now(); };
    if (typeof f !== 'function') throw new Error('CNApRete: serve una funzione fetch');
    var TIMEOUT = d.timeoutMs || 30000, MAX_T = d.maxTentativi || 3, ATTESA_429 = d.attesa429Ms || 60000;
    var registro = [];   // ogni richiesta effettiva (solo URL pubblici): serve alla prova «nessun dato inviato» (A1-T16)
    var attendi = d.attendi || function (ms, segnale) {
      return new Promise(function (res, rej) {
        if (segnale && segnale.aborted) return rej(err('ANNULLATO', 'Operazione annullata.'));
        var t = setTimeout(function () { if (segnale) segnale.removeEventListener('abort', ab); res(); }, ms);
        function ab() { clearTimeout(t); rej(err('ANNULLATO', 'Operazione annullata.')); }
        if (segnale) segnale.addEventListener('abort', ab, { once: true });
      });
    };
    var catena = Promise.resolve();
    function inCoda(fn) { var p = catena.then(fn, fn); catena = p.catch(function () {}); return p; }

    function retryAfterMs(h) {
      var v = h && (typeof h.get === 'function' ? h.get('retry-after') : (h['retry-after'] || h['Retry-After']));
      if (v == null || v === '') return null;
      if (/^\d+$/.test(String(v).trim())) return Math.min(600, +v) * 1000;
      var t = Date.parse(v); return isNaN(t) ? null : Math.max(0, Math.min(600000, t - ora()));
    }

    async function una(url, o) {
      var ctl = typeof AbortController !== 'undefined' ? new AbortController() : null, scaduto = false;
      var timer = setTimeout(function () { scaduto = true; if (ctl) ctl.abort(); }, o.timeoutMs || TIMEOUT);
      var esterno = o.segnale, ab = function () { if (ctl) ctl.abort(); };
      if (esterno) { if (esterno.aborted) { clearTimeout(timer); throw err('ANNULLATO', 'Operazione annullata.'); } esterno.addEventListener('abort', ab, { once: true }); }
      registro.push({ url: url, metodo: 'GET', quando: ora() });
      try {
        var r = await f(url, { method: 'GET', headers: { Accept: o.accept || 'application/json' }, signal: ctl ? ctl.signal : undefined, credentials: 'omit', redirect: 'follow' });   // solo Accept: niente intestazioni che forzino il preflight CORS, niente credenziali
        if (r && r.url && !consentito(r.url.split('#')[0])) throw err('URL_NON_CONSENTITO', 'Il servizio ha reindirizzato fuori dagli endpoint ammessi.');
        return { r: r, chiudi: function () { clearTimeout(timer); if (esterno) esterno.removeEventListener('abort', ab); } };
      } catch (e) {
        clearTimeout(timer); if (esterno) esterno.removeEventListener('abort', ab);
        if (e && e.code === 'URL_NON_CONSENTITO') throw e;
        if (esterno && esterno.aborted) throw err('ANNULLATO', 'Operazione annullata.');
        if (scaduto) throw err('TIMEOUT', 'Il servizio non risponde (tempo scaduto).');
        throw err('RETE', 'Connessione assente o interrotta. Le partite salvate sono disponibili; l\'importazione dal sito richiede connessione.', { causa: String(e && e.message || e) });
      }
    }

    /* richiesta GET con politica comune; o = {accept, segnale, onAttesa, timeoutMs, ndjson, onRiga} */
    function richiesta(url, o) {
      o = o || {};
      if (!consentito(url)) return Promise.reject(err('URL_NON_CONSENTITO', 'Richiesta bloccata: «' + url + '» non è un endpoint pubblico ammesso.'));
      return inCoda(async function () {
        for (var tent = 1; ; tent++) {
          var u = await una(url, o), r = u.r;
          try {
            if (r.status === 429) {
              var ms = retryAfterMs(r.headers) || ATTESA_429;
              if (tent >= MAX_T) throw err('RATE', 'Il servizio chiede una pausa: riprova tra qualche minuto.', { attesaMs: ms });
              if (o.onAttesa) o.onAttesa({ ms: ms, messaggio: 'Il servizio chiede una pausa (' + Math.round(ms / 1000) + ' s).' });
              u.chiudi(); await attendi(ms, o.segnale); continue;
            }
            if (r.status === 404) throw err('NON_TROVATO', 'Account o risorsa non trovati (404).', { status: 404 });
            if (r.status === 401 || r.status === 403 || r.status === 410) throw err('NON_PUBBLICO', 'Dati non pubblici o non disponibili (' + r.status + ').', { status: r.status });
            if (r.status >= 500) {
              if (tent >= MAX_T) throw err('HTTP', 'Errore del servizio (' + r.status + ').', { status: r.status });
              u.chiudi(); await attendi(2000 * tent, o.segnale); continue;
            }
            if (r.status < 200 || r.status >= 300) throw err('HTTP', 'Risposta inattesa del servizio (' + r.status + ').', { status: r.status });
            if (o.ndjson) return await leggiNdjson(r, o);
            var testo = await r.text();
            if (/^\s*</.test(testo)) throw err('RISPOSTA_INATTESA', 'Il servizio ha risposto con una pagina web invece dei dati.');
            var v; try { v = JSON.parse(testo); } catch (e) { throw err('RISPOSTA_INATTESA', 'Dati del servizio non leggibili (JSON non valido).'); }
            return { status: r.status, dati: v, byte: testo.length };
          } catch (e) {
            if (e && e.code) throw e;
            if (o.segnale && o.segnale.aborted) throw err('ANNULLATO', 'Operazione annullata.');
            throw err('RETE', 'Connessione interrotta durante la lettura.', { causa: String(e && e.message || e) });
          } finally { u.chiudi(); }
        }
      });
    }

    async function leggiNdjson(r, o) {
      var righe = [], errori = [], troncato = false, n = 0, resto = '', byte = 0;
      function riga(l, ultima) {
        if (!l.trim()) return;
        n++;
        if (/^\s*</.test(l)) { errori.push({ riga: n, msg: 'pagina web al posto dei dati' }); troncato = true; return; }
        var v; try { v = JSON.parse(l); } catch (e) { errori.push({ riga: n, msg: 'riga non leggibile' + (ultima ? ' (probabile flusso interrotto)' : '') }); if (ultima) troncato = true; return; }
        if (!v || typeof v !== 'object' || Array.isArray(v)) { errori.push({ riga: n, msg: 'riga non è un oggetto' }); return; }
        righe.push(v); if (o.onRiga) o.onRiga(v, n);
      }
      var body = r.body;
      if (body && typeof body.getReader === 'function' && typeof TextDecoder !== 'undefined') {
        var rd = body.getReader(), dec = new TextDecoder('utf-8');
        try {
          for (;;) {
            var x = await rd.read(); if (x.done) break;
            byte += x.value.length; resto += dec.decode(x.value, { stream: true });
            var parti = resto.split('\n'); resto = parti.pop();
            parti.forEach(function (l) { riga(l, false); });
          }
          resto += dec.decode();
        } catch (e) {
          troncato = true;
          if (o.segnale && o.segnale.aborted) { var ea = err('ANNULLATO', 'Operazione annullata.'); ea.parziale = righe; throw ea; }
        }
      } else {
        try { resto = await r.text(); byte = resto.length; } catch (e2) { troncato = true; resto = ''; }
        var tutte = resto.split('\n'); resto = tutte.pop(); tutte.forEach(function (l) { riga(l, false); });
      }
      if (resto.trim()) riga(resto, true);
      return { status: r.status, righe: righe, errori: errori, troncato: troncato, byte: byte };
    }

    return { richiesta: richiesta, consentito: consentito, registro: function () { return registro.slice(); }, svuotaRegistro: function () { registro.length = 0; } };
  }

  /* Adattatore Android (CapacitorHttp): stessa forma di fetch, testo grezzo; niente streaming. DA PROVARE SUL TELEFONO (non eseguito). */
  function daCapacitorHttp(CapacitorHttp, o) {
    o = o || {};
    return async function (url, init) {
      if (init && init.signal && init.signal.aborted) throw new Error('aborted');
      var r = await CapacitorHttp.get({ url: url, headers: (init && init.headers) || {}, responseType: 'text', connectTimeout: o.connectTimeout || 15000, readTimeout: o.readTimeout || 30000 });
      if (init && init.signal && init.signal.aborted) throw new Error('aborted');
      var h = r.headers || {}, data = typeof r.data === 'string' ? r.data : JSON.stringify(r.data);
      return { status: r.status, headers: { get: function (k) { k = k.toLowerCase(); var f = Object.keys(h).filter(function (x) { return x.toLowerCase() === k; })[0]; return f ? h[f] : null; } }, text: async function () { return data; }, body: null };
    };
  }

  /* Guardia cloud-eval (DECISO Q12). In fase 1 nessun modulo chiama cloud-eval; questa funzione è il contratto che la fase 2
     DOVRÀ usare prima di qualsiasi richiesta: false di default, false per partite private/esercizi personali/posizioni riservate,
     false per batch, classificazione, generazione esercizi e galleria. */
  function cloudEvalConsentito(imp, ctx) {
    ctx = ctx || {};
    if (!imp || imp.cloudEvalEnabled !== true || imp.cloudEvalNoticeAccepted !== true) return false;
    if (ctx.uso !== 'live-interattivo') return false;
    if (ctx.private === true || ctx.esercizioPersonale === true || ctx.riservata === true) return ctx.sceltaEsplicitaPerQuesta === true;
    return true;
  }

  return { crea: crea, consentito: consentito, daCapacitorHttp: daCapacitorHttp, cloudEvalConsentito: cloudEvalConsentito, VERSIONE: 'cnap-rete-1' };
});
