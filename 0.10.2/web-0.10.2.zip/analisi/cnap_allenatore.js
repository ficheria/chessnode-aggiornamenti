/* Chess Node · Analisi profonda · FASE 4 · CNApAllenatore — sessioni deduplicate e motivate (A3-09), Piano della settimana,
   riepilogo a 4 settimane, «Rigioca il momento», «Ritrova la tua mossa» (A3-11, Q09). Codice originale Chess Node (09/11/2026).
   Regole: nessun riempitivo (3 approvati → 3), nessuna scelta casuale non tracciabile, motivazione scritta per ogni elemento,
   nessuna notifica né lavoro in background (il piano nasce alla prima apertura utile), nessun progresso regalato.
   «Prima e dopo» è successivo; la gestione del tempo è esclusa. */
(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api; else root.CNApAllenatore = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  var VERSIONE = 'cnap-allenatore-1', POLICY = 'cnap-selezione-proposta-1';
  var PIANO = { maxTemi: 3, min: 10, max: 15 };
  var NOMI = { pezzo_indifeso: 'Pezzo indifeso', forchetta: 'Forchetta', inchiodatura: 'Inchiodatura', infilata: 'Infilata', matto_non_visto: 'Matto non visto', scoperta: 'Attacco di scoperta' };
  var GRAV = { blunder: 3, errore: 2 };

  function crea(d) {
    var DB = d.db, U = d.CNApUtil, E = d.esercizi, R = d.ripasso, T = d.tentativi, A = d.archivio;
    var ora = d.ora || function () { return Date.now(); };
    function giorno(ms) { return U.dataRoma(ms); }
    function lunedi(ms) { var k = giorno(ms), p = k.split('-'), dow = new Date(Date.UTC(+p[0], +p[1] - 1, +p[2])).getUTCDay(); return d.CNApRipasso.addDays(k, -((dow + 6) % 7)); }
    function f4(f) { return String(f).split(' ').slice(0, 4).join(' '); }

    /* ---------- sessioni ---------- */
    async function creaSessione(kind, voci, o) {
      o = o || {};
      var visti = {}, viste = {}, lista = [], motivi = {};
      for (var i = 0; i < voci.length; i++) {
        var v = voci[i], ok = await E.allenabile(v.exerciseId); if (!ok.ok) continue;
        var ex = ok.esercizio, firma = f4(ex.startFen) + '|' + (ex.objective ? ex.objective.tipo : 'biblioteca');
        if (visti[ex.exerciseId] || viste[firma]) continue;   // un esercizio in tre capitoli conta una volta; stessa posizione equivalente una volta
        visti[ex.exerciseId] = 1; viste[firma] = 1; lista.push(ex.exerciseId); motivi[ex.exerciseId] = v.motivo;
        if (o.max && lista.length >= o.max) break;
      }
      var s = { sessionId: 'TS-' + U.hash(kind + '|' + ora() + '|' + lista.join(',')).slice(0, 10), kind: kind, exerciseIds: lista, motivi: motivi, seenExerciseIds: [], currentIndex: 0,
        rimossi: [], selectionPolicyVersion: POLICY, createdAt: ora(), messaggio: lista.length ? null : (o.vuoto || 'Nessun esercizio verificato disponibile.') };
      await DB.tx(['sessions'], 'readwrite', function (t) { return t.put('sessions', s); });
      return s;
    }
    /* refresh: stessa lista, nessun rimescolamento; gli invalidati escono dalla parte FUTURA con un messaggio (mai sostituiti) */
    async function sessione(id) {
      var s = await DB.tx(['sessions'], 'readonly', function (t) { return t.get('sessions', id); }); if (!s) return null;
      var futuri = s.exerciseIds.slice(s.currentIndex), tolti = [];
      for (var i = 0; i < futuri.length; i++) { var ok = await E.allenabile(futuri[i]); if (!ok.ok) tolti.push({ exerciseId: futuri[i], motivo: ok.motivo }); }
      if (tolti.length) {
        s.exerciseIds = s.exerciseIds.filter(function (x, j) { return j < s.currentIndex || !tolti.some(function (t) { return t.exerciseId === x; }); });
        s.rimossi = s.rimossi.concat(tolti); s.messaggio = tolti.length + (tolti.length === 1 ? ' esercizio è tornato' : ' esercizi sono tornati') + ' in verifica e non ti verrà proposto.';
        await DB.tx(['sessions'], 'readwrite', function (t) { return t.put('sessions', s); });
      }
      return s;
    }
    async function avanza(id, exerciseId) {
      var s = await sessione(id); if (!s) return null;
      if (s.seenExerciseIds.indexOf(exerciseId) < 0) s.seenExerciseIds.push(exerciseId);
      while (s.currentIndex < s.exerciseIds.length && s.seenExerciseIds.indexOf(s.exerciseIds[s.currentIndex]) >= 0) s.currentIndex++;
      await DB.tx(['sessions'], 'readwrite', function (t) { return t.put('sessions', s); });
      return { sessione: s, prossimo: s.exerciseIds[s.currentIndex] || null };
    }
    /* percorsi di «I miei errori» */
    async function correggi(o) {
      var ap = (await E.approvati()).filter(function (e) { return e.sourceType === 'personale' && e.exerciseType !== 'ritrova'; }), voci = [];   // le Geniali non sono errori
      for (var i = 0; i < ap.length; i++) { var st = (await T.storico(ap[i].exerciseId)).length; if (!st && !R.stato(ap[i].exerciseId).inRipasso) voci.push({ exerciseId: ap[i].exerciseId, motivo: 'Errore dalla tua partita, mai affrontato', t: ap[i].approvedAt }); }
      voci.sort(function (a, b) { return b.t - a.t; });
      return creaSessione('correggi', voci, Object.assign({ vuoto: 'Non ci sono errori nuovi da correggere.' }, o));
    }
    async function ripassa() {
      var l = R.diOggi();   // già limitato a 10 al giorno, personali + biblioteca insieme
      return creaSessione('ripassa', l.map(function (x) { return { exerciseId: x.exerciseId, motivo: 'Ripasso in scadenza' }; }), { vuoto: 'Nessun ripasso in scadenza oggi.' });
    }
    async function archivioPersonale() {
      var ap = (await E.approvati()).filter(function (e) { return e.sourceType === 'personale'; });
      return creaSessione('archivio', ap.map(function (e) { return { exerciseId: e.exerciseId, motivo: 'Dal tuo archivio personale' }; }));
    }

    /* ---------- Piano della settimana ---------- */
    /* difetti: [{tema, confermato, errori, occasioni, stato}] da CNApDifetti/CNApProfilo; profiloRevisione: stringa */
    async function piano(o) {
      o = o || {};
      var w = lunedi(o.oraMs || ora());
      var esistenti = await DB.tx(['plans'], 'readonly', function (t) { return t.byIndex('plans', 'weekId', w); });
      var attivo = esistenti.filter(function (p) { return p.stato !== 'sostituito'; })[0];
      if (attivo && !o.rigenera) return attivo;
      var conf = (o.difetti || []).filter(function (x) { return x.confermato; }).sort(function (a, b) { return (b.errori - a.errori) || (a.tema < b.tema ? -1 : 1); }).slice(0, PIANO.maxTemi);
      var p = { planId: 'PW-' + w + '-r' + (esistenti.length + 1), weekId: w, revisione: esistenti.length + 1, sourceProfileRevision: o.profiloRevisione || null, creatoIl: ora(), stato: 'attivo',
        temi: [], exerciseIds: [], motivi: {}, spiegazione: null, tipo: null, policyVersion: VERSIONE };
      if (!conf.length) {
        p.tipo = 'generale'; p.spiegazione = 'Servono altre partite analizzate per un piano personale: per ora nessun difetto è confermato. Puoi allenarti nella biblioteca (piano generale, non personalizzato).';
      } else {
        p.tipo = 'personale';
        var ap = (await E.approvati()).filter(function (e) { return e.sourceType === 'personale'; }), usati = {};
        var nuovi = []; for (var i = 0; i < ap.length; i++) if (!(await T.storico(ap[i].exerciseId)).length) nuovi.push(ap[i]);
        // giro tra i temi (varietà), solo esercizi NUOVI e approvati; limite 15, nessun riempitivo
        var perTema = conf.map(function (c) { return { tema: c.tema, lista: nuovi.filter(function (e) { return (e.themeTags || []).indexOf(c.tema) >= 0; }) }; });
        var giro = true;
        while (giro && p.exerciseIds.length < PIANO.max) { giro = false; perTema.forEach(function (pt) { while (pt.lista.length && usati[pt.lista[0].exerciseId]) pt.lista.shift(); if (pt.lista.length && p.exerciseIds.length < PIANO.max) { var e = pt.lista.shift(); usati[e.exerciseId] = 1; p.exerciseIds.push(e.exerciseId); p.motivi[e.exerciseId] = 'Tema da consolidare: ' + (NOMI[pt.tema] || pt.tema); giro = true; } }); }
        p.temi = conf.map(function (c) { return { tema: c.tema, nome: NOMI[c.tema] || c.tema, motivo: c.testo || (c.errori + ' errori su ' + c.occasioni + ' occasioni'), esercizi: p.exerciseIds.filter(function (id) { return p.motivi[id].indexOf(NOMI[c.tema] || c.tema) >= 0; }).length }; });
        p.spiegazione = p.exerciseIds.length >= PIANO.min ? p.exerciseIds.length + ' esercizi nuovi sui tuoi ' + conf.length + ' temi da consolidare.'
          : 'Ci sono solo ' + p.exerciseIds.length + ' esercizi verificati nuovi per i tuoi temi: te ne proponiamo ' + p.exerciseIds.length + ', senza inventarne altri.';
      }
      await DB.tx(['plans'], 'readwrite', async function (t) { if (attivo) { attivo.stato = 'sostituito'; attivo.sostituitoDa = p.planId; await t.put('plans', attivo); } await t.put('plans', p); });
      return p;
    }
    async function storicoPiani() { return (await DB.tx(['plans'], 'readonly', function (t) { return t.all('plans'); })).sort(function (a, b) { return a.weekId < b.weekId ? -1 : a.weekId > b.weekId ? 1 : a.revisione - b.revisione; }); }
    async function avanzamentoPiano(p) {
      var fatti = 0; for (var i = 0; i < p.exerciseIds.length; i++) if ((await T.storico(p.exerciseIds[i])).some(function (a) { return a.endedAt && a.solved; })) fatti++;
      return { risolti: fatti, totale: p.exerciseIds.length };
    }
    /* riepilogo dopo 4 settimane: numeri veri; il confronto nelle partite solo con occasioni sufficienti (soglie Q02) */
    async function riepilogo4(o) {
      o = o || {};
      var piani = (await storicoPiani()).filter(function (p) { return p.stato !== 'sostituito'; });
      if (piani.length < 4) return { disponibile: false, settimane: piani.length, testo: 'Il riepilogo arriva dopo 4 settimane di piano (' + piani.length + '/4).' };
      var ultime = piani.slice(-4), ids = {}; ultime.forEach(function (p) { p.exerciseIds.forEach(function (x) { ids[x] = 1; }); });
      var tutti = []; for (var k in ids) tutti = tutti.concat((await T.storico(k)).filter(function (a) { return a.endedAt; }));
      var dal = ultime[0].weekId, meta = d.CNApRipasso.addDays(dal, 14);
      function quota(l) { return l.length ? Math.round(100 * l.filter(function (a) { return a.outcome === 'risolto senza aiuti'; }).length / l.length) : null; }
      var primi = tutti.filter(function (a) { return giorno(a.startedAt) < meta; }), secondi = tutti.filter(function (a) { return giorno(a.startedAt) >= meta; });
      var qa = quota(primi), qb = quota(secondi), migliora = primi.length >= 10 && secondi.length >= 10 && qb - qa >= 10;
      var es = 'Negli esercizi del piano: ' + tutti.length + ' tentativi conclusi, ' + tutti.filter(function (a) { return a.outcome === 'risolto senza aiuti'; }).length + ' risolti senza aiuti.';
      var g = o.occasioni || {}, basta = g.prima != null && g.dopo != null && g.prima >= 5 && g.dopo >= 5 && g.partitePrima >= 3 && g.partiteDopo >= 3;
      var partite = basta ? 'Nelle partite, sullo stesso tema: errore nel ' + g.tassoPrima + '% delle occasioni prima e nel ' + g.tassoDopo + '% dopo (' + g.prima + ' e ' + g.dopo + ' occasioni verificate).'
        : (migliora ? 'Stai migliorando negli esercizi, ma servono altre partite per verificare se il progresso si riflette nel tuo gioco.' : 'Servono altre partite per verificare se l\'allenamento si riflette nel tuo gioco.');
      return { disponibile: true, settimane: ultime.map(function (p) { return p.weekId; }), tentativi: tutti.length, quotaPrimaMeta: qa, quotaSecondaMeta: qb, migliorando: migliora, confrontoPartite: basta, testo: es + ' ' + partite };
    }

    /* ---------- Rigioca il momento: l'errore più grave VERIFICATO della settimana (tuo, non dell'avversario) ---------- */
    async function rigioca(o) {
      o = o || {};
      var fine = o.oraMs || ora(), inizio = fine - 7 * 86400000;
      var gs = (await A.tx(['games'], 'readonly', function (t) { return t.all('games'); })).filter(function (g) { return g.playedAtMs >= inizio && g.playedAtMs <= fine && g.localAnalysisId; });
      var errori = [];
      for (var i = 0; i < gs.length; i++) {
        var an = await A.tx(['analyses'], 'readonly', function (t) { return t.get('analyses', gs[i].localAnalysisId); }); if (!an || an.status !== 'complete') continue;
        (an.positionResults || []).forEach(function (pr) { if (pr.side === gs[i].userColor && GRAV[pr.label] && pr.verified !== false) errori.push({ gameId: gs[i].gameId, nodeId: pr.nodeIdBefore, label: pr.label, perdita: (pr.labelInfo && pr.labelInfo.loss) || 0, ply: pr.ply }); });
      }
      errori.sort(function (a, b) { return (GRAV[b.label] - GRAV[a.label]) || (b.perdita - a.perdita) || (a.ply - b.ply); });
      if (!errori.length) return { disponibile: false, testo: 'Nessun errore verificato nelle tue partite di questa settimana.' };
      var ap = (await E.approvati()).filter(function (e) { return e.sourceType === 'personale'; });
      for (var j = 0; j < errori.length; j++) {
        var ex = ap.filter(function (e) { return e.sourceGameId === errori[j].gameId && e.sourceNodeId === errori[j].nodeId; })[0];
        if (ex) return { disponibile: true, exerciseId: ex.exerciseId, errore: errori[j], ritorno: E.ritorno(ex), piuGrave: j === 0,
          testo: j === 0 ? 'Il tuo errore più grave della settimana: ritrova la continuazione giusta.' : 'Il tuo errore più grave della settimana non è diventato un esercizio verificato: ti proponiamo il successivo (' + (j + 1) + '° per gravità).' };
      }
      return { disponibile: false, testo: 'I tuoi errori di questa settimana non hanno superato i controlli per diventare esercizi: non te ne proponiamo uno dubbio.' };
    }
    /* ---------- Ritrova la tua mossa: solo da Geniali verificate, stessi controlli ---------- */
    async function ritrova() {
      var ap = (await E.approvati()).filter(function (e) { return e.exerciseType === 'ritrova'; });
      if (!ap.length) return { disponibile: false, testo: 'Nessuna tua mossa geniale verificata da ritrovare, per ora.' };
      var conUltimo = [];
      for (var i = 0; i < ap.length; i++) { var s = await T.storico(ap[i].exerciseId); conUltimo.push({ e: ap[i], ultimo: s.length ? s[s.length - 1].startedAt : 0, visto: s.length > 0 }); }
      conUltimo.sort(function (a, b) { return a.ultimo - b.ultimo || (a.e.exerciseId < b.e.exerciseId ? -1 : 1); });
      var x = conUltimo[0];
      return { disponibile: true, exerciseId: x.e.exerciseId, avviso: 'Hai già giocato questa posizione in partita.' + (x.visto ? ' L\'hai già vista anche in allenamento.' : ''), ritorno: E.ritorno(x.e), motivo: 'Tua mossa Geniale verificata' };
    }
    return { creaSessione: creaSessione, sessione: sessione, avanza: avanza, correggi: correggi, ripassa: ripassa, archivioPersonale: archivioPersonale,
      piano: piano, storicoPiani: storicoPiani, avanzamentoPiano: avanzamentoPiano, riepilogo4: riepilogo4, rigioca: rigioca, ritrova: ritrova, lunedi: lunedi, PIANO: PIANO };
  }
  return { crea: crea, VERSIONE: VERSIONE, PIANO: PIANO };
});
