/* Chess Node Play · collegamento dell'analisi profonda all'app (passo 4 del piano).
   Avvio del database unico, facciata CNApRaccordo, ganci degli esercizi personali,
   import «Analizza me» (solo le tue partite). Il motore dei puzzle resta com'è:
   qui si usa un Worker Stockfish separato, così i tempi dei 1001 non cambiano. */
(function (root) {
  'use strict';

  var STILE = '#cnapErr{position:fixed;left:0;right:0;top:0;z-index:80;display:flex;flex-direction:column;gap:10px;padding:calc(env(safe-area-inset-top,0px) + 12px) 16px 14px;background:var(--s1,#1a2227);color:var(--tx,#eef2f4);box-shadow:0 8px 24px rgba(0,0,0,.28)}'
    + '#cnapErr[hidden]{display:none!important}'
    + '#cnapErr p{margin:0;font:500 15px/1.4 Outfit,Inter,sans-serif}'
    + '#cnapErr .cnap-err-ok{margin:0}';

  var allenabili = {};
  var coda = [];
  var occupato = false;
  var avvioIstanza = null;
  var PASSATE_KEY = 'chessnodeplay-profilo-scacchistico-v1';
  var inPausa = false;
  function rdPassate(){
    try { return JSON.parse(localStorage.getItem(PASSATE_KEY) || 'null') || {}; } catch (e) { return {}; }
  }
  function wrPassate(s){ try { localStorage.setItem(PASSATE_KEY, JSON.stringify(s)); } catch (e) {} }
  function statoPassate(){
    var s = rdPassate();
    return {
      passata: s.storiaFinita ? 2 : (s.passata || 1),
      provvisorio: !s.storiaFinita,
      inCorso: !!(occupato || (coda.length && !inPausa)) || !!s.inCorso,
      inPausa: inPausa || !!s.inPausa,
      storiaFinita: !!s.storiaFinita,
      genialiComplete: !!s.storiaFinita || !!s.genialiComplete,
      primaPassataFatta: !!s.primaPassataFatta
    };
  }
  function segnaNovita(tipo){
    var N = root.CNNotifiche;
    if (N && typeof N.novitaProfilo === 'function') N.novitaProfilo(tipo ? { tipo: tipo } : undefined);
  }

  function $(id) { return document.getElementById(id); }

  function mostraErrore(esito) {
    var box = $('cnapErr'), msg = $('cnapErrMsg');
    if (!box || !msg) return;
    msg.textContent = (esito && esito.messaggio) || 'Qualcosa non ha funzionato nell\'archivio dell\'allenamento.';
    box.hidden = false;
  }
  function nascondiErrore() { var box = $('cnapErr'); if (box) box.hidden = true; }

  function tuttiModuli() {
    return {
      CNApUtil: root.CNApUtil, CNApFen: root.CNApFen, CNApPgn: root.CNApPgn, CNApImport: root.CNApImport,
      CNApBackend: root.CNApBackend, CNApArchivio: root.CNApArchivio, CNApRete: root.CNApRete, CNApSorgenti: root.CNApSorgenti,
      CNApAperture: root.CNApAperture, CNApStat: root.CNApStat, CNApCampione: root.CNApCampione, CNApMigrazione: root.CNApMigrazione,
      CNApServizio: root.CNApServizio, CNApUci: root.CNApUci, CNApPunteggio: root.CNApPunteggio, CNApScheduler: root.CNApScheduler,
      CNApClassifica: root.CNApClassifica, CNApFasi: root.CNApFasi, CNApTemi: root.CNApTemi, CNApAnalisi: root.CNApAnalisi,
      CNApDifetti: root.CNApDifetti, CNApStato: root.CNApStato, CNApTermico: root.CNApTermico, CNVarianti: root.CNVarianti,
      CNApProfilo: root.CNApProfilo, CNApDbAll: root.CNApDbAll, CNApSoluzione: root.CNApSoluzione, CNApControlli: root.CNApControlli,
      CNApCapitoli: root.CNApCapitoli, CNApGeneratore: root.CNApGeneratore, CNApRisposta: root.CNApRisposta, CNApTentativi: root.CNApTentativi,
      CNApRipasso: root.CNApRipasso, CNApEsercizi: root.CNApEsercizi, CNApAllenatore: root.CNApAllenatore,
      CNApAvversario: root.CNApAvversario, CNApSchedaAvversario: root.CNApSchedaAvversario, CNApDbV2: root.CNApDbV2,
      CNApAvvio: root.CNApAvvio, CNApTono: root.CNApTono, CNApRipassoIntegrato: root.CNApRipassoIntegrato, CNApRaccordo: root.CNApRaccordo
    };
  }

  /* Worker dedicato: non si tocca l'Engine dei puzzle in app.js. */
  var uciCache = null;
  function uciApp() {
    if (uciCache) return uciCache;
    if (!root.CNApUci || typeof Worker === 'undefined') return null;
    try {
      var w = new Worker('engine/stockfish-lite.js');
      uciCache = root.CNApUci.crea({ porta: root.CNApUci.daWorker(w) });
    } catch (e) { uciCache = null; }
    return uciCache;
  }

  function chiaveP(id) { return /^p:/.test(id) ? id : 'p:' + id; }
  function idP(k) { return String(k || '').replace(/^p:/, ''); }

  function testoCompito(ex) {
    if (ex.exerciseType === 'difesa') return 'L\'avversario minaccia qualcosa: devi trovare l\'unica mossa che para la minaccia.';
    if (ex.exerciseType === 'ritrova') return 'In partita hai giocato una mossa forte: ritrovala.';
    if (ex.exerciseType === 'matto') return 'Trova il matto.';
    return 'Trova la mossa migliore.';
  }

  function capitoloDi(ex) {
    var mappa = { forchetta: 'dbl', inchiodatura: 'pin', infilata: 'skew', difesa: 'def', matto: 'm2' };
    if (ex.exerciseType === 'difesa') return 'def';
    if (ex.exerciseType === 'matto') return 'm2';
    var tags = ex.themeTags || [], i, id;
    for (i = 0; i < tags.length; i++) { id = mappa[tags[i]]; if (id) return id; }
    return 'mid';
  }

  function solDi(ex) {
    var Chess = root.Chess, fen = ex.startFen, acc = ex.acceptedMoves || [], i, c, m, out = [], albero, nodo, mossa;
    if (ex.solutionTree && ex.solutionTree.nodes && Chess) {
      albero = ex.solutionTree;
      nodo = albero.nodes.filter(function (n) { return n.id === albero.rootId; })[0];
      c = new Chess(fen);
      while (nodo && nodo.acceptedMoves && nodo.acceptedMoves[0]) {
        mossa = nodo.acceptedMoves[0];
        m = null;
        try { m = c.move(mossa.uci || mossa, { sloppy: true }); } catch (e1) {
          try { m = c.move({ from: String(mossa.uci || mossa).slice(0, 2), to: String(mossa.uci || mossa).slice(2, 4), promotion: String(mossa.uci || mossa)[4] }); } catch (e2) { m = null; }
        }
        if (!m) break;
        out.push([m.from + m.to + (m.promotion || ''), (root.__app && root.__app.itSan ? root.__app.itSan(m.san) : m.san), '']);
        nodo = (nodo.risposte && nodo.risposte[0] && albero.nodes.filter(function (n) { return n.id === nodo.risposte[0]; })[0]) || null;
      }
      if (out.length) return out;
    }
    if (!acc.length) return [['', '', '']];
    if (Chess) {
      try {
        c = new Chess(fen);
        for (i = 0; i < 1; i++) {
          m = null;
          try { m = c.move(acc[0], { sloppy: true }); } catch (e3) {
            try { m = c.move({ from: acc[0].slice(0, 2), to: acc[0].slice(2, 4), promotion: acc[0][4] }); } catch (e4) { m = null; }
          }
          if (m) out.push([m.from + m.to + (m.promotion || ''), (root.__app && root.__app.itSan ? root.__app.itSan(m.san) : m.san), '']);
        }
      } catch (e5) {}
    }
    return out.length ? out : [[acc[0], acc[0], '']];
  }

  function lmDi(ex) {
    var u = ex.ultimaMossaAvversaria || (ex.pipeline && ex.pipeline.candidato && ex.pipeline.candidato.ultimaMossaAvversaria);
    if (!u) return null;
    if (u.from && u.to) return { from: u.from, to: u.to };
    if (typeof u === 'string' && u.length >= 4) return { from: u.slice(0, 2), to: u.slice(2, 4) };
    if (u.uci && u.uci.length >= 4) return { from: u.uci.slice(0, 2), to: u.uci.slice(2, 4) };
    return null;
  }

  async function aggiornaAllenabili() {
    var CN = root.__cnap && root.__cnap.CN, E, ap, i, ok, k, nuovo = {};
    if (!CN || !CN.allenamento || !CN.allenamento.esercizi) { allenabili = {}; return; }
    E = CN.allenamento.esercizi;
    try { ap = await E.approvati(); } catch (e) { allenabili = {}; return; }
    for (i = 0; i < ap.length; i++) {
      if (ap[i].sourceType && ap[i].sourceType !== 'personale') continue;
      try { ok = await E.allenabile(ap[i].exerciseId); } catch (e2) { ok = { ok: false }; }
      k = chiaveP(ap[i].exerciseId);
      nuovo[k] = !!(ok && ok.ok);
    }
    allenabili = nuovo;
  }

  async function apriPersonale(chiave) {
    var CN = root.__cnap && root.__cnap.CN, id = idP(chiave), E, ex, e, A = root.__app, ch;
    if (!CN || !CN.allenamento) return;
    E = CN.allenamento.esercizi;
    try { ex = await E.esercizio(id); } catch (err) { ex = null; }
    if (!ex) return;
    var all = await E.allenabile(id);
    if (!all || !all.ok) return;
    e = {
      n: chiaveP(id), c: capitoloDi(ex), fen: ex.startFen, sol: solDi(ex),
      txt: testoCompito(ex), voi: testoCompito(ex), title: 'Dalla tua partita',
      lm: lmDi(ex), personale: true, st: 'v', res: ex.exerciseType === 'matto' ? 'mate' : ''
    };
    root.__cnapEx = root.__cnapEx || {};
    root.__cnapEx[e.n] = e;
    if (root.CNHome && typeof root.CNHome.nascondi === 'function') root.CNHome.nascondi();
    if (A && typeof A.loadEx === 'function') {
      A.loadEx(e.n, true);
      ch = A.chById && A.chById[e.c];
      if (document.getElementById('chapterName')) document.getElementById('chapterName').textContent = (ch && ch.name) ? ch.name : 'I miei errori';
      if (document.getElementById('exTitle')) document.getElementById('exTitle').textContent = e.title;
    }
  }

  function personaleAllenabile(k) { return !!allenabili[chiaveP(k)]; }

  function idsDaReport(r) {
    var det = (r && (r.report && r.report.dettagli || r.dettagli)) || [], out = [], visti = {};
    det.forEach(function (d) {
      if (d && d.gameId && !visti[d.gameId] && d.esito !== 'nonValida') { visti[d.gameId] = 1; out.push(d.gameId); }
    });
    return out;
  }

  async function haAnalisiCompleta(CN, gameId) {
    try {
      var g = await CN.archivio.partita(gameId);
      if (!g || !g.localAnalysisId) return false;
      var a = await CN.archivio.tx(['analyses'], 'readonly', function (t) { return t.get('analyses', g.localAnalysisId); });
      return !!(a && a.status === 'complete');
    } catch (e) { return false; }
  }

  async function riempiCodaPassate(CN, extraIds) {
    (extraIds || []).forEach(function (id) { if (id && coda.indexOf(id) < 0) coda.push(id); });
    var s = rdPassate(), gs = [], i, g;
    try { gs = await CN.archivio.partite({ scope: 'self' }); } catch (e) { gs = []; }
    var prima = [], resto = [];
    for (i = 0; i < gs.length; i++) {
      g = gs[i];
      if (!g || !g.gameId) continue;
      if (await haAnalisiCompleta(CN, g.gameId)) continue;
      if (g.sampling && g.sampling.selectedForEngine) prima.push(g.gameId);
      else resto.push(g.gameId);
    }
    var fonte = s.primaPassataFatta ? resto : prima.concat(resto);
    fonte.forEach(function (id) { if (id && coda.indexOf(id) < 0) coda.push(id); });
    return { prima: prima.length, resto: resto.length };
  }

  async function dopoAnalisi(CN) {
    var s = rdPassate(), gs = [], fatte = 0, i;
    try { gs = await CN.archivio.partite({ scope: 'self' }); } catch (e) { gs = []; }
    for (i = 0; i < gs.length; i++) if (await haAnalisiCompleta(CN, gs[i].gameId)) fatte++;
    var selezionate = gs.filter(function (g) { return g && g.sampling && g.sampling.selectedForEngine; });
    var primaFatte = 0;
    for (i = 0; i < selezionate.length; i++) if (await haAnalisiCompleta(CN, selezionate[i].gameId)) primaFatte++;
    if (!s.primaPassataFatta && selezionate.length && primaFatte >= selezionate.length) {
      s.primaPassataFatta = true; s.passata = 2; wrPassate(s);
      if (fatte) segnaNovita();
    } else if (s.primaPassataFatta && fatte && fatte !== s.ultimoFatte) {
      s.ultimoFatte = fatte; wrPassate(s);
      segnaNovita();
    } else if (!s.primoQuadro && fatte > 0) {
      s.primoQuadro = true; wrPassate(s);
    }
    var inAttesa = coda.length > 0;
    if (s.primaPassataFatta && !inAttesa && fatte >= gs.length && gs.length) {
      if (!s.storiaFinita) {
        s.storiaFinita = true; s.genialiComplete = true; s.inCorso = false; wrPassate(s);
        segnaNovita('completo');
      }
    } else {
      s.inCorso = occupato || (coda.length && !inPausa);
      wrPassate(s);
    }
  }

  async function elaboraCoda() {
    if (occupato || inPausa) return;
    var CN = root.__cnap && root.__cnap.CN, job;
    if (!CN || !CN.analisi || !CN.allenamento) return;
    occupato = true;
    wrPassate(Object.assign(rdPassate(), { inCorso: true, inPausa: false }));
    while (coda.length && !inPausa) {
      job = coda.shift();
      try {
        if (!(await haAnalisiCompleta(CN, job))) {
          await CN.analisi.analizzaPartita(job, {});
          if (CN.allenamento.generatore && CN.allenamento.generatore.genera) await CN.allenamento.generatore.genera(job, {});
          if (progAn) { progAn.fatte = Math.min(progAn.totale, progAn.fatte + 1); var sc = rdColl(); if (sc.fase) { sc.fatte = progAn.fatte; wrColl(sc); } }
        }
      } catch (e) { /* l'import è già riuscito: un errore dell'analisi non si finge un successo */ }
    }
    occupato = false;
    await dopoAnalisi(CN);
    var sf = rdColl(); if (sf.fase === 'analisi' && !coda.length && !inPausa) { sf.fase = 'fatto'; wrColl(sf); }
    await aggiornaAllenabili();
  }

  function mettiInCoda(ids) {
    var CN = root.__cnap && root.__cnap.CN;
    if (!CN) {
      (ids || []).forEach(function (id) { if (id && coda.indexOf(id) < 0) coda.push(id); });
      return;
    }
    riempiCodaPassate(CN, ids).then(function () { elaboraCoda(); });
  }

  function pausaAnalisi(){ inPausa = true; wrPassate(Object.assign(rdPassate(), { inPausa: true, inCorso: false })); }
  // 14-11: dopo una chiusura dell'app in pausa la coda è vuota: Riprendi la ricostruisce (solo le partite non ancora finite)
  function riprendiAnalisi(){
    inPausa = false; wrPassate(Object.assign(rdPassate(), { inPausa: false }));
    var CN = root.__cnap && root.__cnap.CN;
    if (CN && !coda.length && !occupato) riempiCodaPassate(CN, []).then(function () { elaboraCoda(); }); else elaboraCoda();
  }

  /* 14-11 (Kiko t1947u): «Collega i tuoi profili» → «Analizza le mie partite». Scarica le partite pubbliche dai siti
     (CNApServizio.importaDaSito: ultimi 12 mesi, max 60 al mese, cursori per mese → riprende da dove era), poi le mette nella
     coda dell'analisi profonda qui sopra (stessa Pausa/Riprendi, ripresa all'avvio). Solo ad app aperta. Stato in COLL_KEY. */
  var COLL_KEY = 'chessnodeplay-collega-v1', collCtrl = null, progAn = null;
  function rdColl(){ try { return JSON.parse(localStorage.getItem(COLL_KEY) || 'null') || {}; } catch (e) { return {}; } }
  function wrColl(s){ try { localStorage.setItem(COLL_KEY, JSON.stringify(s)); } catch (e) {} }
  function rdAccount(){ try { return JSON.parse(localStorage.getItem('chessnodeplay-account-v1') || 'null') || {}; } catch (e) { return {}; } }
  var TESTI_ERR = { NOUSER: 'nome utente non trovato', NON_PUBBLICO: 'account non disponibile', RETE: 'connessione assente', RATE: 'il sito chiede di aspettare un po\'', NOME_NON_VALIDO: 'nome utente non valido' };
  function statoCollega(){
    var s = rdColl(), a = rdAccount(), p = statoPassate();
    var nomi = s.nomi || { lichess: a.lichess || '', chesscom: a.chesscom || '' };
    return {
      fase: s.fase || 'mai', nomi: nomi, collegati: s.fase === 'analisi' || s.fase === 'fatto',
      importInCorso: !!collCtrl, sito: s.sito || null, mese: s.mese || 0, mesiTot: s.mesiTot || 12, partite: s.partite || 0,
      errori: s.errori || [], errore: s.errore || null, inPausa: p.inPausa,
      analisi: { inCorso: p.inCorso && !p.inPausa, fatte: progAn ? progAn.fatte : (s.fatte || 0), totale: progAn ? progAn.totale : (s.totale || 0), finita: p.storiaFinita },
      pronto: !!(root.__cnap && root.__cnap.CN)
    };
  }
  async function contaAnalisi(CN){
    var gs = [], f = 0, i;
    try { gs = await CN.archivio.partite({ scope: 'self' }); } catch (e) { gs = []; }
    for (i = 0; i < gs.length; i++) if (await haAnalisiCompleta(CN, gs[i].gameId)) f++;
    progAn = { fatte: f, totale: gs.length };
    var s = rdColl(); s.fatte = f; s.totale = gs.length; wrColl(s);
    return progAn;
  }
  function avviaCollega(nomi){
    var s = rdColl(), a = rdAccount();
    nomi = nomi || s.nomi || { lichess: a.lichess || '', chesscom: a.chesscom || '' };
    nomi = { lichess: String(nomi.lichess || '').trim(), chesscom: String(nomi.chesscom || '').trim() };
    if (!nomi.lichess && !nomi.chesscom) return { ok: false, testo: 'Scrivi almeno un nome utente.' };
    var re = /^[A-Za-z0-9_-]{2,30}$/;
    if ((nomi.lichess && !re.test(nomi.lichess)) || (nomi.chesscom && !re.test(nomi.chesscom))) return { ok: false, testo: 'Controlla il nome utente: solo lettere, numeri, - e _.' };
    a.lichess = nomi.lichess; a.chesscom = nomi.chesscom;
    try { localStorage.setItem('chessnodeplay-account-v1', JSON.stringify(a)); } catch (e) {}
    var stessi = s.nomi && s.nomi.lichess === nomi.lichess && s.nomi.chesscom === nomi.chesscom;
    wrColl({ fase: 'import', nomi: nomi, avviato: Date.now(), mesiTot: 12, mese: stessi ? (s.mese || 0) : 0, partite: stessi ? (s.partite || 0) : 0, errori: [], sito: null });
    inPausa = false; wrPassate(Object.assign(rdPassate(), { inPausa: false }));
    eseguiImport();
    return { ok: true };
  }
  async function eseguiImport(){
    var CN = root.__cnap && root.__cnap.CN, s = rdColl();
    if (collCtrl || inPausa || s.fase !== 'import' || !CN || !CN.servizio) return;
    var ctrl = collCtrl = (typeof AbortController !== 'undefined') ? new AbortController() : { signal: { aborted: false }, abort: function () { this.signal.aborted = true; } };
    var siti = [['lichess', s.nomi.lichess], ['chesscom', s.nomi.chesscom]].filter(function (x) { return x[1]; });
    var errori = [], ok = 0, annullato = false, iSito;
    for (iSito = 0; iSito < siti.length; iSito++) {
      if (ctrl.signal.aborted) { annullato = true; break; }
      var sito = siti[iSito][0], nome = siti[iSito][1];
      s = rdColl(); var k = s.sito === sito ? Math.max(0, (s.mese || 0) - 1) : 0;   // ripresa: i mesi già completi vengono saltati senza richiamare onMese
      s.sito = sito; s.mese = k; s.passo = (iSito + 1) + '/' + siti.length; wrColl(s);
      try {
        var r = await CN.servizio.importaDaSito(sito, nome, { mesi: 12, segnale: ctrl.signal, onMese: function (m, ri) {
          var x = rdColl(); x.mese = Math.min(12, ++k); x.partite = (x.partite || 0) + ((ri && ri.nuove) || 0); wrColl(x);
        } });
        if (r && r.annullato) { annullato = true; break; }
        if (r && r.interrotto) errori.push({ sito: sito, codice: r.interrotto, testo: TESTI_ERR[r.interrotto] || 'errore' });
        else ok++;
      } catch (e) {
        if (e && e.code === 'ANNULLATO') { annullato = true; break; }
        errori.push({ sito: sito, codice: e && e.code, testo: TESTI_ERR[e && e.code] || 'non riesco a leggere le partite' });
      }
    }
    collCtrl = null;
    s = rdColl();
    if (annullato) { s.errori = errori; wrColl(s); return; }   // in pausa: il cursore dei mesi già fatti resta, Riprendi continua da lì
    s.errori = errori;
    if (!ok) { s.fase = 'errore'; s.errore = errori.length ? errori.map(function (x) { return (x.sito === 'lichess' ? 'Lichess' : 'Chess.com') + ': ' + x.testo; }).join(' · ') : 'Non riesco a leggere le partite.'; wrColl(s); return; }
    s.fase = 'analisi'; s.importFinito = Date.now(); s.errore = null; wrColl(s);
    await contaAnalisi(CN);
    mettiInCoda([]);
  }
  function pausaCollega(){ pausaAnalisi(); if (collCtrl) collCtrl.abort(); }
  function riprendiCollega(){
    var s = rdColl();
    if (s.fase === 'errore') { s.fase = 'import'; s.errore = null; wrColl(s); }
    riprendiAnalisi();
    eseguiImport();
  }

  async function importaMe(pgn, o) {
    var CN = root.__cnap && root.__cnap.CN, r;
    o = o || {};
    if (!CN || !CN.servizio || !pgn) return null;
    try {
      r = await CN.servizio.importaTesto(pgn, { scope: 'self', private: !!o.private, fileName: o.fileName || null });
    } catch (e) { return { ok: false, errore: e && e.message }; }
    if (r && r.ok) mettiInCoda(idsDaReport(r));
    return r;
  }

  /* 13-11: protezione termica. Sul telefono il plugin nativo «ChessNodeThermal» (MainActivity) manda lo stato termico allo
     scheduler dell'analisi profonda (tabella Q10 in cnap_scheduler.js); sul web/desktop o con un APK senza plugin:
     «non disponibile», in silenzio, nessuna stima inventata. L'avviso (severo/critico) è un toast, mai sopra la scacchiera. */
  function pluginTermico() {
    var C = root.Capacitor, p = null;
    if (!C || typeof C.isNativePlatform !== 'function' || !C.isNativePlatform()) return null;
    p = (C.Plugins && C.Plugins.ChessNodeThermal) || null;
    if (!p && typeof C.registerPlugin === 'function') { try { p = C.registerPlugin('ChessNodeThermal'); } catch (e) { p = null; } }
    return p;
  }
  function avvisoTermico(t) {
    var prima = root.__cnap.avvisoTermico || null;
    root.__cnap.avvisoTermico = t || null;
    try { document.dispatchEvent(new CustomEvent('cnap:termico', { detail: { testo: t || null } })); } catch (e) {}
    if (!t || t === prima) return;
    try { if (root.CNB4 && root.CNB4.toast) { root.CNB4.toast(t); return; } } catch (e) {}
    try { if (root.__app && root.__app.UI && root.__app.UI.toast) root.__app.UI.toast(t); } catch (e) {}
  }
  async function collegaTermico(M, CN) {
    if (!CN || !CN.scheduler || !M.CNApTermico) return;
    try { root.__cnap.termico = await M.CNApTermico.collega(pluginTermico(), CN.scheduler, { onAvviso: avvisoTermico }); }
    catch (e) { root.__cnap.termico = { disponibile: false, stato: function () { return 'non disponibile'; } }; }
  }

  async function monta(esito) {
    var M = tuttiModuli(), S = root.__stats, CN, uci;
    if (!M.CNApRaccordo || !esito || !esito.backend) return;
    uci = uciApp();
    CN = M.CNApRaccordo.crea({
      M: M,
      Chess: root.Chess,
      backend: esito.backend,
      fetch: root.fetch ? root.fetch.bind(root) : undefined,
      uci: uci,
      BOOK: root.BOOK,
      statsDati: function () { return S && S.data ? S.data() : {}; },
      statsSalva: function () { if (S && S.save) S.save(); },
      oggi: function () { return S && S.dayKey && S.now ? S.dayKey(S.now()) : (M.CNApUtil ? M.CNApUtil.dataRoma(Date.now()) : ''); },
      apriPersonale: function (k) { return apriPersonale(k); },
      apribilePersonale: function (k) { return typeof root.__cnapApriPersonale === 'function' && personaleAllenabile(k); }
    });
    root.__cnap.CN = CN;
    root.__cnap.stato = 'pronto';
    root.__cnap.capitoli = CN.capitoli;
    collegaTermico(M, CN);   // non blocca l'avvio: il plugin risponde quando può
    await aggiornaAllenabili();
    var st = rdPassate();
    inPausa = !!st.inPausa;
    if (rdColl().fase) contaAnalisi(CN).catch(function () {});
    if (!inPausa) await riempiCodaPassate(CN, []);
    elaboraCoda();
    if (!inPausa && rdColl().fase === 'import') eseguiImport();   // import interrotto (app chiusa): riprende dai mesi non ancora completi
  }

  async function apriArchivio() {
    var M = tuttiModuli(), avvio, esito;
    if (!M.CNApAvvio || !M.CNApDbV2) return;
    avvio = M.CNApAvvio.crea({
      CNApDbV2: M.CNApDbV2,
      apriV2: function () { return M.CNApDbV2.indexedDB(); },
      apriVecchio: async function () {
        if (!(await M.CNApAvvio.esisteIDB(root.indexedDB, 'chessnodeplay-allenamento'))) return null;
        return M.CNApDbAll.indexedDB({ nome: 'chessnodeplay-allenamento' });
      },
      ora: function () { return Date.now(); }
    });
    avvioIstanza = avvio;
    esito = await avvio.apri();
    root.__cnap.esito = esito;
    if (esito.stato === 'errore') {
      root.__cnap.stato = 'errore';
      root.__cnap.CN = null;
      mostraErrore(esito);
      return;
    }
    nascondiErrore();
    await monta(esito);
  }

  function avvia() {
    if (root.__cnap && root.__cnap._avviato) return;
    root.__cnap = { stato: 'avvio', CN: null, esito: null, importaMe: importaMe, aggiornaAllenabili: aggiornaAllenabili, statoPassate: statoPassate, pausaAnalisi: pausaAnalisi, riprendiAnalisi: riprendiAnalisi, statoCollega: statoCollega, avviaCollega: avviaCollega, pausaCollega: pausaCollega, riprendiCollega: riprendiCollega, _avviato: true };
    root.__cnapApriPersonale = function (k) { return apriPersonale(k); };
    root.__cnapPersonaleAllenabile = function (k) { return personaleAllenabile(k); };
    if (!document.getElementById('cnapErrStile')) {
      var s = document.createElement('style'); s.id = 'cnapErrStile'; s.textContent = STILE; document.head.appendChild(s);
    }
    var btn = $('cnapErrRetry');
    if (btn) btn.addEventListener('click', function () { nascondiErrore(); apriArchivio(); });
    apriArchivio().catch(function (e) {
      root.__cnap.stato = 'errore';
      mostraErrore({ messaggio: (e && e.message) || 'Il nuovo archivio non si è aperto. L\'allenamento resta fermo: premi «Riprova».' });
    });
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', avvia);
  else avvia();
})(typeof window !== 'undefined' ? window : this);
