/* Chess Node · Analisi profonda · FASE 1 · CNApMigrazione — dal salvataggio attuale (localStorage) al nuovo archivio (A1-04, A1-C03).
   Codice originale Chess Node (08/11/2026). Procedura: leggi → valida → scrivi → verifica conteggi/riferimenti → attiva.
   - Le chiavi localStorage originali NON vengono mai cancellate né modificate: restano la copia di ripristino fino a conferma di Kiko.
     Una copia logica (testo originale) va anche nello store «legacy».
   - 'chessnodeplay-analisi-v1' (linea sulla scacchiera di analisi) → una partita «interna» (colore utente sconosciuto: non entra nel
     profilo finché non si sceglie il lato).
   - 'chessnodeplay-analisi-partita-v3' (cache MAXG=12 di analisi_partita.js) → record di analisi «legacy», marcati non validi per
     profilo/esercizi (vanno rivalidati) ma leggibili; etichetta storica «svarione» mappata su «blunder» senza perdere conteggi.
   - 'chessnodeplay-stats-v1' → solo copia logica (appartiene all'allenamento, area 3).
   - Fallimento a metà: nessuna attivazione; rieseguire è sicuro (import idempotente, chiavi deterministiche). */
(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api; else root.CNApMigrazione = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  var ID = 'legacy-localstorage-v1';
  var CHIAVI = { scacchiera: 'chessnodeplay-analisi-v1', analisi: 'chessnodeplay-analisi-partita-v3', stats: 'chessnodeplay-stats-v1', livello: 'chessnodeplay-analisi-livello' };

  /* dizionario unico (A1-06 §10.2): id storico → id nuovo + etichetta visibile. «svarione» → «blunder». */
  var ETICHETTE = {
    geniale: 'Geniale', migliore: 'Migliore', ottima: 'Ottima', buona: 'Buona', tranquilla: 'Tranquilla', imprecisione: 'Imprecisione',
    errore: 'Errore', blunder: 'Blunder', teoria: 'Teoria', obbligata: 'Mossa obbligata', forte: 'Mossa forte', nogiud: 'Nessun giudizio'
  };
  var ALIAS = { svarione: 'blunder' };
  function mappaEtichetta(id) {
    if (id == null) return { id: null, etichetta: null, storico: null };
    var nuovo = ALIAS[id] || id;
    return { id: nuovo, etichetta: ETICHETTE[nuovo] || null, storico: ALIAS[id] ? id : null, sconosciuta: !ETICHETTE[nuovo] };
  }

  function hkey(s) { var a = 0x811c9dc5; for (var i = 0; i < s.length; i++) a = Math.imul(a ^ s.charCodeAt(i), 16777619) >>> 0; return a.toString(36); }   // stessa funzione di analisi_partita.js:98

  function crea(d) {
    var A = d.archivio, Imp = d.CNApImport, Fen = d.CNApFen, U = d.CNApUtil, ora = d.ora || function () { return Date.now(); };
    var Chess = d.Chess;
    if (!A || !Imp || !Fen || !U || !Chess) throw new Error('CNApMigrazione: servono archivio, CNApImport, CNApFen, CNApUtil, Chess');
    // costanti del codice attuale usate SOLO per ricollegare le vecchie analisi alla partita (analisi_partita.js:32–40,67, precisione.js)
    var VECCHIO = Object.assign({ versione: 'cnp-2', regole: 'r7c', livelli: { standard: 24, approfondito: '' } }, d.vecchio || {});

    function leggi(storage) {
      var grezzi = {}, errori = [];
      Object.keys(CHIAVI).forEach(function (k) {
        var v = null; try { v = storage.getItem(CHIAVI[k]); } catch (e) { errori.push({ chiave: CHIAVI[k], msg: 'lettura impossibile' }); }
        grezzi[k] = v;
      });
      var dati = {};
      ['scacchiera', 'analisi', 'stats'].forEach(function (k) {
        if (grezzi[k] == null) { dati[k] = null; return; }
        try { dati[k] = JSON.parse(grezzi[k]); } catch (e) { dati[k] = undefined; errori.push({ chiave: CHIAVI[k], msg: 'JSON non leggibile: conservato solo come testo' }); }
      });
      return { grezzi: grezzi, dati: dati, errori: errori };
    }

    /* piano senza scritture: cosa verrebbe migrato */
    function pianifica(storage) {
      var L = leggi(storage), piano = { partite: [], analisi: [], copie: [], avvisi: L.errori.slice(), etichetteStoriche: {} };
      Object.keys(CHIAVI).forEach(function (k) { if (L.grezzi[k] != null) piano.copie.push({ key: 'ls:' + CHIAVI[k], valore: L.grezzi[k], migratoIl: ora() }); });
      var sc = L.dati.scacchiera, giocoInterno = null;
      if (sc && typeof sc === 'object' && Array.isArray(sc.sans)) {
        var startFen = typeof sc.startFen === 'string' && sc.startFen ? sc.startFen : Fen.START;
        var vf = Fen.valida(startFen, { Chess: Chess });
        if (!vf.ok) piano.avvisi.push({ chiave: CHIAVI.scacchiera, msg: 'posizione iniziale non valida: partita non migrata (testo conservato)' });
        else if (sc.sans.length) {
          var c = new Chess(vf.fen), ok = true;
          for (var i = 0; i < sc.sans.length; i++) { try { c.move(sc.sans[i]); } catch (e) { ok = false; break; } }
          if (!ok) piano.avvisi.push({ chiave: CHIAVI.scacchiera, msg: 'mossa non valida alla semimossa ' + (i + 1) + ': partita non migrata (testo conservato)' });
          else {
            if (vf.fen !== Fen.START) { c.setHeader('SetUp', '1'); c.setHeader('FEN', vf.fen); }
            c.setHeader('Event', 'Scacchiera di analisi (salvataggio precedente)');
            c.setHeader('Result', '*');
            var pgn = c.pgn();
            giocoInterno = { startFen: vf.fen, sans: sc.sans.slice(), src: { source: 'interna', sourceId: 'ls-analisi-v1-' + U.hash(vf.fen + '|' + sc.sans.join(' ')), rawPgn: pgn, fetchedAt: ora(), scope: 'self', identita: [] } };
            piano.partite.push(giocoInterno);
          }
        }
      }
      var an = L.dati.analisi;
      if (an && typeof an === 'object' && an.g && typeof an.g === 'object') {
        Object.keys(an.g).forEach(function (h) {
          var r = an.g[h]; if (!r || typeof r !== 'object') return;
          var conteggi = {}, lab = Array.isArray(r.lab) ? r.lab.map(function (l) {
            if (!l || typeof l !== 'object') return l;
            var m = mappaEtichetta(l.cl), x = Object.assign({}, l, { cl: m.id }); if (m.storico) { x.clStorico = m.storico; piano.etichetteStoriche[m.storico] = (piano.etichetteStoriche[m.storico] || 0) + 1; }
            if (m.id) conteggi[m.id] = (conteggi[m.id] || 0) + 1; return x;
          }) : null;
          var gameId = null;
          if (giocoInterno && r.start === giocoInterno.startFen) {
            Object.keys(VECCHIO.livelli).forEach(function (liv) {
              if (hkey(liv + '|' + VECCHIO.versione + '|' + VECCHIO.regole + '|' + VECCHIO.livelli[liv] + '|' + giocoInterno.startFen + '|' + giocoInterno.sans.join(' ')) === h) gameId = 'G-' + U.hash('interna:' + giocoInterno.src.sourceId);
            });
          }
          piano.analisi.push({
            schemaVersion: 1, analysisId: 'LEG-' + h, gameId: gameId, analysisRevision: 0, status: 'legacy', stale: true,
            invalidationReason: 'Formato precedente (' + (an.v || '?') + ', regole storiche): leggibile come «analisi precedente», da rivalidare prima di profilo/esercizi.',
            eligibleForProfile: false, classificationVersion: (an.v || 'sconosciuta') + '-legacy', livello: r.liv || null, completa: !!r.fatto,
            conteggiEtichette: conteggi, labelsMigrated: lab, legacyOriginale: r, migratoIl: ora(), migrazione: ID
          });
        });
      } else if (an !== null && an !== undefined) piano.avvisi.push({ chiave: CHIAVI.analisi, msg: 'formato inatteso: conservato solo come testo' });
      return piano;
    }

    /* esecuzione: scrive, verifica, attiva. Ritorna rapporto; in caso di verifica fallita NON attiva. */
    async function esegui(storage, o) {
      o = o || {};
      var gia = await A.meta('migrazione:' + ID);
      if (gia && gia.stato === 'attiva' && !o.forza) return { stato: 'già eseguita', dettagli: gia };
      var piano = pianifica(storage), rep = { id: ID, avvisi: piano.avvisi, partite: null, analisi: 0, copie: piano.copie.length, etichetteStoriche: piano.etichetteStoriche };
      try {
        // 1) copia logica dei testi originali
        await A.tx(['legacy'], 'readwrite', async function (t) { for (var i = 0; i < piano.copie.length; i++) if (!(await t.get('legacy', piano.copie[i].key))) await t.put('legacy', piano.copie[i]); });
        // 2) partite (import transazionale e idempotente)
        var attese = [];
        for (var p = 0; p < piano.partite.length; p++) {
          var prep = Imp.prepara(piano.partite[p].src, { ora: ora() });
          rep.partite = await A.importa(prep, { scope: 'self' });
          prep.partite.forEach(function (x) { attese.push(x.game.gameId); });
        }
        // 3) analisi storiche
        await A.tx(['analyses'], 'readwrite', async function (t) { for (var i = 0; i < piano.analisi.length; i++) if (!(await t.get('analyses', piano.analisi[i].analysisId))) await t.put('analyses', piano.analisi[i]); });
        rep.analisi = piano.analisi.length;
        // 4) verifica conteggi e riferimenti
        var problemi = [];
        await A.tx(['games', 'analyses', 'legacy', 'nodes'], 'readonly', async function (t) {
          for (var i = 0; i < attese.length; i++) { var g = await t.get('games', attese[i]); if (!g) problemi.push('partita ' + attese[i] + ' assente'); else if (!(await t.byIndex('nodes', 'gameId', g.gameId)).length) problemi.push('nodi assenti per ' + g.gameId); }
          for (var j = 0; j < piano.analisi.length; j++) {
            var a = await t.get('analyses', piano.analisi[j].analysisId);
            if (!a) { problemi.push('analisi ' + piano.analisi[j].analysisId + ' assente'); continue; }
            var origCnt = (a.legacyOriginale.lab || []).filter(function (l) { return l && l.cl; }).length, nuovoCnt = Object.keys(a.conteggiEtichette).reduce(function (s, k) { return s + a.conteggiEtichette[k]; }, 0);
            if (origCnt !== nuovoCnt) problemi.push('conteggio etichette diverso in ' + a.analysisId);
            if (a.gameId && !(await t.get('games', a.gameId))) problemi.push('riferimento a partita inesistente in ' + a.analysisId);
          }
          for (var k = 0; k < piano.copie.length; k++) { var cpy = await t.get('legacy', piano.copie[k].key); if (!cpy || cpy.valore !== piano.copie[k].valore) problemi.push('copia ' + piano.copie[k].key + ' non corrispondente'); }
        });
        if (problemi.length) { await A.salvaMeta('migrazione:' + ID, { stato: 'fallita', problemi: problemi, quando: ora() }); rep.stato = 'fallita'; rep.problemi = problemi; return rep; }
        // 5) attivazione
        await A.salvaMeta('migrazione:' + ID, { stato: 'attiva', quando: ora(), partite: attese.length, analisi: piano.analisi.length, copie: piano.copie.length, etichetteStoriche: piano.etichetteStoriche, nota: 'Chiavi localStorage originali conservate intatte.' });
        rep.stato = 'attiva'; return rep;
      } catch (e) {
        try { await A.salvaMeta('migrazione:' + ID, { stato: 'fallita', errore: e.code || String(e.message || e), quando: ora() }); } catch (e2) {}
        rep.stato = 'fallita'; rep.errore = { code: e.code || null, msg: e.message }; return rep;
      }
    }
    return { pianifica: pianifica, esegui: esegui };
  }
  return { crea: crea, mappaEtichetta: mappaEtichetta, ETICHETTE: ETICHETTE, CHIAVI: CHIAVI, ID: ID, VERSIONE: 'cnap-migrazione-1' };
});
