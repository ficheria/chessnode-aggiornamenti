/* Chess Node · Analisi profonda · FASE 2 · CNApClassifica — regole di giudizio della mossa (A1-06 §10.1–10.2).
   Calcolo PURO, senza motore. Base: regole r7c di analisi_partita.js (codice di Kiko, 01/11/2026), PORTATE qui con gli stessi
   numeri per non perdere le regressioni (soglie 5/10/20 + margine 2, CHIARO 75, PERSA 10, Mossa forte prudente, matto certo,
   mossa obbligata, nessun giudizio). Aggiunte di questa fase, versione «cnap-class-1»:
   - id «blunder» al posto di «svarione» (etichetta visibile Blunder);
   - Geniale e Tranquilla secondo Q03 (solo se TUTTI i criteri sono verificati; nel dubbio l'etichetta inferiore);
   - indicatore «momento critico» separato dalla gravità.
   Le soglie restano numeri di partenza da tarare sul corpus, non una calibrazione approvata. */
(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api; else root.CNApClassifica = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  var VERSIONE = 'cnap-class-1 (base r7c)';
  var R = {
    SOGLIE: { imp: 5, err: 10, bl: 20 }, MARGINE: 2, CHIARO: 75, PERSA: 10, PROTEZIONE_PERSA: true, PERSA_NEUTRA: true,
    FORTE_PRIMA: 20, FORTE_DOPO: 40, FORTE_UNICA: 10, FORTE_NO_RIPRESA: true, FORTE_PRUDENTE: true,
    MATTO_CERTO: true, MATTO_MAX: 10, MATTO_GRAVE: 3, VERIFICA_DA: 3,
    // Q03 (DECISO 18:18). Valori numerici = proposta tecnica configurabile:
    GENIALE_SACRIFICIO: 2,      // il materiale di chi muove scende di almeno 2 punti-pedone dopo la mossa e la migliore risposta
    TRANQUILLA_DELTA: 2         // la probabilità cambia al massimo di 2 punti
  };
  var NEGATIVE = { imprecisione: 1, errore: 1, blunder: 1 };
  var VAL = { p: 1, n: 3, b: 3, r: 5, q: 9, k: 0 };

  function classe(loss) { var M = R.MARGINE; return loss > R.SOGLIE.bl + M ? 'blunder' : loss > R.SOGLIE.err + M ? 'errore' : loss > R.SOGLIE.imp + M ? 'imprecisione' : null; }
  /* giudizio negativo r3–r7: null = nessuno; 'nogiud' = posizione già persa prima della mossa */
  function giudizio(loss, wB, wA) {
    var c = classe(loss); if (!c) return null;
    if (R.PROTEZIONE_PERSA && wB <= R.PERSA) return 'nogiud';
    if (wA >= R.CHIARO && (c === 'errore' || c === 'blunder')) c = 'imprecisione';
    return c;
  }
  function materiale(fen, lato) { var s = 0; fen.split(' ')[0].split('').forEach(function (ch) { var l = ch.toLowerCase(); if (VAL[l] !== undefined && /[a-z]/i.test(ch)) { var bianco = ch !== l; if ((lato === 'w') === bianco) s += VAL[l]; else s -= VAL[l]; } }); return s; }

  /* etichetta finale di UNA semimossa.
     x = {played, best (dopo verifica se c'è), loss, wB, wA (prob. chi muove), verificata:bool, verifica:{cl, mB, mG, gap, pA, wA, oriz, evid,
          sacrificio:{prima, dopo}, difficile:bool, secondaW}, veloce:{mate, best, gap}, teoria:bool, obbligata:bool, cattura:bool, scacco:bool} */
  function etichetta(x) {
    var cl = null, loss = x.loss, motivi = [], v = x.verifica || null;
    if (v) cl = v.cl;
    if (x.teoria) cl = 'teoria';
    else if (x.obbligata) { cl = 'obbligata'; loss = 0; }
    else if (!cl) cl = x.played === x.best ? 'migliore' : loss <= 2 + R.MARGINE ? 'ottima' : loss <= R.SOGLIE.imp + R.MARGINE ? 'buona' : (giudizio(loss, x.wB, x.wA) || 'buona');
    if (cl === 'svarione') cl = 'blunder';
    // matto certo (r7)
    var mB = v && v.mB !== undefined ? v.mB : (x.veloce && x.veloce.mate), mt = null;
    if (R.MATTO_CERTO && mB && cl !== 'teoria' && cl !== 'obbligata') {
      if (mB < 0) {
        var dd = v && v.mG != null && -mB <= R.MATTO_MAX ? -v.mG : null;
        if (dd !== null && dd < -mB) { cl = -mB - dd >= R.MATTO_GRAVE ? 'errore' : 'imprecisione'; mt = { accorcia: dd, k: -mB }; }
        else if (!NEGATIVE[cl]) { cl = 'nogiud'; mt = { decisa: 1 }; }
      } else if (v && v.mB > 0 && x.played !== x.best && mB <= R.MATTO_MAX && !NEGATIVE[cl]) {
        var dg = v.mG == null ? 99 : v.mG - mB;
        if (dg >= R.MATTO_GRAVE) { cl = 'imprecisione'; mt = { allunga: mB }; } else if (dg >= 1) { cl = 'buona'; mt = { allunga: mB }; }
      }
    }
    if (R.PERSA_NEUTRA && R.PROTEZIONE_PERSA && !mB && cl !== 'teoria' && cl !== 'obbligata' && cl !== 'nogiud' && !NEGATIVE[cl] && (v && v.wB !== undefined ? v.wB : x.wB) <= R.PERSA) cl = 'nogiud';
    // Q03 Geniale: migliore o quasi E (sacrificio OPPURE difficile) E necessaria E non già vinta comunque. Solo con verifica profonda.
    if (v && (cl === 'migliore' || cl === 'ottima' || cl === 'forte') && !mt) {
      var sac = v.sacrificio && v.sacrificio.dopo - v.sacrificio.prima <= -R.GENIALE_SACRIFICIO;
      var necessaria = v.gap != null && v.gap >= R.FORTE_UNICA;
      var giaVinta = v.secondaW != null && v.secondaW >= R.CHIARO;
      if ((sac || v.difficile) && necessaria && !giaVinta && loss <= 2 + R.MARGINE) {
        cl = 'geniale'; motivi = [sac ? 'sacrificio di materiale' : null, v.difficile ? 'trovata solo con la verifica più profonda' : null, 'senza questa mossa la posizione era chiaramente peggiore'].filter(Boolean);
      }
    }
    // Q03 Tranquilla: calma (né presa né scacco), cambia pochissimo la probabilità, una delle buone ma NON la prima scelta del motore.
    // INTERPRETAZIONE da confermare: la prima scelta resta «Migliore»; Tranquilla solo per Ottima/Buona.
    if ((cl === 'ottima' || cl === 'buona') && !x.cattura && !x.scacco && Math.abs((x.wB || 0) - (x.wA || 0)) <= R.TRANQUILLA_DELTA && loss <= R.TRANQUILLA_DELTA) cl = 'tranquilla';
    // momento critico: indicatore separato dalla gravità
    var critico = [];
    var gap = v && v.gap != null ? v.gap : x.veloce && x.veloce.gap;
    if (gap != null && gap >= R.FORTE_UNICA && cl !== 'obbligata') critico.push('una sola mossa buona');
    if (NEGATIVE[cl]) critico.push('errore');
    if (cl === 'geniale' || cl === 'forte') critico.push('combinazione riuscita');
    var out = { cl: cl, loss: Math.round(loss * 10) / 10, best: x.obbligata ? x.played : x.best, critico: critico.length ? critico : null, verificata: !!v };
    if (cl === 'tranquilla' || (cl === 'ottima' && out.loss === 0 && x.best && x.best !== x.played)) out.equivalente = out.loss === 0 && x.best !== x.played;
    if (mt) Object.keys(mt).forEach(function (k) { out[k] = mt[k]; });
    if (motivi.length) out.motivi = motivi;
    if (cl === 'forte') { out.pA = Math.round(v.pA); out.wA = Math.round(v.wA); out.gap = Math.round(v.gap); }
    return out;
  }
  /* la mossa entra nella precisione? (cnp-2 / r6 / r7c) */
  function contaInPrecisione(cl) { return cl !== 'teoria' && cl !== 'obbligata' && cl !== 'nogiud'; }

  return { R: R, classe: classe, giudizio: giudizio, etichetta: etichetta, materiale: materiale, contaInPrecisione: contaInPrecisione, NEGATIVE: NEGATIVE, VERSIONE: VERSIONE };
});
