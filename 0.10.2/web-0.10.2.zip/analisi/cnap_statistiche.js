/* Chess Node · Analisi profonda · FASE 1 · CNApStat — statistiche LEGGERE subito dopo l'archiviazione (A1-01 passo 3, maestro §3.11).
   Codice originale Chess Node (08/11/2026). Solo calcolo puro su partite già archiviate; nessun motore, nessuna precisione inventata.
   Regole: ogni numero ha denominatore e periodo; valore assente = null (in UI «—» o «Pochi dati»), mai zero implicito;
   risultato sconosciuto/in conflitto e colore ignoto esclusi da V/P/S CON conteggio esplicito; siti e ritmi mai fusi in un rating
   unico; precisione dei servizi tenuta per sito e mai mediata con stime Chess Node. */
(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api; else root.CNApStat = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  var VERSIONE = 'cnap-stat-leggere-1';
  var Ap = (typeof require === 'function' ? require('./cnap_aperture.js') : (typeof CNApAperture !== 'undefined' ? CNApAperture : null));

  function sitoDi(g) { var f = (g.sourceRefs || []).filter(function (s) { return s.source === 'lichess' || s.source === 'chesscom'; })[0]; return f ? f.source : (g.sourceRefs && g.sourceRefs[0] ? g.sourceRefs[0].source : 'file'); }
  function esito(g) {
    if (g.resultStatus !== 'dichiarato') return { k: 'sconosciute', motivo: g.resultStatus === 'conflitto' ? 'risultato in conflitto' : 'risultato non dichiarato' };
    if (!g.userColor) return { k: 'sconosciute', motivo: 'colore dell\'utente non identificato' };
    if (g.result === '1/2-1/2') return { k: 'patte' };
    return { k: (g.result === '1-0') === (g.userColor === 'w') ? 'vinte' : 'perse' };
  }
  function vuoto() { return { partite: 0, vinte: 0, patte: 0, perse: 0, sconosciute: 0, motiviSconosciute: {}, percentualeVittorie: null, denominatoreVPS: 0 }; }
  function aggiungi(b, e) {
    b.partite++; b[e.k]++;
    if (e.motivo) b.motiviSconosciute[e.motivo] = (b.motiviSconosciute[e.motivo] || 0) + 1;
  }
  function chiudi(b) {
    b.denominatoreVPS = b.vinte + b.patte + b.perse;
    b.percentualeVittorie = b.denominatoreVPS ? Math.round(1000 * b.vinte / b.denominatoreVPS) / 10 : null;
    return b;
  }

  /* filtro = {scope, da:'YYYY-MM', a:'YYYY-MM', sito, ritmo, colore} */
  function calcola(games, filtro) {
    filtro = filtro || {};
    var nDopp = 0;
    var sel = games.filter(function (g) {
      if (g.variant !== 'standard') return false;
      if (g.duplicateCandidateOf && g.duplicateCandidateOf.length) { nDopp++; return false; }
      if (filtro.scope && (g.scopeRefs || []).indexOf(filtro.scope) < 0) return false;
      if (filtro.da && (!g.monthRome || g.monthRome < filtro.da)) return false;
      if (filtro.a && (!g.monthRome || g.monthRome > filtro.a)) return false;
      if (filtro.sito && sitoDi(g) !== filtro.sito) return false;
      if (filtro.ritmo && g.timeClass !== filtro.ritmo) return false;
      if (filtro.colore && g.userColor !== filtro.colore) return false;
      return true;
    });
    var out = { versione: VERSIONE, filtro: filtro, zona: 'Europe/Rome', totale: vuoto(), perColore: { w: vuoto(), b: vuoto(), sconosciuto: vuoto() }, perRitmo: {}, perSito: {}, perMese: {}, aperture: [], apertureNonIdentificate: 0, rating: [], precisioneServizi: [], senzaData: 0, possibiliDoppioniEsclusi: nDopp };
    var ap = {}, rt = {}, acc = {};
    sel.forEach(function (g) {
      var e = esito(g), s = sitoDi(g), r = g.timeClass || 'sconosciuto';
      aggiungi(out.totale, e);
      aggiungi(out.perColore[g.userColor || 'sconosciuto'], e);
      aggiungi(out.perRitmo[r] = out.perRitmo[r] || vuoto(), e);
      aggiungi(out.perSito[s] = out.perSito[s] || vuoto(), e);
      if (g.monthRome) aggiungi(out.perMese[g.monthRome] = out.perMese[g.monthRome] || vuoto(), e); else out.senzaData++;
      if (!Ap || !Ap.daInizio(g)) { if (g.opening && g.opening.name) out.apertureNonIdentificate++; }
      else if (g.opening && (g.opening.name || g.opening.eco)) {
        var vis = Ap.visibile(g.opening), k = vis.chiave;
        if (!vis.nome) out.apertureNonIdentificate++;
        else { var a = ap[k] = ap[k] || { nome: vis.nome, eco: vis.eco, fonti: {}, conteggi: vuoto(), nomeGrezzo: vis.nomeGrezzo }; a.fonti[g.opening.fonte] = 1; if (vis.eco && !a.eco) a.eco = vis.eco; aggiungi(a.conteggi, e); }
      }
      else out.apertureNonIdentificate++;
      if (g.userColor && g.players[g.userColor].rating != null) {
        var k = s + '|' + r, avv = g.players[g.userColor === 'w' ? 'b' : 'w'].rating;
        var x = rt[k] = rt[k] || { sito: s, ritmo: r, tipo: 'rating-nelle-partite', punti: [], sommaAvv: 0, nAvv: 0 };
        x.punti.push({ ms: g.playedAtMs, data: g.playedDate, rating: g.players[g.userColor].rating, gameId: g.gameId });
        if (avv != null) { x.sommaAvv += avv; x.nAvv++; }
      }
      if (g.externalAccuracy && g.userColor && g.externalAccuracy[g.userColor] != null) {
        var q = acc[g.externalAccuracy.source] = acc[g.externalAccuracy.source] || { fonte: g.externalAccuracy.source, somma: 0, n: 0 };
        q.somma += g.externalAccuracy[g.userColor]; q.n++;
      }
    });
    chiudi(out.totale); ['w', 'b', 'sconosciuto'].forEach(function (c) { chiudi(out.perColore[c]); });
    Object.keys(out.perRitmo).forEach(function (k) { chiudi(out.perRitmo[k]); });
    Object.keys(out.perSito).forEach(function (k) { chiudi(out.perSito[k]); });
    Object.keys(out.perMese).forEach(function (k) { chiudi(out.perMese[k]); });
    out.aperture = Object.keys(ap).map(function (k) { var a = ap[k]; chiudi(a.conteggi); a.fonti = Object.keys(a.fonti); return a; })
      .sort(function (a, b) { return b.conteggi.partite - a.conteggi.partite || (a.nome < b.nome ? -1 : 1); });
    out.rating = Object.keys(rt).sort().map(function (k) {
      var x = rt[k]; x.punti.sort(function (a, b) { return (a.ms || 0) - (b.ms || 0); });
      return { sito: x.sito, ritmo: x.ritmo, tipo: x.tipo, campione: x.punti.length, punti: x.punti, avversarioMedio: x.nAvv ? Math.round(x.sommaAvv / x.nAvv) : null, avversariConRating: x.nAvv, nota: 'Rating del giocatore nelle partite caricate (non uno storico completo). Siti e ritmi separati.' };
    });
    out.precisioneServizi = Object.keys(acc).sort().map(function (k) { var q = acc[k]; return { fonte: q.fonte, media: Math.round(10 * q.somma / q.n) / 10, partite: q.n, nota: 'Calcolata dal servizio, non da Chess Node: non confrontabile né mediabile con la stima Chess Node.' }; });
    out.partiteNelFiltro = sel.length;
    return out;
  }

  return { calcola: calcola, sitoDi: sitoDi, esito: esito, VERSIONE: VERSIONE };
});
