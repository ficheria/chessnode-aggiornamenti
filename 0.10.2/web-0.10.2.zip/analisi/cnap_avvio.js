/* Chess Node · Analisi profonda · FASE 6 (rev. 2) · CNApAvvio — apertura del database unico, trasferimento dal vecchio archivio
   dell'allenamento e CONSERVAZIONE del vecchio archivio (decisioni di Kiko, 09/11 22:54). Codice originale Chess Node.
   Regole:
   - se il database v2 non si apre (es. un'altra scheda tiene aperta la v1) → errore chiaro e «Riprova»; MAI un archivio in memoria
     al suo posto, MAI un'app che sembra funzionare fino al ricaricamento;
   - se il trasferimento fallisce → il vecchio archivio resta com'è, errore chiaro, nuovo tentativo possibile: il trasferimento è
     idempotente e non sovrascrive (il rapporto dice quanti record c'erano già: «giaPresenti»);
   - dopo il trasferimento il vecchio archivio è una copia di sicurezza in SOLA LETTURA: 7 giorni di finestra di verifica, conservato
     com'è fino a 30 giorni; dopo 30 giorni si può eliminare SOLO se tutti i controlli sono riusciti (trasferimento verificato, app
     chiusa e riaperta, nuovo salvataggio riletto, secondo riavvio con i dati presenti) e nessun problema è aperto. Mai in automatico.
   - date e controlli in meta: 'vecchioDb:chessnodeplay-allenamento'. */
(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api; else root.CNApAvvio = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  var GIORNO = 86400000, VERIFICA_GIORNI = 7, CONSERVA_GIORNI = 30, CHIAVE = 'vecchioDb:chessnodeplay-allenamento';
  var CONTROLLI = ['trasferimento', 'riavvio', 'scritturaLettura', 'secondoRiavvio'];
  var TESTI = {
    BLOCCATO: 'Chess Node è aperto anche in un\'altra scheda o finestra con una versione precedente: chiudila e premi «Riprova». Finché l\'archivio non si apre, analisi e allenamento restano fermi.',
    APERTURA: 'L\'archivio di Chess Node non si apre su questo dispositivo. Nessun dato è stato modificato. Premi «Riprova»; se l\'errore resta, esporta un backup.',
    MIGRAZIONE: 'Il trasferimento dei tuoi esercizi nel nuovo archivio non è riuscito. Il vecchio archivio resta com\'era: non è stato cancellato nulla. L\'allenamento resta fermo finché non riesce; premi «Riprova»: i progressi non verranno duplicati.'
  };

  async function leggiMeta(b, k) { return b.tx(['meta'], 'readonly', async function (t) { var m = await t.get('meta', k); return m ? m.valore : null; }); }
  async function scriviMeta(b, k, v, ora) { await b.tx(['meta'], 'readwrite', function (t) { return t.put('meta', { key: k, valore: v, aggiornato: ora }); }); }

  /* d = {CNApDbV2, apriV2: () => backend v2, apriVecchio: () => backend del vecchio archivio | null (se non esiste), ora} */
  function crea(d) {
    var V2 = d.CNApDbV2, ora = d.ora || function () { return Date.now(); };
    function err(codice, extra) { return Object.assign({ stato: 'errore', codice: codice, messaggio: TESTI[codice], puoRiprovare: true, allenamentoDisponibile: false, analisiDisponibile: false }, extra || {}); }

    async function apri() {
      var b = d.apriV2();
      try { if (b.prova) await b.prova(); else await b.tx(['meta'], 'readonly', function (t) { return t.get('meta', 'impostazioni'); }); }
      catch (e) { try { if (b.chiudi) await b.chiudi(); } catch (e2) {} return err(e && e.code === 'BLOCCATO' ? 'BLOCCATO' : 'APERTURA', { dettaglio: e && e.message }); }
      var stato, vecchio = null;
      try { stato = await leggiMeta(b, CHIAVE); } catch (e0) { return err('APERTURA', { dettaglio: e0 && e0.message }); }   // niente eccezione grezza: errore con «Riprova»
      try { vecchio = d.apriVecchio ? await d.apriVecchio() : null; }
      catch (e) {   // vecchio archivio che c'è ma non si apre: NON è «nessun vecchio archivio» (niente successo finto)
        if (!(stato && stato.verificato)) return err('MIGRAZIONE', { backend: b, analisiDisponibile: true, dettaglio: e && e.message });
        vecchio = null;
      }
      if (vecchio && !(stato && stato.verificato)) {
        var tentativi = (stato && stato.tentativi || 0) + 1, rep = null, errore = null;
        try { rep = await V2.trasferisciAllenamento(V2.soloLettura(vecchio), b, { ora: ora() }); } catch (e) { errore = e; }
        if (errore || !rep || !rep.verificato) {
          try { await scriviMeta(b, CHIAVE, Object.assign({}, stato || {}, { verificato: false, tentativi: tentativi, ultimoErrore: errore ? errore.message : 'verifica non superata', ultimoTentativo: ora(), cancellato: false }), ora()); } catch (e3) {}
          return err('MIGRAZIONE', { backend: b, analisiDisponibile: true, dettaglio: errore ? errore.message : 'verifica non superata', rapporto: rep, tentativi: tentativi });
        }
        var t0 = ora();
        stato = { migratoIl: t0, verificaFinoAl: t0 + VERIFICA_GIORNI * GIORNO, cancellazionePossibileDal: t0 + CONSERVA_GIORNI * GIORNO, verificato: true, tentativi: tentativi,
          controlli: { trasferimento: { esito: true, quando: t0, rapporto: { copiati: rep.copiati, giaPresenti: rep.giaPresenti, seq: rep.seqDopo } }, riavvio: null, scritturaLettura: null, secondoRiavvio: null },
          problemi: [], cancellato: false, soloLettura: true, nota: 'Copia di sicurezza: nessun codice la apre in scrittura. Nessuna cancellazione automatica.' };
        try { await scriviMeta(b, CHIAVE, stato, ora()); }
        catch (e4) { return err('MIGRAZIONE', { backend: b, analisiDisponibile: true, dettaglio: e4 && e4.message, rapporto: rep, tentativi: tentativi }); }   // dati copiati ma stato non salvato: «Riprova» li trova «già presenti»
        return { stato: 'pronto', backend: b, migrazione: { eseguita: true, rapporto: rep }, vecchioDb: await statoSicuro(b), allenamentoDisponibile: true, analisiDisponibile: true };
      }
      return { stato: 'pronto', backend: b, migrazione: { eseguita: false, motivo: vecchio ? 'già trasferito e verificato' : 'nessun vecchio archivio' }, vecchioDb: await statoSicuro(b), allenamentoDisponibile: true, analisiDisponibile: true };
    }

    /* controlli per l'integrazione e il test sul telefono: 'riavvio', 'scritturaLettura', 'secondoRiavvio' (esito true/false) */
    async function registraControllo(b, nome, esito, nota) {
      if (CONTROLLI.indexOf(nome) < 0) throw new Error('Controllo sconosciuto: ' + nome);
      var s = await leggiMeta(b, CHIAVE); if (!s) throw new Error('Nessuna migrazione registrata.');
      s.controlli[nome] = { esito: !!esito, quando: ora(), nota: nota || null };
      if (!esito) s.problemi.push({ controllo: nome, quando: ora(), nota: nota || null, risolto: false });
      await scriviMeta(b, CHIAVE, s, ora()); return statoVecchio(b);
    }
    async function risolviProblema(b, indice, nota) { var s = await leggiMeta(b, CHIAVE); if (s && s.problemi[indice]) { s.problemi[indice].risolto = true; s.problemi[indice].risoltoIl = ora(); s.problemi[indice].notaRisoluzione = nota || null; await scriviMeta(b, CHIAVE, s, ora()); } return statoVecchio(b); }
    /* prova di scrittura e rilettura sul database nuovo (per il controllo «scritturaLettura» all'integrazione) */
    async function provaScritturaLettura(b) {
      var k = 'prova:scrittura-lettura', v = { scrittoIl: ora(), valore: Math.random().toString(36).slice(2) };
      await scriviMeta(b, k, v, ora()); var r = await leggiMeta(b, k); return !!(r && r.valore === v.valore);
    }

    async function statoSicuro(b) { try { return await statoVecchio(b); } catch (e) { return { fase: 'sconosciuto', testo: 'Stato della copia di sicurezza non leggibile ora.' }; } }   // solo informativo: non blocca l'avvio
    async function statoVecchio(b) {
      var s = await leggiMeta(b, CHIAVE), adesso = ora();
      if (!s) return { fase: 'nessuno', testo: 'Nessuna migrazione registrata.' };
      if (s.cancellato) return { fase: 'cancellato', quando: s.cancellatoIl };
      if (!s.verificato) return { fase: 'bloccato', motivi: ['trasferimento non verificato'], testo: 'Migrazione non verificata: il vecchio archivio resta e non si cancella.' };
      var motivi = [];
      CONTROLLI.forEach(function (c) { if (!(s.controlli[c] && s.controlli[c].esito === true)) motivi.push('controllo «' + c + '» ' + (s.controlli[c] ? 'non riuscito' : 'non ancora fatto')); });
      s.problemi.forEach(function (p) { if (!p.risolto) motivi.push('problema aperto: ' + p.controllo); });
      var fase = adesso <= s.verificaFinoAl ? 'verifica' : adesso < s.cancellazionePossibileDal ? 'conservazione' : motivi.length ? 'bloccato' : 'eliminabile';
      return { fase: fase, migratoIl: s.migratoIl, verificaFinoAl: s.verificaFinoAl, cancellazionePossibileDal: s.cancellazionePossibileDal, motivi: motivi, eliminabile: fase === 'eliminabile',
        testo: fase === 'verifica' ? 'Primi 7 giorni: verifica del trasferimento.' : fase === 'conservazione' ? 'Copia di sicurezza conservata fino al 30° giorno.' : fase === 'eliminabile' ? 'Tutti i controlli riusciti: la copia di sicurezza si può eliminare (solo su richiesta).' : 'Cancellazione non consentita: ' + motivi.join('; ') + '.' };
    }
    /* eliminazione SOLO su richiesta esplicita e solo se «eliminabile»; elimina = funzione che cancella il vecchio database */
    async function eliminaVecchio(b, elimina) {
      var st = await statoVecchio(b); if (!st.eliminabile) return { eliminato: false, stato: st };
      await elimina(); var s = await leggiMeta(b, CHIAVE); s.cancellato = true; s.cancellatoIl = ora(); await scriviMeta(b, CHIAVE, s, ora());
      return { eliminato: true, stato: await statoVecchio(b) };
    }
    return { apri: apri, registraControllo: registraControllo, risolviProblema: risolviProblema, provaScritturaLettura: provaScritturaLettura, statoVecchio: statoVecchio, eliminaVecchio: eliminaVecchio };
  }

  /* esiste un database IndexedDB con questo nome? Senza crearlo: se l'apertura chiede un aggiornamento da 0, si annulla */
  function esisteIDB(IDB, nome) {
    return new Promise(function (res, rej) {
      var rq = IDB.open(nome), nuovo = false;
      rq.onupgradeneeded = function () { nuovo = true; rq.transaction.abort(); };
      rq.onsuccess = function () { rq.result.close(); res(!nuovo); };
      rq.onerror = function (e) { if (e && e.preventDefault) e.preventDefault(); if (nuovo) res(false); else rej(rq.error || new Error('apertura del vecchio archivio non riuscita')); };   // nuovo = creazione annullata da noi
      rq.onblocked = function () { res(true); };
    });
  }
  return { crea: crea, esisteIDB: esisteIDB, CHIAVE: CHIAVE, CONTROLLI: CONTROLLI, TESTI: TESTI, VERIFICA_GIORNI: VERIFICA_GIORNI, CONSERVA_GIORNI: CONSERVA_GIORNI };
});
