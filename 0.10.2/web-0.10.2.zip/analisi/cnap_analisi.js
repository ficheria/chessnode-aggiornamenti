/* Chess Node · Analisi profonda · FASE 2 · CNApAnalisi — passi 4–5 della pipeline: Stockfish sul campione e classificazione (A1-05, A1-06, A1-08).
   Codice originale Chess Node (08/11/2026). Procedura PORTATA da analisi_partita.js r7c (codice di Kiko): passata veloce a profondità fissa,
   verifica multipv 3 dei candidati, trattamento orizzonte, ricontrollo dei giudizi negativi, etichette. Differenze:
   - il motore passa SOLO dallo scheduler unico (priorità batch, cede all'interattivo);
   - checkpoint nell'archivio (store analysisJobs) dopo OGNI ricerca completata; una ricerca fermata non vale e si rifà;
   - passata veloce con MultiPV 2 (serve a «Tranquilla» e al momento critico; costo in più da misurare);
   - commit finale in UNA transazione (analisi + stato partita); nessun parziale diventa «analizzata»;
   - metadati motore reali, impostazioni e versioni nel record; PV controllate legalmente con chess.js;
   - lato di ogni semimossa dal replay (A1-C07), probabilità unica CNApPunteggio.P (A1-C03), WDL conservato per la visualizzazione;
   - fasi di gioco (Q11) e temi (Q01) calcolati sugli stessi dati verificati;
   - nessuna rete: niente cloud-eval, niente fallback remoto (A1-C02).
   Teoria: senza un elenco aperture approvato nessuna mossa è etichettata «Teoria» (funzione libro iniettabile). */
(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api; else root.CNApAnalisi = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  var LIVELLI = { standard: { depth: 17, vdepth: 21, rdepth: 24 }, approfondito: { depth: 20, vdepth: 24, rdepth: null } };   // come analisi_partita.js

  function crea(d) {
    var S = d.scheduler, A = d.archivio, Chess = d.Chess, Pt = d.CNApPunteggio, Cl = d.CNApClassifica, Fasi = d.CNApFasi || null, Temi = d.CNApTemi || null, U = d.CNApUtil;
    var ora = d.ora || function () { return Date.now(); };
    var libro = d.libro || function () { return []; };
    var MAX_MS = d.maxMs || 20000;
    /* linee della passata veloce: CONFIGURABILE (Kiko 08/11 23:28), default 2; si decide dopo la misura sul telefono. Entra nella versione. */
    var MPV_VELOCE = Math.max(1, Math.min(3, d.multipvVeloce || 2));
    var R = Cl.R, LIV = Object.assign({}, LIVELLI, d.livelli || {});   // livelli extra (es. «prova» a profondità basse) solo per i test
    function err(code, msg) { var e = new Error(msg); e.code = code; return e; }

    function chiaveVersione(livello, meta) {
      var L = LIV[livello];
      return U.hash([Cl.VERSIONE, Pt.VERSIONE, meta && meta.build || 'motore?', livello, L.depth, L.vdepth, L.rdepth, 'mpv' + MPV_VELOCE, Temi ? Temi.VERSIONE : '-', Fasi ? Fasi.VERSIONE : '-'].join('|'));
    }

    /* PV legale? ritorna SAN o null */
    function pvLegale(fen, pv) {
      try { var c = new Chess(fen), out = []; for (var i = 0; i < pv.length; i++) { var u = pv[i], m = c.move({ from: u.slice(0, 2), to: u.slice(2, 4), promotion: u[4] }); if (!m) return null; out.push(m.san); } return out; } catch (e) { return null; }
    }
    /* righe del motore → [{uci, score, cp, mate, wdl, depth, pv, pvSan}] nel punto di vista di chi muove; PV illegali scartate */
    function righe(res, fen) {
      return (res.linee || []).map(function (l) {
        var san = pvLegale(fen, l.pv); if (!san) return null;
        return { uci: l.pv[0], score: l.score, cp: Pt.cpDi(l.score), mate: l.score.tipo === 'mate' ? l.score.valore : null, wdl: l.wdl || null, depth: l.depth, pv: l.pv.slice(0, 12), pvSan: san.slice(0, 12) };
      }).filter(Boolean);
    }

    async function cercaVerificata(ctx, fen, nodeId, opz) {
      for (var t = 0; t < 3; t++) {
        if (ctx.segnale && ctx.segnale.aborted) throw err('ANNULLATO', 'Analisi interrotta: i risultati completi restano salvati.');
        var res = await S.cerca({ owner: ctx.owner, priorita: ctx.priorita, gameId: ctx.gameId, nodeId: nodeId, fen: fen, opz: Object.assign({ maxMs: MAX_MS, pulisci: true }, opz), versione: ctx.versione });
        if (ctx.meta == null) ctx.meta = res.motore;
        if (res.identita.fen !== fen || res.identita.nodeId !== nodeId) continue;   // mai un risultato su posizione diversa
        if (res.nessunaMossa) return { over: true, linee: [] };
        var r = righe(res, fen);
        if (r.length && res.completa) return { linee: r, prof: res.profonditaRaggiunta };
        ctx.incomplete = (ctx.incomplete || 0) + 1;   // fermata per tempo o PV illegali: si riprova
      }
      throw err('MOTORE_INCOMPLETO', 'Il motore non ha completato la ricerca richiesta: posizione non valutata (nessun giudizio).');
    }

    /* dati della linea principale dall'archivio */
    async function partitaDaArchivio(gameId) {
      var g = await A.partita(gameId); if (!g) throw err('NON_TROVATA', 'Partita non trovata.');
      var nodi = await A.nodi(gameId), per = {}; nodi.forEach(function (n) { per[n.nodeId] = n; });
      var ids = [g.rootNodeId], k = g.rootNodeId;
      while (per[k] && per[k].childIds.length && per[per[k].childIds[0]] && per[per[k].childIds[0]].mainLine) { k = per[k].childIds[0]; ids.push(k); }
      var c = new Chess(g.startFen), fens = [c.fen()], ucis = [], cols = [], cat = [], chk = [];
      for (var i = 1; i < ids.length; i++) { var u = per[ids[i]].uci, m = c.move({ from: u.slice(0, 2), to: u.slice(2, 4), promotion: u[4] }); ucis.push(u); cols.push(m.color); cat.push(!!m.captured); chk.push(/[+#]/.test(m.san)); fens.push(c.fen()); }
      return { g: g, start: g.startFen, ids: ids, fens: fens, ucis: ucis, cols: cols, cattura: cat, scacco: chk };
    }

    /* analizza UNA partita; o = {livello, owner, priorita:'batch', segnale, onProgress, manuale} */
    async function analizzaPartita(gameId, o) {
      o = o || {};
      var livello = o.livello || 'standard', L = LIV[livello], p = await partitaDaArchivio(gameId), n = p.ucis.length;
      var ctx = { owner: o.owner || 'batch', priorita: o.priorita || 'batch', gameId: gameId, segnale: o.segnale, meta: null };
      var imp = await A.impostazioni();
      if (imp.analisiSospese && imp.analisiSospese.motivo === 'spazio') throw err('SPAZIO', 'Analisi sospese per spazio insufficiente: scegli cosa liberare o esporta un backup.');
      if (S.avvia) await S.avvia();   // CORREZIONE fase 3: senza avvio la prima analisi della sessione aveva una versione «motore?» diversa dalle successive
      var meta0 = S.meta(); var vkey = chiaveVersione(livello, meta0 && meta0.build ? meta0 : null);
      ctx.versione = vkey;
      var jobId = 'J-' + gameId + '-' + livello;
      var rec = await A.tx(['analysisJobs'], 'readonly', function (t) { return t.get('analysisJobs', jobId); });
      if (!rec || rec.versionKey !== vkey) rec = { jobId: jobId, gameId: gameId, livello: livello, versionKey: vkey, status: 'in corso', stage: 'veloce', E: [], V: {}, creatoIl: ora(), ricerche: 0 };
      else rec.ripreso = (rec.ripreso || 0) + 1;
      async function salva() { rec.aggiornatoIl = ora(); await A.tx(['analysisJobs'], 'readwrite', function (t) { return t.put('analysisJobs', rec); }); }
      await A.tx(['games'], 'readwrite', async function (t) { var g = await t.get('games', gameId); g.archiveState = 'in analisi'; g.analysisJob = { jobId: jobId, stage: rec.stage, fatte: rec.E.filter(Boolean).length, di: n + 1 }; await t.put('games', g); });
      function prog() { if (o.onProgress) o.onProgress({ gameId: gameId, stage: rec.stage, posizioniFatte: rec.E.filter(Boolean).length, posizioni: n + 1, verifiche: Object.keys(rec.V).length }); }
      try {
        // 1) passata veloce (riparte dalla prima posizione non valutata)
        for (var i = 0; i <= n; i++) {
          if (rec.E[i]) continue;
          var g = new Chess(p.fens[i]);
          if (g.isGameOver()) rec.E[i] = { over: 1, cp: g.isCheckmate() ? -Pt.CLIP : 0, mate: g.isCheckmate() ? 0 : null, best: null };
          else {
            var r = await cercaVerificata(ctx, p.fens[i], p.ids[i], { depth: L.depth, multipv: MPV_VELOCE });
            if (r.over) rec.E[i] = { over: 1, cp: 0, best: null };
            else { var a = r.linee[0], b = r.linee[1]; rec.E[i] = { cp: a.cp, mate: a.mate, best: a.uci, wdl: a.wdl, depth: a.depth, pv: a.pvSan.slice(0, 8), second: b ? { uci: b.uci, cp: b.cp, mate: b.mate } : null, nLegali: g.moves().length }; }
          }
          rec.ricerche++; await salva(); prog();
        }
        // 2) candidati e verifica (come r7c + candidati Geniale)
        var book = libro(p), win = Pt.P;
        function veloce(j) { var wB = win(rec.E[j].cp), wA = win(-rec.E[j + 1].cp); return { wB: wB, wA: wA, calo: Math.max(0, wB - wA), loss: p.ucis[j] === rec.E[j].best ? 0 : Math.max(0, wB - wA) }; }
        function gapVeloce(j) { var e = rec.E[j]; return e.second ? win(e.cp) - win(e.second.cp) : null; }
        var obbl = []; for (var o2 = 0; o2 < n; o2++) obbl.push(new Chess(p.fens[o2]).moves().length === 1);
        function primaAvv(j) { return j > 0 ? 100 - win(rec.E[j - 1].cp) : 50; }
        function forseForte(j, v) { return j > 0 && primaAvv(j) <= R.FORTE_PRIMA && v.wA >= R.FORTE_DOPO - 5 && v.loss <= 2 + R.MARGINE; }
        function forseGeniale(j, v) {   // candidato Geniale: mossa (quasi) migliore che lascia materiale, o unica buona
          if (v.loss > 2 + R.MARGINE) return false;
          var gp = gapVeloce(j); if (gp != null && gp >= R.FORTE_UNICA) return true;
          try { var c = new Chess(p.fens[j]), m = c.move({ from: p.ucis[j].slice(0, 2), to: p.ucis[j].slice(2, 4), promotion: p.ucis[j][4] }); var att = c.moves({ verbose: true }).filter(function (x) { return x.to === m.to; }); return att.length > 0 && !m.captured; } catch (e) { return false; }
        }
        rec.stage = 'verifica'; var cand = [];
        for (var j = 0; j < n; j++) {
          var v = veloce(j);
          if (book.indexOf(j) < 0 && !obbl[j] && (v.calo > R.VERIFICA_DA || forseForte(j, v) || forseGeniale(j, v) || (R.MATTO_CERTO && rec.E[j].mate && p.ucis[j] !== rec.E[j].best)) && !rec.V[j]) cand.push(j);
        }
        async function verifica(k, vd) {
          var d1r = await cercaVerificata(ctx, p.fens[k], p.ids[k], { depth: vd, multipv: 3 }), d1 = d1r.linee; rec.ricerche++;
          var wB2 = win(d1[0].cp), mia = d1.filter(function (x) { return x.uci === p.ucis[k]; })[0], wA2, d2 = null;
          if (mia) wA2 = win(mia.cp);
          else if (rec.E[k + 1].over) wA2 = win(-rec.E[k + 1].cp);
          else { d2 = (await cercaVerificata(ctx, p.fens[k + 1], p.ids[k + 1], { depth: vd, multipv: 1 })).linee; rec.ricerche++; wA2 = win(-d2[0].cp); }
          var loss2 = p.ucis[k] === d1[0].uci ? 0 : Math.max(0, wB2 - wA2), bestV = d1[0].uci, wRif = wB2, oriz = 0;
          if (p.ucis[k] === d1[0].uci && !rec.E[k + 1].over && veloce(k).calo > R.VERIFICA_DA) {   // orizzonte (r5)
            var d3 = (await cercaVerificata(ctx, p.fens[k + 1], p.ids[k + 1], { depth: vd, multipv: 1 })).linee; rec.ricerche++;
            var wDopo = win(-d3[0].cp), rif = d1.length > 1 ? win(d1[1].cp) : wB2;
            if (Cl.giudizio(Math.max(0, rif - wDopo), rif, wDopo)) { loss2 = Math.max(0, rif - wDopo); wA2 = wDopo; wRif = rif; bestV = d1.length > 1 ? d1[1].uci : null; oriz = 1; }
            else wA2 = Math.min(wA2, wDopo);
          }
          var gap = d1.length > 1 ? wB2 - win(d1[1].cp) : null, pA = rec.V[k - 1] ? 100 - rec.V[k - 1].wB : primaAvv(k);
          var ripresa = k > 0 && p.ucis[k].slice(2, 4) === p.ucis[k - 1].slice(2, 4), evid = false;
          if (R.FORTE_PRUDENTE && k > 0) { var vp = rec.V[k - 1], lp = vp ? vp.loss : veloce(k - 1).loss; evid = lp > R.SOGLIE.err + R.MARGINE && (p.cattura[k] || p.scacco[k]); }
          var forte = !oriz && !evid && p.ucis[k] === d1[0].uci && !(R.FORTE_NO_RIPRESA && ripresa) && pA <= R.FORTE_PRIMA && Math.min(wB2, wA2) >= R.FORTE_DOPO && gap != null && gap >= R.FORTE_UNICA;
          var mB = d1[0].mate, mG = null;
          if (mB > 0) { if (mia) mG = mia.mate > 0 ? mia.mate : null; else if (rec.E[k + 1].over) mG = new Chess(p.fens[k + 1]).isCheckmate() ? 1 : null; else if (d2) mG = d2[0].mate !== null && d2[0].mate < 0 ? 1 - d2[0].mate : null; }
          else if (mB < 0) { if (mia) mG = mia.mate < 0 ? mia.mate : null; else if (d2) mG = d2[0].mate > 0 ? -d2[0].mate : null; }
          // Q03: sacrificio (materiale dopo mossa + miglior risposta dalla linea verificata) e difficoltà (vista solo più in profondità)
          var sac = null;
          if (mia && mia.pv.length >= 2) { try { var c2 = new Chess(p.fens[k]); c2.move({ from: mia.pv[0].slice(0, 2), to: mia.pv[0].slice(2, 4), promotion: mia.pv[0][4] }); c2.move({ from: mia.pv[1].slice(0, 2), to: mia.pv[1].slice(2, 4), promotion: mia.pv[1][4] }); sac = { prima: Cl.materiale(p.fens[k], p.cols[k]), dopo: Cl.materiale(c2.fen(), p.cols[k]) }; } catch (e) {} }
          var difficile = p.ucis[k] === d1[0].uci && rec.E[k].best !== p.ucis[k];
          return { loss: loss2, wA: wA2, best: bestV, wB: wB2, gap: gap, pA: pA, oriz: oriz, cl: forte ? 'forte' : Cl.giudizio(loss2, wRif, wA2), mB: mB, mG: mG, evid: evid ? 1 : 0,
            sacrificio: sac, difficile: difficile, secondaW: d1.length > 1 ? win(d1[1].cp) : null, linee: d1.map(function (x) { return { uci: x.uci, cp: x.cp, mate: x.mate, wdl: x.wdl, depth: x.depth, pvSan: x.pvSan }; }), profondita: vd };
        }
        for (var c = 0; c < cand.length; c++) { rec.V[cand[c]] = await verifica(cand[c], L.vdepth); await salva(); prog(); }
        // 2b) ricontrollo dei giudizi negativi a profondità rdepth (r6)
        if (L.rdepth) {
          rec.stage = 'ricontrollo';
          var ric = Object.keys(rec.V).map(Number).sort(function (a, b) { return a - b; }).filter(function (k) { return rec.V[k] && Cl.NEGATIVE[rec.V[k].cl === 'svarione' ? 'blunder' : rec.V[k].cl] && !rec.V[k].ric; });
          for (var r3 = 0; r3 < ric.length; r3++) { var k3 = ric[r3], prima = rec.V[k3], dopo = await verifica(k3, L.rdepth); dopo.ric = 1; dopo.v1 = { cl: prima.cl, loss: prima.loss, best: prima.best }; rec.V[k3] = dopo; await salva(); prog(); }
        }
        // 3) etichette, precisione, fasi, temi → record di analisi; commit unico
        rec.stage = 'etichette';
        var risultato = componi(p, rec, book, obbl, veloce, gapVeloce, livello, ctx);
        await A.tx(['games', 'analyses', 'analysisJobs'], 'readwrite', async function (t) {
          var gg = await t.get('games', gameId), prec = gg.localAnalysisId ? await t.get('analyses', gg.localAnalysisId) : null;
          risultato.analysisRevision = prec ? (prec.analysisRevision || 0) + 1 : 1;
          risultato.analysisId = 'AN-' + gameId + '-r' + risultato.analysisRevision;
          if (prec && prec.status === 'complete') { prec.status = 'superseded'; prec.supersededBy = risultato.analysisId; await t.put('analyses', prec); }
          await t.put('analyses', risultato);
          gg.localAnalysisId = risultato.analysisId; gg.archiveState = 'analizzata'; delete gg.analysisJob; gg.analysisStale = false; gg.fuoriCampione = !!o.manuale && !(gg.sampling && gg.sampling.selectedForEngine);
          await t.put('games', gg); await t.del('analysisJobs', jobId);
        });
        prog();
        return risultato;
      } catch (e) {
        try { await salva(); } catch (e2) {}
        await A.tx(['games'], 'readwrite', async function (t) { var g = await t.get('games', gameId); g.archiveState = g.localAnalysisId ? 'analizzata' : 'in attesa'; g.analysisJob = { jobId: jobId, stage: rec.stage, fatte: rec.E.filter(Boolean).length, di: n + 1, sospesa: true, motivo: e.code || 'errore' }; await t.put('games', g); });
        throw e;
      }
    }

    function componi(p, rec, book, obbl, veloce, gapVeloce, livello, ctx) {
      var n = p.ucis.length, pos = [], acc = { w: [], b: [] }, cnt = { w: {}, b: {} };
      var fasi = Fasi ? Fasi.fasi(p.fens) : null;
      for (var m = 0; m < n; m++) {
        var q = veloce(m), V = rec.V[m] || null, best = V ? V.best : rec.E[m].best, loss = V ? V.loss : q.loss;
        var lab = Cl.etichetta({ played: p.ucis[m], best: best, loss: loss, wB: V ? V.wB : q.wB, wA: V ? V.wA : q.wA, verifica: V, veloce: { mate: rec.E[m].mate, best: rec.E[m].best, gap: gapVeloce(m) }, teoria: book.indexOf(m) >= 0, obbligata: obbl[m], cattura: p.cattura[m], scacco: p.scacco[m] });
        var lato = p.cols[m];
        if (lab.cl !== 'nogiud') cnt[lato][lab.cl] = (cnt[lato][lab.cl] || 0) + 1;
        if (Cl.contaInPrecisione(lab.cl)) acc[lato].push(Pt.accMossa(lab.loss));
        var eDopo = rec.E[m + 1], sDopo = eDopo.over ? (eDopo.mate === 0 ? { tipo: 'mate', valore: 0 } : { tipo: 'cp', valore: 0 }) : (eDopo.mate != null ? { tipo: 'mate', valore: eDopo.mate } : { tipo: 'cp', valore: eDopo.cp });
        var trattoDopo = p.fens[m + 1].split(' ')[1];
        pos.push({ ply: m + 1, nodeIdBefore: p.ids[m], nodeId: p.ids[m + 1], side: lato, played: p.ucis[m], best: lab.best, label: lab.cl, labelInfo: lab, wB: Math.round((V ? V.wB : q.wB) * 10) / 10, wA: Math.round((V ? V.wA : q.wA) * 10) / 10,
          evalAfterWhite: eDopo.over && eDopo.mate === 0 ? { tipo: 'mate', valore: 0, matto: trattoDopo === 'w' ? 'nero' : 'bianco' } : Pt.aBianco(sDopo, trattoDopo),
          wdlAfter: eDopo.wdl || null, trattoDopo: trattoDopo, depthFast: eDopo.depth || null, verified: !!V, verifyDepth: V ? V.profondita : null, lines: V ? V.linee : null, critical: !!lab.critico, criticalReasons: lab.critico, phase: fasi ? fasi[m + 1] : null });
      }
      var e0 = rec.E[0];
      var root = { nodeId: p.ids[0], evalWhite: e0.over ? null : Pt.aBianco(e0.mate != null ? { tipo: 'mate', valore: e0.mate } : { tipo: 'cp', valore: e0.cp }, p.fens[0].split(' ')[1]), wdl: e0.wdl || null };
      var temi = Temi ? Temi.rileva({ gameId: p.g.gameId, fens: p.fens, ucis: p.ucis, ids: p.ids, cols: p.cols, posizioni: pos, verifiche: rec.V, Chess: Chess }) : null;
      var meta = ctx.meta || S.meta() || {}, L = LIV[livello];
      return {
        schemaVersion: 1, gameId: p.g.gameId, status: 'complete', livello: livello, versionKey: rec.versionKey,
        validationVersion: 'cnap-rules-1', classificationVersion: Cl.VERSIONE, probabilityModel: { classificazione: 'cnp-2 P(cp)=100/(1+10^(-cp/400))', visualizzazione: meta.wdl ? 'stockfish-wdl' : 'cnp-2-logistica' },
        detectorVersion: Temi ? Temi.VERSIONE : null, phaseVersion: Fasi ? Fasi.VERSIONE : null,
        engineMetadata: { name: meta.nome || null, build: meta.build || null, wdl: !!meta.wdl, threadsMax: meta.threadsMax, depthRequested: { veloce: L.depth, verifica: L.vdepth, ricontrollo: L.rdepth }, multiPV: { veloce: MPV_VELOCE, verifica: 3 }, hashMb: 16, ricerche: rec.ricerche, ricercheIncomplete: ctx.incomplete || 0, budgetExceeded: false, locale: true },
        root: root, positionResults: pos, counts: cnt, accuracy: { w: Pt.media(acc.w), b: Pt.media(acc.b), formula: 'cnp-2', mosseContate: { w: acc.w.length, b: acc.b.length } },
        themes: temi, completedAt: ora(), eligibleForProfile: true, invalidationReason: null, contentHash: U.hash(p.start + '|' + p.ucis.join(' '))
      };
    }

    /* A1-08: dopo un cambio di motore/regole le analisi incompatibili diventano «precedenti» (mai cancellate) e si accoda la rivalidazione */
    async function inventariaObsolete(livello) {
      if (S.avvia) await S.avvia();
      var meta = S.meta(), vkey = chiaveVersione(livello || 'standard', meta && meta.build ? meta : null), stale = [];
      await A.tx(['analyses', 'games'], 'readwrite', async function (t) {
        var all = await t.all('analyses');
        for (var i = 0; i < all.length; i++) {
          var a = all[i]; if (a.status !== 'complete' || a.versionKey === vkey) continue;
          a.status = 'stale'; a.eligibleForProfile = false; a.invalidationReason = 'Motore o regole cambiati: analisi precedente, da rivalidare.'; await t.put('analyses', a);
          var g = await t.get('games', a.gameId); if (g) { g.analysisStale = true; await t.put('games', g); } stale.push(a.gameId);
        }
      });
      return { versionKey: vkey, daRivalidare: stale };
    }

    return { analizzaPartita: analizzaPartita, inventariaObsolete: inventariaObsolete, chiaveVersione: chiaveVersione, pvLegale: pvLegale, LIVELLI: LIVELLI, _partitaDaArchivio: partitaDaArchivio };
  }
  return { crea: crea, LIVELLI: LIVELLI, VERSIONE: 'cnap-analisi-2' };   // 2: linee della passata veloce configurabili
});
