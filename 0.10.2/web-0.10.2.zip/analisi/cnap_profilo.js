/* Chess Node · Analisi profonda · FASE 3 · CNApProfilo — «Il mio profilo scacchistico» e «Analizza me» (A2-09, A2-10, A2-11, A2-13).
   Codice originale Chess Node (08/11/2026). Calcolo PURO sopra l'archivio (partite + analisi complete): nessun motore, nessuna rete.
   Regole:
   - un solo filtro periodo (1 settimana / 1 mese / 6 mesi / 1 anno / Tutto) vale per TUTTE le sezioni;
   - V/P/S sempre visibili con denominatore; sconosciuti esclusi e contati; siti e ritmi mai fusi in un rating unico;
   - capacità tecniche in ordine Tattica, Aperture, Mediogioco, Finali; difetti SOLO con le soglie Q02 (mai da una partita sola);
   - «Pochi dati» se meno di 10 partite analizzate nel periodo (Q02); nessun punteggio 0/100 o punto forte da assenza di dati;
   - solo analisi COMPLETE, valide per il profilo e della stessa versione di metodo; le altre contate a parte («precedenti»);
   - percentuali con arrotondamento che somma 100 sul denominatore dichiarato; ogni numero con il suo campione;
   - nessuna diagnosi psicologica o strategica non dimostrata; collegamenti solo a capitoli esistenti forniti dall'app.
   Minimi non decisi da Kiko = PROPOSTE centralizzate in CFG, stato «sperimentale», mai numeri sparsi nel codice. */
(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api; else root.CNApProfilo = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  var VERSIONE = 'cnap-profilo-1';
  var CFG = {
    stato: 'sperimentale',
    pochiDatiPartiteAnalizzate: 10,          // DECISO Q02
    periodiGiorni: { '1s': 7, '1m': 30, '6m': 182, '1a': 365, tutto: null },   // finestre mobili che finiscono «adesso» (proposta)
    aperturaMinPartite: 5,                   // PROPOSTA: sotto, solo conteggi + «Pochi dati» per quella linea
    finaleMinPartite: 5,                     // PROPOSTA: sotto, «Pochi dati per questo finale»
    vintaNonConvertita: { soglia: 80, mosseConsecutive: 3 },   // DECISO Q11 soglia 80% «nettamente favorevole»; 3 mosse = PROPOSTA (un picco non basta)
    puntoForte: { minOccasioni: 5, minPartite: 3, minPrese: 0.80 },   // PROPOSTA: stesse soglie minime dei difetti, l'80% delle occasioni sfruttate
    confrontoMese: { minPartiteAnalizzate: 5, minMosseClassificate: 100, minDifferenza: 3 },   // PROPOSTA (Q02 non fissa il confronto)
    mesiMax: 12
  };
  var ORDINE_ETICHETTE = ['geniale', 'migliore', 'ottima', 'buona', 'tranquilla', 'forte', 'teoria', 'obbligata', 'imprecisione', 'errore', 'blunder'];
  var NOMI = { geniale: 'Geniale', migliore: 'Migliore', ottima: 'Ottima', buona: 'Buona', tranquilla: 'Tranquilla', forte: 'Mossa forte', teoria: 'Teoria', obbligata: 'Mossa obbligata', imprecisione: 'Imprecisione', errore: 'Errore', blunder: 'Blunder', nogiud: 'Nessun giudizio' };
  var NEG = { imprecisione: 1, errore: 1, blunder: 1 };

  /* arrotondamento a somma 100 (metodo dei resti maggiori), stabile a parità: ordine di ORDINE_ETICHETTE */
  function percentuali(conteggi, chiavi) {
    var tot = chiavi.reduce(function (s, k) { return s + (conteggi[k] || 0); }, 0), out = {};
    if (!tot) { chiavi.forEach(function (k) { out[k] = null; }); return out; }
    var parti = chiavi.map(function (k, i) { var e = 100 * (conteggi[k] || 0) / tot; return { k: k, i: i, base: Math.floor(e), resto: e - Math.floor(e) }; });
    var manca = 100 - parti.reduce(function (s, p) { return s + p.base; }, 0);
    parti.slice().sort(function (a, b) { return b.resto - a.resto || a.i - b.i; }).forEach(function (p, j) { if (j < manca) p.base++; });
    parti.forEach(function (p) { out[p.k] = p.base; });
    return out;
  }
  function accMossa(perdita) { return 100 * Math.exp(-0.035 * Math.max(0, perdita)); }   // = CNPrecisione.accMossa (cnp-2)
  function mediaCnp(acc) {
    if (!acc.length || acc.length < 5) return null;
    var ar = acc.reduce(function (a, b) { return a + b; }, 0) / acc.length, ha = acc.length / acc.reduce(function (a, b) { return a + 1 / Math.max(b, 1); }, 0);
    return Math.round((ar + ha) / 2);
  }
  function contaInPrecisione(cl) { return cl !== 'teoria' && cl !== 'obbligata' && cl !== 'nogiud'; }

  function crea(d) {
    var A = d.archivio, Stat = d.CNApStat, Dif = d.CNApDifetti, ora = d.ora || function () { return Date.now(); }, U = d.CNApUtil;
    var capitoli = d.capitoli || {};   // { tema|tipoFinale|'aperture': {id, titolo} } SOLO capitoli esistenti e verificati forniti dall'app
    if (!A || !Stat || !Dif || !U) throw new Error('CNApProfilo: servono archivio, CNApStat, CNApDifetti, CNApUtil');

    function inPeriodo(g, periodo, adesso) {
      var giorni = CFG.periodiGiorni[periodo || 'tutto'];
      if (giorni == null) return true;
      var t = g.playedAtMs != null ? g.playedAtMs : (g.playedDate ? Date.parse(g.playedDate + 'T12:00:00Z') : null);
      if (t == null) return false;   // senza data: solo in «Tutto» (dichiarato in copertura)
      return t > adesso - giorni * 86400000 && t <= adesso;
    }
    function esito(g) { return Stat.esito(g).k; }
    function sitoDi(g) { return Stat.sitoDi(g); }

    /* dati grezzi: partite dell'ambito e analisi collegate */
    async function carica(scope) {
      var gs = await A.partite({ scope: scope || 'self' }), an = {};
      await A.tx(['analyses'], 'readonly', async function (t) {
        var tutte = await t.all('analyses');
        tutte.forEach(function (a) { (an[a.gameId] = an[a.gameId] || []).push(a); });
      });
      return { partite: gs, analisi: an };
    }

    /* o = {scope:'self', periodo:'1m', versioneMetodo?: versionKey richiesta (default: la più frequente tra le analisi complete)} */
    async function calcola(o) {
      o = o || {};
      var dati = o.dati || await carica(o.scope), adesso = o.ora != null ? o.ora : ora(), periodo = o.periodo || 'tutto';
      var nonDoppione = function (g) { return !(g.duplicateCandidateOf && g.duplicateCandidateOf.length); };   // rilievo 21: un possibile doppione non conta due volte finché l'utente non decide
      var inPer = dati.partite.filter(function (g) { return g.variant === 'standard' && inPeriodo(g, periodo, adesso); });
      var gs = inPer.filter(nonDoppione);
      var senzaData = periodo !== 'tutto' ? dati.partite.filter(function (g) { return g.playedAtMs == null && !g.playedDate; }).length : 0;
      // analisi valide: complete, per il profilo; metodo = versione più frequente (o richiesta)
      var freq = {};
      gs.forEach(function (g) { (dati.analisi[g.gameId] || []).forEach(function (a) { if (a.status === 'complete' && a.eligibleForProfile) freq[a.versionKey] = (freq[a.versionKey] || 0) + 1; }); });
      var metodo = o.versioneMetodo || Object.keys(freq).sort(function (a, b) { return freq[b] - freq[a] || (a < b ? -1 : 1); })[0] || null;
      var analizzate = [], precedenti = 0, altroMetodo = 0;
      gs.forEach(function (g) {
        var lista = dati.analisi[g.gameId] || [], a = lista.filter(function (x) { return x.status === 'complete' && x.eligibleForProfile && x.versionKey === metodo; }).sort(function (x, y) { return (y.analysisRevision || 0) - (x.analysisRevision || 0); })[0];
        if (a) analizzate.push({ g: g, a: a });
        else if (lista.some(function (x) { return x.status === 'complete' && x.versionKey !== metodo; })) altroMetodo++;
        else if (lista.some(function (x) { return x.status === 'stale' || x.status === 'legacy'; })) precedenti++;
      });
      var conColore = analizzate.filter(function (x) { return x.g.userColor; });
      var pochi = conColore.length < CFG.pochiDatiPartiteAnalizzate;

      var out = {
        versione: VERSIONE, configurazione: { stato: CFG.stato, cfg: CFG }, periodo: { id: periodo, giorni: CFG.periodiGiorni[periodo], finoA: U.isoRoma(adesso) },
        copertura: { partite: gs.length, analizzate: conColore.length, nelCampione: gs.filter(function (g) { return g.sampling && g.sampling.selectedForEngine; }).length,
          analisiPrecedenti: precedenti, analisiAltroMetodo: altroMetodo, senzaDataEscluse: senzaData, possibiliDoppioniEsclusi: inPer.length - gs.length, metodo: metodo, aggiornato: U.isoRoma(adesso),
          testo: 'Basato su ' + gs.length + ' partite · ' + conColore.length + ' analizzate dal motore' },
        pochiDati: pochi,
        risultati: risultati(gs),
        tecnica: null, qualita: null, mesi: null, galleria: null
      };
      out.tecnica = { ordine: ['tattica', 'aperture', 'mediogioco', 'finali'], tattica: tattica(conColore, pochi), aperture: aperture(gs, conColore), mediogioco: mediogioco(conColore, pochi), finali: finali(conColore) };
      out.qualita = qualita(conColore, gs.length);
      out.mesi = mesi(dati.partite.filter(function (g) { return g.variant === 'standard' && inPeriodo(g, periodo === 'tutto' ? 'tutto' : periodo, adesso) && nonDoppione(g); }), dati.analisi, metodo, adesso);
      out.galleria = galleria(gs, dati.analisi, metodo);
      return out;
    }

    /* ---------------- risultati: per colore, ritmo e sito separati ---------------- */
    function risultati(gs) {
      var s = Stat.calcola(gs, {});
      return { totale: s.totale, perColore: s.perColore, perRitmo: s.perRitmo, perSito: s.perSito, rating: s.rating, precisioneServizi: s.precisioneServizi,
        nota: 'Gli esiti sconosciuti (risultato assente, in conflitto o lato non scelto) sono esclusi dalle percentuali e contati a parte. Rating separati per sito e ritmo.' };
    }

    /* mosse dell'utente nelle analisi valide */
    function mosseUtente(x) { return x.a.positionResults.filter(function (p) { return p.side === x.g.userColor; }); }
    function precisioneDi(mosse) { var acc = mosse.filter(function (p) { return contaInPrecisione(p.label); }).map(function (p) { return accMossa(p.labelInfo.loss); }); return { valore: mediaCnp(acc), mosseContate: acc.length, formula: 'cnp-2 sulle mosse dell\'utente (min. 5)' }; }

    /* ---------------- Tattica ---------------- */
    function tattica(an, pochi) {
      var occ = [];
      an.forEach(function (x) { ((x.a.themes && x.a.themes.occasioni) || []).forEach(function (o) { if (o.lato === x.g.userColor) occ.push(o); }); });
      var dif = Dif.valuta(occ, an.length), forti = [];
      dif.temi.forEach(function (t) {
        var prese = t.prese / Math.max(1, t.occasioni);
        t.capitolo = capitoli[t.tema] || null;   // link solo se l'app fornisce un capitolo esistente
        if (!pochi && t.occasioni >= CFG.puntoForte.minOccasioni && t.partiteConOccasione >= CFG.puntoForte.minPartite && prese >= CFG.puntoForte.minPrese)
          forti.push({ tema: t.tema, prese: t.prese, occasioni: t.occasioni, testo: 'Hai sfruttato ' + t.prese + ' occasioni su ' + t.occasioni + ' (' + t.partiteConOccasione + ' partite).' });
        t.consiglio = t.confermato ? 'Su questo tema hai mancato ' + t.errori + ' occasioni su ' + t.occasioni + ' in ' + t.partiteConErrore + ' partite diverse.' + (t.capitolo ? ' Allenamento: «' + t.capitolo.titolo + '».' : '') : null;
      });
      return { pochiDati: pochi, temi: dif.temi, puntiForti: forti, occasioniTotali: occ.length, partiteAnalizzate: an.length,
        testo: pochi ? 'Pochi dati: meno di ' + CFG.pochiDatiPartiteAnalizzate + ' partite analizzate nel periodo.' : (dif.temi.some(function (t) { return t.confermato; }) ? null : 'Nessun difetto tattico confermato nel periodo.') };
    }

    /* ---------------- Aperture ---------------- */
    function aperture(gs, an) {
      var per = { w: {}, b: {} }, nonId = { w: 0, b: 0 }, perAn = {};
      an.forEach(function (x) { perAn[x.g.gameId] = x; });
      gs.forEach(function (g) {
        if (!g.userColor) return;
        var Ap = (typeof require === 'function' ? require('../../fase_01/moduli/cnap_aperture.js') : (typeof CNApAperture !== 'undefined' ? CNApAperture : null));
        if (Ap && !Ap.daInizio(g)) { nonId[g.userColor]++; return; }
        var vis = Ap ? Ap.visibile(g.opening) : { chiave: g.opening && g.opening.name, nome: g.opening && g.opening.name, eco: g.opening && g.opening.eco };
        if (!vis.nome) { nonId[g.userColor]++; return; }
        var k = vis.chiave, r = per[g.userColor][k] = per[g.userColor][k] || { nome: vis.nome, eco: vis.eco || null, fonti: {}, partite: 0, vinte: 0, patte: 0, perse: 0, sconosciute: 0, mosse: [] };
        r.fonti[g.opening && g.opening.fonte] = 1; r.partite++;
        var e = esito(g); r[e]++;
        var x = perAn[g.gameId]; if (x) mosseUtente(x).forEach(function (p) { if (p.phase && p.phase.fase === 'apertura') r.mosse.push(p); });
      });
      function righe(c) {
        return Object.keys(per[c]).map(function (k) {
          var r = per[c][k], den = r.vinte + r.patte + r.perse, prec = precisioneDi(r.mosse);
          return { nome: r.nome, eco: r.eco, fonti: Object.keys(r.fonti), partite: r.partite, vinte: r.vinte, patte: r.patte, perse: r.perse, sconosciute: r.sconosciute,
            percentualeVittorie: den && r.partite >= CFG.aperturaMinPartite ? Math.round(1000 * r.vinte / den) / 10 : null,
            pochiDati: r.partite < CFG.aperturaMinPartite, precisionePrimeMosse: prec, nota: 'Nome italiano dalla lista di Kiko (se manca si mostra solo il codice ECO); precisione = stima Chess Node, non quella del sito.' };
        }).sort(function (a, b) { return b.partite - a.partite || (a.nome < b.nome ? -1 : 1); });
      }
      return { bianco: righe('w'), nero: righe('b'), nonIdentificate: nonId, uscitaDallaTeoria: { disponibile: false, testo: 'Fuori dal repertorio disponibile: nessun elenco di teoria approvato, quindi non diciamo dove sei uscito dalla teoria né se è stato un errore.' }, capitolo: capitoli.aperture || null };
    }

    /* ---------------- Mediogioco ---------------- */
    function mediogioco(an, pochi) {
      var mosse = []; an.forEach(function (x) { mosseUtente(x).forEach(function (p) { if (p.phase && p.phase.fase === 'mediogioco') mosse.push(p); }); });
      var cnt = {}; mosse.forEach(function (p) { cnt[p.label] = (cnt[p.label] || 0) + 1; });
      var neg = mosse.filter(function (p) { return NEG[p.label]; }).length;
      return { pochiDati: pochi, mosse: mosse.length, precisione: precisioneDi(mosse), conteggi: cnt, giudiziNegativi: neg,
        testo: pochi ? 'Pochi dati per il mediogioco.' : 'Valutazione della qualità delle scelte; nessuna diagnosi strategica senza temi dimostrati.' };
    }

    /* ---------------- Finali ---------------- */
    function finali(an) {
      var tipi = {};
      an.forEach(function (x) {
        var g = x.g, mosse = mosseUtente(x).filter(function (p) { return p.phase && p.phase.fase === 'finale'; });
        if (!mosse.length) return;
        var visti = {};
        mosse.forEach(function (p) {
          var t = p.phase.tipoFinale || 'non classificato', r = tipi[t] = tipi[t] || { tipo: t, partite: {}, mosse: [], vinteNonConvertite: [] };
          r.partite[g.gameId] = 1; r.mosse.push(p); visti[t] = 1;
        });
        // posizione nettamente favorevole (≥80% per l'utente, WDL quando c'è) per N mosse consecutive dell'utente, ma partita non vinta
        var serie = 0, inizio = null, tipoSerie = null;
        mosse.forEach(function (p) {
          var probUtente = p.wdlAfter ? 100 - (p.wdlAfter[0] + p.wdlAfter[1] / 2) / 10 : p.wA;
          if (probUtente >= CFG.vintaNonConvertita.soglia) { if (!serie) { inizio = p; tipoSerie = p.phase.tipoFinale || 'non classificato'; } serie++; } else serie = 0;
          if (serie === CFG.vintaNonConvertita.mosseConsecutive && esito(g) !== 'vinte' && Stat.esito(g).k !== 'sconosciute') tipi[tipoSerie].vinteNonConvertite.push({ gameId: g.gameId, nodeId: inizio.nodeId, ply: inizio.ply, esito: esito(g) });
        });
      });
      return Object.keys(tipi).sort().map(function (k) {
        var r = tipi[k], n = Object.keys(r.partite).length, pochi = n < CFG.finaleMinPartite;
        return { tipo: k, partite: n, mosse: r.mosse.length, precisione: precisioneDi(r.mosse), vinteNonConvertite: r.vinteNonConvertite, pochiDati: pochi, capitolo: capitoli['finale:' + k] || null,
          testo: pochi ? 'Pochi dati per questo finale (' + n + ' partite).' : (r.vinteNonConvertite.length ? r.vinteNonConvertite.length + ' posizioni nettamente favorevoli (stima del motore, non risultato teorico) non trasformate in vittoria.' : null) };
      });
    }

    /* ---------------- Barra qualità mosse ---------------- */
    function qualita(an, partiteNelPeriodo) {
      function blocco(mosse) {
        var c = {}, nogiud = 0, momenti = {};
        mosse.forEach(function (m) { var p = m.p; if (p.label === 'nogiud') { nogiud++; return; } c[p.label] = (c[p.label] || 0) + 1; (momenti[p.label] = momenti[p.label] || []).push({ gameId: m.g.gameId, nodeId: p.nodeId, nodeIdBefore: p.nodeIdBefore, ply: p.ply }); });
        var cl = ORDINE_ETICHETTE.reduce(function (s, k) { return s + (c[k] || 0); }, 0);
        return { denominatore: cl, denominatoreTesto: 'mosse classificate del tuo lato', conteggi: c, percentuali: percentuali(c, ORDINE_ETICHETTE), nessunGiudizio: nogiud, momenti: momenti };
      }
      var tutte = []; an.forEach(function (x) { mosseUtente(x).forEach(function (p) { tutte.push({ g: x.g, p: p }); }); });
      var perFase = {}; ['apertura', 'mediogioco', 'finale'].forEach(function (f) { perFase[f] = blocco(tutte.filter(function (m) { return m.p.phase && m.p.phase.fase === f; })); });
      var perAp = {}; tutte.forEach(function (m) { var k = m.g.opening && m.g.opening.name ? m.g.opening.name : 'Apertura non identificata'; (perAp[k] = perAp[k] || []).push(m); });
      Object.keys(perAp).forEach(function (k) { perAp[k] = blocco(perAp[k]); });
      return { etichette: ORDINE_ETICHETTE.map(function (k) { return { id: k, nome: NOMI[k] }; }), totale: blocco(tutte), perFase: perFase, perApertura: perAp,
        nonClassificate: partiteNelPeriodo - an.length, nota: (partiteNelPeriodo - an.length) ? (partiteNelPeriodo - an.length) + ' partite del periodo non ancora analizzate: non entrano nelle barre (non è «zero Geniali»).' : null };
    }

    /* ---------------- Mese per mese (Blitz/Rapid separati) ---------------- */
    function mesi(gs, analisi, metodo, adesso) {
      var corrente = U.meseRoma(adesso), per = {};
      gs.forEach(function (g) {
        if (!g.monthRome) return;
        var k = g.monthRome + '|' + (g.timeClass || 'sconosciuto') + '|' + sitoDi(g), r = per[k] = per[k] || { mese: g.monthRome, ritmo: g.timeClass || 'sconosciuto', sito: sitoDi(g), partite: 0, vinte: 0, patte: 0, perse: 0, sconosciute: 0, analizzate: 0, accSomma: 0, accMosse: 0, metodi: {}, ratingAvv: [], atteso: 0, attesoN: 0, punti: 0, mosseClassificate: 0 };
        r.partite++; var e = esito(g); r[e]++;
        var a = (analisi[g.gameId] || []).filter(function (x) { return x.status === 'complete' && x.eligibleForProfile; }).sort(function (x, y) { return (y.analysisRevision || 0) - (x.analysisRevision || 0); })[0];
        if (a && g.userColor) {
          r.metodi[a.versionKey] = 1;
          if (a.versionKey === metodo) {
            r.analizzate++;
            var acc = a.accuracy[g.userColor], n = a.accuracy.mosseContate ? a.accuracy.mosseContate[g.userColor] : 0;
            if (acc != null && n) { r.accSomma += acc * n; r.accMosse += n; }
            r.mosseClassificate += a.positionResults.filter(function (p) { return p.side === g.userColor && p.label !== 'nogiud'; }).length;
          }
        }
        if (g.userColor) {
          var ru = g.players[g.userColor].rating, ro = g.players[g.userColor === 'w' ? 'b' : 'w'].rating;
          if (ro != null) r.ratingAvv.push(ro);
          if (ru != null && ro != null && e !== 'sconosciute') { r.atteso += 1 / (1 + Math.pow(10, (ro - ru) / 400)); r.attesoN++; r.punti += e === 'vinte' ? 1 : e === 'patte' ? 0.5 : 0; }
        }
      });
      var righe = Object.keys(per).map(function (k) {
        var r = per[k];
        return { mese: r.mese, ritmo: r.ritmo, sito: r.sito, inCorso: r.mese === corrente, partite: r.partite, vinte: r.vinte, patte: r.patte, perse: r.perse, sconosciute: r.sconosciute, analizzate: r.analizzate,
          precisione: r.accMosse ? Math.round(10 * r.accSomma / r.accMosse) / 10 : null, precisioneNota: 'media delle precisioni di partita pesata sulle mosse contate (cnp-2)', mosseClassificate: r.mosseClassificate,
          avversarioMedio: r.ratingAvv.length ? Math.round(r.ratingAvv.reduce(function (a, b) { return a + b; }, 0) / r.ratingAvv.length) : null,
          risultatoAtteso: r.attesoN ? { atteso: Math.round(100 * r.atteso) / 100, ottenuto: r.punti, partite: r.attesoN, formula: 'Elo: 1/(1+10^((Ravv−Rtuo)/400)), solo partite con entrambi i rating dello stesso sito e ritmo' } : null,
          metodiDiversi: Object.keys(r.metodi).length > 1 || (Object.keys(r.metodi).length === 1 && !r.metodi[metodo]) };
      }).sort(function (a, b) { return a.mese < b.mese ? 1 : a.mese > b.mese ? -1 : (a.ritmo + a.sito < b.ritmo + b.sito ? -1 : 1); });
      var mesiDistinti = righe.map(function (r) { return r.mese; }).filter(function (m, i, a) { return a.indexOf(m) === i; }).slice(0, CFG.mesiMax);
      righe = righe.filter(function (r) { return mesiDistinti.indexOf(r.mese) >= 0; });
      return { righe: righe, confronti: confronti(righe), nota: 'Mesi di calendario Europe/Rome; il mese in corso è incompleto. Ritmi e siti separati.' };
    }
    /* ultimo mese CHIUSO contro il precedente, stesso ritmo e sito; solo con campioni sufficienti e stesso metodo */
    function confronti(righe) {
      var gruppi = {}; righe.forEach(function (r) { if (!r.inCorso) (gruppi[r.ritmo + '|' + r.sito] = gruppi[r.ritmo + '|' + r.sito] || []).push(r); });
      return Object.keys(gruppi).map(function (k) {
        var l = gruppi[k].sort(function (a, b) { return a.mese < b.mese ? 1 : -1; }), a = l[0], b = l[1], C = CFG.confrontoMese;
        var base = { ritmo: a.ritmo, sito: a.sito, mese: a.mese, precedente: b ? b.mese : null };
        if (!b) return Object.assign(base, { esito: 'insufficiente', testo: 'Non ci sono ancora dati sufficienti per un confronto.' });
        if (a.metodiDiversi || b.metodiDiversi) return Object.assign(base, { esito: 'metodo diverso', testo: 'Le analisi dei due mesi usano metodi diversi: serve ricalcolarle prima di confrontare.' });
        if (a.analizzate < C.minPartiteAnalizzate || b.analizzate < C.minPartiteAnalizzate || a.mosseClassificate < C.minMosseClassificate || b.mosseClassificate < C.minMosseClassificate || a.precisione == null || b.precisione == null)
          return Object.assign(base, { esito: 'insufficiente', testo: 'Non ci sono ancora dati sufficienti per un confronto.' });
        var dlt = Math.round(10 * (a.precisione - b.precisione)) / 10;
        if (Math.abs(dlt) < C.minDifferenza) return Object.assign(base, { esito: 'stabile', differenza: dlt, testo: 'Differenza troppo piccola per dire che qualcosa è cambiato (' + (dlt > 0 ? '+' : '') + String(dlt).replace('.', ',') + ').' });
        return Object.assign(base, { esito: dlt > 0 ? 'migliorata' : 'peggiorata', differenza: dlt, testo: 'Precisione ' + (dlt > 0 ? 'più alta' : 'più bassa') + ' di ' + String(Math.abs(dlt)).replace('.', ',') + ' punti rispetto al mese prima (' + a.analizzate + ' e ' + b.analizzate + ' partite analizzate).' });
      });
    }

    /* ---------------- Galleria «Le mie mosse geniali» ---------------- */
    function galleria(gs, analisi, metodo) {
      var attuali = [], precedenti = [];
      gs.forEach(function (g) {
        if (!g.userColor) return;
        var lista = analisi[g.gameId] || [], cur = lista.filter(function (a) { return a.status === 'complete' && a.eligibleForProfile; }).sort(function (x, y) { return (y.analysisRevision || 0) - (x.analysisRevision || 0); })[0];
        var curGen = {};
        if (cur) cur.positionResults.forEach(function (p) { if (p.side === g.userColor && p.label === 'geniale') { curGen[p.nodeId] = 1; attuali.push(scheda(g, cur, p)); } });
        lista.forEach(function (a) {
          if (a === cur || !a.positionResults) return;
          a.positionResults.forEach(function (p) { if (p.side === g.userColor && p.label === 'geniale' && !curGen[p.nodeId]) precedenti.push(Object.assign(scheda(g, a, p), { stato: 'valutazione precedente', revocataDa: cur ? cur.analysisId : null, etichettaAttuale: cur ? (cur.positionResults.filter(function (q) { return q.nodeId === p.nodeId; })[0] || {}).label || null : null })); });
        });
      });
      return { attuali: attuali, precedenti: precedenti, nota: 'Solo mosse verificate dal classificatore Chess Node (Q03); una Geniale non diventa automaticamente un esercizio.' };
    }
    function scheda(g, a, p) {
      return { gameId: g.gameId, nodeId: p.nodeId, nodeIdBefore: p.nodeIdBefore, ply: p.ply, mossa: p.played, data: g.playedDate, ritmo: g.timeClass, colore: g.userColor, avversario: g.players[g.userColor === 'w' ? 'b' : 'w'].name,
        motivi: p.labelInfo && p.labelInfo.motivi || [], analysisId: a.analysisId, classificationVersion: a.classificationVersion, stato: 'attuale' };
    }

    /* istantanea (derivata, rigenerabile) nello store profileSnapshots */
    async function salvaIstantanea(p, subjectId) {
      var snap = { snapshotId: 'PS-' + (subjectId || 'self') + '-' + p.periodo.id + '-' + U.dataRoma(ora()), subjectId: subjectId || 'self', creatoIl: U.isoRoma(ora()), versione: VERSIONE, metodo: p.copertura.metodo, periodo: p.periodo, copertura: p.copertura, risultati: { totale: p.risultati.totale, perColore: p.risultati.perColore }, rigenerabile: true };
      await A.tx(['profileSnapshots'], 'readwrite', function (t) { return t.put('profileSnapshots', snap); });
      return snap;
    }

    return { calcola: calcola, carica: carica, salvaIstantanea: salvaIstantanea, percentuali: percentuali, CFG: CFG, NOMI: NOMI, ORDINE: ORDINE_ETICHETTE };
  }

  /* «Analizza me»: acquisisce (statistiche subito), poi motore sul campione in sottofondo con progresso e Pausa.
     servizio = CNApServizio (fase 1); analisi = CNApAnalisi (fase 2). Non blocca la lettura del profilo: il profilo si ricalcola quando si vuole. */
  async function analizzaMe(d, o) {
    o = o || {};
    var S = d.servizio, AN = d.analisi, rep = { acquisizioni: [], analizzate: 0, errori: [], daAnalizzare: 0 };
    var imp = await S.archivio.impostazioni();
    var siti = [['lichess', imp.identita.lichess], ['chesscom', imp.identita.chesscom]];
    for (var i = 0; i < siti.length; i++) for (var j = 0; j < (siti[i][1] || []).length; j++) {
      if (o.segnale && o.segnale.aborted) return rep;
      try { var r = await S.importaDaSito(siti[i][0], siti[i][1][j], { mesi: o.mesi || 12, segnale: o.segnale, onAttesa: o.onAttesa }); rep.acquisizioni.push({ sito: siti[i][0], nome: siti[i][1][j], totali: r.totali, notifica: r.notifica }); if (o.onFase) o.onFase('statistiche pronte'); }
      catch (e) { rep.errori.push({ sito: siti[i][0], codice: e.code, messaggio: e.message }); }
    }
    var gs = (await S.archivio.partite({ scope: 'self' })).filter(function (g) { return g.sampling && g.sampling.selectedForEngine && (!g.localAnalysisId || g.analysisStale); });
    rep.daAnalizzare = gs.length;
    for (var k = 0; k < gs.length; k++) {
      if (o.segnale && o.segnale.aborted) break;
      try { await AN.analizzaPartita(gs[k].gameId, { livello: o.livello || 'standard', segnale: o.segnale, onProgress: o.onProgress }); rep.analizzate++; if (o.onPartita) o.onPartita(k + 1, gs.length); }
      catch (e) { if (e.code === 'ANNULLATO') break; rep.errori.push({ gameId: gs[k].gameId, codice: e.code, messaggio: e.message }); if (e.code === 'SPAZIO') break; }
    }
    return rep;
  }

  return { crea: crea, analizzaMe: analizzaMe, percentuali: percentuali, CFG: CFG, VERSIONE: VERSIONE };
});
