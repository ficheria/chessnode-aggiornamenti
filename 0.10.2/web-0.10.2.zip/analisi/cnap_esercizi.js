/* Chess Node · Analisi profonda · FASE 4 · CNApEsercizi — modalità C (A3-08): UN archivio, tre concetti (esercizio · collocazione · tentativo).
   Codice originale Chess Node (09/11/2026).
   - due fonti, un archivio: personali (DB allenamento) + biblioteca (BOOK, SOLA LETTURA, adapter «library:<n>»): nessuna copia;
   - lo stesso esercizio in «I miei errori» e in un capitolo è UN esercizio con UNA cronologia; sourceType = ORIGINE, non posizione;
   - si allenano solo gli approved correnti; le posizioni in verifica non entrano nei totali;
   - filtro «Personali» nascosto finché non c'è almeno un personale approvato (Q06);
   - ritorno ESATTO alla partita: gameId + nodeId dell'archivio (gli stessi ID che CNVarianti 1.1 usa per disegnare la lista). */
(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api; else root.CNApEsercizi = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  var VERSIONE = 'cnap-esercizi-1';
  function fen4(f) { return String(f).split(' ').slice(0, 4).join(' '); }

  /* adapter della biblioteca: BOOK = {chapters:[{id,name}], ex:[{n,c,fen,sol,res,title}]} — mai modificato */
  function biblioteca(BOOK, U) {
    var perFen = {}, perN = {};
    (BOOK && BOOK.ex || []).forEach(function (e) { perN[e.n] = e; if (e.fen) perFen[fen4(e.fen)] = 'library:' + e.n; });
    function impronta() { return U.hash(U.canon(BOOK)); }
    return {
      disponibile: !!(BOOK && BOOK.ex),
      cercaPosizione: function (f4) { return perFen[f4] || null; },
      esercizio: function (id) { var m = /^library:(\d+)$/.exec(id); var e = m && perN[m[1]]; return e ? { exerciseId: id, sourceType: 'biblioteca', chapterId: e.c, startFen: e.fen, title: e.title || null, solaLettura: true, n: e.n } : null; },
      elencoCapitolo: function (cid) { return (BOOK.ex || []).filter(function (e) { return e.c === cid; }).map(function (e) { return 'library:' + e.n; }); },
      capitoli: function () { return (BOOK.chapters || []).map(function (c) { return c.id; }); },
      impronta: impronta
    };
  }

  function crea(d) {
    var DB = d.db, bib = d.biblioteca || null, ripasso = d.ripasso || null, tentativi = d.tentativi || null;
    async function tutti() { return DB.tx(['exercises'], 'readonly', function (t) { return t.all('exercises'); }); }
    async function approvati() { return (await tutti()).filter(function (e) { return e.validationStatus === 'approved'; }); }
    async function esercizio(id) {
      if (/^library:/.test(id)) return bib ? bib.esercizio(id) : null;
      return DB.tx(['exercises'], 'readonly', function (t) { return t.get('exercises', id); });
    }
    /* per l'allenamento: solo approved correnti; altrimenti null con motivo */
    async function allenabile(id) {
      var e = await esercizio(id); if (!e) return { ok: false, motivo: 'Esercizio inesistente.' };
      if (e.sourceType === 'biblioteca') return { ok: true, esercizio: e };
      if (e.validationStatus !== 'approved') return { ok: false, motivo: e.validationStatus === 'needs-revalidation' ? 'Esercizio in nuova verifica: sospeso senza penalità.' : 'Esercizio non pubblicato.' };
      return { ok: true, esercizio: e };
    }
    async function collocazioni(exerciseId) { return DB.tx(['placements'], 'readonly', function (t) { return t.byIndex('placements', 'exerciseId', exerciseId); }); }
    /* capitolo di Studia con filtro Tutti / ChessNode / Personali: la biblioteca resta com'è, i personali si aggiungono come riferimenti */
    async function perCapitolo(chapterId, filtro) {
      filtro = filtro || 'tutti';
      var lib = bib && filtro !== 'personali' ? bib.elencoCapitolo(chapterId) : [];
      var pl = filtro === 'chessnode' ? [] : await DB.tx(['placements', 'exercises'], 'readonly', async function (t) {
        var p = await t.byIndex('placements', 'chapterId', chapterId), out = [];
        for (var i = 0; i < p.length; i++) { var e = await t.get('exercises', p[i].exerciseId); if (e && e.validationStatus === 'approved') out.push(e.exerciseId); }
        return out;
      });
      var righe = lib.map(function (id) { return { exerciseId: id, fonte: 'Biblioteca ChessNode' }; }).concat(pl.map(function (id) { return { exerciseId: id, fonte: 'Dalla tua partita' }; }));
      return { chapterId: chapterId, filtro: filtro, righe: righe, vuoto: !righe.length, testoVuoto: !righe.length && filtro === 'personali' ? 'In questo capitolo non ci sono ancora esercizi dalle tue partite.' : null };
    }
    async function filtroPersonaliVisibile() { return (await approvati()).some(function (e) { return e.sourceType === 'personale'; }); }
    /* «I miei errori»: tre contatori MUTUAMENTE ESCLUSIVI (PROPOSTA da confermare con Kiko) derivati da ripasso + tentativi */
    async function contatori() {
      var ap = (await approvati()).filter(function (e) { return e.sourceType === 'personale' && e.exerciseType !== 'ritrova'; }), c = { daStudiare: 0, daRipassare: 0, dovutiOggi: 0, consolidati: 0, totaleApprovati: ap.length };
      for (var i = 0; i < ap.length; i++) {
        var e = ap[i], st = ripasso ? ripasso.stato(e.exerciseId) : { inRipasso: false }, s = tentativi ? (await tentativi.storico(e.exerciseId)).filter(function (a) { return a.endedAt; }) : [];
        if (st.inRipasso) { c.daRipassare++; if (st.dovuto) c.dovutiOggi++; }
        else if (st.consolidato || s.some(function (a) { return a.outcome === 'risolto senza aiuti'; })) c.consolidati++;
        else c.daStudiare++;
      }
      var pend = (await tutti()).filter(function (e) { return /^(candidate|analysing|verifying|needs-revalidation)$/.test(e.validationStatus); }).length;
      c.inVerifica = pend;   // pannello separato facoltativo, mai badge positivo
      c.testoVuoto = ap.length ? null : 'Non ci sono ancora esercizi personali verificati.' + (d.collegamenti ? ' Puoi analizzare una partita o allenarti nella biblioteca.' : '');
      return c;
    }
    /* ritorno ESATTO alla partita: gameId + nodeId dell'archivio */
    function ritorno(ex) {
      if (!ex || ex.sourceType !== 'personale') return null;
      return { view: 'analysis', gameId: ex.sourceGameId, nodeId: ex.sourceNodeId, nodeIdMossaGiocata: ex.sourceMoveNodeId || null, orientation: ex.solverColor === 'b' ? 'black' : 'white', exerciseId: ex.exerciseId };
    }
    /* apre la schermata di analisi (CNApStato, fase 2) sul nodo giusto e lo verifica; se il nodo non esiste più → posizione valida più vicina con avviso */
    async function apriRitorno(stato, ex) {
      var r = ritorno(ex); if (!r) return null;
      var snap = await stato.apri(r.gameId, { nodeId: r.nodeId });
      if (snap.selectedNodeId !== r.nodeId && stato.nodo(r.nodeId)) snap = stato.selezionaPosizione(r.nodeId);
      return { ritorno: r, snapshot: snap, esatto: snap.selectedNodeId === r.nodeId && snap.fen === ex.startFen, avviso: snap.selectedNodeId === r.nodeId ? null : 'La posizione dell\'esercizio non è più nella partita: aperta la posizione valida più vicina.' };
    }
    return { esercizio: esercizio, allenabile: allenabile, approvati: approvati, tutti: tutti, collocazioni: collocazioni, perCapitolo: perCapitolo, filtroPersonaliVisibile: filtroPersonaliVisibile, contatori: contatori, ritorno: ritorno, apriRitorno: apriRitorno };
  }
  return { crea: crea, biblioteca: biblioteca, fen4: fen4, VERSIONE: VERSIONE };
});
