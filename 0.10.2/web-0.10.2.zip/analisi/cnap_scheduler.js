/* Chess Node · Analisi profonda · FASE 2 · CNApScheduler — UN solo coordinatore del motore (A1-C01, A1-05, Q10 temperatura).
   Codice originale Chess Node (08/11/2026). Dipendenza: un'istanza CNApUci (un solo Worker per tutta l'app).
   Priorità decisa: interattivo esplicito > verifica bloccante (proposta) > batch partite/generazione.
   - Arriva lavoro più importante mentre gira il batch: «stop», drenaggio del bestmove, la ricerca batch interrotta NON vale come
     risultato e viene rimessa in testa alla sua coda (nessuna posizione completa viene rifatta: le completate le salva chi le chiede).
   - Interattivo: attesa breve (220 ms come in analisi_pagina.js, da misurare) e «vince l'ultima selezione» per lo stesso proprietario:
     50 cambi di nodo producono UNA ricerca, le altre vengono scartate (SUPERATA), mai applicate.
   - Ogni risultato e ogni info progressiva porta requestId, gameId, nodeId, FEN, impostazioni: chi riceve confronta tutto.
   - Pausa esplicita del batch: non riparte da sola. Sospensioni automatiche (temperatura, spazio, avviso batteria non ancora
     visto) riprendono quando la causa sparisce. Nessun secondo motore per saltare la coda. */
(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api; else root.CNApScheduler = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  var PRI = { interattivo: 0, verifica: 1, batch: 2 };
  /* DECISO Q10: comportamento per stato termico. «Moderato → meno thread» non ha effetto sulla build Lite (Threads max 1, verificato):
     si usa invece meno hash + una pausa tra le ricerche batch. Valori = proposta tecnica da misurare sul telefono. */
  var TERMICO = {
    normale:          { hashFattore: 1,   pausaBatchMs: 0,    batch: true,  nuove: true },
    leggero:          { hashFattore: 0.5, pausaBatchMs: 150,  batch: true,  nuove: true },
    moderato:         { hashFattore: 0.5, pausaBatchMs: 800,  batch: true,  nuove: true },
    severo:           { hashFattore: 0.5, pausaBatchMs: 0,    batch: false, nuove: true },
    critico:          { hashFattore: 0.5, pausaBatchMs: 0,    batch: false, nuove: false },
    'non disponibile':{ hashFattore: 1,   pausaBatchMs: 0,    batch: true,  nuove: true }
  };

  function err(code, msg) { var e = new Error(msg); e.code = code; return e; }

  function crea(d) {
    var U = d.uci, ora = d.ora || function () { return Date.now(); }, DEB = d.debounceMs != null ? d.debounceMs : 220, HASH = d.hashMb || 16;
    var attendi = d.attendi || function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };
    var coda = [], attiva = null, seq = 0, ciclo = false, ascolti = [];
    var st = { pausaUtente: false, sospensioni: {}, termico: 'non disponibile', avvisoVisto: d.avvisoVisto !== false, ricercheFatte: 0, interruzioniBatch: 0, scartate: 0 };
    var debounce = {}, inAttesa = {};   // owner → timer / richiesta interattiva in attesa del debounce

    function evento(tipo, dati) { ascolti.forEach(function (f) { try { f(tipo, dati); } catch (e) {} }); }
    function batchConsentito() { return !st.pausaUtente && !Object.keys(st.sospensioni).length && st.avvisoVisto && TERMICO[st.termico].batch; }
    function prossimo() {
      var cand = coda.filter(function (r) { return r.pri < 2 || batchConsentito(); });
      if (!cand.length) return null;
      cand.sort(function (a, b) { return a.pri - b.pri || a.ord - b.ord; });
      return cand[0];
    }
    async function gira() {
      if (ciclo) return; ciclo = true;
      try {
        for (;;) {
          var r = prossimo(); if (!r) break;
          if (!TERMICO[st.termico].nuove) break;
          coda.splice(coda.indexOf(r), 1);
          if (r.pri === 2 && TERMICO[st.termico].pausaBatchMs) await attendi(TERMICO[st.termico].pausaBatchMs);
          attiva = r; r.stato = 'in corso'; evento('inizio', identita(r));
          var opz = Object.assign({}, r.opz, { fen: r.fen, mosse: r.mosse, hash: Math.max(1, Math.round((r.opz.hash || HASH) * TERMICO[st.termico].hashFattore)) });
          var res = null, e0 = null;
          try { res = await U.cerca(opz, function (info, sid) { if (attiva === r && !r.interrotta && r.onInfo) r.onInfo(Object.assign({ identita: identita(r) }, info)); }); }
          catch (e) { e0 = e; }
          attiva = null; st.ricercheFatte++;
          if (e0) { r.rifiuta(e0); evento('errore', { identita: identita(r), codice: e0.code }); continue; }
          if (r.interrotta === 'precedenza' || r.interrotta === 'pausa') {   // batch ceduto: torna in testa, la ricerca parziale non vale
            r.interrotta = null; r.ord = -(++seq); coda.push(r); st.interruzioniBatch++; evento('ceduta', identita(r)); continue;
          }
          if (r.interrotta === 'superata') { st.scartate++; r.rifiuta(err('SUPERATA', 'Selezione cambiata: risultato non applicato.')); continue; }
          if (r.interrotta === 'annullata') { r.rifiuta(err('ANNULLATA', 'Richiesta annullata.')); continue; }
          var out = Object.assign({ identita: identita(r), motore: U.meta(), terminatoIl: ora() }, res);
          r.stato = 'fatta'; r.risolvi(out); evento('fine', identita(r));
        }
      } finally { ciclo = false; }
      if (prossimo() && TERMICO[st.termico].nuove) gira();
    }
    function identita(r) { return { requestId: r.requestId, owner: r.owner, priorita: r.priorita, gameId: r.gameId, nodeId: r.nodeId, fen: r.fen, opz: r.opz, versione: r.versione }; }
    function interrompi(r, motivo) { if (attiva === r) { r.interrotta = motivo; return U.ferma(); } return Promise.resolve(); }

    /* q = {owner, priorita, gameId, nodeId, fen, mosse?, opz:{depth,multipv,movetime,pulisci,maxMs}, versione, onInfo} */
    function richiedi(q) {
      if (!PRI.hasOwnProperty(q.priorita)) throw err('PRIORITA', 'Priorità sconosciuta: ' + q.priorita);
      if (!q.fen) throw err('FEN', 'FEN mancante');
      var r = Object.assign({}, q, { requestId: 'R' + (++seq), pri: PRI[q.priorita], ord: seq, opz: q.opz || {}, stato: 'in coda' });
      r.promessa = new Promise(function (a, b) { r.risolvi = a; r.rifiuta = b; });
      r.promessa.catch(function () {});
      if (!TERMICO[st.termico].nuove) { r.rifiuta(err('TERMICO_CRITICO', 'Il dispositivo è molto caldo: nessuna nuova analisi fino al raffreddamento.')); return r; }
      if (r.pri === 0) {
        // vince l'ultima: le precedenti dello stesso proprietario sono superate (in coda o in corso)
        coda.filter(function (x) { return x.owner === r.owner && x.pri === 0; }).forEach(function (x) { coda.splice(coda.indexOf(x), 1); st.scartate++; x.rifiuta(err('SUPERATA', 'Selezione cambiata: risultato non applicato.')); });
        if (attiva && attiva.owner === r.owner && attiva.pri === 0) interrompi(attiva, 'superata');
        clearTimeout(debounce[r.owner]);
        var vecchia = inAttesa[r.owner]; if (vecchia && vecchia !== r && vecchia.stato === 'in coda' && !vecchia.annullata) { vecchia.annullata = true; st.scartate++; vecchia.rifiuta(err('SUPERATA', 'Selezione cambiata: risultato non applicato.')); }
        inAttesa[r.owner] = r;
        debounce[r.owner] = setTimeout(function () {
          if (inAttesa[r.owner] === r) delete inAttesa[r.owner];
          if (r.stato !== 'in coda' || r.annullata) return;
          coda.push(r);
          if (attiva && attiva.pri > 0) interrompi(attiva, 'precedenza').then(gira); else gira();
        }, DEB);
        r.annulla = function () {
          if (r.annullata || r.stato === 'fatta') return; r.annullata = true; st.scartate++;
          if (inAttesa[r.owner] === r) { clearTimeout(debounce[r.owner]); delete inAttesa[r.owner]; }
          var i = coda.indexOf(r); if (i >= 0) { coda.splice(i, 1); r.rifiuta(err('ANNULLATA', 'Richiesta annullata.')); } else if (attiva === r) interrompi(r, 'annullata'); else r.rifiuta(err('ANNULLATA', 'Richiesta annullata.'));
        };
        return r;
      }
      coda.push(r);
      if (attiva && attiva.pri > r.pri) interrompi(attiva, 'precedenza').then(gira); else gira();
      r.annulla = function () { var i = coda.indexOf(r); if (i >= 0) { coda.splice(i, 1); r.rifiuta(err('ANNULLATA', 'Richiesta annullata.')); } else if (attiva === r) interrompi(r, 'annullata'); };
      return r;
    }
    /* comodità per i job batch: promessa del risultato */
    function cerca(q) { return richiedi(q).promessa; }

    function pausaBatch() { st.pausaUtente = true; evento('pausa', {}); if (attiva && attiva.pri === 2) return interrompi(attiva, 'pausa'); return Promise.resolve(); }
    function riprendiBatch() { st.pausaUtente = false; evento('ripresa', {}); gira(); }
    function sospendi(motivo) { st.sospensioni[motivo] = ora(); evento('sospeso', { motivo: motivo }); if (attiva && attiva.pri === 2) return interrompi(attiva, 'pausa'); return Promise.resolve(); }
    function togliSospensione(motivo) { delete st.sospensioni[motivo]; gira(); }
    function impostaAvvisoVisto(v) { st.avvisoVisto = !!v; gira(); }
    /* stato termico dal plugin (o «non disponibile» sul web): applica la tabella Q10 */
    function termico(s) {
      if (!TERMICO[s]) s = 'non disponibile';
      var prima = st.termico; st.termico = s; evento('termico', { da: prima, a: s, regole: TERMICO[s] });
      if (!TERMICO[s].batch && attiva && attiva.pri === 2) return interrompi(attiva, 'pausa');
      if (!TERMICO[s].nuove && attiva) return interrompi(attiva, attiva.pri === 2 ? 'pausa' : 'annullata');
      gira(); return Promise.resolve();
    }
    function stato() {
      return { pausaUtente: st.pausaUtente, sospensioni: Object.keys(st.sospensioni), termico: st.termico, regoleTermiche: TERMICO[st.termico], avvisoVisto: st.avvisoVisto,
        batchConsentito: batchConsentito(), attiva: attiva ? identita(attiva) : null, inCoda: coda.length, inCodaBatch: coda.filter(function (r) { return r.pri === 2; }).length,
        ricercheFatte: st.ricercheFatte, interruzioniBatch: st.interruzioniBatch, scartate: st.scartate };
    }
    /* avvio esplicito del motore: i metadati reali (nome/build) servono PRIMA di calcolare la versione di un'analisi */
    function avvia() { return U.avvia(); }
    return { avvia: avvia, richiedi: richiedi, cerca: cerca, pausaBatch: pausaBatch, riprendiBatch: riprendiBatch, sospendi: sospendi, togliSospensione: togliSospensione,
      impostaAvvisoVisto: impostaAvvisoVisto, termico: termico, stato: stato, ascolta: function (f) { ascolti.push(f); }, meta: function () { return U.meta(); } };
  }
  return { crea: crea, TERMICO: TERMICO, PRIORITA: PRI, VERSIONE: 'cnap-scheduler-1' };
});
