/* Chess Node · Analisi profonda · FASE 4 · CNApRisposta — il controllo della mossa del giocatore durante l'esercizio (A3-04 «Al momento
   della risposta»). Codice originale Chess Node (09/11/2026).
   - illegale (anche promozione senza pezzo esplicito: nessuna auto-Donna) → input illegale, NON errore scacchistico;
   - nelle mosse accettate del nodo → accettata, l'avversario risponde dal ramo verificato (miglior difesa), non dalla PV originaria;
   - matto sulla scacchiera quando l'obiettivo è il matto → accettata (ogni matto è valido, anche se non catalogato);
   - confutata con evidenza registrata → sbagliata, con la linea di confutazione;
   - buona ma non l'obiettivo (es. vince ma non dà matto) → nessuna penalità, «c'è una strada più diretta»;
   - non catalogata → «Verifico questa alternativa…»: richiesta PRIORITARIA allo scheduler, nessuna penalità finché non c'è una prova;
     equivalente → accettata e l'esercizio torna in verifica per aggiungere il ramo; prova insufficiente o motore assente →
     «Non posso valutare con sicurezza questa alternativa», nessun errore. Nessun servizio remoto. */
(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api; else root.CNApRisposta = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  var TESTI = {
    illegale: 'Mossa non valida in questa posizione.',
    accettata: 'Giusto.', alternativaGiusta: 'Giusto: anche questa mossa funziona.',
    sbagliata: 'Non funziona: l\'avversario ha una risposta.',
    nonObiettivo: 'Mossa buona, ma qui l\'obiettivo è un altro: c\'è una strada più diretta. Riprova.',
    verifico: 'Verifico questa alternativa…',
    incerta: 'Non posso valutare con sicurezza questa alternativa. Nessun errore registrato: prova un\'altra mossa o guarda la soluzione.',
    stallo: 'Attenzione: questa mossa dà stallo, la partita finirebbe patta.'
  };
  function crea(d) {
    var Chess = d.Chess, Sol = d.CNApSoluzione, so = d.soluzione;
    function nodi(ex) { var m = {}; ex.solutionTree.nodes.forEach(function (n) { m[n.id] = n; }); return m; }
    function itSan(s) { return s.replace(/[KQRBN]/g, function (p) { return { K: 'R', Q: 'D', R: 'T', B: 'A', N: 'C' }[p]; }); }
    function risposta(N, figlioId) {   // l'avversario risponde SOLO dal ramo verificato (miglior difesa)
      var f = N[figlioId]; if (!f) return { finito: true };
      if (f.tipo === 'terminal') return { finito: true, terminale: f.terminale };
      if (f.tipo === 'opponent') { var e = (f.replyEdges || []).filter(function (x) { return x.bestDefence; })[0] || f.replyEdges[0]; var g = N[e.childId];
        return { finito: !g || g.tipo === 'terminal', mossaAvversario: { uci: e.uci, san: e.san, sanIt: itSan(e.san) }, prossimoNodo: g && g.tipo === 'solver' ? g.id : null, terminale: g && g.terminale }; }
      return { finito: false, prossimoNodo: f.id };
    }
    /* ritorna subito un esito sincrono, oppure {tipo:'verifico', promessa} quando serve il motore */
    function controlla(ex, nodeId, uci) {
      var N = nodi(ex), n = N[nodeId];
      if (!n || n.tipo !== 'solver') return { tipo: 'errore-interno', testo: 'Nodo della soluzione non valido.', penalita: false };
      var x = Sol.mossa(Chess, n.fen, uci);
      if (!x) return { tipo: 'illegale', testo: TESTI.illegale, penalita: false, inputIllegale: true };
      var acc = (n.acceptedMoves || []).filter(function (a) { return a.uci === uci; })[0];
      if (acc) return Object.assign({ tipo: 'accettata', testo: acc.equivalenza === 'equivalente' ? TESTI.alternativaGiusta : TESTI.accettata, penalita: false, san: x.san }, risposta(N, acc.childId));
      if (x.c.isCheckmate() && ex.objective && ex.objective.tipo === 'matto') return { tipo: 'accettata', testo: TESTI.alternativaGiusta, penalita: false, san: x.san, finito: true, terminale: { tipo: 'matto' }, nonCatalogata: true };
      var conf = (n.refutedMoves || []).filter(function (a) { return a.uci === uci; })[0];
      if (conf) return { tipo: 'sbagliata', testo: conf.motivo === 'stallo' ? TESTI.stallo : TESTI.sbagliata, penalita: true, san: x.san, prova: { evidenceRef: conf.evidenceRef, P: conf.P, motivo: conf.motivo } };
      var buona = (n.buoneNonObiettivo || []).filter(function (a) { return a.uci === uci; })[0];
      if (buona) return { tipo: 'non-obiettivo', testo: TESTI.nonObiettivo, penalita: false, san: x.san };
      // mossa non catalogata: verifica prioritaria, nessuna penalità nel frattempo
      var promessa = (so ? so.valutaMossa(ex, n, uci, { priorita: 'interattivo' }) : Promise.resolve({ giudizio: 'incerta', motivo: 'motore non disponibile' })).then(function (v) {
        if (v.giudizio === 'equivalente') return { tipo: 'alternativa-valida', testo: TESTI.alternativaGiusta + ' La aggiungiamo alla soluzione dopo una verifica completa.', penalita: false, san: x.san, finito: true, daRivalidare: true, prova: v };
        if (v.giudizio === 'sbagliata') return { tipo: 'sbagliata', testo: v.stallo ? TESTI.stallo : TESTI.sbagliata, penalita: true, san: x.san, prova: v };
        if (v.giudizio === 'non-obiettivo') return { tipo: 'non-obiettivo', testo: TESTI.nonObiettivo, penalita: false, san: x.san, prova: v };
        return { tipo: 'incerta', testo: TESTI.incerta, penalita: false, san: x.san, prova: v };
      }, function (e) { return { tipo: 'incerta', testo: TESTI.incerta, penalita: false, san: x.san, motivo: e && e.message }; });
      return { tipo: 'verifico', testo: TESTI.verifico, penalita: false, san: x.san, promessa: promessa };
    }
    /* la spiegazione si mostra solo DOPO il tentativo o a soluzione richiesta: mai prima */
    function spiegazione(ex, tentativo) {
      if (!tentativo || !(tentativo.endedAt || tentativo.solutionShown)) return null;
      if (!ex.explanation || ex.explanation.solutionVersion !== ex.solutionVersion) return null;
      return ex.explanation;
    }
    return { controlla: controlla, spiegazione: spiegazione, TESTI: TESTI };
  }
  return { crea: crea, TESTI: TESTI, VERSIONE: 'cnap-risposta-1' };
});
