/* Chess Node · Analisi profonda · FASE 2 · CNApFasi — fasi della partita e tipo di finale (DECISO Q11, A1-06 §10.4).
   Codice originale Chess Node (08/11/2026). Calcolo puro sulle FEN della linea principale.
   - Apertura: termina al PRIMO tra il limite (15ª mossa, configurabile) e gli indicatori soddisfatti insieme:
     fuori teoria (dataset versionato; SENZA dataset l'indicatore non può dirsi soddisfatto prima del limite) + sviluppo + struttura.
     Uscire presto dalla teoria con pezzi non sviluppati NON è mediogioco.
   - Finale: dal materiale rimasto (non basta l'assenza delle donne). Tipi: pedoni, torre, pezzi leggeri, donna, misti.
   - Isteresi: la fase è monotona Apertura → Mediogioco → Finale; una promozione in finale cambia il TIPO, mai la fase.
   Numeri = proposta tecnica versionata e configurabile, da tarare. */
(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api; else root.CNApFasi = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  var CFG = { limiteApertura: 15, sviluppoMinimo: 3, materialeFinaleTotale: 20, versione: 'cnap-fasi-1' };
  var VAL = { q: 9, r: 5, b: 3, n: 3 };

  function pezzi(fen) {
    var b = [], righe = fen.split(' ')[0].split('/');
    righe.forEach(function (r, i) { var f = 0; r.split('').forEach(function (c) { if (/\d/.test(c)) f += +c; else { b.push({ p: c, sq: 'abcdefgh'[f] + (8 - i) }); f++; } }); });
    return b;
  }
  function materiale(fen) {
    var m = { w: { q: 0, r: 0, b: 0, n: 0, p: 0, tot: 0 }, b: { q: 0, r: 0, b: 0, n: 0, p: 0, tot: 0 } };
    pezzi(fen).forEach(function (x) { var l = x.p.toLowerCase(), c = x.p === l ? 'b' : 'w'; if (l === 'k') return; m[c][l]++; if (VAL[l]) m[c].tot += VAL[l]; });
    return m;
  }
  /* pezzi leggeri sviluppati: non più sulle case iniziali */
  function sviluppo(fen) {
    var ps = pezzi(fen), init = { w: ['b1', 'g1', 'c1', 'f1'], b: ['b8', 'g8', 'c8', 'f8'] }, out = {};
    ['w', 'b'].forEach(function (c) {
      var fermi = ps.filter(function (x) { return init[c].indexOf(x.sq) >= 0 && (c === 'w' ? /[NB]/ : /[nb]/).test(x.p); }).length;
      var re = ps.filter(function (x) { return x.p === (c === 'w' ? 'K' : 'k'); })[0];
      out[c] = { leggeriSviluppati: 4 - fermi, reAlSicuro: re && (c === 'w' ? /^[gcb]1$/ : /^[gcb]8$/).test(re.sq) };
    });
    return out;
  }
  function struttura(fen) {   // almeno un pedone centrale (d/e) mosso per lato
    var ps = pezzi(fen), fermi = function (c) { return ps.filter(function (x) { return x.p === (c === 'w' ? 'P' : 'p') && ['d', 'e'].indexOf(x.sq[0]) >= 0 && x.sq[1] === (c === 'w' ? '2' : '7'); }).length; };
    return fermi('w') < 2 && fermi('b') < 2;
  }
  function tipoFinale(m) {
    var t = m.w.tot + m.b.tot;
    if (t > CFG.materialeFinaleTotale) return null;
    var tot = function (k) { return m.w[k] + m.b[k]; };
    if (!t) return 'pedoni';
    if (tot('q') && !tot('r') && !tot('b') && !tot('n')) return 'donna';
    if (tot('r') && !tot('q') && !tot('b') && !tot('n')) return 'torre';
    if (!tot('q') && !tot('r') && (tot('b') || tot('n'))) return 'pezzi leggeri';
    return 'misti';
  }
  /* fens[0..n] → [{fase, tipoFinale?, motivo}]; o.teoria = function(i) → true se la posizione i è nel dataset di teoria (assente → null) */
  function fasi(fens, o) {
    o = o || {};
    var out = [], fase = 'apertura', tipo = null;
    for (var i = 0; i < fens.length; i++) {
      var f = fens[i], fm = +f.split(' ')[5], m = materiale(f), tf = tipoFinale(m), motivo = null;
      if (fase !== 'finale' && tf) { fase = 'finale'; motivo = 'materiale rimasto'; }
      if (fase === 'apertura') {
        var sv = sviluppo(f), inTeoria = o.teoria ? o.teoria(i) : null;
        var sviluppato = sv.w.leggeriSviluppati >= CFG.sviluppoMinimo && sv.b.leggeriSviluppati >= CFG.sviluppoMinimo;
        var fuoriTeoria = inTeoria === false;   // senza dataset: sconosciuto → non conta come soddisfatto
        if (fm > CFG.limiteApertura) { fase = 'mediogioco'; motivo = 'limite di ' + CFG.limiteApertura + ' mosse'; }
        else if (fuoriTeoria && sviluppato && struttura(f)) { fase = 'mediogioco'; motivo = 'fuori teoria con sviluppo e struttura'; }
      }
      if (fase === 'finale') tipo = tf || tipo;   // isteresi: la fase resta Finale; il tipo segue il materiale (es. nuova donna)
      out.push({ fase: fase, tipoFinale: fase === 'finale' ? (tf || tipo) : null, motivo: motivo });
    }
    return out;
  }
  return { fasi: fasi, materiale: materiale, tipoFinale: tipoFinale, sviluppo: sviluppo, CFG: CFG, VERSIONE: CFG.versione };
});
