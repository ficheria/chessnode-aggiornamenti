/* Chess Node · Analisi profonda · FASE 2 · CNApDifetti — difetto ricorrente da occasioni reali (A1-07, DECISO Q02).
   Codice originale Chess Node (08/11/2026). Calcolo puro sulle occasioni di CNApTemi (solo certezza 1, solo analisi valide e di
   versione compatibile). Mai certezza: parole semplici e numeri con denominatore.
   Soglie (configurabili e versionate): ≥5 occasioni E ≥3 errori verificati su ≥3 partite diverse; 5–14 «Possibile debolezza»,
   15–29 «Tendenza ricorrente», 30+ «Campione più consistente»; errore ≥ ~40% (PROPOSTA Kiko-bot); «Pochi dati» se < 10 partite analizzate. */
(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api; else root.CNApDifetti = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  var CFG = { minOccasioni: 5, minErrori: 3, minPartiteErrore: 3, minPercentuale: 0.40, pochiDatiPartite: 10, versione: 'cnap-difetti-q02-1' };

  /* occasioni: [{tema, lato, gameId, esito, certezza, detectorVersion}]; partiteAnalizzate: n; o = {lato:'w'|'b'|null per «utente», versioneRilevatore} */
  function valuta(occasioni, partiteAnalizzate, o) {
    o = o || {};
    var per = {}, versioni = {};
    occasioni.forEach(function (x) {
      if (x.certezza !== 1) return;
      if (o.versioneRilevatore && x.detectorVersion !== o.versioneRilevatore) { versioni[x.detectorVersion] = 1; return; }
      if (o.filtroLato && !o.filtroLato(x)) return;
      var t = per[x.tema] = per[x.tema] || { tema: x.tema, occasioni: 0, errori: 0, partiteErrore: {}, partite: {}, prese: 0 };
      t.occasioni++; t.partite[x.gameId] = 1;
      if (x.esito === 'mancato') { t.errori++; t.partiteErrore[x.gameId] = 1; }
      if (/^preso/.test(x.esito)) t.prese++;
    });
    var pochi = partiteAnalizzate < CFG.pochiDatiPartite;
    var out = Object.keys(per).sort().map(function (k) {
      var t = per[k], pe = Object.keys(t.partiteErrore).length, rate = t.occasioni ? t.errori / t.occasioni : null, stato, livello = null;
      var basta = t.occasioni >= CFG.minOccasioni && t.errori >= CFG.minErrori && pe >= CFG.minPartiteErrore && rate >= CFG.minPercentuale;
      if (pochi) stato = 'Pochi dati';
      else if (!basta) stato = 'da osservare';
      else { livello = t.occasioni >= 30 ? 'Campione più consistente' : t.occasioni >= 15 ? 'Tendenza ricorrente' : 'Possibile debolezza'; stato = livello; }
      return { tema: k, occasioni: t.occasioni, errori: t.errori, prese: t.prese, partiteConOccasione: Object.keys(t.partite).length, partiteConErrore: pe,
        percentualeErrore: rate == null ? null : Math.round(rate * 1000) / 10, stato: stato, confermato: !!livello, partiteAnalizzate: partiteAnalizzate,
        testo: livello ? livello + ': ' + t.errori + ' errori su ' + t.occasioni + ' occasioni in ' + pe + ' partite diverse (su ' + partiteAnalizzate + ' analizzate).'
          : stato === 'Pochi dati' ? 'Pochi dati: meno di ' + CFG.pochiDatiPartite + ' partite analizzate nel periodo.' : 'Da osservare: ' + t.errori + ' errori su ' + t.occasioni + ' occasioni.' };
    });
    return { versione: CFG.versione, partiteAnalizzate: partiteAnalizzate, temi: out, escluseVersioneDiversa: Object.keys(versioni) };
  }
  return { valuta: valuta, CFG: CFG, VERSIONE: CFG.versione };
});
