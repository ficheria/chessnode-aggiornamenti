/* Chess Node · Analisi profonda · FASE 5 · CNApAvversario — «Studia un avversario» (A2-12, Q04, Q05).
   Codice originale Chess Node (09/11/2026). Stesso archivio, stesso motore, stesso classificatore e stesse formule di «Analizza me»,
   con un AMBITO distinto: scope = subjectId = 'opp:<servizio>:<id account>'. Serve a prepararsi PRIMA di una partita.
   Regole:
   - solo chiamate pubbliche (adattatori della fase 1: lista positiva, nessun login, nessun token); del profilo si tiene SOLO id, nome
     pubblico e ritmi (mai realName, location o simili); nessun upload; tutto sul dispositivo; cloud-eval spento;
   - due account con lo stesso nome su siti diversi = due soggetti distinti (l'ID contiene il servizio);
   - il colore «dell'utente» di una partita resta quello dell'UTENTE (identità delle impostazioni), mai quello dell'avversario:
     il lato studiato si ricava dai giocatori della partita e non viene scritto sulla partita;
   - campione per l'analisi salvato nel record del soggetto, NON su Game.sampling (che è del profilo personale);
   - conservazione Q05: non salvato → cancellato dopo 30 giorni dalla creazione (expiresAt fisso, mai prolungato di nascosto);
     «Salva» lo tiene; cancellazione manuale sempre; si tolgono ambito, analisi e cache dedicati, MAI una partita condivisa
     con l'archivio personale o con un altro soggetto salvato. */
(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api; else root.CNApAvversario = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  var VERSIONE = 'cnap-avversario-1', POLITICA = 'campione-avversario-q04-v1';
  var GIORNO = 86400000;
  var CFG = { giorniConservazione: 30, mesi: 12, perMese: 60, obiettivoMese: 15, ritmiEsclusi: ['bullet', 'ultrabullet'], minMossePiene: 10,
    repertorio: { minPartitePerColore: 5, quotaMin: 0.20, minPartite: 3 }, letturaOpposta: { minDistacco: 10 } };

  function crea(d) {
    var S = d.servizio, A = S.archivio, U = d.CNApUtil, AN = d.analisi || null, ora = d.ora || function () { return Date.now(); };
    var C = Object.assign({}, CFG, d.cfg || {});
    function err(c, m) { var e = new Error(m); e.code = c; return e; }
    function chiaveRecord(id) { return 'avversario:' + id; }
    function soggettoId(servizio, idAccount) { return 'opp:' + servizio + ':' + String(idAccount).toLowerCase(); }
    async function record(id) { return A.meta(chiaveRecord(id)); }
    async function scriviRecord(r) { await A.salvaMeta(chiaveRecord(r.subjectId), r); return r; }
    function nomeServizio(s) { return s === 'lichess' ? 'Lichess' : 'Chess.com'; }

    /* ---------- lato studiato di una partita: il giocatore con lo stesso nome pubblico, e solo se la partita viene da quel servizio ---------- */
    function latoSoggetto(g, r) {
      if (!(g.sourceRefs || []).some(function (s) { return s.source === r.service; })) return null;
      var n = r.publicName.toLowerCase(), w = (g.players.w.name || '').toLowerCase() === n, b = (g.players.b.name || '').toLowerCase() === n;
      return w && !b ? 'w' : b && !w ? 'b' : null;
    }
    /* vista: copie delle partite dell'ambito con userColor := lato studiato (solo in memoria, mai salvate) */
    async function vista(id) {
      var r = await record(id); if (!r) return null;
      var gs = await A.partite({ scope: id }), an = {}, opposte = r.letturaOpposta || {};
      await A.tx(['analyses'], 'readonly', async function (t) { (await t.all('analyses')).forEach(function (a) { if (!opposte[a.gameId]) (an[a.gameId] = an[a.gameId] || []).push(a); }); });
      var senzaLato = 0;
      var partite = gs.map(function (g) { var c = U.clone(g), l = latoSoggetto(g, r); if (!l) senzaLato++; c.userColor = l; c.sampling = { selectedForEngine: !!(r.campione.selezionate[g.gameId]), motivo: r.campione.selezionate[g.gameId] || null }; return c; });
      return { record: r, dati: { partite: partite, analisi: an }, senzaLato: senzaLato };
    }

    /* ---------- repertorio dell'utente (dalle SUE partite) per pesare le aperture che probabilmente incontrerà ---------- */
    async function repertorioUtente() {
      var gs = (await A.partite({ scope: 'self' })).filter(function (g) { return g.userColor && g.mainLineUci && g.mainLineUci.length >= 2; });
      var out = { w: null, b: null, partite: { w: 0, b: 0 } };
      ['w', 'b'].forEach(function (c) {
        var mie = gs.filter(function (g) { return g.userColor === c; }); out.partite[c] = mie.length;
        if (mie.length < C.repertorio.minPartitePerColore) return;
        var cnt = {}; mie.forEach(function (g) { var k = c === 'w' ? g.mainLineUci[0] : g.mainLineUci[0] + ' ' + g.mainLineUci[1]; cnt[k] = (cnt[k] || 0) + 1; });
        var chiavi = Object.keys(cnt).filter(function (k) { return cnt[k] >= C.repertorio.minPartite && cnt[k] / mie.length >= C.repertorio.quotaMin; }).sort();
        if (chiavi.length) out[c] = { chiavi: chiavi, conteggi: chiavi.reduce(function (m, k) { m[k] = cnt[k]; return m; }, {}), partite: mie.length };
      });
      out.presente = !!(out.w || out.b);
      return out;
    }
    /* la partita è un'apertura che l'utente probabilmente incontrerà? (l'utente avrebbe il colore opposto al soggetto) */
    function pertinente(g, lato, rep) {
      if (!g.mainLineUci || g.mainLineUci.length < 2) return false;
      if (lato === 'b') return !!(rep.w && rep.w.chiavi.indexOf(g.mainLineUci[0]) >= 0);                                   // l'utente col Bianco: stessa prima mossa
      return !!(rep.b && rep.b.chiavi.indexOf(g.mainLineUci[0] + ' ' + g.mainLineUci[1]) >= 0);                             // l'utente col Nero: stessa risposta
    }
    function h(s) { var a = 0x811c9dc5; for (var i = 0; i < s.length; i++) a = Math.imul(a ^ s.charCodeAt(i), 16777619) >>> 0; return a; }
    function ordine(a, b) { return (b.playedAtMs || 0) - (a.playedAtMs || 0) || h(a.gameId) - h(b.gameId) || (a.gameId < b.gameId ? -1 : 1); }

    /* ---------- selezione DETERMINISTICA per un mese (tetti Q04 invariati) ---------- */
    function selezionaMese(games, r, rep) {
      var out = { politica: POLITICA, popolazione: games.length, idonee: 0, selezionate: [], escluse: [], perColore: { w: 0, b: 0 }, pertinenti: 0, criterio: rep.presente ? 'repertorio' : 'generale', nota: null };
      var idonee = [];
      games.slice().sort(ordine).forEach(function (g) {
        var l = latoSoggetto(g, r), m = null;
        if (g.variant !== 'standard') m = 'variante non standard';
        else if (C.ritmiEsclusi.indexOf(g.timeClass) >= 0) m = 'ritmo ' + g.timeClass + ' escluso dall\'analisi automatica';
        else if (!g.timeClass) m = 'ritmo sconosciuto';
        else if ((g.fullMoves || 0) < C.minMossePiene) m = 'terminata prima della ' + C.minMossePiene + 'ª mossa';
        else if (!l) m = 'lato del giocatore studiato non identificato';
        if (m) out.escluse.push({ gameId: g.gameId, motivo: m }); else idonee.push({ g: g, l: l });
      });
      out.idonee = idonee.length;
      var target = Math.min(C.obiettivoMese, idonee.length), preso = {};
      function prendi(x, motivo) { out.selezionate.push({ gameId: x.g.gameId, motivo: motivo }); preso[x.g.gameId] = 1; out.perColore[x.l]++; }
      // 1) prima le aperture che l'utente probabilmente incontrerà (solo se il repertorio c'è)
      if (rep.presente) idonee.forEach(function (x) { if (out.selezionate.length < target && pertinente(x.g, x.l, rep)) { prendi(x, 'apertura che probabilmente incontrerai'); out.pertinenti++; } });
      // 2) il resto: equilibrio dei colori e dei ritmi in proporzione (come il campione generale)
      var pool = idonee.filter(function (x) { return !preso[x.g.gameId]; }), classi = {};
      idonee.forEach(function (x) { classi[x.g.timeClass] = (classi[x.g.timeClass] || 0) + 1; });
      var nomi = Object.keys(classi).sort(), perRitmo = {};
      out.selezionate.forEach(function (s) { var g = idonee.filter(function (x) { return x.g.gameId === s.gameId; })[0].g; perRitmo[g.timeClass] = (perRitmo[g.timeClass] || 0) + 1; });
      while (out.selezionate.length < target && pool.length) {
        var best = null, bd = -Infinity;
        nomi.forEach(function (k) { if (!pool.some(function (x) { return x.g.timeClass === k; })) return; var def = target * classi[k] / idonee.length - (perRitmo[k] || 0); if (def > bd + 1e-9) { bd = def; best = k; } });
        var col = out.perColore.w <= out.perColore.b ? 'w' : 'b';
        var cand = pool.filter(function (x) { return x.g.timeClass === best && x.l === col; })[0] || pool.filter(function (x) { return x.g.timeClass === best; })[0];
        prendi(cand, rep.presente ? 'equilibrio colore/ritmo' : 'campione generale (equilibrio colore/ritmo)'); perRitmo[best] = (perRitmo[best] || 0) + 1; pool.splice(pool.indexOf(cand), 1);
      }
      pool.forEach(function (x) { if (!preso[x.g.gameId]) out.escluse.push({ gameId: x.g.gameId, motivo: 'obiettivo mensile raggiunto' }); });
      if (idonee.length < C.obiettivoMese) out.nota = 'Solo ' + idonee.length + ' partite idonee nel mese: analizzate tutte, nessun riempimento.';
      return out;
    }
    async function ricampiona(r) {
      var rep = await repertorioUtente(), gs = await A.partite({ scope: r.subjectId }), perMese = {};
      gs.forEach(function (g) { if (g.monthRome) (perMese[g.monthRome] = perMese[g.monthRome] || []).push(g); });
      var sel = {}, mesi = {};
      Object.keys(perMese).sort().forEach(function (m) { var x = selezionaMese(perMese[m], r, rep); mesi[m] = x; x.selezionate.forEach(function (s) { sel[s.gameId] = s.motivo; }); });
      Object.keys(r.campione.fuoriCampione || {}).forEach(function (gid) { if (!sel[gid]) sel[gid] = 'analisi manuale (fuori campione)'; });
      r.campione = { politica: POLITICA, mesi: mesi, selezionate: sel, fuoriCampione: r.campione.fuoriCampione || {}, repertorio: rep,
        criterio: rep.presente ? 'Più peso alle aperture che probabilmente incontrerai (dal tuo repertorio: ' + (rep.w ? rep.w.partite + ' tue partite col Bianco' : '') + (rep.w && rep.b ? ', ' : '') + (rep.b ? rep.b.partite + ' col Nero' : '') + ').'
          : 'Il tuo repertorio non è disponibile (servono almeno ' + C.repertorio.minPartitePerColore + ' tue partite per colore): campione generale con equilibrio di colori e ritmi.' };
      return r;
    }

    /* ---------- avvio di uno studio: profilo pubblico, import mese per mese, campione ---------- */
    async function studia(servizio, nome, o) {
      o = o || {};
      await scadenze();
      if (servizio !== 'lichess' && servizio !== 'chesscom') return { esito: 'servizio-non-valido', testo: 'Scegli Lichess o Chess.com.' };
      var prof;
      try { prof = servizio === 'lichess' ? await S.sorgenti.profiloLichess(nome, o) : await S.sorgenti.profiloChesscom(nome, o); }
      catch (e) {
        if (e.code === 'NOUSER') return { esito: 'non-trovato', testo: 'Su ' + nomeServizio(servizio) + ' non esiste un account pubblico «' + nome + '». Controlla il nome: non cerchiamo account simili né su altri siti.' };
        if (e.code === 'NOME_NON_VALIDO') return { esito: 'nome-non-valido', testo: e.message };
        if (e.code === 'NON_PUBBLICO') return { esito: 'non-pubblico', testo: 'L\'account «' + nome + '» non è disponibile pubblicamente su ' + nomeServizio(servizio) + ': nessun dato scaricato.' };
        return { esito: 'rete', codice: e.code, testo: 'Servizio non raggiungibile ora: nessun dato scaricato. Riprova più tardi.' };
      }
      var imp0 = await A.impostazioni(), mie = (imp0.identita[servizio] || []).map(function (x) { return x.toLowerCase(); });
      if (mie.indexOf(prof.nome.toLowerCase()) >= 0 || mie.indexOf(prof.id.toLowerCase()) >= 0) return { esito: 'sei-tu', testo: 'Questo è il tuo account: per le tue partite usa «Analizza me».' };
      var id = soggettoId(servizio, prof.id), r = await record(id), adesso = ora();
      if (!r) r = { subjectId: id, scope: id, service: servizio, accountId: prof.id, publicName: prof.nome, ritmi: prof.ritmi, saved: false, createdAt: adesso, lastUpdatedAt: null,
        expiresAt: adesso + C.giorniConservazione * GIORNO, retentionPolicy: 'q05-30-giorni', campione: { selezionate: {}, fuoriCampione: {} }, letturaOpposta: {}, versione: VERSIONE };
      // import: stesse chiamate pubbliche della fase 1; l'identità è quella dell'UTENTE (così userColor resta il suo, mai l'avversario)
      var identitaUtente = (imp0.identita.file || []).concat(imp0.identita.lichess || [], imp0.identita.chesscom || []);
      var tot = { nuove: 0, identiche: 0, arricchite: 0, collegate: 0 };
      var rep = await S.sorgenti.acquisisci(servizio, prof.nome, {
        mesi: C.mesi, perMese: C.perMese, segnale: o.segnale, aggiorna: o.aggiorna, ora: o.ora || adesso,
        cursori: { get: function (k) { return A.meta(k); }, set: function (k, v) { return A.salvaMeta(k, v); } },
        onMese: async function (m) {
          var prep = { partite: [], diagnostiche: [] };
          m.sorgenti.forEach(function (s) { s.scope = id; s.identita = identitaUtente; var p = S.import.prepara(s, { ora: ora(), batchId: 'B-' + id + '-' + m.mese }); prep.partite = prep.partite.concat(p.partite); prep.diagnostiche = prep.diagnostiche.concat(p.diagnostiche); });
          var ri = await A.importa(prep, { scope: id });
          Object.keys(tot).forEach(function (k) { tot[k] += ri[k] || 0; });
          if (o.onMese) o.onMese(m, ri);
          return ri;
        }
      });
      r.lastUpdatedAt = ora();   // expiresAt NON cambia: si conserva solo con «Salva»
      r.importazione = { mesi: rep.mesi.map(function (x) { return { mese: x.mese, stato: x.stato, importate: x.importate }; }), interrotto: rep.interrotto || null, annullato: !!rep.annullato, totali: tot };
      await ricampiona(r);
      await scriviRecord(r);
      return { esito: 'ok', subjectId: id, record: r, import: rep };
    }

    /* ---------- analisi locale del campione; si ferma e riprende senza rifare il lavoro finito ---------- */
    async function analisiCompleta(gameId) {
      var g = await A.partita(gameId); if (!g || !g.localAnalysisId) return false;
      var a = await A.tx(['analyses'], 'readonly', function (t) { return t.get('analyses', g.localAnalysisId); });
      return !!(a && a.status === 'complete');
    }
    async function annota(r, gameId) {   // analisi di una partita SOLO di avversari: marcata per la pulizia (Q05); se è anche tua non si marca
      var g = await A.partita(gameId); if (!g || !g.localAnalysisId) return;
      var soloAvv = g.scopeRefs.every(function (s) { return /^opp:/.test(s); });
      await A.tx(['analyses'], 'readwrite', async function (t) {
        var a = await t.get('analyses', g.localAnalysisId); if (!a) return;
        if (soloAvv) { a.scope = r.subjectId; a.savedByUser = !!r.saved; a.expiresAt = r.saved ? null : r.expiresAt; } else { delete a.scope; delete a.savedByUser; delete a.expiresAt; }
        await t.put('analyses', a);
      });
    }
    async function avanzamento(id) {
      var r = await record(id); if (!r) return null;
      var ids = Object.keys(r.campione.selezionate), fatte = 0;
      for (var i = 0; i < ids.length; i++) if (await analisiCompleta(ids[i])) fatte++;
      return { selezionate: ids.length, analizzate: fatte, daFare: ids.length - fatte, testo: 'Analizzate ' + fatte + ' di ' + ids.length + ' partite scelte. Nessuna data di fine promessa: l\'analisi gira su questo dispositivo e si ferma se lo chiudi.' };
    }
    async function analizza(id, o) {
      o = o || {};
      if (!AN) throw err('MOTORE', 'Analisi non configurata.');
      var r = await record(id); if (!r) throw err('SOGGETTO', 'Studio inesistente.');
      var ids = Object.keys(r.campione.selezionate).sort(), fatte = 0, nuove = 0;
      for (var i = 0; i < ids.length; i++) {
        if (o.segnale && (o.segnale.fermo || o.segnale.aborted)) return Object.assign(await avanzamento(id), { interrotto: true });   // anche un AbortSignal (come rete e analisi)
        if (await analisiCompleta(ids[i])) { fatte++; await annota(r, ids[i]); continue; }
        await AN.analizzaPartita(ids[i], { livello: o.livello || 'standard', priorita: 'batch', owner: 'avversario' });
        await annota(r, ids[i]); fatte++; nuove++;
        if (o.max && nuove >= o.max) break;
        if (o.onProgress) o.onProgress({ fatte: fatte, di: ids.length });
      }
      await controllaLetture(id);
      return Object.assign(await avanzamento(id), { nuoveAnalisi: nuove });
    }
    /* analisi manuale di qualsiasi partita: sempre possibile, dichiarata «fuori campione» */
    async function segnaFuoriCampione(id, gameId) {
      var r = await record(id); var g = await A.partita(gameId);
      if (!r || !g || g.scopeRefs.indexOf(id) < 0) throw err('PARTITA', 'Partita non presente in questo studio.');
      if (!r.campione.selezionate[gameId]) { r.campione.fuoriCampione[gameId] = ora(); r.campione.selezionate[gameId] = 'analisi manuale (fuori campione)'; }
      return scriviRecord(r);
    }

    /* ---------- valutazioni NOSTRE: una lettura opposta a quella del sito si indaga, non si pubblica ---------- */
    async function controllaLetture(id) {
      var r = await record(id), gs = await A.partite({ scope: id }), op = {};
      for (var i = 0; i < gs.length; i++) {
        var g = gs[i], ea = g.externalAccuracy; if (!ea || ea.w == null || ea.b == null || !g.localAnalysisId) continue;
        var a = await A.tx(['analyses'], 'readonly', function (t) { return t.get('analyses', g.localAnalysisId); }); if (!a || !a.accuracy || a.accuracy.w == null || a.accuracy.b == null) continue;
        var dl = ea.w - ea.b, dn = a.accuracy.w - a.accuracy.b, M = C.letturaOpposta.minDistacco;
        if (Math.abs(dl) >= M && Math.abs(dn) >= M && (dl > 0) !== (dn > 0)) op[g.gameId] = { servizio: ea.source, loro: { w: ea.w, b: ea.b }, nostra: { w: a.accuracy.w, b: a.accuracy.b }, motivo: 'lettura opposta della partita: esclusa dalla scheda finché non è verificata' };
      }
      r.letturaOpposta = op; await scriviRecord(r); return op;
    }

    /* ---------- conservazione (Q05) ---------- */
    function testoConservazione(r) {
      if (r.saved) return 'Studio salvato: resta su questo dispositivo finché non lo cancelli.';
      return 'Studio non salvato: si cancella da solo il ' + U.dataRoma(r.expiresAt).split('-').reverse().join('/') + ' (30 giorni dalla creazione). Premi «Salva» per tenerlo. Puoi cancellarlo in ogni momento.';
    }
    async function salva(id) { var r = await record(id); if (!r) return null; r.saved = true; r.savedAt = ora(); r.expiresAt = null; await scriviRecord(r); for (var g of Object.keys(r.campione.selezionate)) await annota(r, g); return r; }
    /* togliere il salvataggio fa ripartire 30 giorni da ADESSO (dichiarato nel testo), non da una data nascosta */
    async function nonSalvare(id) { var r = await record(id); if (!r) return null; r.saved = false; r.expiresAt = ora() + C.giorniConservazione * GIORNO; await scriviRecord(r); for (var g of Object.keys(r.campione.selezionate)) await annota(r, g); return r; }
    /* apertura della scheda: legge e basta (nessuna scrittura di date) */
    async function apri(id) { await scadenze(); return record(id); }
    async function elenco() { await scadenze(); return (await A.tx(['meta'], 'readonly', function (t) { return t.all('meta'); })).filter(function (m) { return /^avversario:/.test(m.key); }).map(function (m) { return m.valore || m.value || m; }); }

    async function elimina(id, motivo) {
      var r = await record(id); if (!r) return { eliminato: false };
      var stores = ['games', 'nodes', 'gameSources', 'analyses', 'analysisJobs', 'exerciseRefs', 'profileSnapshots', 'cache', 'meta'];
      var rep = { subjectId: id, motivo: motivo || 'manuale', partiteCancellate: 0, partiteConservate: 0, analisiCancellate: 0 };
      await A.tx(stores, 'readwrite', async function (t) {
        var gs = await t.byIndex('games', 'scope', id);
        for (var i = 0; i < gs.length; i++) {
          var g = gs[i], altri = g.scopeRefs.filter(function (s) { return s !== id; });
          if (altri.length) {   // partita anche tua o di un altro studio: si toglie solo questo ambito
            g.scopeRefs = altri; g.updatedAt = ora(); await t.put('games', g); rep.partiteConservate++;
            if (g.localAnalysisId) { var a0 = await t.get('analyses', g.localAnalysisId); if (a0 && a0.scope === id) { if (altri.every(function (s) { return /^opp:/.test(s); })) a0.scope = altri[0]; else { delete a0.scope; delete a0.expiresAt; delete a0.savedByUser; } await t.put('analyses', a0); } }
            continue;
          }
          var del = async function (s, idx) { var l = await t.byIndex(s, idx, g.gameId); for (var j = 0; j < l.length; j++) await t.del(s, l[j][{ nodes: 'nodeId', gameSources: 'sourceRevKey', analyses: 'analysisId', analysisJobs: 'jobId', exerciseRefs: 'refId' }[s]]); return l.length; };
          await del('nodes', 'gameId'); await del('gameSources', 'gameId'); rep.analisiCancellate += await del('analyses', 'gameId'); await del('analysisJobs', 'gameId'); await del('exerciseRefs', 'gameId');
          await t.del('games', g.gameId); await t.del('meta', 'statoAnalisi:' + g.gameId); rep.partiteCancellate++;
        }
        var snap = await t.byIndex('profileSnapshots', 'subjectId', id); for (var k = 0; k < snap.length; k++) await t.del('profileSnapshots', snap[k].snapshotId);
        var cache = await t.all('cache'); for (var c = 0; c < cache.length; c++) if (String(cache[c].key).indexOf(id) === 0) await t.del('cache', cache[c].key);
        var meta = await t.all('meta'), pref = 'cursore:' + r.service + ':' + r.publicName.toLowerCase() + ':';
        for (var m = 0; m < meta.length; m++) if (String(meta[m].key).indexOf(pref) === 0) await t.del('meta', meta[m].key);
        await t.del('meta', chiaveRecord(id));
      });
      rep.eliminato = true; return rep;
    }
    /* cancellazione automatica: solo i NON salvati la cui scadenza è passata (strettamente dopo expiresAt) */
    async function scadenze() {
      var adesso = ora(), metas = await A.tx(['meta'], 'readonly', function (t) { return t.all('meta'); }), out = [];
      for (var i = 0; i < metas.length; i++) {
        if (!/^avversario:/.test(metas[i].key)) continue;
        var r = await record(metas[i].key.slice('avversario:'.length));
        if (r && !r.saved && r.expiresAt != null && adesso > r.expiresAt) out.push(await elimina(r.subjectId, 'scadenza 30 giorni (non salvato)'));
      }
      return out;
    }

    return { soggettoId: soggettoId, studia: studia, analizza: analizza, avanzamento: avanzamento, segnaFuoriCampione: segnaFuoriCampione, vista: vista, latoSoggetto: latoSoggetto,
      repertorioUtente: repertorioUtente, selezionaMese: selezionaMese, ricampiona: ricampiona, controllaLetture: controllaLetture,
      salva: salva, nonSalvare: nonSalvare, apri: apri, elenco: elenco, elimina: elimina, scadenze: scadenze, record: record, testoConservazione: testoConservazione, CFG: C };
  }
  return { crea: crea, CFG: CFG, VERSIONE: VERSIONE, POLITICA: POLITICA };
});
