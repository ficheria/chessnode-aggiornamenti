/* Chess Node · Analisi profonda · FASE 2 · CNApStato — UN solo stato della posizione corrente per la schermata di analisi (A2-04, A2-05, A2-08).
   Codice originale Chess Node (08/11/2026). Prototipo tecnico della fase 2: nessun DOM. La UI legge solo snapshot().
   Catena unica: Partita → Nodo → FEN (derivata dal nodo, mai seconda fonte) → Valutazione → Commento.
   - La linea principale (mosse giocate) è IMMUTABILE: ogni mossa diversa crea un ramo di analisi separato; se il ramo esiste si riusa.
   - selezionaPosizione() è l'unico punto di cambio: incrementa selectionRevision, annulla la richiesta live precedente, mostra solo
     dati del nodo esatto. Una risposta tardiva può essere salvata sul SUO nodo ma non aggiorna la vista.
   - «Torna alla partita» usa un segnalibro esplicito impostato uscendo dalla principale (i rami annidati non lo sovrascrivono).
   - Annulla agisce sulle modifiche (aggiunta/eliminazione ramo), mai sulla navigazione e mai sulla linea importata.
   - Diretta (Stockfish live) SPENTA all'apertura (Q06); MultiPV 1–5, default 3; spegnere non cancella valutazioni salvate.
   - Ritorno dall'esercizio: riferimento completo e ripristino esatto. Persistenza dopo ogni selezione/modifica. */
(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api; else root.CNApStato = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  function err(code, msg) { var e = new Error(msg); e.code = code; return e; }

  function crea(d) {
    var A = d.archivio, Chess = d.Chess, S = d.scheduler || null, Pt = d.CNApPunteggio, U = d.CNApUtil, ora = d.ora || function () { return Date.now(); };
    var owner = d.owner || 'analisi-live';
    var st = null, nodi = {}, analisi = null, live = {}, ascolti = [], richiesta = null, undo = [];

    function avvisa() { var s = snapshot(); ascolti.forEach(function (f) { try { f(s); } catch (e) {} }); }
    async function salva() {
      if (!st) return;
      try { await A.salvaMeta('statoAnalisi:' + st.gameId, { gameId: st.gameId, selectedNodeId: st.selectedNodeId, mainReturnNodeId: st.mainReturnNodeId, orientation: st.orientation, multiPV: st.multiPV, instructorDetail: st.instructorDetail, preferiti: st.preferiti, trainingReturn: st.trainingReturn, salvatoIl: ora() }); st.erroreSalvataggio = null; }
      catch (e) { st.erroreSalvataggio = e.message; }   // diagnostica: mai ignorato in silenzio
    }

    async function apri(gameId, o) {
      o = o || {};
      var g = await A.partita(gameId); if (!g) throw err('NON_TROVATA', 'Partita non trovata.');
      nodi = {}; (await A.nodi(gameId)).forEach(function (n) { nodi[n.nodeId] = n; });
      unisciFigliAnalisi();   // le varianti salvate stanno in analysisChildIds: in memoria si uniscono a childIds, così restano visibili e non si crea un doppione
      analisi = g.localAnalysisId ? await A.tx(['analyses'], 'readonly', function (t) { return t.get('analyses', g.localAnalysisId); }) : null;
      var sal = await A.meta('statoAnalisi:' + gameId), nota = null;
      st = { schemaVersion: 1, gameId: gameId, game: g, selectedNodeId: g.rootNodeId, mainReturnNodeId: g.rootNodeId, orientation: g.userColor === 'b' ? 'black' : 'white',
        liveEnabled: false, multiPV: 3, selectionRevision: 0, activeRequestId: null, instructorDetail: 'normale', preferiti: {}, trainingReturn: null, comparison: null };
      if (sal) {
        ['orientation', 'multiPV', 'instructorDetail', 'preferiti', 'trainingReturn'].forEach(function (k) { if (sal[k] != null) st[k] = sal[k]; });
        st.mainReturnNodeId = nodi[sal.mainReturnNodeId] ? sal.mainReturnNodeId : g.rootNodeId;
        var cand = o.nodeId || sal.selectedNodeId;
        if (cand && !nodi[cand]) { nota = 'La posizione salvata non esiste più: aperta la posizione valida più vicina.'; cand = st.mainReturnNodeId; }
        if (cand) st.selectedNodeId = cand;
      } else if (o.nodeId && nodi[o.nodeId]) st.selectedNodeId = o.nodeId;
      st.liveEnabled = false;   // Q06: mai acceso all'apertura, anche se lo era alla chiusura
      st.avviso = nota;
      return selezionaPosizione(st.selectedNodeId, { daApertura: true });
    }

    function figliDi(n) {
      if (!n) return [];
      var ids = (n.childIds || []).concat(n.analysisChildIds || []), visti = {}, out = [];
      ids.forEach(function (c) { if (c && nodi[c] && !visti[c]) { visti[c] = 1; out.push(c); } });
      return out;
    }
    function unisciFigliAnalisi() {
      Object.keys(nodi).forEach(function (id) {
        var n = nodi[id], uniti = figliDi(n);
        if (uniti.length !== (n.childIds || []).length) nodi[id] = Object.assign({}, n, { childIds: uniti });
      });
    }
    function nodo(id) { return nodi[id] || null; }
    function principale(id) { return !!(nodi[id] && (nodi[id].mainLine || nodi[id].origin === 'root')); }
    function percorso(id) { var out = []; while (id) { out.unshift(id); id = nodi[id] ? nodi[id].parentId : null; } return out; }
    function primoPrincipaleAntenato(id) { var p = percorso(id); for (var i = p.length - 1; i >= 0; i--) if (principale(p[i])) return p[i]; return st.game.rootNodeId; }

    /* l'unico punto di cambio della posizione */
    function selezionaPosizione(id, o) {
      o = o || {};
      var n = nodi[id]; if (!n) throw err('NODO', 'Nodo inesistente: selezione bloccata.');
      var prima = st.selectedNodeId;
      if (principale(id)) st.mainReturnNodeId = id;                                      // scelta esplicita di un nodo principale aggiorna il segnalibro
      else if (prima && principale(prima) && !o.daApertura) st.mainReturnNodeId = prima;  // si esce dalla principale: segnalibro sul punto di partenza
      st.selectedNodeId = id; st.selectionRevision++;
      if (n.parentId) st.preferiti[n.parentId] = id;
      if (richiesta) { try { richiesta.annulla(); } catch (e) {} richiesta = null; st.activeRequestId = null; }
      if (st.liveEnabled) avviaLive();
      salva(); avvisa();
      return snapshot();
    }

    function figlioPreferito(id) { var n = nodi[id], f = figliDi(n); if (!n || !f.length) return null; var p = st.preferiti[id]; return p && f.indexOf(p) >= 0 ? p : f[0]; }
    function avanti() { var c = figlioPreferito(st.selectedNodeId); return c ? selezionaPosizione(c) : snapshot(); }
    function indietro() { var p = nodi[st.selectedNodeId].parentId; return p ? selezionaPosizione(p) : snapshot(); }
    function inizio() { return selezionaPosizione(st.game.rootNodeId); }
    function fine() { var id = st.selectedNodeId, c; while ((c = figlioPreferito(id))) id = c; return selezionaPosizione(id); }
    function tornaAllaPartita() { Object.keys(st.preferiti).forEach(function (k) { if (principale(k)) delete st.preferiti[k]; }); return selezionaPosizione(st.mainReturnNodeId); }   // poi Avanti segue la principale
    function ruota() { st.orientation = st.orientation === 'white' ? 'black' : 'white'; salva(); avvisa(); return snapshot(); }   // non cambia FEN, valutazioni o grafico

    /* gioca una mossa sulla posizione corrente: mai sulla principale; ramo riusato se esiste */
    function giocaMossa(uci) {
      var cur = nodi[st.selectedNodeId], c = new Chess(cur.fen), m;
      try { m = c.move({ from: uci.slice(0, 2), to: uci.slice(2, 4), promotion: uci[4] }); } catch (e) { m = null; }
      if (!m) throw err('ILLEGALE', 'Mossa non legale in questa posizione.');
      var u = m.from + m.to + (m.promotion || '');
      var gia = figliDi(cur).filter(function (k) { return nodi[k] && nodi[k].uci === u; })[0];
      if (gia) return selezionaPosizione(gia);
      var id = st.gameId + ':u' + U.hash(cur.nodeId + '>' + u).slice(0, 10), base = id, k = 2;
      while (nodi[id]) id = base + '-' + (k++);
      nodi[id] = { schemaVersion: 1, nodeId: id, gameId: st.gameId, parentId: cur.nodeId, childIds: [], ply: cur.ply + 1, san: m.san, uci: u, fen: c.fen(), mainLine: false, origin: 'analisi-utente', savedByUser: false, pgnCommentsBefore: [], pgnCommentsAfter: [], nags: [], commentIds: [], evaluationIds: [] };
      cur.childIds = cur.childIds.concat([id]);   // copia: la principale salvata in archivio non viene toccata
      undo.push({ tipo: 'aggiungi', nodeId: id, parentId: cur.nodeId });
      return selezionaPosizione(id);
    }
    /* annulla l'ultima MODIFICA (non la navigazione); la linea importata non è mai annullabile */
    function annulla() {
      var a = undo.pop(); if (!a) return { annullato: false, snapshot: snapshot() };
      if (a.tipo === 'aggiungi' && nodi[a.nodeId] && !principale(a.nodeId)) {
        var via = [], q = [a.nodeId]; while (q.length) { var x = q.shift(); via.push(x); q = q.concat(nodi[x].childIds); }
        var p = nodi[a.parentId]; p.childIds = p.childIds.filter(function (k) { return k !== a.nodeId; });
        var eraDentro = via.indexOf(st.selectedNodeId) >= 0;
        via.forEach(function (x) { delete nodi[x]; });
        if (eraDentro) selezionaPosizione(a.parentId);
      }
      return { annullato: true, snapshot: snapshot() };
    }
    /* salva il ramo corrente come variante dell'utente (nodi separati, la principale resta intatta) */
    async function salvaVariante() {
      var ids = percorso(st.selectedNodeId).filter(function (x) { return !principale(x) && !nodi[x].savedByUser; });
      if (!ids.length) return { salvati: 0 };
      await A.tx(['nodes'], 'readwrite', async function (t) {
        for (var i = 0; i < ids.length; i++) { var n = Object.assign({}, nodi[ids[i]], { savedByUser: true, salvatoIl: ora() }); n.childIds = n.childIds.filter(function (c) { return ids.indexOf(c) >= 0 || (nodi[c] && nodi[c].savedByUser); }); await t.put('nodes', n); nodi[ids[i]].savedByUser = true; }
        var padre = Object.assign({}, nodi[nodi[ids[0]].parentId]); var orig = await t.get('nodes', padre.nodeId);
        orig.analysisChildIds = (orig.analysisChildIds || []).concat([ids[0]]).filter(function (x, i, a) { return a.indexOf(x) === i; });   // il figlio principale non cambia
        await t.put('nodes', orig);
      });
      return { salvati: ids.length };
    }

    /* ---------------- valutazioni: analisi salvata + diretta ---------------- */
    function valutazioneSalvata(id) {
      if (!analisi) return null;
      if (id === analisi.root.nodeId && analisi.root.evalWhite) return { fonte: 'analisi salvata', scoreWhite: analisi.root.evalWhite, wdl: analisi.root.wdl, tratto: nodi[id].fen.split(' ')[1], stato: analisi.status };
      var pr = analisi.positionResults.filter(function (x) { return x.nodeId === id; })[0];
      return pr ? { fonte: 'analisi salvata', scoreWhite: pr.evalAfterWhite, wdl: pr.wdlAfter, tratto: pr.trattoDopo, profondita: pr.depthFast, stato: analisi.status } : null;
    }
    function giudizioDelNodo(id) { if (!analisi) return null; var pr = analisi.positionResults.filter(function (x) { return x.nodeId === id; })[0]; return pr || null; }
    function chiaveLive(id) { return id + '|mpv' + st.multiPV; }
    function avviaLive() {
      if (!S) return;
      var id = st.selectedNodeId, n = nodi[id], rev = st.selectionRevision, mpv = st.multiPV, c = new Chess(n.fen);
      if (c.isGameOver()) { live[chiaveLive(id)] = { fineDiPartita: true }; return; }
      var r = S.richiedi({ owner: owner, priorita: 'interattivo', gameId: st.gameId, nodeId: id, fen: n.fen, opz: { depth: d.depthLive || 18, multipv: mpv, maxMs: 15000 },
        onInfo: function (info) { if (info.identita.nodeId === st.selectedNodeId && rev === st.selectionRevision && mpv === st.multiPV) { var k = chiaveLive(id); var x = live[k] = live[k] || { parziale: true, linee: {} }; x.linee[info.multipv] = info; avvisa(); } } });
      richiesta = r; st.activeRequestId = r.requestId;
      r.promessa.then(function (res) {
        var linee = res.linee.filter(function (l) { return pvOk(n.fen, l.pv); });   // PV illegali scartate
        live[id + '|mpv' + res.impostazioni.multipv] = { parziale: !res.completa, linee: linee, profondita: res.profonditaRaggiunta, motore: res.motore && res.motore.nome, nodeId: res.identita.nodeId, fen: res.identita.fen };
        if (res.identita.nodeId === st.selectedNodeId && rev === st.selectionRevision && res.impostazioni.multipv === st.multiPV) { richiesta = null; st.activeRequestId = null; avvisa(); }
      }, function () {});
    }
    function pvOk(fen, pv) { try { var c = new Chess(fen); for (var i = 0; i < pv.length; i++) if (!c.move({ from: pv[i].slice(0, 2), to: pv[i].slice(2, 4), promotion: pv[i][4] })) return false; return true; } catch (e) { return false; } }
    function diretta(on) { st.liveEnabled = !!on; if (!on && richiesta) { richiesta.annulla(); richiesta = null; st.activeRequestId = null; } if (on) avviaLive(); avvisa(); return snapshot(); }
    function impostaMultiPV(k) { k = Math.max(1, Math.min(5, k | 0)); st.multiPV = k; if (richiesta) { richiesta.annulla(); richiesta = null; } if (st.liveEnabled) avviaLive(); salva(); avvisa(); return snapshot(); }

    /* ---------------- grafico della principale (punto di vista del Bianco, matti con tetto fisso) ---------------- */
    function grafico() {
      var main = [], id = st.game.rootNodeId; while (id) { main.push(id); var c = nodi[id].childIds.filter(function (k) { return nodi[k] && nodi[k].mainLine; })[0]; id = c || null; }
      return main.map(function (nid, i) {
        var v = valutazioneSalvata(nid), s = v && v.scoreWhite, pr = giudizioDelNodo(nid);
        var y = null, etich = null;
        if (s) { if (s.tipo === 'mate') { y = s.valore > 0 || s.matto === 'bianco' ? 1 : s.valore < 0 || s.matto === 'nero' ? -1 : 0; etich = s.valore === 0 ? (s.matto === 'bianco' ? '1-0 #' : '0-1 #') : (s.valore > 0 ? '+M' : '−M') + Math.abs(s.valore); } else y = Math.max(-1, Math.min(1, s.valore / 1000)) * 0.9; }   // ±M sul tetto fisso, cp mai oltre 90% dell'altezza
        return { indice: i, nodeId: nid, dopoLaSemimossa: i, y: y, etichetta: etich, mancante: y == null, giudizio: pr ? pr.label : null, critico: pr ? pr.critical : false };
      });
    }
    /* commento SOLO da fatti verificati; altrimenti generico (A2-07) */
    function commento(id) {
      var pr = giudizioDelNodo(id), n = nodi[id];
      if (!n || !n.parentId) return { brief: 'Posizione iniziale.', normal: '', certezza: null, autoplay: false };
      if (!pr) return { brief: principale(id) ? 'Analisi non ancora disponibile.' : 'Mossa di analisi: nessun giudizio salvato.', normal: principale(id) ? 'Questa posizione è in attesa di verifica.' : '', certezza: null, autoplay: false };
      var NOMI = { geniale: 'Geniale', migliore: 'Migliore', ottima: 'Ottima', buona: 'Buona', tranquilla: 'Tranquilla', imprecisione: 'Imprecisione', errore: 'Errore', blunder: 'Blunder', teoria: 'Teoria', obbligata: 'Mossa obbligata', forte: 'Mossa forte', nogiud: 'Nessun giudizio' };
      var IT = { K: 'R', Q: 'D', R: 'T', B: 'A', N: 'C' }, it = function (x) { return x ? x.replace(/^[KQRBN]/, function (c) { return IT[c]; }).replace(/=([QRBN])/, function (m, c) { return '=' + IT[c]; }) : x; };   // italiano solo nella vista
      var san = it(n.san), bestSan = null;
      if (pr.best && pr.best !== pr.played) { try { var c = new Chess(nodi[pr.nodeIdBefore].fen); bestSan = it(c.move({ from: pr.best.slice(0, 2), to: pr.best.slice(2, 4), promotion: pr.best[4] }).san); } catch (e) {} }
      var neg = /^(imprecisione|errore|blunder)$/.test(pr.label), temi = (analisi.themes && analisi.themes.occasioni || []).filter(function (o) { return o.nodeId === pr.nodeIdBefore && o.esito === 'mancato'; });
      var brief = san + ': ' + NOMI[pr.label] + (neg && bestSan ? '. Meglio ' + bestSan + '.' : '.');
      var normal = neg ? (temi.length ? 'Occasione di ' + temi[0].nome.toLowerCase() + ' non sfruttata: la linea verificata ' + temi[0].prova.linea.slice(0, 4).map(it).join(' ') + (temi[0].prova.conseguenza && temi[0].prova.conseguenza.tipo === 'matto' ? ' porta al matto.' : ' vince materiale.') : 'La mossa peggiora la valutazione; il motivo non è stato identificato con sufficiente sicurezza.')
        : pr.label === 'geniale' ? 'Verificata: ' + (pr.labelInfo.motivi || []).join(', ') + '.' : '';
      return { brief: brief, normal: normal, certezza: temi.length ? 1 : neg ? 3 : null, label: pr.label, verificata: pr.verified, profondita: pr.verifyDepth || pr.depthFast, versione: analisi.classificationVersion, stato: analisi.status, autoplay: false };
    }

    /* ---------------- esercizio personale e ritorno al nodo d'origine ---------------- */
    function apriEsercizio(exerciseId) {
      st.trainingReturn = { sessionId: 'TS-' + U.hash(st.gameId + '|' + exerciseId + '|' + ora()).slice(0, 8), exerciseIds: [exerciseId], returnTo: { view: 'analysis', gameId: st.gameId, nodeId: st.selectedNodeId, branchId: principale(st.selectedNodeId) ? 'main' : 'ramo', orientation: st.orientation, selectionRevision: st.selectionRevision }, completedExerciseIds: [], status: 'in corso' };
      if (richiesta) { richiesta.annulla(); richiesta = null; }
      salva(); avvisa(); return st.trainingReturn;
    }
    function chiudiEsercizio(completato) {
      var tr = st.trainingReturn; if (!tr) return snapshot();
      if (completato) tr.completedExerciseIds = tr.exerciseIds.slice();
      st.trainingReturn = null; st.orientation = tr.returnTo.orientation;
      return selezionaPosizione(nodi[tr.returnTo.nodeId] ? tr.returnTo.nodeId : primoPrincipaleAntenato(tr.returnTo.nodeId));
    }

    function snapshot() {
      if (!st) return null;
      var n = nodi[st.selectedNodeId], lv = live[chiaveLive(st.selectedNodeId)] || null;
      return { schemaVersion: 1, gameId: st.gameId, selectedNodeId: st.selectedNodeId, fen: n.fen, san: n.san, ply: n.ply, inVariante: !principale(st.selectedNodeId), mainReturnNodeId: st.mainReturnNodeId,
        orientation: st.orientation, liveEnabled: st.liveEnabled, multiPV: st.multiPV, selectionRevision: st.selectionRevision, activeRequestId: st.activeRequestId,
        instructorDetail: st.instructorDetail, valutazioneSalvata: valutazioneSalvata(st.selectedNodeId), live: lv && lv.nodeId && lv.nodeId !== st.selectedNodeId ? null : lv,
        commento: commento(st.selectedNodeId), trainingReturn: st.trainingReturn, avviso: st.avviso, erroreSalvataggio: st.erroreSalvataggio || null, puoAnnullare: undo.length > 0 };
    }
    return { apri: apri, selezionaPosizione: selezionaPosizione, avanti: avanti, indietro: indietro, inizio: inizio, fine: fine, tornaAllaPartita: tornaAllaPartita, ruota: ruota,
      giocaMossa: giocaMossa, annulla: annulla, salvaVariante: salvaVariante, diretta: diretta, impostaMultiPV: impostaMultiPV, grafico: grafico, commento: commento,
      apriEsercizio: apriEsercizio, chiudiEsercizio: chiudiEsercizio, snapshot: snapshot, nodo: nodo,
      /* elencoNodi: per disegnare la lista con CNVarianti.caricaNodi (fase 3) */
      elencoNodi: function () { return Object.keys(nodi).map(function (k) { return nodi[k]; }); }, percorso: percorso, ascolta: function (f) { ascolti.push(f); }, _live: live };
  }
  return { crea: crea, VERSIONE: 'cnap-stato-1' };
});
