/* Chess Node · Analisi profonda · FASE 2 · CNApUci — adattatore UCI verso il Worker Stockfish ESISTENTE (engine/stockfish-lite.js).
   Codice originale Chess Node (08/11/2026). Stockfish (GPLv3) resta un programma separato nel suo Worker: qui si parla solo UCI
   via messaggi di testo; nessun codice del motore è copiato o incorporato.
   - Una porta = {invia(riga), ascolta(fn)}: daWorker(new Worker('engine/stockfish-lite.js')) nel browser/WebView; nei test Node
     un processo figlio con la stessa interfaccia.
   - Metadati REALI rilevati dal motore (id name, opzioni, UCI_ShowWDL, Threads max): mai versione presunta.
   - Una sola ricerca attiva. stop() manda «stop» e DRENA il bestmove della ricerca fermata prima di accettare la successiva:
     le righe info residue non possono finire sul nodo nuovo. Ricerca fermata = parziale (stopped:true), mai prova finale.
   - Punteggi nel punto di vista di CHI MUOVE (convenzione UCI); la conversione al Bianco si fa una sola volta (CNApPunteggio). */
(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api; else root.CNApUci = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  function err(code, msg) { var e = new Error(msg); e.code = code; return e; }

  function daWorker(w) {
    var fns = [];
    w.onmessage = function (ev) { var l = String(ev.data); fns.forEach(function (f) { f(l); }); };
    return {
      invia: function (l) { w.postMessage(l); }, ascolta: function (f) { fns.push(f); },
      onErrore: function (f) { w.onerror = function (e) { f(e && e.message || 'errore del Worker'); }; },
      chiudi: function () { try { w.postMessage('quit'); w.terminate(); } catch (e) {} }
    };
  }

  /* riga info → oggetto, o null se non è una riga di ricerca utile */
  function leggiInfo(l) {
    if (l.indexOf('info ') !== 0 || l.indexOf(' score ') < 0) return null;
    var t = l.split(/\s+/), o = { multipv: 1, bound: null };
    for (var i = 1; i < t.length; i++) {
      var k = t[i];
      if (k === 'depth') o.depth = +t[++i];
      else if (k === 'seldepth') o.seldepth = +t[++i];
      else if (k === 'multipv') o.multipv = +t[++i];
      else if (k === 'nodes') o.nodes = +t[++i];
      else if (k === 'time') o.time = +t[++i];
      else if (k === 'score') { o.score = { tipo: t[++i], valore: +t[++i] }; if (t[i + 1] === 'lowerbound' || t[i + 1] === 'upperbound') o.bound = t[++i]; }
      else if (k === 'wdl') { o.wdl = [+t[++i], +t[++i], +t[++i]]; }
      else if (k === 'pv') { o.pv = t.slice(i + 1); break; }
    }
    if (!o.score || !/^(cp|mate)$/.test(o.score.tipo) || isNaN(o.score.valore)) return null;
    return o;
  }

  function crea(d) {
    var porta = d.porta, ora = d.ora || function () { return Date.now(); };
    if (!porta) throw new Error('CNApUci: serve una porta');
    var meta = { nome: null, autore: null, opzioni: {}, wdl: false, threadsMax: null, hashMax: null };
    var stato = 'spento', attiva = null, attesaRiga = null, seq = 0, errore = null, guasto = null;
    porta.ascolta(function (l) {
      if (attesaRiga && attesaRiga.re.test(l)) { var a = attesaRiga; attesaRiga = null; a.ok(l); }
      if (/^id name /.test(l)) meta.nome = l.slice(8).trim();
      else if (/^id author /.test(l)) meta.autore = l.slice(10).trim();
      else if (/^option name /.test(l)) {
        var m = /^option name (.+?) type (\w+)(.*)$/.exec(l);
        if (m) { var op = { tipo: m[2] }; var mx = /max (\d+)/.exec(m[3]); if (mx) op.max = +mx[1]; var df = /default (\S+)/.exec(m[3]); if (df) op.default = df[1]; meta.opzioni[m[1]] = op; }
      }
      if (!attiva) return;
      var info = leggiInfo(l);
      if (info) {
        if (info.bound || !info.pv || !info.pv.length) return;   // limiti parziali o senza linea: non sono valori pieni
        attiva.righe[info.multipv] = info;
        if (info.multipv === 1) attiva.profondita = info.depth;
        if (attiva.onInfo && !attiva.fermata) { try { attiva.onInfo(info, attiva.id); } catch (e) {} }
        return;
      }
      if (/^bestmove/.test(l)) {
        var r = attiva; attiva = null; clearTimeout(r.timer);
        var bm = l.split(/\s+/)[1];
        var linee = Object.keys(r.righe).map(Number).sort(function (a, b) { return a - b; }).map(function (k) { return r.righe[k]; });
        var prof = linee.length ? Math.min.apply(null, linee.map(function (x) { return x.depth; })) : 0;
        r.risolvi({ id: r.id, fen: r.fen, bestmove: bm && bm !== '(none)' ? bm : null, nessunaMossa: bm === '(none)', linee: linee, profonditaRaggiunta: prof,
          profonditaRichiesta: r.opz.depth || null, fermata: !!r.fermata, completa: !r.fermata && (!r.opz.depth || prof >= r.opz.depth || bm === '(none)'), ms: ora() - r.t0, impostazioni: r.opz });
      }
    });
    if (porta.onErrore) porta.onErrore(function (m) { guasto = m; if (attiva) { var r = attiva; attiva = null; clearTimeout(r.timer); r.rifiuta(err('MOTORE_GUASTO', 'Il motore si è fermato: ' + m)); } if (attesaRiga) { var a = attesaRiga; attesaRiga = null; a.ko(err('MOTORE_GUASTO', m)); } });

    function aspetta(re, ms, codice) {
      return new Promise(function (ok, ko) {
        var t = setTimeout(function () { attesaRiga = null; ko(err(codice || 'MOTORE_NON_RISPONDE', 'Il motore non risponde.')); }, ms);
        attesaRiga = { re: re, ok: function (l) { clearTimeout(t); ok(l); }, ko: function (e) { clearTimeout(t); ko(e); } };
      });
    }

    var avvio = null;
    function avvia() {
      if (avvio) return avvio;
      stato = 'avvio';
      avvio = (async function () {
        porta.invia('uci'); await aspetta(/^uciok/, d.timeoutAvvioMs || 20000, 'MOTORE_NON_DISPONIBILE');
        meta.wdl = !!meta.opzioni.UCI_ShowWDL;
        meta.threadsMax = meta.opzioni.Threads ? meta.opzioni.Threads.max || 1 : null;
        meta.hashMax = meta.opzioni.Hash ? meta.opzioni.Hash.max || null : null;
        if (meta.wdl) porta.invia('setoption name UCI_ShowWDL value true');
        if (meta.opzioni.UCI_LimitStrength) porta.invia('setoption name UCI_LimitStrength value false');
        if (meta.opzioni['Skill Level']) porta.invia('setoption name Skill Level value 20');
        porta.invia('isready'); await aspetta(/^readyok/, 10000);
        meta.build = meta.nome ? meta.nome + ' · opzioni ' + Object.keys(meta.opzioni).sort().join(',') : null;
        stato = 'pronto'; return meta;
      })();
      avvio.catch(function (e) { stato = 'errore'; errore = e; avvio = null; });
      return avvio;
    }

    /* o = {fen, mosse?, depth?, movetime?, nodes?, multipv=1, hash?, pulisci?, maxMs?} */
    async function cerca(o, onInfo) {
      if (guasto) throw err('MOTORE_GUASTO', 'Il motore si è fermato: ' + guasto);
      await avvia();
      if (attiva) throw err('OCCUPATO', 'Una ricerca è già attiva: fermarla prima (scheduler).');
      var id = ++seq, mpv = Math.max(1, Math.min(5, o.multipv || 1));
      porta.invia('setoption name MultiPV value ' + mpv);
      if (o.hash && meta.opzioni.Hash) porta.invia('setoption name Hash value ' + o.hash);
      if (o.pulisci) { porta.invia('ucinewgame'); if (meta.opzioni['Clear Hash']) porta.invia('setoption name Clear Hash'); }
      porta.invia('isready'); await aspetta(/^readyok/, 10000);
      return new Promise(function (risolvi, rifiuta) {
        var opz = { depth: o.depth || null, movetime: o.movetime || null, nodes: o.nodes || null, multipv: mpv, hash: o.hash || null };
        attiva = { id: id, fen: o.fen, righe: {}, opz: opz, onInfo: onInfo, risolvi: risolvi, rifiuta: rifiuta, t0: ora(), fermata: false };
        var maxMs = o.maxMs || 60000;
        attiva.timer = setTimeout(function () { if (attiva && attiva.id === id) { attiva.fermata = true; attiva.perTempo = true; porta.invia('stop'); } }, maxMs);
        porta.invia('position fen ' + o.fen + (o.mosse && o.mosse.length ? ' moves ' + o.mosse.join(' ') : ''));
        var go = 'go';
        if (o.depth) go += ' depth ' + o.depth;
        if (o.movetime) go += ' movetime ' + o.movetime;
        if (o.nodes) go += ' nodes ' + o.nodes;
        if (go === 'go') go += ' depth 12';
        porta.invia(go);
      });
    }
    /* ferma la ricerca attiva e ATTENDE il suo bestmove (drenaggio) */
    function ferma() {
      if (!attiva) return Promise.resolve(null);
      var a = attiva; a.fermata = true;
      var p = new Promise(function (ok) { var orig = a.risolvi; a.risolvi = function (r) { orig(r); ok(r); }; });
      porta.invia('stop');
      return p;
    }
    return { avvia: avvia, cerca: cerca, ferma: ferma, meta: function () { return meta; }, stato: function () { return attiva ? 'occupato' : stato; }, chiudi: function () { if (porta.chiudi) porta.chiudi(); } };
  }

  return { crea: crea, daWorker: daWorker, leggiInfo: leggiInfo, VERSIONE: 'cnap-uci-1' };
});
