/* Chess Node · Analisi profonda · FASE 4 · CNApControlli — i NOVE controlli automatici (A3-03), il filtro didattico,
   la difficoltà provvisoria 1–5 (A3-06) e la spiegazione verificata (Q07).
   Codice originale Chess Node (09/11/2026).
   Ogni controllo restituisce {n, nome, status: 'pass'|'fail'|'unknown', evidenceRefs[], reason, ruleVersion}: unknown NON è pass.
   L'approvazione richiede 9 pass + filtro didattico pass nella STESSA revisione (lo decide CNApGeneratore).
   Nessuna casella spuntata a mano: tutto è ricalcolato da posizione, albero, evidenze del motore e archivio. */
(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api; else root.CNApControlli = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  var REGOLE = 'cnap-controlli-1', DIDATTICA = 'cnap-didattica-1', DIFF = 'cnap-diff-proposta-1';
  var START = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';
  var NOMI_LIVELLO = { 1: 'Base', 2: 'Facile', 3: 'Intermedio', 4: 'Avanzato', 5: 'Esperto' };
  var NOMI_CONTROLLO = ['FEN valida e raggiungibile', 'Lato del solutore', 'Mosse della soluzione legali', 'Alternative confrontate',
    'Difese dell\'avversario controllate', 'Risultato promesso ottenuto', 'Tema dimostrato', 'Difficoltà e spiegazione coerenti', 'Non duplicato'];
  var NOMI_TEMA = { pezzo_indifeso: 'pezzo indifeso', forchetta: 'forchetta', inchiodatura: 'inchiodatura', infilata: 'infilata', matto_non_visto: 'matto', scoperta: 'attacco di scoperta', difesa: 'difesa', geniale: 'mossa geniale' };
  var VAL = { p: 1, n: 3, b: 3, r: 5, q: 9, k: 0 };

  function fen4(f) { return f.split(' ').slice(0, 4).join(' '); }
  function uciDi(m) { return m.from + m.to + (m.promotion || ''); }

  function crea(d) {
    var Chess = d.Chess, U = d.CNApUtil, Temi = d.CNApTemi, Sol = d.CNApSoluzione;
    var CFG = Sol.CFG;
    function r(n, status, reason, refs) { return { n: n, nome: NOMI_CONTROLLO[n - 1], status: status, evidenceRefs: refs || [], reason: reason || null, ruleVersion: REGOLE }; }
    function nodiPer(ex) { var m = {}; (ex.solutionTree ? ex.solutionTree.nodes : []).forEach(function (n) { m[n.id] = n; }); return m; }
    function play(fen, uci) { return Sol.mossa(Chess, fen, uci); }
    /* linea principale: prima mossa accettata (la migliore) e miglior difesa */
    function lineaPrincipale(ex) {
      var N = nodiPer(ex), n = N[ex.solutionTree.rootId], out = [];
      while (n) {
        var e = n.tipo === 'solver' ? (n.acceptedMoves || [])[0] : n.tipo === 'opponent' ? (n.replyEdges || []).filter(function (x) { return x.bestDefence; })[0] : null;
        if (!e) break; out.push({ uci: e.uci, san: e.san, nodo: n.id, lato: n.lato }); n = N[e.childId];
      }
      return out;
    }
    function foglie(ex) { var N = nodiPer(ex), out = []; (function giu(id, mosseSol) { var n = N[id]; if (!n) { out.push({ id: id, mancante: true }); return; }
      var ed = n.tipo === 'solver' ? n.acceptedMoves || [] : n.tipo === 'opponent' ? n.replyEdges || [] : [];
      if (n.tipo === 'terminal' || !ed.length) { out.push({ id: id, nodo: n, mosseSolutore: mosseSol }); return; }
      ed.forEach(function (e) { giu(e.childId, mosseSol + (n.tipo === 'solver' ? 1 : 0)); }); })(ex.solutionTree.rootId, 0); return out; }

    /* ================= i nove controlli ================= */
    async function esegui(ex, ctx) {
      ctx = ctx || {};
      var out = [], N = ex.solutionTree ? nodiPer(ex) : {}, evid = {}; (ex.evidence || []).forEach(function (e) { evid[e.ref] = e; });

      // 1 — FEN valida e raggiungibile: replay del percorso nell'archivio dalla partita validata
      out.push(await (async function () {
        try { new Chess(ex.startFen); } catch (e) { return r(1, 'fail', 'FEN non valida: ' + e.message); }
        if (!ctx.archivio || !ex.sourceGameId) return r(1, 'unknown', 'Partita d\'origine non disponibile: storia non dimostrata.');
        var g = await ctx.archivio.partita(ex.sourceGameId); if (!g) return r(1, 'unknown', 'Partita d\'origine non trovata.');
        if (g.startFen && g.startFen !== START) return r(1, 'unknown', 'Partita con SetUp/FEN iniziale senza prova di storia.');
        var nodi = {}; (await ctx.archivio.nodi(ex.sourceGameId)).forEach(function (n) { nodi[n.nodeId] = n; });
        var path = [], id = ex.sourceNodeId; while (id) { var n = nodi[id]; if (!n) return r(1, 'fail', 'Nodo d\'origine assente: ' + id); path.unshift(n); id = n.parentId; }
        var c = new Chess(g.startFen || START);
        for (var i = 1; i < path.length; i++) {
          var mv = c.moves({ verbose: true }).filter(function (m) { return uciDi(m) === path[i].uci; })[0];
          if (!mv) return r(1, 'fail', 'Mossa illegale nel replay al nodo ' + path[i].nodeId);
          c.move(mv); if (fen4(c.fen()) !== fen4(path[i].fen)) return r(1, 'fail', 'FEN del nodo ' + path[i].nodeId + ' diversa dal replay.');
        }
        if (c.fen() !== ex.startFen) return r(1, 'fail', 'La posizione dell\'esercizio non coincide con il replay della partita.');
        if (ex.sourcePly !== path.length - 1) return r(1, 'fail', 'sourcePly (' + ex.sourcePly + ') diverso dalla profondità del nodo (' + (path.length - 1) + ').');
        return r(1, 'pass', 'Replay legale di ' + (path.length - 1) + ' semimosse dalla posizione iniziale; FEN identica.', ['partita:' + ex.sourceGameId, 'nodo:' + ex.sourceNodeId]);
      })());

      // 2 — lato del solutore
      out.push((function () {
        var t = ex.startFen.split(' ')[1];
        if (t !== ex.solverColor) return r(2, 'fail', 'Il tratto è del ' + (t === 'w' ? 'Bianco' : 'Nero') + ' ma il solutore è l\'altro lato.');
        if (ctx.userColor && ex.candidateKind && ex.solverColor !== ctx.userColor) return r(2, 'fail', 'Candidato dalle tue partite ma il solutore non è il tuo colore.');
        return r(2, 'pass', 'Tratto del FEN = solutore = ' + (ctx.userColor ? 'tuo colore' : 'lato indicato') + '.');
      })());

      // 3 — tutte le mosse dell'albero legali (ogni ramo), promozioni esplicite, terminali coerenti
      out.push((function () {
        if (!ex.solutionTree || !N[ex.solutionTree.rootId]) return r(3, 'fail', 'Albero della soluzione assente.');
        if (N[ex.solutionTree.rootId].fen !== ex.startFen) return r(3, 'fail', 'La radice dell\'albero non è la posizione dell\'esercizio.');
        var archi = 0;
        for (var id in N) {
          var n = N[id], ed = n.tipo === 'solver' ? n.acceptedMoves || [] : n.tipo === 'opponent' ? n.replyEdges || [] : [];
          for (var i = 0; i < ed.length; i++) {
            var x = play(n.fen, ed[i].uci); if (!x) return r(3, 'fail', 'Mossa illegale o promozione non esplicita: ' + ed[i].uci + ' in ' + id);
            var f = N[ed[i].childId]; if (!f) return r(3, 'fail', 'Ramo senza seguito: ' + id + ' ' + ed[i].uci);
            if (f.fen !== x.fen) return r(3, 'fail', 'FEN del figlio incoerente in ' + id + ' ' + ed[i].uci);
            archi++;
          }
          if (n.tipo === 'terminal' && n.terminale && n.terminale.tipo === 'matto' && !new Chess(n.fen).isCheckmate()) return r(3, 'fail', 'Terminale «matto» senza matto sulla scacchiera: ' + id);
        }
        return r(3, 'pass', archi + ' mosse ripetute legalmente su tutti i rami.');
      })());

      // 4 — alternative migliori confrontate (ogni nodo del solutore)
      out.push((function () {
        var refs = [], sol = Object.keys(N).map(function (k) { return N[k]; }).filter(function (n) { return n.tipo === 'solver'; });
        if (!sol.length) return r(4, 'fail', 'Nessun nodo del solutore.');
        for (var i = 0; i < sol.length; i++) {
          var n = sol[i];
          if (n.incerto) return r(4, 'unknown', n.id + ': ' + n.incerto);
          if (!n.evidenceRefs || !n.evidenceRefs.length) return r(4, 'unknown', n.id + ': nessuna evidenza del motore.');
          for (var k = 0; k < n.evidenceRefs.length; k++) { var e = evid[n.evidenceRefs[k]]; if (!e) return r(4, 'unknown', 'Evidenza mancante ' + n.evidenceRefs[k]); if (!e.completa || (e.profondita || 0) < (e.richiesta || 0)) return r(4, 'unknown', 'Evidenza ' + e.ref + ' incompleta o sotto la profondità richiesta.'); }
          if (n.grigie && n.grigie.length) return r(4, 'fail', n.id + ': alternativa vicina non confutata.');
          if (n.instabili && n.instabili.length) return r(4, 'unknown', n.id + ': valutazione instabile.');
          if (n.coperturaCompleta !== true) return r(4, 'unknown', n.id + ': mosse fuori dalla lista non coperte.');
          if (!n.acceptedMoves || !n.acceptedMoves.length) return r(4, 'fail', n.id + ': nessuna mossa accettata.');
          refs = refs.concat(n.evidenceRefs);
        }
        var rad = N[ex.solutionTree.rootId];
        if (ex.originalMove) {
          var tutte = (rad.acceptedMoves || []).concat(rad.refutedMoves || [], rad.buoneNonObiettivo || []).map(function (x) { return x.uci; });
          if (tutte.indexOf(ex.originalMove) < 0) return r(4, 'unknown', 'La mossa giocata in partita non è stata esaminata.');
        }
        return r(4, 'pass', sol.length + ' nodi del solutore: ogni candidata riverificata, accettate equivalenti, le altre confutate con distacco ≥ ' + CFG.GAP + '.', refs.slice(0, 20));
      })());

      // 5 — difese dell'avversario (ogni nodo dell'avversario)
      out.push((function () {
        var opp = Object.keys(N).map(function (k) { return N[k]; }).filter(function (n) { return n.tipo === 'opponent'; }), refs = [];
        for (var i = 0; i < opp.length; i++) {
          var n = opp[i];
          if (n.incerto) return r(5, 'unknown', n.id + ': ' + n.incerto);
          if (!n.replyEdges || !n.replyEdges.length) return r(5, 'unknown', n.id + ': nessuna difesa verificata.');
          if (!n.replyEdges.some(function (e) { return e.bestDefence; })) return r(5, 'fail', n.id + ': miglior difesa assente.');
          if (!n.copertura) return r(5, 'unknown', n.id + ': copertura delle difese non dichiarata.');
          refs = refs.concat(n.evidenceRefs || []);
        }
        if (ex.objective && ex.objective.tipo === 'matto' && ex.objective.esatto && !(ex.certification && ex.certification.certo)) return r(5, 'unknown', 'Matto in N senza certificazione di tutte le difese.');
        var nota = ex.objective && ex.objective.esatto ? ' Matto certificato contro TUTTE le difese (ricerca esaustiva legale).' : '';
        return r(5, 'pass', opp.length + ' nodi dell\'avversario: seguite tutte le difese equivalenti alla migliore.' + nota, refs.slice(0, 20));
      })());

      // 6 — risultato promesso ottenuto su ogni foglia
      out.push((function () {
        var ob = ex.objective; if (!ob) return r(6, 'fail', 'Obiettivo assente.');
        var F = foglie(ex), refs = [];
        if (ex.exerciseType === 'difesa' && !(ex.threat && ex.threat.dimostrata)) return r(6, 'fail', 'Minaccia non dimostrata.');
        for (var i = 0; i < F.length; i++) {
          var f = F[i]; if (f.mancante) return r(6, 'fail', 'Foglia mancante ' + f.id);
          var t = f.nodo.terminale; if (f.nodo.tipo !== 'terminal' || !t) return r(6, 'unknown', 'Il ramo ' + f.id + ' finisce senza obiettivo dimostrato.');
          if (t.tipo === 'patta' || t.tipo === 'matto-subito') return r(6, 'fail', 'Il ramo ' + f.id + ' finisce in patta/stallo.');
          if (ob.tipo === 'matto') { if (t.tipo !== 'matto' || !new Chess(f.nodo.fen).isCheckmate()) return r(6, 'fail', 'Ramo ' + f.id + ' senza matto.'); if (ob.esatto && f.mosseSolutore > ob.n) return r(6, 'fail', 'Matto oltre le ' + ob.n + ' mosse promesse.'); }
          else if (ob.tipo === 'materiale') { var g = Sol.materiale(Chess, f.nodo.fen, ex.solverColor) - Sol.materiale(Chess, ex.startFen, ex.solverColor);
            if (t.tipo === 'matto') continue;
            if (t.tipo !== 'materiale' || (t.guadagno < CFG.GUADAGNO_MIN) || t.P < CFG.P_OBIETTIVO) return r(6, 'fail', 'Ramo ' + f.id + ': guadagno non consolidato.');
            if (f.nodo.tipo === 'terminal' && t.rispostaMigliore == null && g < CFG.GUADAGNO_MIN) return r(6, 'fail', 'Ramo ' + f.id + ': il materiale sulla scacchiera non conferma il guadagno.');
            refs.push(t.evidenceRef); }
          else if (ob.tipo === 'difesa') { if (t.tipo !== 'tenuta' || t.P < CFG.P_DIFESA_MIN) return r(6, 'fail', 'Ramo ' + f.id + ': la difesa non tiene.'); refs.push(t.evidenceRef); }
          else if (ob.tipo === 'ritrova') { if (t.tipo !== 'ritrovata' && t.tipo !== 'matto') return r(6, 'fail', 'Ramo ' + f.id + ' senza conferma.'); refs.push(t.evidenceRef); }
        }
        return r(6, 'pass', F.length + ' rami: obiettivo «' + ob.tipo + '» raggiunto contro la miglior difesa.', refs.filter(Boolean));
      })());

      // 7 — tema dimostrato (predicato + ruolo causale nella linea verificata)
      out.push(temaDimostrato(ex, ctx));

      // 8 — difficoltà e spiegazione coerenti
      out.push((function () {
        var dl = ex.difficultyEstimate; if (!dl || !(dl.level >= 1 && dl.level <= 5) || dl.name !== NOMI_LIVELLO[dl.level]) return r(8, 'fail', 'Livello 1–5 assente o nome incoerente.');
        var sp = ex.explanation; if (!sp || !sp.brief) return r(8, 'fail', 'Spiegazione verificata assente.');
        if (sp.solutionVersion !== ex.solutionVersion) return r(8, 'fail', 'Spiegazione di un\'altra versione della soluzione.');
        var frasi = sp.brief.split(/[.!?](\s|$)/).filter(function (x) { return x && x.trim(); }).length; if (frasi > 3) return r(8, 'fail', 'Spiegazione breve oltre 3 frasi.');
        for (var i = 0; i < (sp.claims || []).length; i++) { var c = sp.claims[i]; if (!c.evidenceRef || !(evid[c.evidenceRef] || /^(albero|predicato|certificazione|minaccia|analisi):/.test(c.evidenceRef))) return r(8, 'fail', 'Affermazione senza evidenza: «' + c.testo + '».'); }
        var testo = (sp.brief + ' ' + (sp.approfondisci || '')).toLowerCase();
        if (/matto in \d/.test(testo) && !(ex.objective.tipo === 'matto' && ex.objective.esatto)) return r(8, 'fail', 'La spiegazione promette un matto in N non certificato.');
        var temiCitati = Object.keys(NOMI_TEMA).filter(function (k) { return k !== 'matto_non_visto' && k !== 'difesa' && testo.indexOf(NOMI_TEMA[k]) >= 0; });
        var nonDimostrati = temiCitati.filter(function (k) { return (ex.themeTags || []).indexOf(k) < 0; });
        if (nonDimostrati.length) return r(8, 'fail', 'La spiegazione cita un tema non dimostrato: ' + nonDimostrati.join(', ') + '.');
        var lunga = foglie(ex).some(function (f) { return f.mosseSolutore > CFG.maxMosseSolutore; }); if (lunga) return r(8, 'fail', 'Soluzione più lunga del limite configurato.');
        return r(8, 'pass', 'Livello ' + dl.level + ' «' + dl.name + '» (' + (dl.provisional ? 'provvisorio' : 'calibrato') + '); ' + (sp.claims || []).length + ' affermazioni con evidenza.', (sp.claims || []).map(function (c) { return c.evidenceRef; }));
      })());

      // 9 — non duplicato (archivio esercizi + riferimento biblioteca)
      out.push(await (async function () {
        var simili = ctx.esercizi ? (await ctx.esercizi(ex.posKey)).filter(function (x) { return x.exerciseId !== ex.exerciseId && x.validationStatus !== 'rejected'; }) : null;
        if (simili == null) return r(9, 'unknown', 'Archivio esercizi non consultabile.');
        if (simili.length) return r(9, 'fail', 'Stessa posizione e obiettivo di ' + simili[0].exerciseId + '.', [simili[0].exerciseId]);
        if (!ctx.biblioteca || typeof ctx.biblioteca.cercaPosizione !== 'function') return r(9, 'unknown', 'Indice della biblioteca non disponibile: confronto non fatto.');
        var lib = ctx.biblioteca.cercaPosizione(fen4(ex.startFen));
        if (lib) return r(9, 'fail', 'La posizione è già nella biblioteca (' + lib + '): si usa quella, nessuna copia.', [lib]);
        return r(9, 'pass', 'Nessun esercizio con la stessa posizione+obiettivo; nessuna corrispondenza in biblioteca.');
      })());
      return out;
    }

    function temaDimostrato(ex, ctx) {
      var tags = ex.themeTags || [];
      if (!tags.length) return r(7, 'fail', 'Nessun tema dimostrato (no-theme).');
      var prove = ex.themeEvidence || {};
      for (var i = 0; i < tags.length; i++) {
        var t = tags[i], p = prove[t];
        if (t === 'matto_non_visto') { if (!(ex.objective && ex.objective.tipo === 'matto')) return r(7, 'fail', 'Tema matto senza obiettivo di matto.'); continue; }
        if (t === 'difesa') { if (!(ex.threat && ex.threat.dimostrata)) return r(7, 'fail', 'Difesa senza minaccia dimostrata.'); continue; }
        if (t === 'geniale') { if (!(ctx.etichettaOrigine && ctx.etichettaOrigine.label === 'geniale' && ctx.etichettaOrigine.verificata)) return r(7, 'unknown', 'Etichetta Geniale non verificata nell\'analisi.'); continue; }
        var ricalc = provaTema(ex, t);
        if (!ricalc) return r(7, 'fail', 'Tema «' + t + '»: la geometria c\'è ma il bersaglio non cade nella linea verificata (non è la causa del guadagno).');
        if (!p) return r(7, 'unknown', 'Prova del tema «' + t + '» non registrata.');
      }
      return r(7, 'pass', 'Temi dimostrati: ' + tags.join(', ') + ' (predicato + ruolo nella linea verificata).', tags.map(function (t) { return 'predicato:' + t; }));
    }
    /* ricalcolo indipendente della prova di un tema tattico sulla linea principale (stessa regola di CNApTemi v2) */
    function provaTema(ex, t) {
      var lp = lineaPrincipale(ex); if (!lp.length) return null;
      var c0 = new Chess(ex.startFen), c1 = new Chess(ex.startFen), m = c1.move(play(ex.startFen, lp[0].uci).m.san);
      var pred = Temi.predicati(c0, c1, m)[t]; if (!pred) return null;
      var c = new Chess(ex.startFen), presi = [];
      lp.forEach(function (x) { var mm = c.move(play(c.fen(), x.uci).m.san); if (mm.captured && mm.color === ex.solverColor) presi.push(mm.to); });
      var cade = function (sqs) { return sqs.some(function (s) { return presi.indexOf(s) >= 0; }); };
      var ok = t === 'pezzo_indifeso' ? true : t === 'forchetta' ? cade(pred.bersagli) : t === 'inchiodatura' ? cade([pred.inchiodato, pred.dietro]) : t === 'infilata' ? cade([pred.dietro]) : t === 'scoperta' ? (cade([pred.bersaglio]) || pred.scacco) : false;
      return ok ? { predicato: pred, catture: presi } : null;
    }
    /* temi da assegnare (solo quelli dimostrati) */
    function assegnaTemi(ex) {
      var tags = [], prove = {};
      if (ex.exerciseType === 'ritrova') { tags.push('geniale'); prove.geniale = { ref: 'analisi:' + ex.sourceNodeId }; }
      if (ex.objective.tipo === 'matto') { tags.push('matto_non_visto'); prove.matto_non_visto = { ref: 'albero:' + ex.solutionTree.rootId }; }
      else if (ex.objective.tipo === 'difesa') { tags.push('difesa'); prove.difesa = { ref: 'minaccia:' + (ex.threat && ex.threat.evidenceRef) }; }
      else {
        ['forchetta', 'inchiodatura', 'infilata', 'scoperta', 'pezzo_indifeso'].forEach(function (t) { var p = provaTema(ex, t); if (p) { tags.push(t); prove[t] = p; } });
      }
      // un pezzo indifeso «di contorno» non si aggiunge se c'è già un tema più specifico che spiega il guadagno
      if (tags.length > 1 && tags.indexOf('pezzo_indifeso') >= 0) { tags.splice(tags.indexOf('pezzo_indifeso'), 1); delete prove.pezzo_indifeso; }
      return { themeTags: tags, themeEvidence: prove };
    }

    /* ================= difficoltà provvisoria (PROPOSTA, non calibrata) ================= */
    function difficolta(ex) {
      var lp = lineaPrincipale(ex), s = lp.filter(function (x, i) { return i % 2 === 0; }).length, N = nodiPer(ex);
      var primo = play(ex.startFen, lp[0].uci).m, punti = s;
      if (!primo.captured && primo.san.indexOf('+') < 0) punti += 1;           // prima mossa tranquilla: più difficile da vedere
      else punti -= 0.5;
      if (Object.keys(N).some(function (k) { return N[k].tipo === 'opponent' && (N[k].replyEdges || []).length >= 2; })) punti += 0.5;
      if ((N[ex.solutionTree.rootId].acceptedMoves || []).length >= 2) punti -= 0.5;
      if (ex.objective.tipo === 'matto' && ex.objective.esatto && ex.objective.n === 1) punti = Math.min(punti, 1);
      var lv = punti <= 1 ? 1 : punti <= 1.75 ? 2 : punti <= 2.5 ? 3 : punti <= 3.25 ? 4 : 5;
      return { level: lv, name: NOMI_LIVELLO[lv], provisional: true, methodVersion: DIFF, fattori: { mosseSolutore: s, primaTranquilla: !primo.captured && primo.san.indexOf('+') < 0, punti: punti } };
    }

    /* ================= spiegazione verificata: solo affermazioni con evidenza ================= */
    function itSan(san) { return san.replace(/[KQRBN]/g, function (p) { return { K: 'R', Q: 'D', R: 'T', B: 'A', N: 'C' }[p]; }); }
    function spiegazione(ex) {
      var lp = lineaPrincipale(ex), N = nodiPer(ex), rad = N[ex.solutionTree.rootId], ob = ex.objective, claims = [];
      var s1 = itSan(lp[0].san), risp = lp[1] ? itSan(lp[1].san) : null, s2 = lp[2] ? itSan(lp[2].san) : null, brief, appr = [];
      var refRad = rad.evidenceRefs[0];
      var temaT = (ex.themeTags || []).filter(function (t) { return t !== 'geniale' && t !== 'matto_non_visto' && t !== 'difesa'; })[0];
      if (ob.tipo === 'matto' && ex.exerciseType !== 'ritrova') {
        brief = s1 + (ob.esatto ? ' dà matto in ' + ob.n + (ob.n === 1 ? ' mossa' : ' mosse') : ' porta al matto') + (risp ? ': ' + [s1, risp, s2].filter(Boolean).join(' ') + '.' : '.');
        claims.push({ testo: 'linea di matto', evidenceRef: 'albero:' + rad.id });
        if (ob.esatto) claims.push({ testo: 'matto in ' + ob.n + ' contro ogni difesa', evidenceRef: 'certificazione:' + (ex.certification && ex.certification.metodo) });
      } else if (ob.tipo === 'materiale' && ex.exerciseType !== 'ritrova') {
        var g = lp.length ? (N[lp[lp.length - 1].nodo] || {}) : {};
        var fog = foglie(ex).map(function (f) { return f.nodo && f.nodo.terminale; }).filter(Boolean)[0] || {};
        brief = s1 + (temaT ? ' sfrutta ' + (temaT === 'forchetta' ? 'una forchetta' : temaT === 'inchiodatura' ? 'un\'inchiodatura' : temaT === 'infilata' ? 'un\'infilata' : temaT === 'scoperta' ? 'un attacco di scoperta' : 'un pezzo indifeso') : '') + ' e vince materiale.' +
          (risp ? ' Dopo la miglior difesa ' + risp + (s2 ? ' segue ' + s2 : '') + ' e il guadagno resta.' : '');
        claims.push({ testo: 'mossa migliore', evidenceRef: refRad });
        if (temaT) claims.push({ testo: 'tema ' + temaT, evidenceRef: 'predicato:' + temaT });
        if (fog.evidenceRef) claims.push({ testo: 'guadagno consolidato', evidenceRef: fog.evidenceRef });
      } else if (ob.tipo === 'difesa') {
        var mn = ex.threat;
        brief = 'L\'avversario minacciava ' + (mn.tipo === 'matto' ? 'il matto' : 'di vincere materiale') + '. ' + s1 + ' neutralizza la minaccia e la posizione tiene.';
        claims.push({ testo: 'minaccia', evidenceRef: mn.evidenceRef }); claims.push({ testo: 'difesa', evidenceRef: refRad });
      } else {
        brief = 'In partita hai trovato ' + s1 + ', una mossa giudicata Geniale dall\'analisi verificata.' + (rad.acceptedMoves.length > 1 ? ' Erano corrette anche: ' + rad.acceptedMoves.slice(1).map(function (a) { return itSan(a.san); }).join(', ') + '.' : '');
        claims.push({ testo: 'geniale', evidenceRef: 'analisi:' + ex.sourceNodeId }); claims.push({ testo: 'mossa migliore', evidenceRef: refRad });
      }
      if (rad.acceptedMoves.length > 1 && ob.tipo !== 'ritrova') appr.push('Sono accettate anche: ' + rad.acceptedMoves.slice(1).map(function (a) { return itSan(a.san); }).join(', ') + '.');
      var orig = ex.originalMove && (rad.refutedMoves || []).filter(function (x) { return x.uci === ex.originalMove; })[0];
      if (orig) {
        var coda = orig.motivo === 'stallo' ? ', che dà stallo.'
                 : (ex.exerciseType === 'difesa' || (ob && ob.tipo === 'difesa')) ? ', che non para la minaccia secondo la verifica.'
                 : ', che secondo la verifica è peggiore.';
        appr.push('In partita è stata giocata ' + itSan(orig.san) + coda);
        claims.push({ testo: 'mossa della partita confutata', evidenceRef: orig.evidenceRef || refRad });
      }
      var stalli = (rad.refutedMoves || []).filter(function (x) { return x.motivo === 'stallo' && x.uci !== ex.originalMove; });
      if (stalli.length) appr.push('Attenzione: ' + stalli.map(function (x) { return itSan(x.san); }).join(', ') + ' darebbe stallo.');
      return { brief: brief, approfondisci: appr.join(' ') || null, claims: claims, solutionVersion: ex.solutionVersion, versione: 'cnap-spiegazione-1', mostrare: 'dopo il tentativo o a soluzione richiesta' };
    }

    /* ================= filtro didattico (conservativo: nel dubbio blocca) ================= */
    function filtroDidattico(ex, ctx) {
      ctx = ctx || {};
      var motivi = [], N = nodiPer(ex), rad = N[ex.solutionTree.rootId], lp = lineaPrincipale(ex);
      if (!ex.objective || ['matto', 'materiale', 'difesa', 'ritrova'].indexOf(ex.objective.tipo) < 0) motivi.push('obiettivo non adatto a un quiz');
      if (!ex.explanation || !ex.explanation.brief) motivi.push('consegna senza spiegazione');
      var nonTerm = (rad.acceptedMoves || []).filter(function (a) { var f = N[a.childId]; return !(f && f.tipo === 'terminal' && f.terminale && f.terminale.tipo === 'matto'); });
      if (nonTerm.length > CFG.maxAccettate) motivi.push('troppe soluzioni equivalenti alla prima mossa');
      if (ex.objective && ex.objective.tipo === 'difesa' && (rad.acceptedMoves || []).length > 3) motivi.push('difesa non semplice: troppe difese equivalenti (V1 solo difese semplici)');
      if (ex.objective && ex.objective.tipo === 'materiale' && ctx.ultimaMossaAvversaria && lp.length) {
        var pm = play(ex.startFen, lp[0].uci).m;
        if (pm.captured && ctx.ultimaMossaAvversaria.slice(2, 4) === pm.to && lp.length <= 2) motivi.push('è solo una ripresa di materiale');
      }
      if (lp.filter(function (x, i) { return i % 2 === 0; }).length > CFG.maxMosseSolutore) motivi.push('linea troppo lunga per un esercizio breve');
      if (ex.objective && ex.objective.tipo === 'matto' && !ex.objective.esatto && ex.objective.n > 3) motivi.push('matto lungo non certificato');
      return { status: motivi.length ? 'fail' : 'pass', reason: motivi.length ? motivi.join('; ') : 'Tema riconoscibile, consegna chiara, punto di arresto definito.', motivi: motivi, ruleVersion: DIDATTICA };
    }

    function consegna(ex) {
      var lato = ex.solverColor === 'w' ? 'Il Bianco' : 'Il Nero', ob = ex.objective;
      if (ex.exerciseType === 'ritrova') return lato + ' muove: ritrova la mossa che hai giocato in partita (valgono anche le alternative equivalenti).';
      if (ob.tipo === 'matto') return lato + ' muove e dà matto' + (ob.esatto ? ' in ' + (ob.n === 1 ? 'una mossa' : ob.n === 2 ? 'due mosse' : ob.n + ' mosse') : '') + '.';
      if (ob.tipo === 'materiale') return lato + ' muove e vince materiale.';
      if (ob.tipo === 'difesa') return lato + ' muove: c\'è una minaccia, difenditi.';
      return lato + ' muove: ritrova la mossa che hai giocato in partita (valgono anche le alternative equivalenti).';
    }

    return { esegui: esegui, filtroDidattico: filtroDidattico, difficolta: difficolta, spiegazione: spiegazione, assegnaTemi: assegnaTemi, provaTema: provaTema, lineaPrincipale: lineaPrincipale, foglie: foglie, consegna: consegna };
  }
  return { crea: crea, fen4: fen4, NOMI_LIVELLO: NOMI_LIVELLO, NOMI_CONTROLLO: NOMI_CONTROLLO, REGOLE: REGOLE, DIDATTICA: DIDATTICA, DIFF: DIFF };
});
