/* Chess Node · Analisi profonda · FASE 6 · CNApRaccordo — fa CONVIVERE i moduli delle fasi 1–5 su un solo database (v2),
   senza riscrivere import, motore, classificatore, profili o allenatore. Codice originale Chess Node (09/11/2026).
   Aggiunge solo i raccordi decisi da Kiko il 09/11:
   1) «I miei errori» vede SOLO le partite di «Analizza me» (ambito self): il generatore e l'allenatore della fase 4 ricevono una
      vista dell'archivio filtrata su self. Una tua partita arrivata solo dallo studio di un avversario resta in quello studio;
      se lo studio non salvato scade, se ne va con lui; se più tardi la importi da «Analizza me», diventa tua per davvero.
   2) Rimandi ai capitoli: sempre confrontati con l'ELENCO VIVO di BOOK.chapters (mai solo con la mappa fissa).
   3) Analisi condivise da più studi: la marcatura per la pulizia (fase 1, classe 2) si ricalcola su TUTTI gli studi della partita:
      se uno è salvato (o la partita è anche tua) l'analisi non scade; altrimenti vale la scadenza più lontana.
   4) Scheda avversario con il controllo del tono versione 2 (CNApTono) come rete di sicurezza. */
(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api; else root.CNApRaccordo = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  var VERSIONE = 'cnap-raccordo-1';
  /* elenco approvato da Kiko (09/11): id → nome. miss e cur NON sono capitoli */
  var ELENCO_KIKO = { m1: 'Matto in una', m2: 'Matto in due', dbl: 'Attacco doppio', disa: 'Attacco di scoperta', disc: 'Scacco di scoperta', dch: 'Scacco doppio',
    pin: 'Inchiodatura', skew: 'Infilata', defl: 'Deviazione', decoy: 'Sacrificio di adescamento', promo: 'Promozione', fin: 'Finali', draw: 'Tattiche di patta',
    mid: 'Mediogioco', m3: 'Matto in tre', m4: 'Matto in quattro', def: 'Difesa' };
  var MAI = { miss: 'non è un capitolo', cur: 'non è un capitolo' };
  /* temi che una SCHEDA o il PROFILO può collegare (difficoltà verificate dal rilevatore, certezza 1). La scoperta non si collega
     qui perché disa/disc dipende dallo scacco, che le occasioni aggregate non distinguono; matto solo per esercizi certificati (fase 4). */
  var TEMI_LINK = { forchetta: 'dbl', inchiodatura: 'pin', infilata: 'skew', difesa: 'def' };

  /* ---------- capitoli: elenco VIVO ---------- */
  function capitoliVivi(BOOK) {
    var vivi = Array.isArray(BOOK && BOOK.chapters) ? BOOK.chapters : null, out = { disponibile: !!vivi, presenti: [], nomi: {}, scartati: [] };
    (vivi || []).forEach(function (c) {
      if (!c || !c.id) return;
      if (MAI[c.id]) { out.scartati.push({ id: c.id, motivo: MAI[c.id] }); return; }
      if (!ELENCO_KIKO[c.id]) { out.scartati.push({ id: c.id, motivo: 'non è nell\'elenco approvato' }); return; }
      out.presenti.push(c.id); out.nomi[c.id] = c.name || ELENCO_KIKO[c.id];
    });
    var mappa = {}; Object.keys(TEMI_LINK).forEach(function (t) { if (out.presenti.indexOf(TEMI_LINK[t]) >= 0) mappa[t] = TEMI_LINK[t]; });
    out.perScheda = { MAPPA_TEMI: mappa, CAPITOLI: out.nomi };                                       // stessa forma di CNApCapitoli per la scheda della fase 5
    out.perProfilo = {}; Object.keys(mappa).forEach(function (t) { out.perProfilo[t] = { id: mappa[t], titolo: out.nomi[mappa[t]] }; });   // forma di CNApProfilo (fase 3)
    out.perEsercizi = out.presenti.slice();                                                            // capitoliPresenti del generatore (fase 4)
    return out;
  }

  /* ---------- vista dell'archivio limitata all'ambito self ---------- */
  function mia(g) { return !!(g && (g.scopeRefs || []).indexOf('self') >= 0); }
  function archivioSelf(A) {
    var v = Object.create(A);
    v.partita = async function (id) { var g = await A.partita(id); return mia(g) ? g : null; };
    v.partite = async function (f) { f = Object.assign({}, f || {}, { scope: 'self' }); return A.partite(f); };
    v.tx = function (stores, mode, fn) {
      return A.tx(stores, mode, function (t) {
        var t2 = Object.create(t);
        t2.get = async function (s, k) { var x = await t.get(s, k); return s === 'games' && x && !mia(x) ? undefined : x; };
        t2.all = async function (s) { var l = await t.all(s); return s === 'games' ? l.filter(mia) : l; };
        t2.byIndex = async function (s, i, val) { var l = await t.byIndex(s, i, val); return s === 'games' ? l.filter(mia) : l; };
        return fn(t2);
      });
    };
    v.soloSelf = true;
    return v;
  }
  /* generatore della fase 4 che riceve solo le partite di «Analizza me» */
  function generatorePersonale(CNApGeneratore, deps) {
    var A = deps.archivio, AS = archivioSelf(A);
    var gen = CNApGeneratore.crea(Object.assign({}, deps, { archivio: AS }));
    var MOT = 'Partita non presente in «Analizza me»: i suoi errori non entrano in «I miei errori».';
    var g2 = Object.create(gen);
    g2.candidati = async function (gameId) { if (!mia(await A.partita(gameId))) return { candidati: [], motivo: MOT }; return gen.candidati(gameId); };
    g2.genera = async function (gameId, o) { if (!mia(await A.partita(gameId))) return { gameId: gameId, candidati: 0, esiti: {}, esercizi: [], motivo: MOT }; return gen.genera(gameId, o); };
    g2.elabora = async function (c, o) { if (!mia(await A.partita(c.gameId))) { var e = new Error(MOT); e.code = 'NON_SELF'; throw e; } return gen.elabora(c, o); };
    return g2;
  }

  /* ---------- analisi condivise da più studi: marcatura coerente ---------- */
  async function riallineaAnalisi(A, gameIds) {
    var out = { controllate: 0, modificate: 0 };
    var ids = gameIds || (await A.tx(['games'], 'readonly', function (t) { return t.all('games'); })).filter(function (g) { return g.localAnalysisId; }).map(function (g) { return g.gameId; });
    var rec = {}; (await A.tx(['meta'], 'readonly', function (t) { return t.all('meta'); })).forEach(function (m) { if (/^avversario:/.test(m.key) && m.valore) rec[m.valore.subjectId] = m.valore; });
    await A.tx(['games', 'analyses'], 'readwrite', async function (t) {
      for (var i = 0; i < ids.length; i++) {
        var g = await t.get('games', ids[i]); if (!g || !g.localAnalysisId) continue;
        var a = await t.get('analyses', g.localAnalysisId); if (!a) continue;
        out.controllate++;
        var prima = JSON.stringify([a.scope, a.savedByUser, a.expiresAt, a.ambitiAvversario]);
        var opp = (g.scopeRefs || []).filter(function (s) { return /^opp:/.test(s) && rec[s]; });
        if (mia(g) || !opp.length) { delete a.scope; delete a.savedByUser; delete a.expiresAt; delete a.ambitiAvversario; }
        else {
          var salvati = opp.filter(function (s) { return rec[s].saved; });
          a.ambitiAvversario = opp.slice().sort();
          if (salvati.length) { a.scope = salvati.sort()[0]; a.savedByUser = true; a.expiresAt = null; }
          else { var piu = opp.slice().sort(function (x, y) { return (rec[y].expiresAt || 0) - (rec[x].expiresAt || 0) || (x < y ? -1 : 1); })[0]; a.scope = piu; a.savedByUser = false; a.expiresAt = rec[piu].expiresAt; }
        }
        if (JSON.stringify([a.scope, a.savedByUser, a.expiresAt, a.ambitiAvversario]) !== prima) { await t.put('analyses', a); out.modificate++; }
      }
    });
    return out;
  }
  /* «Studia un avversario» con il riallineamento dopo ogni operazione che cambia ambiti o conservazione */
  function avversarioCoerente(AV, A) {
    var w = Object.create(AV);
    ['studia', 'analizza', 'salva', 'nonSalvare', 'elimina', 'scadenze', 'segnaFuoriCampione'].forEach(function (k) {
      w[k] = async function () { var r = await AV[k].apply(AV, arguments); await riallineaAnalisi(A); return r; };
    });
    w.apri = async function (id) { await w.scadenze(); return AV.record(id); };
    w.elenco = async function () { await w.scadenze(); return AV.elenco(); };
    return w;
  }

  /* ---------- ripasso di oggi integrato (rev. 2): stessa regola di stats.js corretto ----------
     R = adattatore della fase 4; dati() = oggetto di stats.js; apribile(chiave) = il personale si può aprire? */
  function ripassoIntegrato(R, RI, dati, oggi, apribile) {
    var w = Object.create(R);
    function giorno() { var x = dati(); return x.rd && x.rd.day === oggi() ? x.rd.done : []; }
    w.dovutiApribili = function () { return R.dovuti().filter(function (x) { return x.fonte === 'biblioteca' || apribile(x.chiave); }); };
    w.diOggi = function () {
      var dov = R.dovuti(), per = {}; dov.forEach(function (x) { per[x.fonte === 'biblioteca' ? String(x.n) : x.chiave] = x; });
      return RI.scegli(dov.map(function (x) { return x.fonte === 'biblioteca' ? x.n : x.chiave; }), giorno(), apribile).map(function (k) { return per[String(k)]; });
    };
    w.coda = function () { return R.coda().filter(function (x) { return x.fonte === 'biblioteca' || apribile(x.chiave); }); };
    // «oggi» solo se è davvero nel ripasso di oggi (gancio, tetto 5/10); R.quando usa il diOggi interno senza queste regole
    w.quando = function (id) { var q = R.quando(id); return q === 'oggi' && !w.diOggi().some(function (y) { return y.exerciseId === id; }) ? 'domani' : q; };
    return w;
  }

  /* ---------- scheda avversario: capitoli vivi + tono v2 ---------- */
  async function schedaAvversario(d) {
    var s = await d.CNApSchedaAvversario.calcola({ profilo: d.profilo, vista: await d.avversario.vista(d.subjectId), avversario: d.avversario, capitoli: d.capitoli.perScheda, periodo: d.periodo, ora: d.ora });
    s.tonoFase5 = s.tono;
    return d.CNApTono.proteggi(s);
  }

  /* ---------- facciata: un database, tutti i moduli ----------
     d = {M: tutti i moduli (globali CNAp*), Chess, backend (CNApDbV2), fetch?, uci?, BOOK, statsDati: () => oggetto stats.js, oggi?, ora?, livelli?} */
  function crea(d) {
    var M = d.M, ora = d.ora || function () { return Date.now(); }, B = d.backend, U = M.CNApUtil;
    var S = M.CNApServizio.crea(Object.assign({ Chess: d.Chess, ora: ora, backend: B, attendi: d.attendi }, M, d.fetch ? { fetch: d.fetch } : {}));
    var A = S.archivio, cap = capitoliVivi(d.BOOK);
    // rev. 2: il riallineamento parte da solo anche dopo un import da «Analizza me» (nessun passo manuale per l'utente)
    ['importaTesto', 'importaDaSito', 'annullaNotifica'].forEach(function (k) { var f = S[k]; S[k] = async function () { var r = await f.apply(S, arguments); await riallineaAnalisi(A); return r; }; });
    var sch = d.uci ? M.CNApScheduler.crea({ uci: d.uci, debounceMs: d.debounceMs }) : null;
    var AN = sch ? M.CNApAnalisi.crea({ scheduler: sch, archivio: A, Chess: d.Chess, CNApPunteggio: M.CNApPunteggio, CNApClassifica: M.CNApClassifica, CNApFasi: M.CNApFasi, CNApTemi: M.CNApTemi, CNApUtil: U, ora: ora, livelli: d.livelli }) : null;
    var profilo = M.CNApProfilo.crea({ archivio: A, CNApStat: M.CNApStat, CNApDifetti: M.CNApDifetti, CNApUtil: U, ora: ora, capitoli: cap.perProfilo });
    var AV = avversarioCoerente(M.CNApAvversario.crea({ servizio: S, analisi: AN, CNApUtil: U, ora: ora }), A);
    var So = sch ? M.CNApSoluzione.crea({ scheduler: sch, Chess: d.Chess, CNApPunteggio: M.CNApPunteggio, CNApUtil: U, cfg: d.cfgSoluzione }) : null;
    var K = M.CNApControlli.crea({ Chess: d.Chess, CNApUtil: U, CNApTemi: M.CNApTemi, CNApSoluzione: M.CNApSoluzione });
    var bib = M.CNApEsercizi.biblioteca(d.BOOK, U);
    var gen = generatorePersonale(M.CNApGeneratore, { archivio: A, db: B, soluzione: So, controlli: K, Chess: d.Chess, CNApUtil: U, CNApCapitoli: M.CNApCapitoli, CNApControlli: M.CNApControlli, CNApSoluzione: M.CNApSoluzione,
      scheduler: sch, ora: ora, biblioteca: bib, capitoliPresenti: cap.disponibile ? cap.perEsercizi : null });
    var T = M.CNApTentativi.crea({ db: B, CNApUtil: U, ora: ora });
    var oggi = d.oggi || function () { return U.dataRoma(ora()); };
    // un personale si può aprire solo se l'app ha il gancio (rev. 2); allenabile = esercizio approvato e corrente
    var apribile = d.apribilePersonale || function () { return typeof d.apriPersonale === 'function'; };
    var R = ripassoIntegrato(M.CNApRipasso.crea({ dati: d.statsDati, oggi: oggi, salva: d.statsSalva }), M.CNApRipassoIntegrato, d.statsDati, oggi, apribile);
    var E = M.CNApEsercizi.crea({ db: B, biblioteca: bib, ripasso: R, tentativi: T, collegamenti: true });
    var All = M.CNApAllenatore.crea({ db: B, CNApUtil: U, CNApRipasso: M.CNApRipasso, esercizi: E, ripasso: R, tentativi: T, archivio: archivioSelf(A), ora: ora });
    var Ri = M.CNApRisposta.crea({ Chess: d.Chess, CNApSoluzione: M.CNApSoluzione, soluzione: So });
    return { servizio: S, archivio: A, scheduler: sch, analisi: AN, profilo: profilo, avversario: AV, capitoli: cap, biblioteca: bib,
      allenamento: { soluzione: So, controlli: K, generatore: gen, tentativi: T, ripasso: R, esercizi: E, allenatore: All, risposta: Ri },
      scheda: function (subjectId, periodo) { return schedaAvversario({ CNApSchedaAvversario: M.CNApSchedaAvversario, CNApTono: M.CNApTono, profilo: profilo, avversario: AV, capitoli: cap, subjectId: subjectId, periodo: periodo || 'tutto', ora: ora() }); },
      riallinea: function () { return riallineaAnalisi(A); }, backend: B };
  }

  return { crea: crea, capitoliVivi: capitoliVivi, ripassoIntegrato: ripassoIntegrato, archivioSelf: archivioSelf, generatorePersonale: generatorePersonale, riallineaAnalisi: riallineaAnalisi, avversarioCoerente: avversarioCoerente,
    schedaAvversario: schedaAvversario, ELENCO_KIKO: ELENCO_KIKO, TEMI_LINK: TEMI_LINK, VERSIONE: VERSIONE };
});
