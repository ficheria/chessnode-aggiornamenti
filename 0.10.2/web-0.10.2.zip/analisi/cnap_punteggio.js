/* Chess Node · Analisi profonda · FASE 2 · CNApPunteggio — convenzioni di valutazione e probabilità (A1-06 §10.1, §10.4, A1-C03, A1-C07).
   Codice originale Chess Node (08/11/2026).
   - UNA sola formula di probabilità per la classificazione: quella di precisione.js (CNPrecisione.P, cnp-2):
       P(cp) = 100 / (1 + 10^(−cp/400)), cp limitato a ±1000, matto = ±1000. Stessi numeri ⇒ stesse soglie storiche (regressioni).
     La logistica diversa di cn_profilo.js:157 NON si usa più (convergenza A1-C03).
   - Percentuale MOSTRATA: WDL di Stockfish quando la build lo dà (UCI_ShowWDL, verificato su «Stockfish 17.1 Lite WASM»),
     altrimenti la formula sopra con etichetta del modello. È una stima convenzionale, non una previsione del risultato.
   - Due punti di vista: «chi muove» (UCI, giudizi) e «Bianco» (barra e grafico). Si converte una volta sola; ruotare la
     scacchiera non cambia segno a nulla. */
(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api; else root.CNApPunteggio = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  var CLIP = 1000, K = 0.035, MIN_MOSSE = 5, SOGLIA_NETTA = 80;   // 80% = «nettamente favorevole» (Q11), configurabile, MAI «vinta»

  function P(cp) { cp = Math.max(-CLIP, Math.min(CLIP, cp)); return 100 / (1 + Math.pow(10, -cp / 400)); }
  /* score UCI {tipo:'cp'|'mate', valore} → cp limitato (matto = ±CLIP) */
  function cpDi(s) { if (!s) return null; if (s.tipo === 'mate') return s.valore > 0 ? CLIP : s.valore < 0 ? -CLIP : -CLIP; return Math.max(-CLIP, Math.min(CLIP, s.valore)); }
  function probDi(s) { var c = cpDi(s); return c == null ? null : P(c); }
  /* inverte il punto di vista (dopo una mossa il tratto passa all'altro lato) */
  function inverti(s) { return s ? { tipo: s.tipo, valore: s.valore === 0 && s.tipo === 'mate' ? 0 : -s.valore } : s; }
  /* punto di vista di chi muove → punto di vista del Bianco */
  function aBianco(s, tratto) { return tratto === 'w' ? s : inverti(s); }
  /* WDL in millesimi dal punto di vista di chi muove → probabilità attesa (vittoria + metà patta) in % per chi muove */
  function probWdl(wdl) { return wdl ? (wdl[0] + wdl[1] / 2) / 10 : null; }
  /* percentuale da mostrare, con modello dichiarato. riga = {score, wdl}, tratto del FEN; punto di vista richiesto 'w' o 'chi-muove' */
  function percentuale(riga, tratto, pov) {
    var p, modello;
    if (riga.wdl) { p = probWdl(riga.wdl); modello = 'stockfish-wdl'; } else { p = probDi(riga.score); modello = 'cnp-2-logistica'; }
    if (pov === 'w' && tratto === 'b') p = 100 - p;
    return { valore: Math.round(p * 10) / 10, modello: modello, nettamenteFavorevole: p >= SOGLIA_NETTA, nota: 'Stima convenzionale del modello indicato, non probabilità garantita né risultato teorico.' };
  }
  /* testo della valutazione dal punto di vista del Bianco: «+0,38», «+M3», «−M2» */
  function testo(sBianco) {
    if (!sBianco) return '—';
    if (sBianco.tipo === 'mate' && sBianco.valore === 0) return sBianco.matto === 'bianco' ? '1-0 #' : sBianco.matto === 'nero' ? '0-1 #' : '#';   // matto già sulla scacchiera
    if (sBianco.tipo === 'mate') return (sBianco.valore > 0 ? '+M' : '−M') + Math.abs(sBianco.valore);
    var v = sBianco.valore / 100; return (v > 0 ? '+' : v < 0 ? '−' : '') + Math.abs(v).toFixed(2).replace('.', ',');
  }
  /* precisione della mossa e della partita: stessa formula di precisione.js (accMossa, media) */
  function accMossa(perdita) { return 100 * Math.exp(-K * Math.max(0, perdita)); }
  function media(acc) {
    if (!acc || acc.length < MIN_MOSSE) return null;
    var ar = acc.reduce(function (a, b) { return a + b; }, 0) / acc.length, ha = acc.length / acc.reduce(function (a, b) { return a + 1 / Math.max(b, 1); }, 0);
    return Math.round((ar + ha) / 2);
  }
  /* A1-C07: il lato di ogni semimossa viene dal tratto della FEN iniziale (o dal colore del replay), non dalla parità dell'indice */
  function latoDellaSemimossa(startFen, i) { var nero = startFen.split(' ')[1] === 'b'; return (i % 2 === 0) !== nero ? 'w' : 'b'; }

  return { P: P, cpDi: cpDi, probDi: probDi, inverti: inverti, aBianco: aBianco, probWdl: probWdl, percentuale: percentuale, testo: testo, accMossa: accMossa, media: media, latoDellaSemimossa: latoDellaSemimossa, CLIP: CLIP, K: K, MIN_MOSSE: MIN_MOSSE, SOGLIA_NETTA: SOGLIA_NETTA, VERSIONE: 'cnp-2' };
});
