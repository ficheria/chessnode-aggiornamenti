/* Chess Node · Analisi profonda · CNApAperture — nomi italiani dalla lista di Kiko (stessa di app/web/data/aperture_kiko.json).
   Nessun nome inventato: se un codice ECO corrisponde a più nomi italiani, si mostra un nome di famiglia
   già presente nella lista (es. «Partita Italiana»), mai un nome nuovo o sbagliato; se non c'è una famiglia
   comune corretta resta solo il codice ECO. Il nome inglese del sito resta solo come dato grezzo. */
(function (root, factory) {
  'use strict';
  var api = factory(root);
  if (typeof module === 'object' && module.exports) module.exports = api; else root.CNApAperture = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function (root) {
  'use strict';

  var INIZIO4 = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq';
  var RITMI_IT = { bullet: 'lampo', ultraBullet: 'lampo', blitz: 'blitz', rapid: 'rapida', classical: 'classica', correspondence: 'per corrispondenza', daily: 'per corrispondenza' };
  /* Nomi di famiglia corretti per i codici ECO in cui la lista ha più linee senza un prefisso comune.
     Solo etichette generiche già usate in italiano, mai un nome specifico inventato o sbagliato. */
  var FAMIGLIE_ECO = {
    C80: 'Partita Spagnola',
    C44: 'Partita aperta (1.e4 e5)',
    C21: 'Partita aperta (1.e4 e5)',
    C40: 'Partita aperta (1.e4 e5)',
    D10: 'Difesa Slava',
    A02: 'Apertura Bird',
    A04: 'Apertura Réti',
    A07: 'Attacco Est-Indiano',
    A51: 'Gambetto Budapest',
    A82: 'Difesa Olandese',
    A00: 'Aperture irregolari',
    B00: 'Difese inconsuete (1.e4)',
    B07: 'Difesa Pirc',
    A40: 'Apertura di donna (1.d4)',
    A41: 'Apertura di donna (1.d4)',
    A45: 'Apertura di donna (1.d4)',
    D01: 'Apertura di donna (1.d4)'
  };
  var cache = null;

  function norm(s) {
    return String(s || '').toLowerCase().replace(/[’]/g, "'").replace(/[:.,\-\/_]+/g, ' ').replace(/\s+/g, ' ').trim();
  }
  function pulisci(it) { return String(it || '').replace(/\.\s*$/, '').trim(); }

  function leggiJson(p) {
    if (typeof require !== 'function') return null;
    try { return JSON.parse(require('fs').readFileSync(p, 'utf8')); } catch (e) { return null; }
  }
  function caricaDati() {
    if (cache) return cache;
    var nomi = [], eco = {}, path, i, cands, raw, e;
    if (root && root.__cnapApertureDati && root.__cnapApertureDati.nomi) {
      cache = { nomi: root.__cnapApertureDati.nomi, eco: root.__cnapApertureDati.eco || {} };
      return cache;
    }
    if (typeof require === 'function' && typeof __dirname === 'string') {
      path = require('path');
      cands = [
        path.join(__dirname, '../data/aperture_kiko.json'),
        path.join(__dirname, '../../../../app/web/data/aperture_kiko.json'),
        path.join(__dirname, '../../fase_01/moduli/../../../../app/web/data/aperture_kiko.json')
      ];
      for (i = 0; i < cands.length; i++) { raw = leggiJson(cands[i]); if (raw && raw.nomi) { nomi = raw.nomi; break; } }
      cands = [
        path.join(__dirname, 'aperture_eco_kiko.json'),
        path.join(__dirname, '../../fase_01/moduli/aperture_eco_kiko.json')
      ];
      for (i = 0; i < cands.length; i++) { e = leggiJson(cands[i]); if (e) { eco = e; break; } }
    }
    cache = { nomi: nomi, eco: eco };
    return cache;
  }

  /* x è una specializzazione di F solo se F è un nome ufficiale e x è F oppure una sua linea. */
  function specializza(x, F) {
    if (!x || !F) return false;
    if (x === F) return true;
    if (x.indexOf(F + ',') === 0 || x.indexOf(F + ' -') === 0 || x.indexOf(F + '-') === 0 || x.indexOf(F + ' ') === 0) return true;
    var pref = ['Difesa ', 'Partita ', 'Apertura ', 'Sistema '], i, p, X, p2;
    for (i = 0; i < pref.length; i++) {
      p = pref[i];
      if (F.indexOf(p) !== 0) continue;
      X = F.slice(p.length);
      if (X.length < 4) continue;
      if (x === X || x.indexOf(X + ',') === 0 || x.indexOf(X + ' ') === 0 || x.indexOf(X + ' -') === 0) return true;
      /* Apertura X e Difesa X sono la stessa famiglia (es. Catalana); non si mescolano con Partita o Gambetto. */
      if (p === 'Apertura ' || p === 'Difesa ') {
        p2 = p === 'Apertura ' ? 'Difesa ' : 'Apertura ';
        if (x === p2 + X || x.indexOf(p2 + X + ',') === 0 || x.indexOf(p2 + X + ' -') === 0 || x.indexOf(p2 + X + ' ') === 0) return true;
      }
    }
    return false;
  }
  function famiglieUfficiali() {
    var out = [], visti = {};
    (caricaDati().nomi || []).forEach(function (n) {
      var it = pulisci(n && n.it);
      if (!it || it.indexOf(',') >= 0 || it.indexOf(' -') >= 0 || visti[it]) return;
      visti[it] = 1; out.push(it);
    });
    out.sort(function (a, b) { return b.length - a.length || (a < b ? -1 : 1); });
    return out;
  }
  function generico(nomi) {
    var unici = [];
    nomi.forEach(function (n) { if (n && unici.indexOf(n) < 0) unici.push(n); });
    if (!unici.length) return null;
    if (unici.length === 1) return unici[0];
    var ordered = unici.slice().sort(function (a, b) { return a.length - b.length || (a < b ? -1 : 1); });
    var i, g, ok, fam, cands = [];
    for (i = 0; i < ordered.length; i++) {
      g = ordered[i];
      ok = unici.every(function (x) { return x === g || x.indexOf(g + ',') === 0 || x.indexOf(g + ' -') === 0 || x.indexOf(g + '-') === 0; });
      if (ok) return g;
    }
    fam = famiglieUfficiali();
    for (i = 0; i < fam.length; i++) {
      if (unici.every(function (x) { return specializza(x, fam[i]); })) cands.push(fam[i]);
    }
    if (cands.length) return cands[0];
    /* stelo comune già presente nelle voci ufficiali (es. «Gambetto Budapest, …») */
    var sti = unici.map(function (x) { var k = x.indexOf(','); return k > 0 ? x.slice(0, k) : null; });
    if (sti[0] && sti[0].length >= 8 && sti.every(function (s) { return s === sti[0]; })) return sti[0];
    return null;
  }

  function daEco(code) {
    var d = caricaDati(), idx = d.eco[code], its = [];
    if (!idx || !idx.length || !d.nomi.length) return FAMIGLIE_ECO[code] || null;
    idx.forEach(function (i) { if (d.nomi[i]) its.push(pulisci(d.nomi[i].it)); });
    return generico(its) || FAMIGLIE_ECO[code] || null;
  }

  function daInglese(name) {
    var d = caricaDati(), q = norm(name), exact = [];
    if (!q || !d.nomi.length) return null;
    d.nomi.forEach(function (n) { if (norm(n.en) === q) exact.push(pulisci(n.it)); });
    return generico(exact);
  }

  function visibile(opening) {
    opening = opening || {};
    var eco = opening.eco || null, grezzo = opening.name || null;
    var it = eco ? daEco(eco) : null;
    if (!it && grezzo) it = daInglese(grezzo);
    return { chiave: eco || it || grezzo || '', nome: it || eco || null, eco: eco, nomeIt: it, nomeGrezzo: grezzo };
  }

  function daInizio(g) {
    if (!g) return false;
    if (g.variant && g.variant !== 'standard') return false;
    if (!g.startFen) return true;
    return String(g.startFen).split(' ').slice(0, 3).join(' ') === INIZIO4;
  }

  function ritmoIt(k) { return RITMI_IT[k] || k; }

  return { visibile: visibile, daEco: daEco, daInglese: daInglese, daInizio: daInizio, ritmoIt: ritmoIt, INIZIO4: INIZIO4, VERSIONE: 'cnap-aperture-2' };
});
