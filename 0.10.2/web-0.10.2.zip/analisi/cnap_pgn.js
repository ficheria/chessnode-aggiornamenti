/* Chess Node · Analisi profonda · FASE 1 · CNApPgn — lettura PGN completa e senza perdite dichiarate (A1-02 §6.1).
   Codice originale Chess Node (08/11/2026). Legalità delle mosse: chess.js (BSD-2) iniettato, già usato dall'app.
   - PGN singolo o multi-partita; intestazioni (tutte, nell'ordine originale); commenti {..} e ;..; NAG $n e suffissi !,?,!!,??,!?,?!;
     varianti annidate; terminatori 1-0 0-1 1/2-1/2 *; SetUp/FEN con tratto Nero e numerazione iniziale conservati.
   - Il testo originale di ogni partita viene conservato byte per byte (raw); il modello navigabile è separato.
   - Errore nella linea principale ⇒ partita NON valida (mai troncata in silenzio). Errore in una variante ⇒ variante esclusa dal
     modello con avviso e flag completo:false; il testo originale resta conservato.
   - Nessuna promozione implicita a Donna: una spinta in ottava senza pezzo indicato è un errore.
   - SAN interna inglese standard (quella prodotta da chess.js); la notazione originale diversa resta in sanOriginale.
   API: CNApPgn.crea({Chess, CNApFen, CNApUtil, limiti}) → {leggi(text), leggiAsync(text,{ogni,onPartita}), esporta(partita), LIMITI} */
(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api; else root.CNApPgn = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  /* Limiti PROPOSTI, configurabili, da confermare con benchmark sul telefono (A1-02 §6.1). */
  var LIMITI_DEFAULT = { maxCaratteri: 20 * 1024 * 1024, maxPartite: 5000, maxProfonditaVarianti: 24, maxNodiPartita: 6000 };
  var SUFFISSI = { '!': 1, '?': 2, '!!': 3, '??': 4, '!?': 5, '?!': 6 };
  var RISULTATI = { '1-0': 1, '0-1': 1, '1/2-1/2': 1, '*': 1 };

  function crea(d) {
    var Chess = d.Chess, Fen = d.CNApFen, U = d.CNApUtil;
    if (!Chess || !Fen || !U) throw new Error('CNApPgn: servono Chess, CNApFen e CNApUtil');
    var LIM = Object.assign({}, LIMITI_DEFAULT, d.limiti || {});

    /* ---------------- 1. tokenizzatore con riga/colonna ---------------- */
    function tokenizza(text) {
      var toks = [], i = 0, n = text.length, line = 1, lineStart = 0;
      function push(t, v, s, e) { toks.push({ t: t, v: v, s: s, e: e, line: line, col: s - lineStart + 1 }); }
      function nl(k) { if (text[k] === '\n') { line++; lineStart = k + 1; } }
      while (i < n) {
        var c = text[i];
        if (c === '\n') { nl(i); i++; continue; }
        if (c === ' ' || c === '\t' || c === '\r' || c === '\f' || c === '\v' || c === '\uFEFF') { i++; continue; }
        if (c === '%' && i === lineStart) { while (i < n && text[i] !== '\n') i++; continue; }   // riga di escape (standard PGN)
        var s = i, l0 = line, c0 = i - lineStart + 1;
        if (c === '[') {
          var m = /^\[\s*([A-Za-z0-9_]+)\s*"((?:[^"\\]|\\.)*)"\s*\]/.exec(text.slice(i, i + 4096));
          if (m) { push('TAG', { nome: m[1], valore: m[2].replace(/\\(["\\])/g, '$1') }, s, s + m[0].length); i += m[0].length; continue; }
          var j = text.indexOf(']', i); var e = j < 0 ? n : j + 1;
          toks.push({ t: 'BAD', v: text.slice(i, Math.min(e, i + 80)), s: s, e: e, line: l0, col: c0, why: 'Intestazione non valida' });
          for (var k = i; k < e; k++) nl(k); i = e; continue;
        }
        if (c === '{') {
          var j2 = text.indexOf('}', i + 1);
          if (j2 < 0) { toks.push({ t: 'BAD', v: '{', s: s, e: n, line: l0, col: c0, why: 'Commento aperto con «{» e mai chiuso' }); for (var k2 = i; k2 < n; k2++) nl(k2); i = n; continue; }
          var txt = text.slice(i + 1, j2);
          for (var k3 = i; k3 <= j2; k3++) nl(k3);
          toks.push({ t: 'COMMENT', v: txt, s: s, e: j2 + 1, line: l0, col: c0 }); i = j2 + 1; continue;
        }
        if (c === ';') { var j3 = text.indexOf('\n', i); if (j3 < 0) j3 = n; toks.push({ t: 'COMMENT', v: text.slice(i + 1, j3).replace(/\r$/, ''), s: s, e: j3, line: l0, col: c0, riga: true }); i = j3; continue; }
        if (c === '(') { push('LP', '(', s, s + 1); i++; continue; }
        if (c === ')') { push('RP', ')', s, s + 1); i++; continue; }
        if (c === '$') { var m2 = /^\$(\d+)/.exec(text.slice(i, i + 8)); if (m2) { push('NAG', +m2[1], s, s + m2[0].length); i += m2[0].length; continue; } }
        // parola: fino a spazio o delimitatore
        var j4 = i; while (j4 < n && !/[\s{}()\[\];$]/.test(text[j4])) j4++;
        if (j4 === i) { toks.push({ t: 'BAD', v: c, s: s, e: s + 1, line: l0, col: c0, why: 'Carattere inatteso' }); i++; continue; }
        var w = text.slice(i, j4); i = j4;
        parola(w, s, l0, c0, toks);
      }
      return toks;
    }
    function parola(w, s, line, col, toks) {
      var base = { s: s, e: s + w.length, line: line, col: col };
      if (RISULTATI[w]) { toks.push(Object.assign({ t: 'RES', v: w }, base)); return; }
      if (w === '½-½' || w === '1/2' || w === '½') { toks.push(Object.assign({ t: 'RES', v: '1/2-1/2', avviso: 'Risultato di patta scritto in forma non standard («' + w + '»).' }, base)); return; }
      var m = /^(\d+)(\.+)(.*)$/.exec(w);
      if (m) { toks.push(Object.assign({ t: 'NUM', v: +m[1], nero: m[2].length >= 3 }, base)); if (m[3]) parola(m[3], s + m[1].length + m[2].length, line, col + m[1].length + m[2].length, toks); return; }
      if (/^\d+$/.test(w)) { toks.push(Object.assign({ t: 'NUM', v: +w, nero: false, senzaPunto: true }, base)); return; }
      var m3 = /^(.*?)([!?]{1,2})$/.exec(w);
      if (m3 && m3[1] && SUFFISSI[m3[2]]) { toks.push(Object.assign({ t: 'SAN', v: m3[1], suffisso: m3[2] }, base)); return; }
      if (SUFFISSI[w]) { toks.push(Object.assign({ t: 'NAG', v: SUFFISSI[w], daSuffisso: w }, base)); return; }
      if (/^e\.p\.?$/i.test(w) || /^ep$/i.test(w)) { toks.push(Object.assign({ t: 'EP', v: w }, base)); return; }
      var epm = /^(.*(?:x[a-h][1-8]|[a-h]x[a-h]?[1-8])(?:[+#=][QRNBqrnb]?)?)(e\.p\.?)$/i.exec(w);
      if (epm && epm[1]) { parola(epm[1], s, line, col, toks); toks.push({ t: 'EP', v: epm[2], s: s + epm[1].length, e: s + w.length, line: line, col: col + epm[1].length }); return; }
      toks.push(Object.assign({ t: 'SAN', v: w }, base));
    }

    /* ---------------- 2. divisione in partite + albero sintattico ---------------- */
    function dividi(text, toks) {
      var partite = [], i = 0, n = toks.length;
      while (i < n) {
        while (i < n && toks[i].t === 'COMMENT' && !partite.length && toks[i + 1] && toks[i + 1].t === 'TAG') i++;   // commento prima del primo header: fuori dalle partite
        if (i >= n) break;
        var p = { headers: [], diag: [], inizio: toks[i].s, line: toks[i].line, tokens: [] };
        while (i < n && toks[i].t === 'TAG') { p.headers.push(toks[i].v); i++; }
        var depth = 0;
        while (i < n) {
          var t = toks[i];
          if (t.t === 'TAG' && depth === 0) break;                          // nuova partita senza terminatore
          if (t.t === 'TAG') { p.diag.push(dg('error', 'PARENTESI', 'Intestazione trovata dentro una variante aperta: manca «)».', t)); depth = 0; break; }
          p.tokens.push(t); i++;
          if (t.t === 'LP') depth++;
          if (t.t === 'RP') depth--;
          if (t.t === 'RES' && depth === 0) break;
        }
        var last = p.tokens.length ? p.tokens[p.tokens.length - 1] : null;
        p.fine = last ? last.e : (i > 0 ? toks[i - 1].e : p.inizio);
        p.raw = text.slice(p.inizio, p.fine);
        if (!last || last.t !== 'RES') p.diag.push(dg('warning', 'SENZA_TERMINATORE', 'La partita non termina con un risultato (1-0, 0-1, 1/2-1/2 o *).', last || { line: p.line, col: 1 }));
        if (p.headers.length || p.tokens.length) partite.push(p);
      }
      return partite;
    }
    function dg(livello, code, msg, tok, extra) {
      var o = { livello: livello, code: code, msg: msg, line: tok ? tok.line : null, col: tok ? tok.col : null };
      if (extra) Object.keys(extra).forEach(function (k) { o[k] = extra[k]; });
      return o;
    }
    /* linea = {mosse:[{san, tok, nags[], pre[], post[{c}|{v:linea}]}], coda:[commenti finali], tokApertura} */
    function albero(p) {
      var toks = p.tokens, i = 0, risultato = null;
      function linea(depth, tokApertura) {
        var L = { mosse: [], coda: [], tok: tokApertura }, pre = [], ultima = null;
        while (i < toks.length) {
          var t = toks[i];
          if (t.t === 'RP') { if (depth === 0) { p.diag.push(dg('error', 'PARENTESI', 'Parentesi «)» senza apertura.', t)); i++; continue; } i++; L.coda = pre; return L; }
          if (t.t === 'RES') {
            i++;
            if (depth === 0) { risultato = t; if (t.avviso) p.diag.push(dg('warning', 'RISULTATO_FORMA', t.avviso, t)); }
            else p.diag.push(dg('warning', 'RISULTATO_IN_VARIANTE', 'Risultato dentro una variante: ignorato come terminatore.', t));
            continue;
          }
          if (t.t === 'NUM') { i++; continue; }
          if (t.t === 'BAD') { p.diag.push(dg('error', 'SINTASSI', t.why + ' («' + t.v + '»).', t)); i++; continue; }
          if (t.t === 'COMMENT') { i++; if (ultima && !pre.length) ultima.post.push({ c: t.v }); else pre.push(t.v); continue; }
          if (t.t === 'NAG') { i++; if (ultima) ultima.nags.push(t.v); else p.diag.push(dg('warning', 'NAG_ORFANO', 'Annotazione $' + t.v + ' senza mossa: ignorata.', t)); continue; }
          if (t.t === 'LP') {
            i++;
            if (!ultima) { p.diag.push(dg('error', 'VARIANTE_SENZA_MOSSA', 'Variante aperta prima di qualsiasi mossa.', t)); linea(depth + 1, t); continue; }
            if (depth + 1 > LIM.maxProfonditaVarianti) { p.diag.push(dg('error', 'LIMITE_PROFONDITA', 'Varianti annidate oltre il limite configurato (' + LIM.maxProfonditaVarianti + ').', t)); linea(depth + 1, t); continue; }
            var v = linea(depth + 1, t); ultima.post.push({ v: v }); continue;
          }
          if (t.t === 'EP') {
            p.diag.push(dg('warning', 'SAN_NON_STANDARD', 'Notazione non standard «' + t.v + '» dopo una presa di pedone: ignorata.', t));
            i++; continue;
          }
          if (t.t === 'SAN') {
            i++;
            ultima = { san: t.v, tok: t, nags: t.suffisso ? [SUFFISSI[t.suffisso]] : [], pre: pre, post: [] };
            pre = []; L.mosse.push(ultima); continue;
          }
          i++;
        }
        if (depth > 0) p.diag.push(dg('error', 'PARENTESI', 'Variante aperta con «(» e mai chiusa.', tokApertura));
        L.coda = pre; return L;
      }
      var main = linea(0, null);
      return { main: main, risultato: risultato };
    }

    /* ---------------- 3. replay legale e nodi con identità stabile ---------------- */
    function normalizzaSan(s) {
      return s.replace(/^0-0-0/, 'O-O-O').replace(/^0-0/, 'O-O').replace(/^o-o-o$/i, 'O-O-O').replace(/^o-o$/i, 'O-O');
    }
    function prova(c, tokSan) {
      var raw = tokSan, s = normalizzaSan(raw), mv = null, nonStd = s !== raw;
      try { mv = c.move(s, { strict: true }); } catch (e) { mv = null; }
      if (!mv) { try { mv = c.move(s); nonStd = true; } catch (e2) { mv = null; } }
      if (!mv && /^[a-h](x[a-h])?[18][+#]?$/.test(s)) {   // spinta in ottava senza pezzo: è una promozione implicita, non la si completa
        var prova2 = null; try { prova2 = c.move(s.replace(/[+#]$/, '') + '=Q'); } catch (e3) { prova2 = null; }
        if (prova2) { c.undo(); return { ok: false, implicita: true }; }
      }
      if (!mv) return { ok: false };
      if (mv.promotion && !/[QRBNqrbn]$/.test(s.replace(/[+#!?]+$/, ''))) {
        c.undo(); return { ok: false, implicita: true };
      }
      return { ok: true, mv: mv, nonStandard: nonStd || (s.replace(/[+#]+$/, '') !== mv.san.replace(/[+#]+$/, '')) };
    }

    function replay(p, tree, startFen, gid) {
      var nodi = {}, ordine = [], completo = true, nNodi = 0, rootKey = 'n0';
      var root = { key: rootKey, parentKey: null, childKeys: [], ply: 0, san: null, uci: null, fen: startFen, mainLine: true, nags: [], commentsBefore: [], commentsAfter: tree.main.mosse.length ? tree.main.mosse[0].pre.slice() : tree.main.coda.slice() };
      nodi[rootKey] = root; ordine.push(rootKey);
      if (tree.main.mosse.length) tree.main.mosse[0].pre = [];   // i commenti iniziali diventano commento di partita (radice)
      var principaleOk = true, erroreMain = null;

      function aggiungi(nodo) {
        if (++nNodi > LIM.maxNodiPartita) throw U.errore('LIMITE_NODI', 'Troppe mosse/varianti in una partita (limite ' + LIM.maxNodiPartita + ').');
        nodi[nodo.key] = nodo; ordine.push(nodo.key); nodi[nodo.parentKey].childKeys.push(nodo.key);
      }
      // linea principale con UNA istanza: conserva la storia (ripetizioni, 50 mosse)
      var c = new Chess(startFen), parentKey = rootKey, ply = 0, varianti = [];
      for (var k = 0; k < tree.main.mosse.length; k++) {
        var m = tree.main.mosse[k], fenPrima = c.fen(), r = prova(c, m.san);
        if (!r.ok) {
          principaleOk = false;
          erroreMain = dg('error', r.implicita ? 'PROMOZIONE_IMPLICITA' : 'MOSSA_ILLEGALE',
            (r.implicita ? 'Promozione senza pezzo indicato («' + m.san + '»): serve =D/=T/=A/=C (Q/R/B/N).' : 'Mossa non valida o illegale «' + m.san + '»') + ' alla semimossa ' + (ply + 1) + ' (mossa ' + numeroDa(startFen, ply) + ').', m.tok, { ply: ply + 1 });
          p.diag.push(erroreMain); break;
        }
        ply++;
        var key = 'n' + ply;
        var nodo = { key: key, parentKey: parentKey, childKeys: [], ply: ply, san: r.mv.san, uci: r.mv.from + r.mv.to + (r.mv.promotion || ''), fen: c.fen(), mainLine: true, nags: m.nags.slice(), commentsBefore: m.pre.slice(), commentsAfter: [] };
        if (r.nonStandard) { nodo.sanOriginale = m.san; p.diag.push(dg('warning', 'SAN_NON_STANDARD', 'Notazione non standard «' + m.san + '» letta come ' + r.mv.san + '.', m.tok, { ply: ply })); }
        aggiungi(nodo);
        m.post.forEach(function (x) { if (x.c != null) nodo.commentsAfter.push(x.c); else varianti.push({ linea: x.v, parentKey: parentKey, fen: fenPrima, depth: 1 }); });
        parentKey = key;
      }
      var finale = c;
      if (principaleOk) {
        // varianti: ogni variante è un'alternativa alla mossa che la precede, giocata dalla stessa posizione
        while (varianti.length) {
          var v = varianti.shift();
          var ok = replayVariante(v, nodi, aggiungi, varianti, p);
          if (!ok) completo = false;
        }
      }
      if (tree.main.coda.length && tree.main.mosse.length && principaleOk) nodi[parentKey].commentsAfter = nodi[parentKey].commentsAfter.concat(tree.main.coda);
      return { nodi: nodi, ordine: ordine, ok: principaleOk, completo: completo && principaleOk, finale: finale, ultimoKey: parentKey, ply: ply };
    }
    function replayVariante(v, nodi, aggiungi, coda, p) {
      var c, parentKey = v.parentKey, primo = true;
      try { c = new Chess(v.fen); } catch (e) { return false; }
      for (var k = 0; k < v.linea.mosse.length; k++) {
        var m = v.linea.mosse[k], fenPrima = c.fen(), r = prova(c, m.san);
        if (!r.ok) {
          p.diag.push(dg('warning', 'VARIANTE_NON_VALIDA', 'Variante esclusa dal modello: «' + m.san + '» non è valida in quella posizione. Il testo originale resta conservato.', m.tok));
          return false;
        }
        var uci = r.mv.from + r.mv.to + (r.mv.promotion || '');
        var key = 'x' + U.hash(parentKey + '>' + uci).slice(0, 10), base = key, dup = 2;
        while (nodi[key]) key = base + '-' + (dup++);
        var nodo = { key: key, parentKey: parentKey, childKeys: [], ply: nodi[parentKey].ply + 1, san: r.mv.san, uci: uci, fen: c.fen(), mainLine: false, nags: m.nags.slice(), commentsBefore: m.pre.slice(), commentsAfter: [] };
        if (r.nonStandard) { nodo.sanOriginale = m.san; p.diag.push(dg('warning', 'SAN_NON_STANDARD', 'Notazione non standard «' + m.san + '» letta come ' + r.mv.san + '.', m.tok)); }
        aggiungi(nodo);
        var pk = parentKey;
        m.post.forEach(function (x) { if (x.c != null) nodo.commentsAfter.push(x.c); else coda.push({ linea: x.v, parentKey: pk, fen: fenPrima, depth: v.depth + 1 }); });
        parentKey = key; primo = false;
      }
      if (v.linea.coda.length && !primo) nodi[parentKey].commentsAfter = nodi[parentKey].commentsAfter.concat(v.linea.coda);
      return true;
    }
    function numeroDa(fen, plyFatti) { var nero = fen.split(' ')[1] === 'b', fm = +fen.split(' ')[5]; var idx = plyFatti + (nero ? 1 : 0); return (fm + Math.floor(idx / 2)) + (idx % 2 ? '...' : '.'); }

    /* ---------------- 4. una partita completa ---------------- */
    function costruisci(p, indice) {
      var H = {}, ordineH = [];
      p.headers.forEach(function (h) { if (H[h.nome] !== undefined) p.diag.push(dg('warning', 'HEADER_DOPPIO', 'Intestazione «' + h.nome + '» ripetuta: vale la prima.', { line: p.line, col: 1 })); else { H[h.nome] = h.valore; ordineH.push(h.nome); } });
      var out = { indice: indice, raw: p.raw, rawHash: U.hash(p.raw), riga: p.line, headers: H, ordineHeaders: ordineH, diagnostica: p.diag, stato: 'valida', variante: 'standard', startFen: null, startStandard: true, nodi: null, ordineNodi: null, completo: false, risultatoHeader: H.Result || null, terminatore: null, esitoScacchiera: null, mainLineUci: [], mainLineSan: [] };
      // variante di gioco
      var vh = (H.Variant || '').trim();
      if (vh && !/^(standard|from position|normal|chess)$/i.test(vh)) {
        out.variante = /960|fischer/i.test(vh) ? 'chess960' : vh.toLowerCase();
        out.stato = 'non_supportata';
        p.diag.push(dg('error', 'VARIANTE', 'Variante «' + vh + '»: esclusa da motore e statistiche standard (primo ambito solo scacchi standard). Il testo è conservato.', { line: p.line, col: 1 }));
        return out;
      }
      // posizione iniziale
      var start = Fen.START;
      if (H.FEN != null) {
        var vf = Fen.valida(H.FEN, { Chess: Chess });
        if (!vf.ok) {
          out.stato = vf.variante === 'chess960' ? 'non_supportata' : 'non_valida'; out.variante = vf.variante;
          vf.errori.forEach(function (e) { p.diag.push(dg('error', 'FEN_' + e.code, 'FEN iniziale: ' + e.msg, { line: p.line, col: 1 })); });
          return out;
        }
        if (H.SetUp !== '1') p.diag.push(dg('warning', 'SETUP_MANCANTE', 'Intestazione FEN presente senza [SetUp "1"]: posizione iniziale usata comunque.', { line: p.line, col: 1 }));
        start = vf.fen;
      } else if (H.SetUp === '1') { p.diag.push(dg('error', 'FEN_MANCANTE', '[SetUp "1"] senza intestazione FEN.', { line: p.line, col: 1 })); out.stato = 'non_valida'; return out; }
      out.startFen = start; out.startStandard = start === Fen.START;
      var tree = albero(p);
      out.terminatore = tree.risultato ? tree.risultato.v : null;
      if (p.diag.some(function (x) { return x.livello === 'error'; })) { out.stato = 'non_valida'; return out; }
      var rp;
      try { rp = replay(p, tree, start); }
      catch (e) { p.diag.push(dg('error', e.code || 'REPLAY', e.message, { line: p.line, col: 1 })); out.stato = 'non_valida'; return out; }
      if (!rp.ok) { out.stato = 'non_valida'; return out; }
      out.nodi = rp.nodi; out.ordineNodi = rp.ordine; out.completo = rp.completo;
      var k = 'n0';
      while (rp.nodi[k].childKeys.length) { var ch = rp.nodi[k].childKeys[0]; if (!rp.nodi[ch].mainLine) break; k = ch; out.mainLineUci.push(rp.nodi[k].uci); out.mainLineSan.push(rp.nodi[k].san); }
      var f = rp.finale;
      out.esitoScacchiera = f.isCheckmate() ? { tipo: 'matto', vincitore: f.turn() === 'w' ? 'b' : 'w' }
        : f.isStalemate() ? { tipo: 'stallo' } : f.isInsufficientMaterial() ? { tipo: 'materiale_insufficiente' }
        : f.isThreefoldRepetition() ? { tipo: 'triplice_ripetizione' } : f.isDrawByFiftyMoves() ? { tipo: 'cinquanta_mosse' } : null;
      return out;
    }

    function leggi(text) {
      text = String(text == null ? '' : text);
      if (text.length > LIM.maxCaratteri) return { partite: [], errore: { code: 'LIMITE_DIMENSIONE', msg: 'File troppo grande (' + text.length + ' caratteri, limite ' + LIM.maxCaratteri + '): nessuna partita importata.' } };
      var toks = tokenizza(text), parti = dividi(text, toks);
      if (parti.length > LIM.maxPartite) return { partite: [], errore: { code: 'LIMITE_PARTITE', msg: 'Il file contiene ' + parti.length + ' partite, oltre il limite di ' + LIM.maxPartite + ': nessuna importata (dividere il file).' } };
      if (!parti.length) return { partite: [], errore: { code: 'VUOTO', msg: 'Nessuna partita trovata nel testo.' } };
      return { partite: parti.map(costruisci), errore: null };
    }
    /* versione che cede il controllo all'interfaccia ogni `ogni` partite (niente blocco UI su file grandi) */
    async function leggiAsync(text, o) {
      o = o || {}; text = String(text == null ? '' : text);
      if (text.length > LIM.maxCaratteri) return leggi(text);
      var toks = tokenizza(text), parti = dividi(text, toks), out = [], ogni = o.ogni || 25;
      if (parti.length > LIM.maxPartite) return leggi(text);
      if (!parti.length) return { partite: [], errore: { code: 'VUOTO', msg: 'Nessuna partita trovata nel testo.' } };
      for (var i = 0; i < parti.length; i++) {
        if (o.segnale && o.segnale.aborted) throw U.errore('ANNULLATO', 'Lettura annullata.');
        out.push(costruisci(parti[i], i));
        if (o.onPartita) o.onPartita(i + 1, parti.length);
        if ((i + 1) % ogni === 0) await new Promise(function (r) { setTimeout(r, 0); });
      }
      return { partite: out, errore: null };
    }

    /* ---------------- 5. esportazione dal modello (nodi) ---------------- */
    function escTag(v) { return String(v).replace(/\\/g, '\\\\').replace(/"/g, '\\"'); }
    function escCom(c) { return String(c).replace(/}/g, ')'); }
    /* partita = {headers, ordineHeaders, startFen, nodi (mappa key→nodo), rootKey:'n0', terminatore}
       Ricrea un PGN con TUTTE le intestazioni, commenti, NAG e varianti del modello. Il testo originale resta comunque la copia fedele. */
    function esporta(g) {
      var H = g.headers || {}, ord = (g.ordineHeaders || Object.keys(H)).slice();
      Object.keys(H).forEach(function (k) { if (ord.indexOf(k) < 0) ord.push(k); });
      var righe = ord.map(function (k) { return '[' + k + ' "' + escTag(H[k]) + '"]'; });
      var nodi = g.nodi, rootKey = g.rootKey || 'n0', parti = [];
      var start = g.startFen || Fen.START, nero0 = start.split(' ')[1] === 'b', fm0 = +start.split(' ')[5];
      function numero(ply) { var idx = ply - 1 + (nero0 ? 1 : 0); return { n: fm0 + Math.floor(idx / 2), nero: idx % 2 === 1 }; }
      var root = nodi[rootKey];
      (root.commentsAfter || []).forEach(function (c) { parti.push('{' + escCom(c) + '}'); });
      function linea(firstKey, forzaNumero) {
        var k = firstKey, forza = forzaNumero;
        while (k) {
          var nd = nodi[k], num = numero(nd.ply);
          (nd.commentsBefore || []).forEach(function (c) { parti.push('{' + escCom(c) + '}'); forza = true; });
          if (!num.nero) parti.push(num.n + '.'); else if (forza) parti.push(num.n + '...');
          parti.push(nd.san);
          (nd.nags || []).forEach(function (x) { parti.push('$' + x); });
          forza = false;
          (nd.commentsAfter || []).forEach(function (c) { parti.push('{' + escCom(c) + '}'); forza = true; });
          var padre = nodi[nd.parentKey], fratelli = padre.childKeys.slice(1);
          if (padre.childKeys[0] === k) fratelli.forEach(function (fk) { parti.push('('); linea(fk, true); parti.push(')'); forza = true; });
          k = nd.childKeys[0] || null;
        }
      }
      if (root.childKeys.length) linea(root.childKeys[0], true);
      parti.push(g.terminatore || H.Result || '*');
      var testo = '', riga = '';
      parti.forEach(function (t) {
        var sep = riga === '' || /\($/.test(riga) || t === ')' ? '' : ' ';
        if ((riga + sep + t).length > 79 && riga) { testo += riga + '\n'; riga = t; } else riga += sep + t;
      });
      testo += riga;
      return righe.join('\n') + (righe.length ? '\n\n' : '') + testo + '\n';
    }

    return { leggi: leggi, leggiAsync: leggiAsync, esporta: esporta, LIMITI: LIM, _tokenizza: tokenizza };
  }

  return { crea: crea, LIMITI_DEFAULT: LIMITI_DEFAULT, VERSIONE: 'cnap-pgn-1' };
});
