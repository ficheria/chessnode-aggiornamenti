/* Chess Node · Analisi profonda · FASE 4 · CNApSoluzione — passi 2 e 3 della nascita di un esercizio (A3-01, A3-04).
   Codice originale Chess Node (09/11/2026). Costruisce l'ALBERO DELLA SOLUZIONE con il motore locale (solo tramite lo scheduler,
   priorità «verifica»; Stockfish resta un Worker separato) e certifica i matti brevi con una ricerca ESAUSTIVA legale in JS.
   Principi (dalla specifica e dalle istruzioni del 09/11):
   - ogni nodo del solutore ha l'INSIEME delle mosse accettate, non una mossa sola: chi mantiene l'obiettivo verificato è giusto;
   - per pubblicare, ogni altra mossa analizzata deve essere CHIARAMENTE confutata (distacco ≥ GAP); una zona grigia → ambiguo;
   - ogni candidata (accettate, prima scartata, mossa originale della partita) è riverificata cercando la posizione figlia in
     condizioni comparabili: se il giudizio cambia → instabile → mai approvato;
   - ai nodi dell'avversario si seguono tutte le risposte equivalenti alla miglior difesa (non la risposta giocata né una PV sola);
     le altre sono peggiori per l'avversario per l'ordinamento MultiPV alla stessa profondità (evidenza registrata);
   - timeout, budget o ricerca incompleta → «unknown», mai approvato per inerzia.
   Probabilità: la stessa P(cp) cnp-2 di CNApPunteggio, dal punto di vista del SOLUTORE. Nessuna chiamata di rete. */
(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api; else root.CNApSoluzione = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  var VERSIONE = 'cnap-soluzione-1';
  var VAL = { p: 1, n: 3, b: 3, r: 5, q: 9, k: 0 };
  /* soglie (PROPOSTA tecnica, versionate in VERSIONE; tarabili sul corpus) */
  var CFG = {
    depth: 16,             // profondità delle ricerche di verifica
    mpvIniziale: 3, mpvMax: 5,
    EQ: 4,                 // due mosse con P entro 4 punti sono equivalenti (stesso obiettivo)
    GAP: 20,               // una mossa è «chiaramente confutata» se ≥ 20 punti sotto la peggiore accettata
    STABILE: 12,           // differenza massima tra passata MultiPV e riverifica della figlia prima di parlare di instabilità
    P_OBIETTIVO: 80,       // vantaggio decisivo (≈ +2,4) per l'obiettivo «guadagno di materiale»
    P_VINTO: 90,           // oltre questa soglia due mosse vincenti sono EQUIVALENTI anche con punteggi diversi (es. =D e =T che vincono entrambe)
    maxAccettate: 3,       // più di 3 mosse equivalenti non terminali in un nodo: non è un esercizio a soluzione definita
    GUADAGNO_MIN: 2,       // punti-pedone netti a fine scambio
    P_DIFESA_MIN: 35,      // una difesa «tiene» se il solutore resta ≥ 35 (non perde)
    EQ_DIFESA: 6, GAP_DIFESA: 20,
    maxMosseSolutore: 4,   // limite breve CONFIGURABILE (Q07 non fissato): mai troncare prima della confutazione decisiva → unknown
    maxRispostePerNodo: 4,
    maxRicerche: 80,
    budgetEsaustivo: 400000  // nodi della ricerca esaustiva dei matti
  };

  function materiale(Chess, fen, lato) { var t = 0; new Chess(fen).board().forEach(function (r) { r.forEach(function (x) { if (x) t += (x.color === lato ? 1 : -1) * VAL[x.type]; }); }); return t; }
  function uciDi(m) { return m.from + m.to + (m.promotion || ''); }
  function mossa(Chess, fen, uci) {
    var c = new Chess(fen);
    if (!/^[a-h][1-8][a-h][1-8][qrbn]?$/.test(uci || '')) return null;
    var leg = c.moves({ verbose: true }).filter(function (m) { return uciDi(m) === uci; });
    if (!leg.length) return null;   // promozione SENZA pezzo esplicito = illegale (nessuna auto-Donna)
    var m = c.move(leg[0]); return { c: c, m: m, fen: c.fen(), san: m.san };
  }

  /* ---------- matti brevi: ricerca esaustiva legale (certificazione indipendente dal motore) ---------- */
  function certificaMatto(Chess, fen, nMax, budget) {
    var nodi = 0, lim = budget || CFG.budgetEsaustivo, fuori = false;
    function forzato(c, n) {   // il lato al tratto dà matto in ≤ n contro OGNI difesa
      var ms = c.moves({ verbose: true });
      ms.sort(function (a, b) { return (b.san.indexOf('+') >= 0) - (a.san.indexOf('+') >= 0) || (!!b.captured - !!a.captured); });
      for (var i = 0; i < ms.length; i++) {
        if (++nodi > lim) { fuori = true; return false; }
        c.move(ms[i]);
        var ok;
        if (c.isCheckmate()) ok = true;
        else if (n <= 1 || c.isGameOver()) ok = false;   // stallo, patta: non è matto
        else {
          ok = true;
          var risp = c.moves({ verbose: true });
          for (var j = 0; j < risp.length && ok; j++) { c.move(risp[j]); if (!forzato(c, n - 1)) ok = false; c.undo(); if (fuori) ok = false; }
        }
        c.undo();
        if (ok) return true;
        if (fuori) return false;
      }
      return false;
    }
    for (var n = 1; n <= nMax; n++) {
      var c = new Chess(fen);
      if (forzato(c, n)) return { certo: true, n: n, nodi: nodi, metodo: 'esaustivo-legale' };
      if (fuori) return { certo: false, n: null, nodi: nodi, metodo: 'esaustivo-legale', motivo: 'budget' };
    }
    return { certo: true, n: null, nodi: nodi, metodo: 'esaustivo-legale', nessunMatto: true };
  }
  /* tutte le mosse che danno matto subito (matti in uno multipli: ognuna è valida) */
  function mattiInUno(Chess, fen) { var c = new Chess(fen); return c.moves({ verbose: true }).filter(function (m) { c.move(m); var x = c.isCheckmate(); c.undo(); return x; }).map(uciDi); }
  /* mosse che danno matto in ≤ n (esaustivo), per accettare ogni matto corretto, non solo quello del motore */
  function mosseDiMatto(Chess, fen, n, budget) {
    var c = new Chess(fen), out = [], tutte = c.moves({ verbose: true }), incerto = false;
    tutte.forEach(function (m) {
      var c2 = new Chess(fen); c2.move(m);
      if (c2.isCheckmate()) { out.push(uciDi(m)); return; }
      if (n <= 1 || c2.isGameOver()) return;
      var ok = true, risp = c2.moves({ verbose: true });
      for (var j = 0; j < risp.length && ok; j++) { var c3 = new Chess(c2.fen()); c3.move(risp[j]); var r = certificaMatto(Chess, c3.fen(), n - 1, budget); if (r.motivo === 'budget') { incerto = true; ok = false; } else if (!r.certo || r.nessunMatto || r.n == null) ok = false; }
      if (ok) out.push(uciDi(m));
    });
    return { mosse: out, incerto: incerto };
  }

  function crea(d) {
    var S = d.scheduler, Chess = d.Chess, Pt = d.CNApPunteggio, U = d.CNApUtil;
    var C = Object.assign({}, CFG, d.cfg || {});
    var P = Pt.P, ctxRitrova = { P: 100 };

    /* una ricerca registrata come EVIDENZA */
    async function cerca(ctx, fen, multipv, prio) {
      if (ctx.ricerche >= C.maxRicerche) { var e = new Error('Budget di ricerche esaurito'); e.code = 'BUDGET'; throw e; }
      ctx.ricerche++;
      var r = await S.cerca({ owner: ctx.owner || 'allenatore', priorita: prio || 'verifica', gameId: ctx.gameId, nodeId: ctx.nodeId, fen: fen, opz: { depth: C.depth, multipv: multipv }, versione: ctx.versione });
      var ev = { ref: 'E' + (ctx.evidenze.length + 1), fen: fen, multipv: multipv, profondita: r.profonditaRaggiunta, richiesta: r.profonditaRichiesta || C.depth, completa: !!r.completa && !r.fermata,
        nessunaMossa: !!r.nessunaMossa, linee: (r.linee || []).map(function (l) { var cp = Pt.cpDi(l.score); return { uci: l.pv[0], cp: cp, mate: l.score.tipo === 'mate' ? l.score.valore : null, P: Math.round(P(cp) * 10) / 10, depth: l.depth, pv: l.pv.slice(0, 10) }; }) };
      if (r.motore && r.motore.build) ctx.motore = r.motore.build;
      ctx.evidenze.push(ev);
      return ev;
    }
    /* riverifica di una mossa: posizione figlia cercata dal punto di vista dell'avversario, poi invertita */
    async function riverifica(ctx, fen, uci) {
      var x = mossa(Chess, fen, uci); if (!x) return null;
      if (x.c.isCheckmate()) return { uci: uci, san: x.san, P: 100, mate: 1, matto: true, fen: x.fen, ref: null };
      if (x.c.isGameOver()) return { uci: uci, san: x.san, P: 50, mate: null, patta: true, stallo: x.c.isStalemate(), fen: x.fen, ref: null };
      var ev = await cerca(ctx, x.fen, 1);
      if (!ev.completa || !ev.linee.length) return { uci: uci, san: x.san, incompleta: true, fen: x.fen, ref: ev.ref };
      var l = ev.linee[0];
      return { uci: uci, san: x.san, P: Math.round((100 - l.P) * 10) / 10, mate: l.mate != null ? (l.mate > 0 ? -(l.mate) : -l.mate + 1) : null, fen: x.fen, ref: ev.ref, pvAvv: l.pv };
    }

    function soddisfa(ob, v, resto) {
      if (!v || v.incompleta) return null;
      if (ob.tipo === 'matto') return v.matto || (v.mate != null && v.mate > 0 && v.mate <= resto);
      if (ob.tipo === 'difesa') return v.P >= C.P_DIFESA_MIN;
      if (ob.tipo === 'ritrova') return v.P >= ctxRitrova.P - C.EQ;
      return v.P >= C.P_OBIETTIVO;
    }

    /* ---------- nodo del solutore ---------- */
    async function nodoSolutore(ctx, fen, resto, pathUci, radice) {
      var id = pathUci.length ? 'S' + U.hash(pathUci.join(' ')).slice(0, 10) : 'S0';
      var c = new Chess(fen), nodo = { id: id, fen: fen, tipo: 'solver', lato: c.turn(), resto: resto, acceptedMoves: [], refutedMoves: [], buoneNonObiettivo: [], evidenceRefs: [] };
      ctx.nodi.push(nodo);
      if (c.isGameOver()) { nodo.tipo = 'terminal'; nodo.terminale = { tipo: c.isCheckmate() ? 'matto-subito' : 'patta' }; return nodo; }
      var ob = ctx.obiettivo, mat0 = ctx.materialeRadice;
      // terminale «materiale»: guadagno netto realizzato e consolidato (valutazione stabile su questa posizione)
      if (ob.tipo === 'materiale' && pathUci.length) {
        var g = materiale(Chess, fen, ctx.solutore) - mat0;
        if (g >= C.GUADAGNO_MIN) {
          var evT = await cerca(ctx, fen, 1); nodo.evidenceRefs.push(evT.ref);
          if (evT.completa && evT.linee.length && evT.linee[0].P >= C.P_OBIETTIVO) { nodo.tipo = 'terminal'; nodo.terminale = { tipo: 'materiale', guadagno: g, P: evT.linee[0].P, evidenceRef: evT.ref }; return nodo; }
        }
      }
      if (ob.tipo === 'difesa' && pathUci.length) {   // V1: difesa in UNA mossa; dopo la miglior risposta la posizione deve tenere
        var evD = await cerca(ctx, fen, 1); nodo.evidenceRefs.push(evD.ref);
        if (evD.completa && evD.linee.length && evD.linee[0].P >= C.P_DIFESA_MIN) { nodo.tipo = 'terminal'; nodo.terminale = { tipo: 'tenuta', P: evD.linee[0].P, evidenceRef: evD.ref }; return nodo; }
        nodo.incerto = 'la difesa non tiene dopo la miglior risposta'; return nodo;
      }
      if (ob.tipo === 'ritrova' && pathUci.length) {
        var evR = await cerca(ctx, fen, 1); nodo.evidenceRefs.push(evR.ref);
        if (evR.completa && evR.linee.length && evR.linee[0].P >= ctx.pRitrova - C.EQ - C.STABILE) { nodo.tipo = 'terminal'; nodo.terminale = { tipo: 'ritrovata', P: evR.linee[0].P, evidenceRef: evR.ref }; return nodo; }
        nodo.incerto = 'il vantaggio non si conferma dopo la risposta'; return nodo;
      }
      if (resto <= 0) { nodo.incerto = 'obiettivo non raggiunto entro il limite di ' + C.maxMosseSolutore + ' mosse del solutore'; return nodo; }

      // 1) MultiPV, allargata finché compare una mossa confutata (o le mosse legali finiscono)
      var legali = c.moves().length, mpv = Math.min(C.mpvIniziale, legali), ev;
      for (;;) {
        ev = await cerca(ctx, fen, mpv); nodo.evidenceRefs.push(ev.ref);
        if (!ev.completa) { nodo.incerto = 'ricerca incompleta'; return nodo; }
        var best = ev.linee[0] ? ev.linee[0].P : 0, ultima = ev.linee[ev.linee.length - 1];
        var tutteBuone = ultima && ultima.P >= best - (ob.tipo === 'difesa' ? C.GAP_DIFESA : C.GAP) + 1;
        if (!tutteBuone || mpv >= Math.min(C.mpvMax, legali)) break;
        mpv = Math.min(C.mpvMax, legali);
      }
      // 2) candidate da riverificare: tutte le linee + mossa originale della partita (alla radice) + matti esaustivi
      var cand = ev.linee.map(function (l) { return l.uci; });
      if (radice && ctx.mossaOriginale && cand.indexOf(ctx.mossaOriginale) < 0) cand.push(ctx.mossaOriginale);
      c.moves({ verbose: true }).forEach(function (m) { if (m.promotion && cand.indexOf(uciDi(m)) < 0) cand.push(uciDi(m)); });   // tutte le promozioni, anche minori
      var esaustivi = null;
      if (ob.tipo === 'matto' && resto <= 2) {
        var mm = mosseDiMatto(Chess, fen, resto, C.budgetEsaustivo);
        esaustivi = mm; mm.mosse.forEach(function (u) { if (cand.indexOf(u) < 0) cand.push(u); });   // matti fuori dalla top list: accettati
      }
      var vv = [];
      for (var i = 0; i < cand.length; i++) {
        var v = await riverifica(ctx, fen, cand[i]); if (!v) continue;
        var lm = ev.linee.filter(function (l) { return l.uci === cand[i]; })[0];
        v.Pmpv = lm ? lm.P : null; v.mateMpv = lm ? lm.mate : null;
        if (v.ref) nodo.evidenceRefs.push(v.ref);
        vv.push(v);
      }
      // 3) classificazione con la riverifica; stabilità rispetto alla passata MultiPV
      var buoneOb = vv.filter(function (v) { return soddisfa(ob, v, resto); });
      if (esaustivi) buoneOb = vv.filter(function (v) { return esaustivi.mosse.indexOf(v.uci) >= 0 || (v.matto); });
      if (vv.some(function (v) { return v.incompleta; })) { nodo.incerto = 'riverifica incompleta'; return nodo; }
      if (!buoneOb.length) { nodo.incerto = 'nessuna mossa mantiene l\'obiettivo'; return nodo; }
      var top = Math.max.apply(null, buoneOb.map(function (v) { return v.P; }));
      var eq = ob.tipo === 'difesa' ? C.EQ_DIFESA : C.EQ, gap = ob.tipo === 'difesa' ? C.GAP_DIFESA : C.GAP;
      var acc = (ob.tipo === 'matto' || ob.tipo === 'difesa') ? buoneOb : buoneOb.filter(function (v) { return v.P >= top - eq || (top >= C.P_VINTO && v.P >= C.P_VINTO); });
      var minAcc = Math.min.apply(null, acc.map(function (v) { return v.P; }));
      vv.forEach(function (v) {
        var r = { uci: v.uci, san: v.san, P: v.P, mate: v.mate, evidenceRef: v.ref, Pmpv: v.Pmpv };
        if (acc.indexOf(v) >= 0) return;
        if (v.stallo) { r.motivo = 'stallo'; nodo.refutedMoves.push(r); return; }
        if (soddisfa(ob, v, resto) || (ob.tipo === 'matto' && v.P >= C.P_OBIETTIVO)) { r.motivo = ob.tipo === 'matto' ? (v.mate > 0 ? 'matto più lento' : 'buona ma non dà matto') : 'buona ma non equivalente'; nodo.buoneNonObiettivo.push(r); return; }
        if (v.P <= minAcc - gap) { r.motivo = 'confutata'; nodo.refutedMoves.push(r); return; }
        r.motivo = 'zona grigia'; (nodo.grigie = nodo.grigie || []).push(r);
      });
      // instabilità: una mossa accettata o confutata che cambia categoria tra MultiPV e riverifica
      var instabili = ob.tipo === 'matto' ? (esaustivi ? [] : vv).filter(function (v) { return v.mateMpv != null && v.mateMpv > 0 && !v.matto && !(v.mate > 0); })
        : vv.filter(function (v) { return v.Pmpv != null && Math.abs(v.Pmpv - v.P) > C.STABILE && (acc.indexOf(v) >= 0) !== (v.Pmpv >= minAcc - eq); });
      if (instabili.length) nodo.instabili = instabili.map(function (v) { return { uci: v.uci, Pmpv: v.Pmpv, P: v.P }; });
      // mossa ultima della lista ancora non confutata → le mosse fuori lista non sono coperte
      var ultimaL = ev.linee[ev.linee.length - 1];
      if (esaustivi) nodo.coperturaCompleta = !esaustivi.incerto;
      else if (ev.linee.length >= legali) nodo.coperturaCompleta = true;
      else if (ob.tipo === 'matto') nodo.coperturaCompleta = !(ultimaL.mate != null && ultimaL.mate > 0 && ultimaL.mate <= resto);   // fuori lista nessun matto più veloce dell'ultima linea
      else nodo.coperturaCompleta = ultimaL.P <= minAcc - gap;
      nodo.metodoCopertura = esaustivi ? 'ricerca esaustiva legale' : 'ordinamento MultiPV alla profondità ' + C.depth;
      nodo.distaccoMinimo = vv.filter(function (v) { return acc.indexOf(v) < 0; }).reduce(function (m, v) { return Math.min(m, minAcc - v.P); }, 100);
      if (acc.filter(function (v) { return !v.matto; }).length > C.maxAccettate) { nodo.incerto = 'troppe mosse equivalenti (' + acc.length + '): non è un esercizio a soluzione definita'; nodo.acceptedMoves = acc.map(function (a) { return { uci: a.uci, san: a.san, P: a.P }; }); return nodo; }
      // 4) rami: ogni mossa accettata ha il proprio seguito verificato
      for (var k = 0; k < acc.length; k++) {
        var a = acc[k], ed = { uci: a.uci, san: a.san, P: a.P, mate: a.mate, evidenceRef: a.ref, equivalenza: a.P >= top - 0.05 ? 'migliore' : 'equivalente' };
        nodo.acceptedMoves.push(ed);
        if (a.matto) { var t = { id: id + '.' + a.uci, fen: a.fen, tipo: 'terminal', terminale: { tipo: 'matto', prova: 'scacco matto sulla scacchiera (chess.js)' } }; ctx.nodi.push(t); ed.childId = t.id; continue; }
        var figlio = await nodoAvversario(ctx, a.fen, resto - 1, pathUci.concat([a.uci]));
        ed.childId = figlio.id;
      }
      return nodo;
    }

    /* ---------- nodo dell'avversario ---------- */
    async function nodoAvversario(ctx, fen, resto, pathUci) {
      var id = 'O' + U.hash(pathUci.join(' ')).slice(0, 10), c = new Chess(fen);
      var nodo = { id: id, fen: fen, tipo: 'opponent', lato: c.turn(), replyEdges: [], evidenceRefs: [] };
      ctx.nodi.push(nodo);
      if (c.isGameOver()) { nodo.tipo = 'terminal'; nodo.terminale = { tipo: c.isCheckmate() ? 'matto' : 'patta' }; if (!c.isCheckmate()) nodo.incerto = 'patta/stallo nella linea'; return nodo; }
      // guadagno già realizzato dalla mossa del solutore e non recuperabile: dopo la miglior risposta resta ≥ GUADAGNO e decisivo → terminale
      if (ctx.obiettivo.tipo === 'materiale' && materiale(Chess, fen, ctx.solutore) - ctx.materialeRadice >= C.GUADAGNO_MIN) {
        var evG = await cerca(ctx, fen, 1); nodo.evidenceRefs.push(evG.ref);
        if (evG.completa && evG.linee.length && 100 - evG.linee[0].P >= C.P_OBIETTIVO) {
          var dopo = mossa(Chess, fen, evG.linee[0].uci), g2 = dopo ? materiale(Chess, dopo.fen, ctx.solutore) - ctx.materialeRadice : null;
          if (g2 != null && g2 >= C.GUADAGNO_MIN) { nodo.tipo = 'terminal'; nodo.terminale = { tipo: 'materiale', guadagno: g2, P: Math.round((100 - evG.linee[0].P) * 10) / 10, rispostaMigliore: dopo.san, evidenceRef: evG.ref, prova: 'guadagno realizzato e mantenuto dopo la miglior difesa' }; return nodo; }
        }
      }
      var legali = c.moves().length, mpv = Math.min(C.maxRispostePerNodo, legali), ev, bestO, rel;
      for (;;) {
        ev = await cerca(ctx, fen, mpv); nodo.evidenceRefs.push(ev.ref);
        if (!ev.completa || !ev.linee.length) { nodo.incerto = 'ricerca incompleta'; return nodo; }
        bestO = ev.linee[0].P;
        rel = ev.linee.filter(function (l) { return l.P >= bestO - C.EQ; });
        if (rel.length < ev.linee.length || mpv >= Math.min(C.mpvMax, legali)) break;
        mpv = Math.min(C.mpvMax, legali);
      }
      var tutteLeLegali = ev.linee.length >= legali;
      if ((rel.length > C.maxRispostePerNodo && !tutteLeLegali) || (rel.length === ev.linee.length && !tutteLeLegali)) { nodo.incerto = 'troppe difese equivalenti da coprire'; return nodo; }
      nodo.copertura = { linee: ev.linee.length, legali: legali, metodo: 'tutte le risposte entro ' + C.EQ + ' punti dalla miglior difesa; le altre sono peggiori per l\'avversario nell\'ordinamento MultiPV' };
      for (var i = 0; i < rel.length; i++) {
        var x = mossa(Chess, fen, rel[i].uci);
        var e = { uci: rel[i].uci, san: x.san, bestDefence: i === 0, P_avversario: rel[i].P, evidenceRef: ev.ref };
        nodo.replyEdges.push(e);
        var f = await nodoSolutore(ctx, x.fen, resto, pathUci.concat([rel[i].uci]), false);
        e.childId = f.id;
      }
      return nodo;
    }

    /* obiettivo dalla linea migliore (radice). cand.tipo: tattica | difesa | ritrova */
    function obiettivoDa(cand, l0, fen) {
      if (cand.tipo === 'difesa') return { tipo: 'difesa', testo: 'Difenditi dalla minaccia' };
      if (l0.mate != null && l0.mate > 0 && l0.mate <= C.maxMosseSolutore) return { tipo: 'matto', n: l0.mate, esatto: false };
      if (cand.tipo === 'ritrova') return { tipo: 'ritrova' };
      // materiale: guadagno netto a fine scambio lungo la PV verificata
      var c = new Chess(fen), lato = c.turn(), base = materiale(Chess, fen, lato), g = null;
      for (var i = 0; i < Math.min(l0.pv.length, 2 * C.maxMosseSolutore); i++) { var mm = c.moves({ verbose: true }).filter(function (m) { return uciDi(m) === l0.pv[i]; })[0]; if (!mm) break; c.move(mm); if (i % 2 === 1) g = materiale(Chess, c.fen(), lato) - base; }
      if (g != null && g >= C.GUADAGNO_MIN && l0.P >= C.P_OBIETTIVO) return { tipo: 'materiale', guadagno: g };
      return null;
    }

    /* minaccia per gli esercizi di difesa: «mossa nulla» (si passa il tratto) — l'avversario deve vincere materiale o dare matto */
    async function minaccia(ctx, fen) {
      var p = fen.split(' '); if (new Chess(fen).inCheck()) return { dimostrata: false, motivo: 'sotto scacco: non è una difesa semplice V1' };
      p[1] = p[1] === 'w' ? 'b' : 'w'; p[3] = '-';
      var fn = p.join(' '); try { new Chess(fn); } catch (e) { return { dimostrata: false, motivo: 'posizione con tratto invertito non valida' }; }
      var ev = await cerca(ctx, fn, 1);
      if (!ev.completa || !ev.linee.length) return { dimostrata: false, motivo: 'ricerca incompleta', evidenceRef: ev.ref };
      var l = ev.linee[0], lato = p[1], base = materiale(Chess, fn, lato), c = new Chess(fn), g = null;
      for (var i = 0; i < Math.min(4, l.pv.length); i++) { var mm = c.moves({ verbose: true }).filter(function (m) { return uciDi(m) === l.pv[i]; })[0]; if (!mm) break; c.move(mm); if (i % 2 === 1) g = materiale(Chess, c.fen(), lato) - base; }
      var matto = l.mate != null && l.mate > 0 && l.mate <= 3;
      var ok = matto || (g != null && g >= C.GUADAGNO_MIN && l.P >= C.P_OBIETTIVO);
      return { dimostrata: ok, tipo: matto ? 'matto' : 'materiale', matto: matto ? l.mate : null, guadagno: g, linea: l.pv.slice(0, 4), P: l.P, evidenceRef: ev.ref, motivo: ok ? null : 'nessuna minaccia concreta dimostrata' };
    }

    /* ======== VERIFICA COMPLETA di un candidato → esito + albero + evidenze ========
       cand = {startFen, solverColor, tipo:'tattica'|'difesa'|'ritrova', mossaOriginale?, mossaGeniale?, gameId, nodeId}  */
    async function verifica(cand, o) {
      o = o || {};
      var ctx = { gameId: cand.gameId, nodeId: cand.nodeId, owner: o.owner || 'allenatore', versione: o.versione, ricerche: 0, evidenze: [], nodi: [], solutore: cand.solverColor, mossaOriginale: cand.mossaOriginale, motore: null };
      var fen = cand.startFen, c = new Chess(fen), out = { versione: VERSIONE, cfg: C };
      try {
        if (c.turn() !== cand.solverColor) return fine('scartato', 'wrong-side', 'Il tratto della posizione non è del solutore.');
        if (c.isGameOver()) return fine('scartato', 'game-over', 'Partita già finita in questa posizione.');
        var ev0 = await cerca(ctx, fen, Math.min(C.mpvIniziale, c.moves().length));
        if (!ev0.completa || !ev0.linee.length) return fine('pending', 'incomplete', 'Ricerca iniziale incompleta.');
        var l0 = ev0.linee[0];
        if (cand.tipo === 'difesa') { out.minaccia = await minaccia(ctx, fen); if (!out.minaccia.dimostrata) return fine('scartato', 'no-threat', 'Minaccia non dimostrata: ' + out.minaccia.motivo + '.'); }
        var ob = obiettivoDa(cand, l0, fen);
        if (!ob) return fine('lesson-candidate', 'no-objective', 'Nessun obiettivo concreto (matto o guadagno netto di materiale): resta nell\'analisi.');
        if (ob.tipo === 'ritrova') { var vg = await riverifica(ctx, fen, cand.mossaGeniale); if (!vg || vg.incompleta) return fine('pending', 'incomplete', 'Riverifica della mossa geniale incompleta.'); ctx.pRitrova = vg.P; ctxRitrova.P = vg.P; ob.P = vg.P; ob.mossaGeniale = cand.mossaGeniale; }
        // matto: certificazione della distanza (esaustiva fino a 2, oltre solo «trova il matto» senza N promesso)
        if (ob.tipo === 'matto') {
          var cert = ob.n <= 2 ? certificaMatto(Chess, fen, 2, C.budgetEsaustivo) : { certo: false, metodo: 'non tentata (oltre 2 mosse)' };
          out.certificazione = cert;
          if (cert.certo && cert.n) { ob.n = cert.n; ob.esatto = true; } else if (cert.certo && cert.nessunMatto) return fine('scartato', 'false-mate', 'Il motore indicava un matto che la ricerca esaustiva non conferma.');
          else { ob.esatto = false; }
        }
        ctx.obiettivo = ob; ctx.materialeRadice = materiale(Chess, fen, cand.solverColor);
        var resto = ob.tipo === 'matto' && ob.esatto ? ob.n : (ob.tipo === 'difesa' || ob.tipo === 'ritrova') ? 1 : C.maxMosseSolutore;
        var radice = await nodoSolutore(ctx, fen, resto, [], true);
        out.obiettivo = ob;
        out.albero = { rootId: radice.id, nodes: ctx.nodi };
        var probl = problemi(ctx.nodi, ob);
        if (probl.length) return fine('ambiguo', probl[0].codice, probl.map(function (p) { return p.testo; }).join(' · '));
        return fine('ok', null, null);
      } catch (e) {
        if (e && e.code === 'BUDGET') return fine('pending', 'budget', 'Budget di verifica esaurito: resta in attesa.');
        if (e && /SUPERATA|ANNULLATA|TERMICO|MOTORE/.test(e.code || '')) return fine('pending', 'interrupted', e.message);
        throw e;
      }
      function fine(esito, codice, testo) {
        out.esito = esito; out.codice = codice; out.motivo = testo; out.evidenze = ctx.evidenze; out.ricerche = ctx.ricerche;
        out.engineMetadata = { name: 'Stockfish', build: ctx.motore || (S.meta && S.meta() && S.meta().build) || null, depthRequested: C.depth, depthReached: ctx.evidenze.reduce(function (m, e) { return Math.min(m, e.profondita || 0); }, ctx.evidenze.length ? 99 : 0), multiPVMax: C.mpvMax, locale: true };
        if (!out.albero && ctx.nodi.length) out.albero = { rootId: ctx.nodi[0].id, nodes: ctx.nodi };
        return out;
      }
    }

    /* problemi dell'albero che vietano la pubblicazione automatica */
    function problemi(nodi, ob) {
      var out = [];
      nodi.forEach(function (n) {
        if (n.incerto) out.push({ codice: 'unknown', testo: n.id + ': ' + n.incerto });
        if (n.grigie && n.grigie.length) out.push({ codice: 'close-alternative', testo: n.id + ': alternativa vicina non confutata (' + n.grigie.map(function (g) { return g.san; }).join(', ') + ')' });
        if (n.instabili && n.instabili.length) out.push({ codice: 'unstable', testo: n.id + ': valutazione instabile' });
        if (n.tipo === 'solver' && n.coperturaCompleta === false) out.push({ codice: 'coverage', testo: n.id + ': mosse fuori lista non coperte' });
        if (n.tipo === 'solver' && n.buoneNonObiettivo && n.buoneNonObiettivo.length && ob && ob.tipo !== 'matto') out.push({ codice: 'several-wins', testo: n.id + ': altre mosse vincenti non equivalenti (' + n.buoneNonObiettivo.map(function (g) { return g.san; }).join(', ') + ')' });
      });
      return out;
    }

    /* ======== verifica LIVE di una mossa del giocatore non catalogata (checker) ========
       nodo = nodo del solutore dell'esercizio; ritorna {giudizio:'equivalente'|'sbagliata'|'non-obiettivo'|'incerta', P, prova} */
    async function valutaMossa(ex, nodo, uci, o) {
      o = o || {};
      var ctx = { gameId: ex.sourceGameId, nodeId: ex.sourceNodeId, owner: o.owner || 'allenatore-risposta', ricerche: 0, evidenze: [], nodi: [] };
      var C2 = C;
      try {
        var v; var x = mossa(Chess, nodo.fen, uci); if (!x) return { giudizio: 'illegale' };
        if (x.c.isCheckmate()) return { giudizio: 'equivalente', P: 100, matto: true, prova: 'scacco matto sulla scacchiera' };
        if (x.c.isGameOver()) { var acc0 = (nodo.acceptedMoves || []).map(function (a) { return a.P; }), m0 = acc0.length ? Math.min.apply(null, acc0) : 100;
          return 50 <= m0 - C.GAP ? { giudizio: 'sbagliata', P: 50, prova: x.c.isStalemate() ? 'stallo: la partita finisce patta' : 'patta sulla scacchiera', stallo: x.c.isStalemate() } : { giudizio: 'incerta', P: 50, motivo: 'patta immediata' }; }
        var save = C.maxRicerche; C.maxRicerche = 4;
        try { v = await (async function () { var ev = await cerca(Object.assign(ctx, { owner: ctx.owner }), x.fen, 1, o.priorita || 'interattivo'); if (!ev.completa || !ev.linee.length) return null; return { P: 100 - ev.linee[0].P, mate: ev.linee[0].mate, ref: ev }; })(); }
        finally { C.maxRicerche = save; }
        if (!v) return { giudizio: 'incerta', motivo: 'ricerca incompleta' };
        var ob = ex.objective || {}, acc = (nodo.acceptedMoves || []).map(function (a) { return a.P; }), minAcc = acc.length ? Math.min.apply(null, acc) : 100;
        var gap = ob.tipo === 'difesa' ? C2.GAP_DIFESA : C2.GAP, eq = ob.tipo === 'difesa' ? C2.EQ_DIFESA : C2.EQ;
        var matto = v.mate != null && v.mate < 0;   // dal punto di vista dell'avversario: matto subito contro di lui
        var dist = matto ? -v.mate + 1 : null;
        var buona = ob.tipo === 'matto' ? (matto && dist <= (nodo.resto || 99)) : v.P >= minAcc - eq && (ob.tipo === 'difesa' ? v.P >= C2.P_DIFESA_MIN : v.P >= C2.P_OBIETTIVO || ob.tipo === 'ritrova');
        if (buona) return { giudizio: 'equivalente', P: v.P, evidenza: v.ref };
        if (ob.tipo === 'matto' && v.P >= C2.P_OBIETTIVO) return { giudizio: 'non-obiettivo', P: v.P, evidenza: v.ref };
        if (ob.tipo !== 'matto' && ob.tipo !== 'difesa' && v.P >= C2.P_OBIETTIVO) return { giudizio: 'non-obiettivo', P: v.P, evidenza: v.ref };
        if (v.P <= minAcc - gap) return { giudizio: 'sbagliata', P: v.P, evidenza: v.ref, linea: v.ref.linee[0].pv.slice(0, 4) };
        return { giudizio: 'incerta', P: v.P, evidenza: v.ref, motivo: 'distacco non sufficiente per un giudizio sicuro' };
      } catch (e) {
        if (e && e.code === 'SUPERATA') throw e;
        return { giudizio: 'incerta', motivo: 'motore non disponibile: ' + (e && e.message) };
      }
    }

    return { verifica: verifica, valutaMossa: valutaMossa, problemi: problemi, minaccia: minaccia, cfg: C };
  }

  return { crea: crea, certificaMatto: certificaMatto, mattiInUno: mattiInUno, mosseDiMatto: mosseDiMatto, mossa: mossa, materiale: materiale, uciDi: uciDi, CFG: CFG, VERSIONE: VERSIONE };
});
