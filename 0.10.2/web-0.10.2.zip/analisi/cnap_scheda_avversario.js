/* Chess Node · Analisi profonda · FASE 5 · CNApSchedaAvversario — la scheda «Studia un avversario» (A2-12, A2-13).
   Codice originale Chess Node (09/11/2026). Calcolo PURO: usa CNApProfilo (stesse formule e STESSE soglie del profilo personale,
   non abbassate) sulla vista dell'ambito avversario, poi scrive frasi NEUTRE in terza persona: fatti con il loro denominatore
   («Con il Nero ha giocato … in N partite»), mai giudizi sulla persona, mai deduzioni da luogo, età, avatar o stato online.
   Pochi consigli netti invece di una scheda piena di ipotesi; il «piano di gioco» non promette la vittoria.
   Titolo distinto da «Il mio profilo scacchistico»; icona binocolo (Lucide v2). */
(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api; else root.CNApSchedaAvversario = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  var VERSIONE = 'cnap-scheda-avversario-1';
  var PERIODI = { '7': '1s', '30': '1m', '182': '6m', '365': '1a', tutto: 'tutto' };
  var NOMI_PERIODO = { '7': 'ultimi 7 giorni', '30': 'ultimi 30 giorni', '182': 'ultimi 182 giorni', '365': 'ultimi 365 giorni', tutto: 'tutto il periodo disponibile' };
  var TEMI = { pezzo_indifeso: 'pezzo indifeso', forchetta: 'forchetta', inchiodatura: 'inchiodatura', infilata: 'infilata', matto_non_visto: 'matto', scoperta: 'attacco di scoperta' };
  var STATI = { 'Possibile debolezza': 'Possibile difficoltà ricorrente', 'Tendenza ricorrente': 'Tendenza ricorrente', 'Campione più consistente': 'Tendenza su un campione più consistente' };
  var MIN = 5;   // stessa soglia del profilo (aperture e finali: almeno 5 partite)
  /* tono: parole e costrutti vietati (giudizi sulla persona, sorveglianza, promesse, dati personali) */
  var VIETATI = [/aggressiv/i, /nervos/i, /emotiv/i, /paur/i, /ansi[ao]/i, /\btilt/i, /carattere/i, /personalit/i, /psicolog/i, /\bspia/i, /sorvegli/i, /\bdebol[ei]\b/i,
    /è un(a)? (giocatore|giocatrice|persona)/i, /\bet[àa]\b/i, /\banni\b/i, /città/i, /\bpaese\b/i, /avatar/i, /\bonline\b/i, /realname/i, /location/i,
    /vincerai/i, /vittoria (sicura|garantita)/i, /(?<!non )garantisc/i, /sempre perde|perde sempre/i, /punto debole definitivo/i, /\bscarso|\bpessim/i];

  var Ap = (typeof require === 'function' ? require('../../fase_01/moduli/cnap_aperture.js') : (typeof CNApAperture !== 'undefined' ? CNApAperture : null));
  function itSan(s) { return String(s).replace(/[KQRBN]/g, function (p) { return { K: 'R', Q: 'D', R: 'T', B: 'A', N: 'C' }[p]; }); }
  function mossa(san, ply) { return ply % 2 === 0 ? Math.floor(ply / 2) + 1 + '.' + itSan(san) : Math.floor(ply / 2) + 1 + '...' + itSan(san); }
  function vps(r) { return r.vinte + '/' + r.patte + '/' + r.perse + (r.sconosciute ? ' (+' + r.sconosciute + ' senza esito noto)' : ''); }
  function colore(c) { return c === 'w' ? 'il Bianco' : 'il Nero'; }

  function controllaTono(x) {
    var trovati = [];
    (function giu(v, p) {
      if (typeof v === 'string') { VIETATI.forEach(function (re) { if (re.test(v)) trovati.push({ percorso: p, testo: v, regola: String(re) }); }); return; }
      if (v && typeof v === 'object') Object.keys(v).forEach(function (k) { if (k !== 'soggetto' && k !== 'campioneDettaglio') giu(v[k], p + '.' + k); });
    })(x, '');
    return trovati;
  }

  /* abitudini VERIFICABILI: contate sulle mosse delle partite, ciascuna con il suo denominatore */
  function abitudini(partite) {
    var out = [], conLato = partite.filter(function (g) { return g.userColor && g.mainLineSan && g.mainLineSan.length && (!Ap || Ap.daInizio(g)); });
    var W = conLato.filter(function (g) { return g.userColor === 'w'; }), B = conLato.filter(function (g) { return g.userColor === 'b'; });
    function distrib(gs, f) { var c = {}; gs.forEach(function (g) { var k = f(g); if (k) c[k] = (c[k] || 0) + 1; }); return Object.keys(c).sort(function (a, b) { return c[b] - c[a] || (a < b ? -1 : 1); }).map(function (k) { return { k: k, n: c[k] }; }); }
    if (W.length >= MIN) { var d = distrib(W, function (g) { return g.mainLineSan[0]; }); out.push({ id: 'prima-mossa-bianco', partite: W.length, righe: d, testo: 'Con il Bianco ha aperto con ' + d.slice(0, 3).map(function (x) { return mossa(x.k, 0) + ' in ' + x.n; }).join(', ') + ' partite su ' + W.length + '.' }); }
    else out.push({ id: 'prima-mossa-bianco', partite: W.length, pochiDati: true, testo: 'Prime mosse col Bianco: pochi dati (' + W.length + ' partite).' });
    ['e4', 'd4'].forEach(function (m) {
      var gs = B.filter(function (g) { return g.mainLineSan[0] === m && g.mainLineSan.length > 1; });
      if (gs.length >= MIN) { var d = distrib(gs, function (g) { return g.mainLineSan[1]; }); out.push({ id: 'risposta-' + m, partite: gs.length, righe: d, testo: 'Con il Nero, contro ' + mossa(m, 0) + ', ha risposto ' + d.slice(0, 3).map(function (x) { return mossa(x.k, 1) + ' in ' + x.n; }).join(', ') + ' partite su ' + gs.length + '.' }); }
    });
    var lunghe = conLato.filter(function (g) { return g.mainLineSan.length >= 20; });
    if (lunghe.length >= MIN) {
      var c = { corto: 0, lungo: 0, nessuno: 0 };
      lunghe.forEach(function (g) { var s = g.userColor === 'w' ? 0 : 1, x = 'nessuno'; for (var i = s; i < g.mainLineSan.length; i += 2) { var t = g.mainLineSan[i].replace(/[+#]/, ''); if (t === 'O-O') { x = 'corto'; break; } if (t === 'O-O-O') { x = 'lungo'; break; } } c[x]++; });
      out.push({ id: 'arrocco', partite: lunghe.length, conteggi: c, testo: 'Arrocco nelle partite di almeno 10 mosse: corto in ' + c.corto + ', lungo in ' + c.lungo + ', nessun arrocco in ' + c.nessuno + ' (su ' + lunghe.length + ').' });
    }
    var rit = distrib(conLato, function (g) { return g.timeClass; });
    if (rit.length) out.push({ id: 'ritmi', partite: conLato.length, righe: rit, testo: 'Ritmi delle partite pubbliche: ' + rit.map(function (x) { return (Ap ? Ap.ritmoIt(x.k) : x.k) + ' ' + x.n; }).join(', ') + '.' });
    return out;
  }

  /* d = {profilo: CNApProfilo creato, vista: {record, dati, senzaLato}, avversario: CNApAvversario, capitoli: CNApCapitoli, periodo, ora} */
  async function calcola(d) {
    var r = d.vista.record, per = d.periodo || 'tutto', P = await d.profilo.calcola({ dati: d.vista.dati, periodo: PERIODI[per], ora: d.ora });
    var adesso = d.ora, partite = d.vista.dati.partite.filter(function (g) { return per === 'tutto' || (g.playedAtMs != null && g.playedAtMs > adesso - (+per) * 86400000 && g.playedAtMs <= adesso); });
    var nomeServ = r.service === 'lichess' ? 'Lichess' : 'Chess.com';
    var out = {
      versione: VERSIONE, titolo: 'Studia un avversario', icona: 'binoculars',
      soggetto: { servizio: r.service, nomeServizio: nomeServ, nomePubblico: r.publicName, subjectId: r.subjectId },
      avviso: 'Basato solo sulle partite pubbliche disponibili.',
      scopo: 'Per prepararsi prima di una partita, non durante.',
      periodo: { id: per, testo: NOMI_PERIODO[per] },
      copertura: { partite: P.copertura.partite, analizzate: P.copertura.analizzate, selezionate: Object.keys(r.campione.selezionate).length, fuoriCampione: Object.keys(r.campione.fuoriCampione || {}).length,
        inVerifica: Object.keys(r.letturaOpposta || {}).length, latoNonIdentificato: d.vista.senzaLato,
        testo: 'Basato su ' + P.copertura.partite + ' partite · ' + P.copertura.analizzate + ' analizzate dal motore' },
      campione: r.campione.criterio,
      pochiDati: P.pochiDati,
      risultati: { bianco: P.risultati.perColore.w, nero: P.risultati.perColore.b },
      aperture: null, abitudini: abitudini(partite), difficolta: [], preparazione: null, mesi: null,
      conservazione: { saved: r.saved, createdAt: r.createdAt, lastUpdatedAt: r.lastUpdatedAt, expiresAt: r.expiresAt, testo: d.avversario.testoConservazione(r) }
    };
    if (out.copertura.inVerifica) out.copertura.notaVerifica = out.copertura.inVerifica + (out.copertura.inVerifica === 1 ? ' partita esclusa' : ' partite escluse') + ': la nostra lettura è opposta a quella del sito e va verificata prima di usarla.';
    // aperture per colore: frequenze e V/P/S; percentuale solo con almeno 5 partite (stessa soglia del profilo)
    function righe(lista, c) { return lista.map(function (x) {
      return { nome: x.nome, eco: x.eco, partite: x.partite, vinte: x.vinte, patte: x.patte, perse: x.perse, sconosciute: x.sconosciute, percentualeVittorie: x.percentualeVittorie, pochiDati: x.pochiDati,
        testo: 'Con ' + colore(c) + ' ha giocato ' + x.nome + ' in ' + x.partite + (x.partite === 1 ? ' partita' : ' partite') + ' (V/P/S ' + vps(x) + ')' + (x.pochiDati ? ' · pochi dati per una percentuale.' : ' · ' + String(x.percentualeVittorie).replace('.', ',') + '% vinte.') }; }); }
    out.aperture = { bianco: righe(P.tecnica.aperture.bianco, 'w'), nero: righe(P.tecnica.aperture.nero, 'b'), senzaNome: P.tecnica.aperture.nonIdentificate,
      nota: 'Nomi italiani dalla lista di Kiko; se il nome italiano manca si mostra solo il codice ECO.' };
    // difficoltà ricorrenti: SOLO difetti confermati con le soglie Q02 (≥5 occasioni, ≥3 errori in ≥3 partite), mai con «Pochi dati»
    if (P.pochiDati) out.difficoltaTesto = 'Pochi dati: ' + P.copertura.analizzate + ' partite analizzate dal motore (ne servono almeno 10). Nessuna difficoltà ricorrente indicata.';
    else {
      P.tecnica.tattica.temi.filter(function (t) { return t.confermato; }).sort(function (a, b) { return b.errori - a.errori || (a.tema < b.tema ? -1 : 1); }).forEach(function (t) {
        out.difficolta.push({ tipo: 'tattica', tema: t.tema, stato: STATI[t.stato] || t.stato, occasioni: t.occasioni, errori: t.errori, partite: t.partiteConErrore, analizzate: t.partiteAnalizzate,
          testo: 'Ha mancato ' + t.errori + ' occasioni di ' + TEMI[t.tema] + ' su ' + t.occasioni + ', in ' + t.partiteConErrore + ' partite diverse (su ' + t.partiteAnalizzate + ' analizzate). Dato delle partite pubbliche, può cambiare.' });
      });
      P.tecnica.finali.filter(function (f) { return !f.pochiDati && f.vinteNonConvertite.length >= 2 && new Set(f.vinteNonConvertite.map(function (v) { return v.gameId; })).size >= 2; }).forEach(function (f) {
        out.difficolta.push({ tipo: 'finale', finale: f.tipo, partite: f.partite, episodi: f.vinteNonConvertite.length,
          testo: 'Nei finali «' + f.tipo + '» (' + f.partite + ' partite): ' + f.vinteNonConvertite.length + ' posizioni nettamente favorevoli (stima del motore, non risultato teorico) non trasformate in vittoria.' });
      });
      if (!out.difficolta.length) out.difficoltaTesto = 'Nessuna difficoltà ricorrente confermata con i minimi richiesti (almeno 5 occasioni e 3 errori in 3 partite diverse).';
    }
    // preparazione prepartita: solo se i dati bastano; al massimo 3 indicazioni nette
    var prep = [], rep = r.campione.repertorio || {};
    if (!P.pochiDati) {
      var ab = {}; out.abitudini.forEach(function (a) { ab[a.id] = a; });
      if (rep.w) rep.w.chiavi.forEach(function (k) {   // l'utente col Bianco: come risponde il soggetto col Nero
        var san = { e2e4: 'e4', d2d4: 'd4' }[k], a = san && ab['risposta-' + san];
        if (a && a.righe[0]) prep.push({ tipo: 'linea', testo: 'Se apri ' + mossa(san, 0) + ': con il Nero ha risposto ' + mossa(a.righe[0].k, 1) + ' in ' + a.righe[0].n + ' partite su ' + a.partite + '.', partite: a.partite });
      });
      if (rep.b && ab['prima-mossa-bianco'] && !ab['prima-mossa-bianco'].pochiDati) {
        var x = ab['prima-mossa-bianco'].righe[0]; prep.push({ tipo: 'linea', testo: 'Quando hai il Nero: con il Bianco ha aperto con ' + mossa(x.k, 0) + ' in ' + x.n + ' partite su ' + ab['prima-mossa-bianco'].partite + '.', partite: ab['prima-mossa-bianco'].partite });
      }
      out.difficolta.filter(function (t) { return t.tipo === 'tattica'; }).forEach(function (t) {
        var cid = d.capitoli && d.capitoli.MAPPA_TEMI[t.tema], cap = cid ? { id: cid, nome: d.capitoli.CAPITOLI[cid] } : null;
        prep.push({ tipo: 'tema', tema: t.tema, capitolo: cap, testo: 'Nelle sue partite analizzate le occasioni di ' + TEMI[t.tema] + ' sono state mancate ' + t.errori + ' volte su ' + t.occasioni + ': vale la pena cercarle.' + (cap ? ' Ripasso: capitolo «' + cap.nome + '».' : '') });
      });
    }
    prep = prep.slice(0, 3);
    out.preparazione = prep.length ? { disponibile: true, voci: prep, nota: 'Indicazioni ricavate da ' + P.copertura.partite + ' partite pubbliche: non garantiscono il risultato e possono cambiare con nuove partite.' }
      : { disponibile: false, voci: [], nota: P.pochiDati ? 'Preparazione non disponibile: pochi dati (meno di 10 partite analizzate dal motore).' : 'Preparazione non disponibile: nessuna indicazione supera i minimi richiesti.' };
    out.mesi = { righe: P.mesi.righe.map(function (m) { return { mese: m.mese, ritmo: m.ritmo, sito: m.sito, inCorso: m.inCorso, partite: m.partite, analizzate: m.analizzate }; }), confronti: P.mesi.confronti, nota: P.mesi.nota };
    out.tono = controllaTono(out);
    return out;
  }
  return { calcola: calcola, controllaTono: controllaTono, abitudini: abitudini, PERIODI: PERIODI, VIETATI: VIETATI, VERSIONE: VERSIONE };
});
