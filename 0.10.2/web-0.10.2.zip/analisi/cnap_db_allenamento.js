/* Chess Node · Analisi profonda · FASE 4 · CNApDbAll — archivio dell'ALLENAMENTO (esercizi, collocazioni, tentativi, sessioni, piani).
   Codice originale Chess Node (09/11/2026). Stesso contratto di CNApBackend (fase 1): tx(stores, mode, fn) atomica con
   t.get/put/del/all/byIndex/count. Database SEPARATO dall'archivio partite ('chessnodeplay-allenamento'): la fase 1 approvata
   non si tocca; l'unificazione in un solo DB versione 2 è proposta in DIFFERENZE_PROPOSTE (fase 6).
   Regola per chi scrive fn: dentro una transazione SOLO await su operazioni t.* (IndexedDB chiude la transazione altrimenti). */
(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api; else root.CNApDbAll = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  var DB_VERSION = 1;
  var STORES = {
    exercises:  { key: 'exerciseId', idx: { status: 'validationStatus', gameId: 'sourceGameId', posKey: 'posKey' } },
    placements: { key: 'placementId', idx: { exerciseId: 'exerciseId', kind: 'kind', chapterId: 'chapterId' } },
    attempts:   { key: 'attemptId', idx: { exerciseId: 'exerciseId', sessionId: 'sessionId' } },
    sessions:   { key: 'sessionId', idx: { kind: 'kind' } },
    plans:      { key: 'planId', idx: { weekId: 'weekId' } },
    meta:       { key: 'key', idx: {} }
  };
  function erroreSpazio(c) { var e = new Error('Spazio di archiviazione esaurito: nessuna modifica salvata.'); e.code = 'SPAZIO'; e.causa = c; return e; }
  function clone(v) { return v === undefined ? undefined : JSON.parse(JSON.stringify(v)); }

  function memoria(o) {
    o = o || {};
    var dati = {}; Object.keys(STORES).forEach(function (s) { dati[s] = new Map(); });
    var quota = o.quotaByte || Infinity, guasto = null;
    return {
      tipo: 'memoria',
      tx: async function (stores, mode, fn) {
        var mod = {};
        function vista(s) { var m = new Map(dati[s]); if (mod[s]) mod[s].forEach(function (v, k) { if (v === null) m.delete(k); else m.set(k, v); }); return m; }
        function chk(s) { if (stores.indexOf(s) < 0) throw new Error('Store «' + s + '» non incluso nella transazione'); }
        function rw() { if (mode !== 'readwrite') throw new Error('Transazione in sola lettura'); }
        var t = {
          get: async function (s, k) { chk(s); return clone(vista(s).get(k)); },
          put: async function (s, v) { chk(s); rw(); var k = v[STORES[s].key]; if (k == null) throw new Error('Chiave mancante per ' + s); (mod[s] = mod[s] || new Map()).set(k, clone(v)); },
          del: async function (s, k) { chk(s); rw(); (mod[s] = mod[s] || new Map()).set(k, null); },
          all: async function (s) { chk(s); return Array.from(vista(s).values()).map(clone); },
          byIndex: async function (s, i, val) { chk(s); var p = STORES[s].idx[i]; return Array.from(vista(s).values()).filter(function (v) { return v[p] === val; }).map(clone); },
          count: async function (s) { chk(s); return vista(s).size; }
        };
        var r = await fn(t);
        if (mode === 'readwrite') {
          if (guasto) { var g = guasto; guasto = null; throw g; }
          if (quota !== Infinity) { var n = 0; Object.keys(STORES).forEach(function (s) { vista(s).forEach(function (v) { n += JSON.stringify(v).length * 2; }); }); if (n > quota) throw erroreSpazio('quota simulata superata'); }
          Object.keys(mod).forEach(function (s) { mod[s].forEach(function (v, k) { if (v === null) dati[s].delete(k); else dati[s].set(k, v); }); });
        }
        return r;
      },
      _guastoAlProssimoCommit: function (e) { guasto = e || erroreSpazio('guasto simulato'); },
      _impostaQuota: function (q) { quota = q; },
      _dump: function () { var x = {}; Object.keys(dati).forEach(function (s) { x[s] = Array.from(dati[s].values()).map(clone); }); return x; }
    };
  }

  function indexedDB_(o) {
    o = o || {};
    var IDB = o.indexedDB || (typeof indexedDB !== 'undefined' ? indexedDB : null);
    if (!IDB) throw new Error('IndexedDB non disponibile in questo ambiente');
    var nome = o.nome || 'chessnodeplay-allenamento', dbP = null;
    function apri() {
      if (dbP) return dbP;
      dbP = new Promise(function (res, rej) {
        var rq = IDB.open(nome, DB_VERSION);
        rq.onupgradeneeded = function () {
          var db = rq.result;
          Object.keys(STORES).forEach(function (s) {
            if (db.objectStoreNames.contains(s)) return;
            var os = db.createObjectStore(s, { keyPath: STORES[s].key });
            Object.keys(STORES[s].idx).forEach(function (i) { os.createIndex(i, STORES[s].idx[i]); });
          });
        };
        rq.onsuccess = function () { res(rq.result); }; rq.onerror = function () { rej(rq.error); };
        rq.onblocked = function () { rej(new Error('Archivio bloccato da un\'altra scheda aperta')); };
      });
      return dbP;
    }
    function req(r) { return new Promise(function (res, rej) { r.onsuccess = function () { res(r.result); }; r.onerror = function (e) { e.preventDefault(); rej(r.error); }; }); }
    return {
      tipo: 'indexeddb', nome: nome,
      tx: async function (stores, mode, fn) {
        var db = await apri(), tr = db.transaction(stores, mode), fin;
        var fatto = new Promise(function (res, rej) { tr.oncomplete = function () { res(); }; tr.onabort = function () { var e = tr.error; rej(e && e.name === 'QuotaExceededError' ? erroreSpazio(e.message) : (e || fin || new Error('Transazione annullata'))); }; });
        fatto.catch(function () {});
        var t = {
          get: function (s, k) { return req(tr.objectStore(s).get(k)); }, put: function (s, v) { return req(tr.objectStore(s).put(v)); },
          del: function (s, k) { return req(tr.objectStore(s).delete(k)); }, all: function (s) { return req(tr.objectStore(s).getAll()); },
          byIndex: function (s, i, v) { return req(tr.objectStore(s).index(i).getAll(v)); }, count: function (s) { return req(tr.objectStore(s).count()); }
        };
        var r;
        try { r = await fn(t); } catch (e) { fin = e; try { tr.abort(); } catch (e2) {} try { await fatto; } catch (e3) { if (e3 && e3.code === 'SPAZIO') throw e3; } throw e; }
        await fatto; return r;
      },
      chiudi: async function () { if (dbP) { (await dbP).close(); dbP = null; } },
      elimina: async function () { if (dbP) { (await dbP).close(); dbP = null; } await new Promise(function (res, rej) { var r = IDB.deleteDatabase(nome); r.onsuccess = function () { res(); };
        r.onerror = function () { rej(r.error || new Error('eliminazione non riuscita')); };
        r.onblocked = function () { rej(new Error('Archivio ancora aperto: chiudi le altre schede e riprova.')); }; }); }
    };
  }
  return { memoria: memoria, indexedDB: indexedDB_, STORES: STORES, DB_VERSION: DB_VERSION, VERSIONE: 'cnap-db-allenamento-1' };
});
