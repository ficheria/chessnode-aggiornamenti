/* Chess Node · Analisi profonda · FASE 6 · CNApDbV2 — UN solo database «chessnodeplay-analisi», versione 2.
   Codice originale Chess Node (09/11/2026). Decisione di Kiko (09/11): il database dell'allenamento (chessnodeplay-allenamento, fase 4)
   confluisce in quello dell'analisi come versione 2. L'aggiornamento 1 → 2 AGGIUNGE soltanto gli store di allenamento
   (exercises, placements, attempts, sessions, plans): nessuna migrazione dei dati delle partite. «meta» è già presente ed è condiviso
   (chiavi diverse: impostazioni, cursore:…, statoAnalisi:…, avversario:…, seqTentativi).
   Stesso contratto di CNApBackend / CNApDbAll: tx(stores, mode, fn) atomica con t.get/put/del/all/byIndex/count, quindi i moduli
   delle fasi 1–5 funzionano senza modifiche. Il trasferimento dei dati dal vecchio DB porta anche meta.seqTentativi con un valore
   ≥ al più alto «ordine» già salvato (altrimenti i numeri d'ordine ripartirebbero da 1 e lo storico tornerebbe ambiguo). */
(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api; else root.CNApDbV2 = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  var DB_VERSION = 2, NOME = 'chessnodeplay-analisi', VECCHIO_ALLENAMENTO = 'chessnodeplay-allenamento';
  /* fase 1 (versione 1) — identici a CNApBackend.STORES */
  var STORES_V1 = {
    games:            { key: 'gameId', idx: { playedAtMs: 'playedAtMs', monthRome: 'monthRome', scope: ['scopeRefs', true], archiveState: 'archiveState', contentKey: 'contentKey' } },
    gameSources:      { key: 'sourceRevKey', idx: { gameId: 'gameId', sourceKey: 'sourceKey' } },
    nodes:            { key: 'nodeId', idx: { gameId: 'gameId' } },
    analyses:         { key: 'analysisId', idx: { gameId: 'gameId', status: 'status' } },
    analysisJobs:     { key: 'jobId', idx: { status: 'status', gameId: 'gameId' } },
    profileSnapshots: { key: 'snapshotId', idx: { subjectId: 'subjectId' } },
    exerciseRefs:     { key: 'refId', idx: { gameId: 'gameId' } },
    diagnostics:      { key: 'diagId', idx: { batchId: 'batchId' } },
    mergeLog:         { key: 'mergeId', idx: { keptGameId: 'keptGameId' } },
    legacy:           { key: 'key', idx: {} },
    cache:            { key: 'key', idx: { cleanupClass: 'cleanupClass' } },
    meta:             { key: 'key', idx: {} }
  };
  /* fase 4 — store aggiunti dalla versione 2 (identici a CNApDbAll.STORES tranne meta, che è già in v1) */
  var STORES_ALLENAMENTO = {
    exercises:  { key: 'exerciseId', idx: { status: 'validationStatus', gameId: 'sourceGameId', posKey: 'posKey' } },
    placements: { key: 'placementId', idx: { exerciseId: 'exerciseId', kind: 'kind', chapterId: 'chapterId' } },
    attempts:   { key: 'attemptId', idx: { exerciseId: 'exerciseId', sessionId: 'sessionId' } },
    sessions:   { key: 'sessionId', idx: { kind: 'kind' } },
    plans:      { key: 'planId', idx: { weekId: 'weekId' } }
  };
  var STORES = {}; Object.keys(STORES_V1).forEach(function (k) { STORES[k] = STORES_V1[k]; }); Object.keys(STORES_ALLENAMENTO).forEach(function (k) { STORES[k] = STORES_ALLENAMENTO[k]; });

  function erroreSpazio(c) { var e = new Error('Spazio di archiviazione esaurito: nessuna modifica salvata.'); e.code = 'SPAZIO'; e.causa = c; return e; }
  function clone(v) { return v === undefined ? undefined : JSON.parse(JSON.stringify(v)); }
  function leggi(o, p) { return o == null ? undefined : o[p]; }

  /* ---------- memoria (prove e anteprima): può partire dal contenuto di un DB versione 1 (dump), come un aggiornamento ---------- */
  function memoria(o) {
    o = o || {};
    var dati = {}; Object.keys(STORES).forEach(function (s) { dati[s] = new Map(); });
    if (o.daVersione1) Object.keys(o.daVersione1).forEach(function (s) { if (!STORES_V1[s]) return; (o.daVersione1[s] || []).forEach(function (v) { dati[s].set(v[STORES[s].key], clone(v)); }); });
    var quota = o.quotaByte || Infinity, guasto = null;
    return {
      tipo: 'memoria', versione: DB_VERSION,
      tx: async function (stores, mode, fn) {
        var mod = {};
        function vista(s) { var m = new Map(dati[s]); if (mod[s]) mod[s].forEach(function (v, k) { if (v === null) m.delete(k); else m.set(k, v); }); return m; }
        function chk(s) { if (!STORES[s]) throw new Error('Store sconosciuto «' + s + '»'); if (stores.indexOf(s) < 0) throw new Error('Store «' + s + '» non incluso nella transazione'); }
        function rw() { if (mode !== 'readwrite') throw new Error('Transazione in sola lettura'); }
        var t = {
          get: async function (s, k) { chk(s); return clone(vista(s).get(k)); },
          put: async function (s, v) { chk(s); rw(); var k = leggi(v, STORES[s].key); if (k == null) throw new Error('Chiave mancante per ' + s); (mod[s] = mod[s] || new Map()).set(k, clone(v)); },
          del: async function (s, k) { chk(s); rw(); (mod[s] = mod[s] || new Map()).set(k, null); },
          all: async function (s) { chk(s); return Array.from(vista(s).values()).map(clone); },
          byIndex: async function (s, i, val) { chk(s); var d = STORES[s].idx[i], p = Array.isArray(d) ? d[0] : d, multi = Array.isArray(d) && d[1];
            return Array.from(vista(s).values()).filter(function (v) { var x = leggi(v, p); return multi && Array.isArray(x) ? x.indexOf(val) >= 0 : x === val; }).map(clone); },
          count: async function (s) { chk(s); return vista(s).size; }
        };
        var r = await fn(t);
        if (mode === 'readwrite') {
          if (guasto) { var g = guasto; guasto = null; throw g; }
          if (quota !== Infinity) { var n = 0; Object.keys(STORES).forEach(function (s) { vista(s).forEach(function (v) { n += JSON.stringify(v).length * 2; }); }); if (n > quota) throw erroreSpazio('quota simulata superata'); }
          Object.keys(mod).forEach(function (s) { mod[s].forEach(function (v, k) { if (v === null) dati[s].delete(k); else dati[s].set(k, v); }); });
        }
        return r;
      },
      _guastoAlProssimoCommit: function (e) { guasto = e || erroreSpazio('guasto simulato'); },
      _impostaQuota: function (q) { quota = q; },
      _dump: function () { var x = {}; Object.keys(dati).forEach(function (s) { x[s] = Array.from(dati[s].values()).map(clone); }); return x; },
      chiudi: async function () {}
    };
  }

  /* ---------- IndexedDB: aggiornamento 1 → 2 che AGGIUNGE gli store mancanti e non tocca quelli esistenti ---------- */
  function indexedDB_(o) {
    o = o || {};
    var IDB = o.indexedDB || (typeof indexedDB !== 'undefined' ? indexedDB : null);
    if (!IDB) throw new Error('IndexedDB non disponibile in questo ambiente');
    var nome = o.nome || NOME, dbP = null, info = { daVersione: null, storeAggiunti: [] }, stato = 'chiuso', ultimoErrore = null;
    /* rev. 2: un'apertura fallita NON resta in memoria come promessa rifiutata per sempre (si può riprovare) e non viene mai
       sostituita da un archivio in memoria: chi chiama riceve l'errore con un codice chiaro. Se un'altra scheda chiede di
       aggiornare il database, questa connessione si chiude da sola (niente blocchi invisibili). */
    var sospesa = null;   // richiesta di apertura bloccata ancora pendente: un'altra richiesta resterebbe in coda dietro di lei per sempre
    function apri() {
      if (dbP) return dbP;
      if (sospesa) return Promise.reject(sospesa);
      stato = 'in apertura';
      var p = dbP = new Promise(function (res, rej) {
        var rq = IDB.open(nome, DB_VERSION), rinunciato = false;
        rq.onupgradeneeded = function (ev) {
          var db = rq.result; info.daVersione = ev.oldVersion;
          Object.keys(STORES).forEach(function (s) {
            if (db.objectStoreNames.contains(s)) return;   // gli store esistenti (partite, analisi, meta…) restano come sono
            var os = db.createObjectStore(s, { keyPath: STORES[s].key });
            Object.keys(STORES[s].idx).forEach(function (i) { var d = STORES[s].idx[i]; os.createIndex(i, Array.isArray(d) ? d[0] : d, { multiEntry: Array.isArray(d) && !!d[1] }); });
            info.storeAggiunti.push(s);
          });
        };
        rq.onsuccess = function () {
          var db = rq.result;
          if (rinunciato) { db.close(); sospesa = null; return; }   // l'apertura era già stata dichiarata fallita (blocco): non si tiene una connessione nascosta
          db.onversionchange = function () { db.close(); dbP = null; stato = 'chiuso: aggiornamento da un\'altra scheda'; };
          stato = 'aperto'; res(db);
        };
        rq.onerror = function () { if (rinunciato) { sospesa = null; return; } var e = new Error('Apertura dell\'archivio non riuscita: ' + (rq.error && rq.error.message || 'errore sconosciuto') + '.'); e.code = 'APERTURA'; e.causa = rq.error; rej(e); };
        rq.onblocked = function () { rinunciato = true; var e = new Error('L\'archivio è tenuto aperto da un\'altra scheda o finestra di Chess Node con una versione precedente: chiudila e riprova.'); e.code = 'BLOCCATO'; sospesa = e; rej(e); };
      });
      p.catch(function (e) { if (dbP === p) dbP = null; stato = 'errore'; ultimoErrore = e; });
      return p;
    }
    function req(r) { return new Promise(function (res, rej) { r.onsuccess = function () { res(r.result); }; r.onerror = function (e) { e.preventDefault(); rej(r.error); }; }); }
    return {
      tipo: 'indexeddb', nome: nome, versione: DB_VERSION, aggiornamento: function () { return info; },
      stato: function () { return { stato: stato, errore: ultimoErrore ? { codice: ultimoErrore.code, messaggio: ultimoErrore.message } : null }; },
      prova: async function () { await apri(); return true; },
      tx: async function (stores, mode, fn) {
        var db = await apri(), tr = db.transaction(stores, mode), fin;
        var fatto = new Promise(function (res, rej) { tr.oncomplete = function () { res(); }; tr.onabort = function () { var e = tr.error; rej(e && e.name === 'QuotaExceededError' ? erroreSpazio(e.message) : (e || fin || new Error('Transazione annullata'))); }; });
        fatto.catch(function () {});
        var t = {
          get: function (s, k) { return req(tr.objectStore(s).get(k)); }, put: function (s, v) { return req(tr.objectStore(s).put(v)); },
          del: function (s, k) { return req(tr.objectStore(s).delete(k)); }, all: function (s) { return req(tr.objectStore(s).getAll()); },
          byIndex: function (s, i, v) { return req(tr.objectStore(s).index(i).getAll(v)); }, count: function (s) { return req(tr.objectStore(s).count()); }
        };
        var r;
        try { r = await fn(t); } catch (e) { fin = e; try { tr.abort(); } catch (e2) {} try { await fatto; } catch (e3) { if (e3 && e3.code === 'SPAZIO') throw e3; } throw e; }
        await fatto; return r;
      },
      storeEsistenti: async function () { var db = await apri(); return Array.prototype.slice.call(db.objectStoreNames); },
      chiudi: async function () { if (dbP) { (await dbP).close(); dbP = null; } },
      elimina: async function () { if (dbP) { (await dbP).close(); dbP = null; } await new Promise(function (res) { var r = IDB.deleteDatabase(nome); r.onsuccess = res; r.onerror = res; r.onblocked = res; }); }
    };
  }

  /* ---------- trasferimento dal vecchio DB dell'allenamento (fase 4) al DB unico ----------
     da, a = backend con tx(). Idempotente: un record già presente nel DB unico NON viene sovrascritto (potrebbe essere più nuovo).
     meta.seqTentativi = max(seq vecchio, seq nuovo, ordine più alto tra tutti i tentativi) — mai un valore più basso. */
  async function trasferisciAllenamento(da, a, o) {
    o = o || {};
    var NOMI = Object.keys(STORES_ALLENAMENTO), sorg = {}, rep = { copiati: {}, giaPresenti: {}, seqVecchio: 0, seqPrima: 0, ordineMassimo: 0, seqDopo: 0 };
    await da.tx(NOMI.concat(['meta']), 'readonly', async function (t) {
      for (var i = 0; i < NOMI.length; i++) sorg[NOMI[i]] = await t.all(NOMI[i]);
      var m = await t.get('meta', 'seqTentativi'); rep.seqVecchio = m ? (m.valore || 0) : 0;
    });
    await a.tx(NOMI.concat(['meta']), 'readwrite', async function (t) {
      for (var i = 0; i < NOMI.length; i++) {
        var s = NOMI[i], k = STORES[s].key; rep.copiati[s] = 0; rep.giaPresenti[s] = 0;
        for (var j = 0; j < sorg[s].length; j++) { var v = sorg[s][j]; if (await t.get(s, v[k])) { rep.giaPresenti[s]++; continue; } await t.put(s, v); rep.copiati[s]++; }
      }
      var tutti = await t.all('attempts');
      rep.ordineMassimo = tutti.reduce(function (m, x) { return Math.max(m, x.ordine || 0); }, 0);
      var m2 = await t.get('meta', 'seqTentativi'); rep.seqPrima = m2 ? (m2.valore || 0) : 0;
      rep.seqDopo = Math.max(rep.seqVecchio, rep.seqPrima, rep.ordineMassimo);
      await t.put('meta', { key: 'seqTentativi', valore: rep.seqDopo, aggiornato: o.ora || Date.now(), origine: 'trasferimento fase 6' });
      await t.put('meta', { key: 'migrazione:allenamento-v2', valore: { quando: o.ora || Date.now(), copiati: rep.copiati, giaPresenti: rep.giaPresenti, seq: rep.seqDopo } });
    });
    // verifica: ogni record del vecchio DB è nel nuovo (stessa chiave)
    rep.verificato = await a.tx(NOMI, 'readonly', async function (t) {
      for (var i = 0; i < NOMI.length; i++) { var s = NOMI[i]; for (var j = 0; j < sorg[s].length; j++) if (!(await t.get(s, sorg[s][j][STORES[s].key]))) return false; }
      return true;
    });
    return rep;
  }

  /* copia di sicurezza in SOLA LETTURA (rev. 2): dopo il trasferimento nessun codice apre il vecchio database in scrittura */
  function soloLettura(b) {
    return { tipo: (b.tipo || '?') + '-sola-lettura', soloLettura: true,
      tx: function (stores, mode, fn) { if (mode !== 'readonly') { var e = new Error('Copia di sicurezza del vecchio archivio: sola lettura.'); e.code = 'SOLA_LETTURA'; return Promise.reject(e); } return b.tx(stores, 'readonly', fn); },
      chiudi: function () { return b.chiudi ? b.chiudi() : Promise.resolve(); } };
  }
  return { memoria: memoria, indexedDB: indexedDB_, trasferisciAllenamento: trasferisciAllenamento, soloLettura: soloLettura, STORES: STORES, STORES_V1: STORES_V1, STORES_ALLENAMENTO: STORES_ALLENAMENTO,
    DB_VERSION: DB_VERSION, NOME: NOME, VECCHIO_ALLENAMENTO: VECCHIO_ALLENAMENTO, VERSIONE: 'cnap-db-v2-1' };
});
