/* =====================================================================================================
   cn_varianti.js — Varianti personali nella scacchiera di analisi
   Proprietario: Kiko. Codice originale, scritto da zero. Unica dipendenza: chess.js (BSD-2), global `Chess`.
   Nessun codice GPL / AGPL / NC. Nessun motore qui dentro: il modulo avvisa l'app con onNuovaMossa(nodo)
   e l'app decide se chiamare Stockfish.

   IDEA
   Le mosse formano un ALBERO. Ogni nodo è una mossa; la radice è la posizione iniziale (nessuna mossa).
   Per ogni nodo, figli[0] è la CONTINUAZIONE principale; gli altri figli (figli[1], figli[2]…) sono VARIANTI,
   cioè alternative a figli[0] giocate dalla stessa posizione. La "linea principale della partita" è la catena
   radice → figli[0] → figli[0] → …  Una variante può avere a sua volta varianti (a qualunque profondità).

   USO RAPIDO
     var A = CNVarianti.nuovoAlbero({ onNuovaMossa: function(n){ ... }, onCambio: function(n){ ... } });
     A.daMosse(['e4','e5','Nf3']);            // carica la partita (SAN inglese, come la produce chess.js)
     A.vaiA(A.linea()[1]);                    // vado alla 2ª mossa della partita
     A.aggiungiMossa(A.corrente, {from:'d7', to:'d6'});   // nasce una variante (o si va sul ramo se esiste già)
     A.collega(document.getElementById('mosse'));          // notazione cliccabile (HTML con classi CSS)
     A.inVariante();                                       // true → mostra il banner «La tua variante»
     A.tornaAllaPartita();                                 // torna alla linea principale

   NODO: { id, san, uci, fen, num, colore, padre, figli[], giudizio, valutazione }
     san        mossa in SAN inglese (es. "Nf3", "O-O", "exd6", "e8=Q+"); null nella radice
     uci        "e2e4", "e7e8q"…; null nella radice
     fen        posizione DOPO la mossa (nella radice: posizione iniziale)
     num        numero di mossa della mossa (1, 2, 3…) — quello che si scrive davanti: "12." o "12..."
     colore     'w' o 'b': chi ha giocato la mossa
     giudizio   campo libero scelto dall'app (es. "Ottima", "Imprecisione", "Errore", "Svarione") o null
     valutazione campo libero scelto dall'app (es. +0.35, o "M3") o null
   ATTENZIONE: i nodi hanno il riferimento `padre` (circolare): per salvare usa aJSON(), non JSON.stringify(nodo).

   VERSIONE 1.1 (Chess Node, analisi profonda fase 3, 08/11/2026 — decisione Kiko 23:28):
   - CODICI FISSI: id = codice del padre + mossa (hash FNV di «idPadre>uci»), radice «r» (o opzioni.radiceId). Stessa mossa dallo
     stesso padre ⇒ stesso id a ogni caricamento: esercizi e commenti non puntano più al nodo sbagliato dopo una ricarica.
     opzioni.idDi(idPadre, uci) permette all'app di usare i codici del suo archivio.
   - caricaNodi(nodi, {radiceId, giudizi, valutazioni, corrente}): disegna un albero che ARRIVA DALL'ARCHIVIO (unica fonte),
     usando gli stessi nodeId. In questo uso CNVarianti serve solo a disegnare la lista e a navigare, non a salvare.
   - aJSON() versione 2 salva anche gli id; daJSON() legge v1 e v2. Gli id sono stringhe (data-id="...").
   - Piccole correzioni segnalate nella VERIFICA dell'8/11: accenti \u0300-\u036f; aPGN con SetUp prima di FEN e mai con la posizione iniziale standard.
   - Classe cn-o-<origine> per distinguere mosse giocate, importate e di analisi (quando il nodo ha `origine`).
   ===================================================================================================== */
(function (radiceGlobale) {
  'use strict';

  var FEN_INIZIALE = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';
  var VERSIONE_JSON = 2;

  // ---------------------------------------------------------------------------------------------
  // Utilità
  // ---------------------------------------------------------------------------------------------

  // Nuova istanza di chess.js (trova la classe sia come global sia come modulo CommonJS)
  function nuovaPartita(fen) {
    var C = (typeof Chess !== 'undefined') ? Chess : (typeof require === 'function' ? require('chess.js').Chess : null);
    if (!C) throw new Error('cn_varianti: chess.js non trovato (serve il global Chess).');
    return fen ? new C(fen) : new C();
  }

  // Prova a fare una mossa con chess.js: ritorna l'oggetto-mossa oppure null se illegale
  // (chess.js 1.x lancia un'eccezione, le versioni vecchie ritornano null: gestiamo entrambe).
  function provaMossa(g, mossa) {
    try {
      var m = g.move(mossa);
      return m || null;
    } catch (e) {
      return null;
    }
  }

  // SAN inglese → italiano: R(e) D(onna) T(orre) A(lfiere) C(avallo). Il pedone non ha lettera.
  // Le lettere maiuscole K Q R B N compaiono solo come pezzo o come promozione ("=Q"); le colonne sono minuscole.
  var TRADUZIONE = { K: 'R', Q: 'D', R: 'T', B: 'A', N: 'C' };
  function sanItaliano(san) {
    return san.replace(/[KQRBN]/g, function (c) { return TRADUZIONE[c]; });
  }

  function esc(s) {
    return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; });
  }

  // "Imprecisione" → "imprecisione": serve per creare una classe CSS (cn-g-imprecisione)
  function slug(s) {
    return String(s).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
  }

  // ---------------------------------------------------------------------------------------------
  // L'albero
  // ---------------------------------------------------------------------------------------------
  // codice fisso padre + mossa (FNV-1a 2×32 bit, sincrono)
  function fnv(s, seed) { var h = seed >>> 0; for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; } return ('00000000' + (h >>> 0).toString(16)).slice(-8); }
  function codiceFisso(idPadre, uci) { var k = String(idPadre) + '>' + uci; return 'v' + fnv(k, 0x811c9dc5) + fnv(k, 0x5bd1e995).slice(0, 4); }

  function Albero(opzioni) {
    opzioni = opzioni || {};
    this._opz = opzioni;
    this._prossimoId = 1;   // non più usato per gli id (compatibilità)
    this._perId = {};
    this._fenIniziale = opzioni.fen || FEN_INIZIALE;
    this.radice = this._creaNodo(null, null, null, this._fenIniziale, null);
    this.corrente = this.radice;
    this._contenitori = [];      // elementi HTML collegati con collega()
  }

  var P = Albero.prototype;

  // Crea un nodo e lo registra (non lo aggancia al padre: lo fa chi chiama)
  P._creaNodo = function (padre, san, uci, fen, infoMossa, idEsplicito) {
    var id = idEsplicito != null ? String(idEsplicito)
      : padre === null ? String(this._opz.radiceId || 'r')
      : (typeof this._opz.idDi === 'function' ? String(this._opz.idDi(padre.id, uci)) : codiceFisso(padre.id, uci));
    var base = id, k = 2; while (this._perId[id]) id = base + '-' + (k++);   // salvaguardia: non succede con padre+mossa distinti
    var n = {
      id: id,
      san: san,
      uci: uci,
      fen: fen,
      num: infoMossa ? infoMossa.num : null,
      colore: infoMossa ? infoMossa.colore : null,
      padre: padre,
      figli: [],
      giudizio: null,
      valutazione: null,
      origine: null
    };
    this._perId[n.id] = n;
    return n;
  };

  // Accetta un nodo, un id numerico oppure null (= nodo corrente) e ritorna il nodo
  P.nodo = function (x) {
    if (x === undefined || x === null) return this.corrente;
    if (typeof x === 'object') return x;
    return this._perId[x] || null;
  };

  // ------------------------------- stato -------------------------------------------------------

  // true se il nodo sta sulla linea principale (catena di figli[0] dalla radice)
  P.eInPrincipale = function (nodo) {
    var n = this.nodo(nodo);
    if (!n) return false;
    while (n.padre) {
      if (n.padre.figli[0] !== n) return false;
      n = n.padre;
    }
    return true;
  };

  // true se la posizione attuale è dentro una variante (per mostrare il banner «La tua variante»)
  P.inVariante = function () { return !this.eInPrincipale(this.corrente); };

  // Lista dei nodi della linea principale (senza la radice)
  P.linea = function () {
    var out = [], n = this.radice;
    while (n.figli.length) { n = n.figli[0]; out.push(n); }
    return out;
  };

  // FEN della posizione attuale (da passare alla scacchiera)
  P.fenCorrente = function () { return this.corrente.fen; };

  // Come i dati del nodo: numero di mossa e colore della mossa che SEGUE un nodo (serve per il nodo successivo)
  function infoDa(fenPrima) {
    var campi = fenPrima.split(' ');
    return { num: parseInt(campi[5], 10) || 1, colore: campi[1] === 'b' ? 'b' : 'w' };
  }

  // Questa mossa richiede la scelta del pezzo di promozione? (per mostrare il selettore prima di aggiungerla)
  P.richiedePromozione = function (nodo, da, a) {
    var n = this.nodo(nodo); if (!n) return false;
    var g = nuovaPartita(n.fen);
    var pz = g.get(da);
    if (!pz || pz.type !== 'p') return false;
    var riga = a.charAt(1);
    if (!((pz.color === 'w' && riga === '8') || (pz.color === 'b' && riga === '1'))) return false;
    // vero solo se la mossa è legale con almeno una promozione
    return !!provaMossa(g, { from: da, to: a, promotion: 'q' });
  };

  // ------------------------------- aggiungere mosse --------------------------------------------

  /* aggiungiMossa(nodo, mossa)
     - nodo: nodo (o id, o null = nodo corrente) da cui si gioca
     - mossa: SAN ("Nf3", "O-O", "e8=Q") oppure {from:'e7', to:'e8', promotion:'q'}
     Ritorna il nodo della mossa (nuovo o già esistente) oppure null se la mossa è illegale.
     - Se la stessa mossa esiste già tra i figli, NON si duplica: si va su quel ramo.
     - Se il nodo non ha figli la mossa prosegue la linea (figli[0]); altrimenti nasce una variante.
     - Controlla con chess.js: arrocco, en passant e promozione compresi. Promozione senza pezzo scelto → null
       (usa richiedePromozione() per chiedere il pezzo all'utente).
     - Alla fine il nodo corrente diventa quello della mossa. Per una mossa NUOVA parte onNuovaMossa(nodo). */
  P.aggiungiMossa = function (nodo, mossa) {
    var padre = this.nodo(nodo);
    if (!padre) return null;
    var g = nuovaPartita(padre.fen);
    var info = infoDa(padre.fen);
    var m = provaMossa(g, mossa);
    if (!m) return null;
    var uci = m.from + m.to + (m.promotion || '');

    // già esistente? allora si va su quel ramo
    for (var i = 0; i < padre.figli.length; i++) {
      if (padre.figli[i].uci === uci) {
        this._vai(padre.figli[i]);
        return padre.figli[i];
      }
    }
    var nuovo = this._creaNodo(padre, m.san, uci, g.fen(), info);
    padre.figli.push(nuovo);
    this._vai(nuovo);
    if (typeof this._opz.onNuovaMossa === 'function') this._opz.onNuovaMossa(nuovo);
    return nuovo;
  };

  /* daMosse(lista, fen) — azzera l'albero e carica una partita come linea principale.
     lista: array di SAN o di UCI/oggetti-mossa. Si ferma alla prima mossa illegale. Ritorna quante mosse sono entrate.
     Non chiama onNuovaMossa (le mosse della partita non sono "mosse dell'utente"). */
  P.daMosse = function (lista, fen) {
    var cb = this._opz.onNuovaMossa;
    this._opz.onNuovaMossa = null;
    this._azzera(fen);
    var n = this.radice, entrate = 0;
    for (var i = 0; i < lista.length; i++) {
      var mossa = lista[i];
      // formato UCI "e2e4" / "e7e8q" → oggetto
      if (typeof mossa === 'string' && /^[a-h][1-8][a-h][1-8][qrbn]?$/.test(mossa)) {
        mossa = { from: mossa.slice(0, 2), to: mossa.slice(2, 4), promotion: mossa.charAt(4) || undefined };
      }
      var nuovo = this.aggiungiMossa(n, mossa);
      if (!nuovo) break;
      n = nuovo; entrate++;
    }
    this._opz.onNuovaMossa = cb;
    this._vai(this.radice);
    return entrate;
  };

  /* daPGN(testo) — carica la linea principale di un PGN semplice (usa chess.js). Le varianti dentro il PGN
     importato non vengono lette: le varianti personali si ricreano o si caricano con daJSON(). */
  P.daPGN = function (testo) {
    var g = nuovaPartita();
    try {
      if (typeof g.loadPgn === 'function') g.loadPgn(testo); else g.load_pgn(testo);
    } catch (e) { return -1; }
    var h = (typeof g.header === 'function') ? g.header() : {};
    var fen = (h && h.FEN) ? h.FEN : null;
    return this.daMosse(g.history(), fen);
  };

  P._azzera = function (fen) {
    this._prossimoId = 1; this._perId = {};
    this._fenIniziale = fen || FEN_INIZIALE;
    this.radice = this._creaNodo(null, null, null, this._fenIniziale, null);
    this.corrente = this.radice;
  };

  // ------------------------------- navigazione -------------------------------------------------

  // Sposta il nodo corrente e avvisa l'app (onCambio) se è cambiato davvero
  P._vai = function (n) {
    var cambiato = (n !== this.corrente);
    this.corrente = n;
    this._ridisegna();
    if (cambiato && typeof this._opz.onCambio === 'function') this._opz.onCambio(n);
  };

  // Vai al nodo indicato (nodo o id). Ritorna il nodo, o null se non esiste.
  P.vaiA = function (x) {
    var n = this.nodo(x);
    if (!n || this._perId[n.id] !== n) return null;
    this._vai(n);
    return n;
  };

  // Mossa avanti lungo la continuazione principale del ramo in cui si è (figli[0]). Null se non c'è.
  P.avanti = function () {
    var n = this.corrente;
    if (!n.figli.length) return null;
    this._vai(n.figli[0]);
    return n.figli[0];
  };

  // Mossa indietro. Dall'inizio non si va oltre (ritorna null).
  P.indietro = function () {
    var n = this.corrente;
    if (!n.padre) return null;
    this._vai(n.padre);
    return n.padre;
  };

  /* inizioVariante() — porta alla PRIMA mossa della variante in cui ci si trova.
     Se si è sulla linea principale non c'è nessuna variante: ritorna null e non si muove nulla. */
  P.inizioVariante = function () {
    var n = this.corrente;
    if (this.eInPrincipale(n)) return null;
    // si sale finché il nodo è la continuazione (figli[0]) del suo padre: il primo che NON lo è apre la variante
    while (n.padre && n.padre.figli[0] === n) n = n.padre;
    this._vai(n);
    return n;
  };

  /* tornaAllaPartita() — esce dalla variante e ritorna sulla linea principale, nella posizione da cui
     la variante era partita (anche se si era dentro varianti annidate). Se si è già sulla linea principale
     non cambia nulla. Ritorna il nodo raggiunto. */
  P.tornaAllaPartita = function () {
    var n = this.corrente;
    while (n.padre && !this.eInPrincipale(n)) n = n.padre;
    this._vai(n);
    return n;
  };

  P.inizio = function () { this._vai(this.radice); return this.radice; };
  P.fine = function () {   // fine del ramo corrente (segue sempre figli[0])
    var n = this.corrente;
    while (n.figli.length) n = n.figli[0];
    this._vai(n); return n;
  };

  /* eliminaVariante(nodo) — toglie la mossa indicata e tutto ciò che la segue (con le sue sotto-varianti).
     Passando la prima mossa di una variante si cancella tutta la variante. La linea principale della partita
     NON si può cancellare (ritorna false). Se la posizione attuale era dentro la parte cancellata, si torna
     alla mossa precedente. Ritorna true se ha cancellato. */
  P.eliminaVariante = function (x) {
    var n = this.nodo(x);
    if (!n || !n.padre || this._perId[n.id] !== n) return false;
    if (this.eInPrincipale(n)) return false;
    var self = this, stavoDentro = false;
    (function togli(k) {            // cancella k e i discendenti dall'indice dei nodi
      if (k === self.corrente) stavoDentro = true;
      delete self._perId[k.id];
      for (var i = 0; i < k.figli.length; i++) togli(k.figli[i]);
    })(n);
    n.padre.figli.splice(n.padre.figli.indexOf(n), 1);
    if (stavoDentro) this.corrente = n.padre;
    this._ridisegna();
    if (stavoDentro && typeof this._opz.onCambio === 'function') this._opz.onCambio(this.corrente);
    return true;
  };

  // Scorciatoia per l'app: salva giudizio e valutazione del motore su un nodo
  P.impostaGiudizio = function (x, giudizio, valutazione) {
    var n = this.nodo(x); if (!n) return;
    n.giudizio = (giudizio === undefined) ? null : giudizio;
    n.valutazione = (valutazione === undefined) ? null : valutazione;
    this._ridisegna();
  };

  // ---------------------------------------------------------------------------------------------
  // NOTAZIONE HTML (italiana, varianti rientrate tra parentesi)
  // ---------------------------------------------------------------------------------------------
  /* html() produce, per esempio:
       <div class="cn-notazione">
         <div class="cn-linea cn-liv0">
           <span class="cn-num">1.</span> <span class="cn-mossa" data-id="1">e4</span> <span class="cn-mossa" data-id="2">e5</span> …
         </div>
         <div class="cn-var cn-liv1">
           <div class="cn-linea"><span class="cn-par">(</span><span class="cn-num">2...</span> <span class="cn-mossa" data-id="9">d6</span> … <span class="cn-par">)</span></div>
         </div>
         <div class="cn-linea cn-liv0 cn-continua"> … il resto della linea … </div>
       </div>
     Classi: cn-notazione, cn-linea, cn-liv0/1/2… (profondità), cn-var (blocco variante), cn-continua (la linea riprende
     dopo una variante), cn-num, cn-mossa, cn-attuale (mossa corrente), cn-principale (mossa della partita),
     cn-g-<giudizio> (es. cn-g-errore), cn-par (parentesi). Ogni mossa ha data-id = id del nodo. Nessuno stile inline.
     Una variante sta SOTTO la mossa che sostituisce (come nel PGN: "1. e4 (1. d4) e5"). */
  P.html = function (opzioni) {
    var self = this, attuale = this.corrente;

    function spanMossa(n, conNumero) {
      var num = '';
      if (conNumero) num = '<span class="cn-num">' + n.num + (n.colore === 'w' ? '.' : '...') + '</span> ';
      var cls = 'cn-mossa' + (self.eInPrincipale(n) ? ' cn-principale' : '') + (n === attuale ? ' cn-attuale' : '') +
        (n.giudizio ? ' cn-g-' + slug(n.giudizio) : '') + (n.origine ? ' cn-o-' + slug(n.origine) : '');
      return num + '<span class="' + cls + '" data-id="' + esc(n.id) + '">' + esc(sanItaliano(n.san)) + '</span>';
    }

    /* Scrive la linea che inizia con il nodo `inizio` e prosegue con figli[0].
       livello: profondità (0 = partita). apri/chiudi: aggiunge "(" all'inizio e ")" alla fine (varianti).
       Ritorna l'HTML (sequenza di <div class="cn-linea"> e <div class="cn-var">). */
    function linea(inizio, livello, apri, chiudi) {
      var out = '', run = [], n = inizio, forzaNumero = true, primaRiga = true;

      function chiudiRun(ultimo) {
        var testo = run.join(' ');
        if (primaRiga && apri) testo = '<span class="cn-par">(</span>' + testo;
        if (ultimo && chiudi) testo += '<span class="cn-par">)</span>';
        var cls = 'cn-linea cn-liv' + livello + (primaRiga ? '' : ' cn-continua');
        out += '<div class="' + cls + '">' + testo + '</div>';
        run = []; primaRiga = false;
      }

      while (n) {
        run.push(spanMossa(n, n.colore === 'w' || forzaNumero));
        forzaNumero = false;
        // varianti = fratelli successivi di n (alternative a n, nate dallo stesso padre) — solo se n è figli[0]
        var padre = n.padre, varianti = (padre && padre.figli[0] === n) ? padre.figli.slice(1) : [];
        if (varianti.length) {
          chiudiRun(false);
          for (var i = 0; i < varianti.length; i++) {
            out += '<div class="cn-var cn-liv' + (livello + 1) + '">' + linea(varianti[i], livello + 1, true, true) + '</div>';
          }
          forzaNumero = true;       // dopo una variante, anche una mossa del Nero riporta il numero ("12...")
        }
        n = n.figli.length ? n.figli[0] : null;
      }
      if (run.length || !out) chiudiRun(true);
      else if (chiudi) out += '<div class="cn-linea cn-liv' + livello + ' cn-continua"><span class="cn-par">)</span></div>';
      return out;
    }

    var corpo = this.radice.figli.length ? linea(this.radice.figli[0], 0, false, false) : '';
    // varianti alternative alla PRIMA mossa della partita (figli[1…] della radice)
    // (già gestite dentro linea(): il primo nodo ha padre = radice)
    return '<div class="cn-notazione">' + corpo + '</div>';
  };

  /* collega(elemento) — disegna la notazione dentro `elemento` e la tiene aggiornata a ogni cambiamento.
     Un click su una mossa chiama vaiA(id). Si possono collegare più elementi. Ritorna se stesso. */
  P.collega = function (el) {
    var self = this;
    this._contenitori.push(el);
    el.addEventListener('click', function (ev) {
      var t = ev.target;
      while (t && t !== el && !(t.getAttribute && t.getAttribute('data-id') !== null && /\bcn-mossa\b/.test(t.className))) t = t.parentNode;
      if (t && t !== el) self.vaiA(t.getAttribute('data-id'));
    });
    el.innerHTML = this.html();
    return this;
  };
  P._ridisegna = function () {
    if (!this._contenitori.length) return;
    var h = this.html();
    this._contenitori.forEach(function (el) { el.innerHTML = h; });
  };

  // ---------------------------------------------------------------------------------------------
  // SALVATAGGIO (JSON per localStorage) e PGN
  // ---------------------------------------------------------------------------------------------

  /* aJSON() → stringa. Salva l'albero come struttura annidata (senza FEN: si ricalcolano al caricamento, così
     un file danneggiato non può creare posizioni impossibili). Ricorda anche la posizione attuale. */
  P.aJSON = function () {
    var self = this, percorso = [];
    // percorso del nodo corrente: indici dei figli dalla radice (resta valido anche se gli id cambiano)
    (function () {
      var n = self.corrente, rev = [];
      while (n.padre) { rev.push(n.padre.figli.indexOf(n)); n = n.padre; }
      percorso = rev.reverse();
    })();
    function conv(n) {
      var o = { m: n.san, id: n.id };
      if (n.giudizio !== null && n.giudizio !== undefined) o.g = n.giudizio;
      if (n.valutazione !== null && n.valutazione !== undefined) o.v = n.valutazione;
      if (n.figli.length) o.f = n.figli.map(conv);
      return o;
    }
    return JSON.stringify({
      versione: VERSIONE_JSON,
      fen: this._fenIniziale,
      radiceId: this.radice.id,
      posizione: percorso,
      posizioneId: this.corrente.id,
      figli: this.radice.figli.map(conv)
    });
  };

  /* daJSON(testo) — ricostruisce l'albero (metodo di istanza). Ritorna true/false.
     In caso di errore l'albero non viene toccato. Ogni mossa viene riverificata con chess.js. */
  P.daJSON = function (testo) {
    var d;
    try { d = JSON.parse(testo); } catch (e) { return false; }
    if (!d || (d.versione !== 1 && d.versione !== 2) || !Array.isArray(d.figli)) return false;
    var nuovo = new Albero({ fen: d.fen || FEN_INIZIALE, radiceId: d.radiceId || this._opz.radiceId, idDi: this._opz.idDi });
    var diversi = 0;
    var ok = true;
    function carica(padre, lista) {
      for (var i = 0; i < lista.length && ok; i++) {
        var j = lista[i];
        var g = nuovaPartita(padre.fen), info = infoDa(padre.fen), m = provaMossa(g, j.m);
        if (!m) { ok = false; return; }
        var n = nuovo._creaNodo(padre, m.san, m.from + m.to + (m.promotion || ''), g.fen(), info);
        if (j.id != null && j.id !== n.id) diversi++;   // con i codici fissi non succede: lo si conta per diagnosi
        n.giudizio = (j.g === undefined) ? null : j.g;
        n.valutazione = (j.v === undefined) ? null : j.v;
        padre.figli.push(n);
        if (j.f) carica(n, j.f);
      }
    }
    try { carica(nuovo.radice, d.figli); } catch (e) { ok = false; }
    if (!ok) return false;
    // sostituisco i dati dell'albero attuale con quelli ricostruiti (i contenitori HTML collegati restano)
    this._prossimoId = nuovo._prossimoId; this._perId = nuovo._perId;
    this._fenIniziale = nuovo._fenIniziale; this.radice = nuovo.radice;
    var n = this.radice, p = d.posizione || [];
    if (d.posizioneId && this._perId[d.posizioneId]) n = this._perId[d.posizioneId];
    else for (var k = 0; k < p.length; k++) { if (!n.figli[p[k]]) break; n = n.figli[p[k]]; }
    this.corrente = n; this.idDiversiAlCaricamento = diversi;
    this._ridisegna();
    if (typeof this._opz.onCambio === 'function') this._opz.onCambio(this.corrente);
    return true;
  };

  /* caricaNodi(nodi, opzioni) — l'albero arriva dall'ARCHIVIO (unica fonte). nodi = [{nodeId, parentId, childIds[], san, uci, fen,
     origin?}] con UNA radice (parentId null). Gli id dell'albero sono i nodeId dell'archivio. Nessuna mossa viene ricalcolata
     o salvata qui: serve a disegnare la lista e a navigare. opzioni: {giudizi:{nodeId: etichetta}, valutazioni:{nodeId: testo},
     corrente: nodeId}. Ritorna il numero di nodi caricati; -1 se l'elenco è incoerente (albero non toccato). */
  P.caricaNodi = function (nodi, opzioni) {
    opzioni = opzioni || {};
    var per = {}, radice = null, i;
    for (i = 0; i < nodi.length; i++) { per[nodi[i].nodeId] = nodi[i]; if (!nodi[i].parentId) { if (radice) return -1; radice = nodi[i]; } }
    if (!radice) return -1;
    var perId = {}, conta = 0, ok = true, vecchiOpz = this._opz;
    var tmp = new Albero({ fen: radice.fen, radiceId: radice.nodeId });
    tmp.radice.origine = radice.origin || null;
    (function scendi(a, nd) {
      var figli = nd.childIds || [];
      for (var j = 0; j < figli.length && ok; j++) {
        var c = per[figli[j]]; if (!c) continue;        // figlio non fornito (es. ramo non salvato): si salta
        if (c.parentId !== nd.nodeId) { ok = false; return; }
        var info = infoDa(a.fen), n = tmp._creaNodo(a, c.san, c.uci, c.fen, info, c.nodeId);
        n.origine = c.origin || null;
        if (opzioni.giudizi && opzioni.giudizi[c.nodeId]) n.giudizio = opzioni.giudizi[c.nodeId];
        if (opzioni.valutazioni && opzioni.valutazioni[c.nodeId] != null) n.valutazione = opzioni.valutazioni[c.nodeId];
        a.figli.push(n); conta++;
        scendi(n, c);
      }
    })(tmp.radice, radice);
    if (!ok) return -1;
    this._perId = tmp._perId; this.radice = tmp.radice; this._fenIniziale = tmp._fenIniziale; this._opz = vecchiOpz;
    this.corrente = (opzioni.corrente && this._perId[opzioni.corrente]) || this.radice;
    this._ridisegna();
    return conta;
  };

  /* aPGN(intestazioni) → stringa PGN con le varianti tra parentesi (SAN inglese, standard).
     intestazioni: oggetto opzionale {Event:'…', White:'…', Black:'…', Result:'1-0', …}.
     Se la partita non parte dalla posizione iniziale si aggiungono SetUp e FEN. Il risultato in fondo è Result o "*". */
  P.aPGN = function (intestazioni) {
    var h = {}, k;
    var def = { Event: 'Analisi', Site: '?', Date: '????.??.??', Round: '?', White: '?', Black: '?', Result: '*' };
    for (k in def) h[k] = def[k];
    if (intestazioni) for (k in intestazioni) h[k] = intestazioni[k];
    delete h.SetUp; delete h.FEN;   // l'albero decide: SetUp prima di FEN, e solo se la posizione iniziale non è quella standard
    if (this._fenIniziale !== FEN_INIZIALE) { h.SetUp = '1'; h.FEN = this._fenIniziale; }
    var testa = '';
    for (k in h) testa += '[' + k + ' "' + String(h[k]).replace(/\\/g, '\\\\').replace(/"/g, '\\"') + '"]\n';

    function seq(inizio) {   // testo della linea che inizia con `inizio`, seguendo figli[0]
      var parti = [], n = inizio, forza = true;
      while (n) {
        var num = (n.colore === 'w') ? n.num + '.' : (forza ? n.num + '...' : '');
        parti.push((num ? num + ' ' : '') + n.san);
        forza = false;
        var padre = n.padre;
        if (padre && padre.figli[0] === n) {
          for (var i = 1; i < padre.figli.length; i++) { parti.push('(' + seq(padre.figli[i]) + ')'); forza = true; }
        }
        n = n.figli.length ? n.figli[0] : null;
      }
      return parti.join(' ');
    }
    var corpo = this.radice.figli.length ? seq(this.radice.figli[0]) : '';
    return testa + '\n' + (corpo ? corpo + ' ' : '') + h.Result + '\n';
  };

  // ---------------------------------------------------------------------------------------------
  // Interfaccia pubblica
  // ---------------------------------------------------------------------------------------------
  var CNVarianti = {
    versione: '1.1',
    codiceFisso: codiceFisso,
    nuovoAlbero: function (opzioni) { return new Albero(opzioni); },
    // crea un albero direttamente da un JSON salvato (null se il JSON non è valido)
    daJSON: function (testo, opzioni) {
      var a = new Albero(opzioni);
      return a.daJSON(testo) ? a : null;
    },
    sanItaliano: sanItaliano
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = CNVarianti;
  radiceGlobale.CNVarianti = CNVarianti;
})(typeof window !== 'undefined' ? window : (typeof globalThis !== 'undefined' ? globalThis : this));
