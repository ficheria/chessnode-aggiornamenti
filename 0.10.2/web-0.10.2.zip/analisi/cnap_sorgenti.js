/* Chess Node · Analisi profonda · FASE 1 · CNApSorgenti — adattatori pubblici Lichess e Chess.com (A1-03, A1-C04, A1-C05).
   Codice originale Chess Node (08/11/2026); riprende l'impostazione di CNProfilo (strumenti/claude_moduli_01-11) correggendone i punti
   segnalati: niente PGN errato trasformato in lista vuota, colore controllato su entrambi i lati, precisione esterna separata,
   risultato assente ≠ patta, cursori per MESE con ripresa sovrapposta invece di un «sync = adesso» globale.
   Dipendenze: rete (CNApRete.crea), CNApUtil, CNApImport (istanza, per idChesscomDaUrl). Nessuna credenziale.
   Quantità (DECISO Q04): fino a 60 partite per mese di calendario (Europe/Rome), ultimi 12 mesi. Regola di scelta dichiarata:
   le 60 più recenti del mese tra le partite standard concluse. Il limite vale per l'acquisizione, NON per l'archivio. */
(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api; else root.CNApSorgenti = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  var POLITICA = 'acq-60-piu-recenti-mese-roma-v1';
  var LI_PERF = 'ultraBullet,bullet,blitz,rapid,classical,correspondence';   // solo scacchi standard: niente varianti
  var LI_DRAW = { stalemate: 1, draw: 1, insufficientMaterialClaim: 1 };
  var LI_SCARTA = { created: 'in corso', started: 'in corso', aborted: 'annullata', noStart: 'mai iniziata' };
  var CC_PATTA = { agreed: 1, repetition: 1, stalemate: 1, insufficient: 1, '50move': 1, timevsinsufficient: 1 };
  var CC_SCONFITTA = { checkmated: 1, timeout: 1, resigned: 1, lose: 1, abandoned: 1 };

  function crea(d) {
    var R = d.rete, U = d.CNApUtil, Imp = d.CNApImport, ora = d.ora || function () { return Date.now(); };
    if (!R || !U || !Imp) throw new Error('CNApSorgenti: servono rete, CNApUtil, CNApImport');
    var cache = d.cache || null;   // {get(k), set(k,v)} Promise — archivio mensile Chess.com (ricostruibile)
    var TTL_CORRENTE = d.ttlMeseCorrenteMs || 3600000;

    function nomeValido(sito, nome) {
      nome = String(nome || '').trim();
      var ok = sito === 'lichess' ? /^[A-Za-z0-9][A-Za-z0-9_-]{1,29}$/.test(nome) : /^[A-Za-z0-9_-]{3,25}$/.test(nome);
      if (!ok) throw U.errore('NOME_NON_VALIDO', 'Nome utente non valido per ' + (sito === 'lichess' ? 'Lichess' : 'Chess.com') + ': «' + nome + '».');
      return nome;
    }
    var enc = function (n) { return encodeURIComponent(n.toLowerCase()); };

    /* ---------------- Lichess ---------------- */
    async function profiloLichess(nome, o) {
      nome = nomeValido('lichess', nome);
      var r;
      try { r = await R.richiesta('https://lichess.org/api/user/' + enc(nome), o); }
      catch (e) { if (e.code === 'NON_TROVATO') throw U.errore('NOUSER', 'Account Lichess «' + nome + '» non trovato.'); throw e; }
      var p = r.dati;
      if (!p || typeof p !== 'object' || !p.id) throw U.errore('RISPOSTA_INATTESA', 'Profilo Lichess in formato inatteso.');
      if (p.disabled || p.tosViolation || p.closed) throw U.errore('NON_PUBBLICO', 'L\'account Lichess «' + nome + '» non è disponibile pubblicamente.');
      var perfs = {};
      ['ultraBullet', 'bullet', 'blitz', 'rapid', 'classical', 'correspondence'].forEach(function (k) { var x = p.perfs && p.perfs[k]; if (x && x.games) perfs[k === 'correspondence' ? 'daily' : k.toLowerCase()] = { rating: x.rating, partite: x.games, provvisorio: !!x.prov, fonte: 'lichess-attuale' }; });
      // PRIVACY (Kiko 08/11 20:32): del profilo si leggono SOLO id, username e rating. profile.realName, location, bio, firstName,
      // lastName, links, flag/country e simili non vengono mai copiati, salvati o mostrati (lista positiva, non lista nera).
      return { sito: 'lichess', id: String(p.id), nome: String(p.username), ritmi: perfs };
    }
    /* storico con dettaglio: serie usate + serie ricevute ma ignorate (varianti, puzzle, vuote) con il motivo */
    async function storicoRatingLichessDettaglio(nome, o) {
      nome = nomeValido('lichess', nome);
      var r = await R.richiesta('https://lichess.org/api/user/' + enc(nome) + '/rating-history', o), a = r.dati;
      if (!Array.isArray(a)) throw U.errore('RISPOSTA_INATTESA', 'Storico rating Lichess in formato inatteso.');
      var M = { UltraBullet: 'ultrabullet', Bullet: 'bullet', Blitz: 'blitz', Rapid: 'rapid', Classical: 'classical', Correspondence: 'daily' };
      var ignorate = [];
      a.forEach(function (s) {
        var n = s && Array.isArray(s.points) ? s.points.length : 0, nm = s && s.name || '?';
        if (!M[nm]) ignorate.push({ nome: nm, punti: n, motivo: nm === 'Puzzles' ? 'puzzle, non partite' : 'variante non standard' });
        else if (!n) ignorate.push({ nome: nm, punti: 0, motivo: 'nessun punto (ritmo mai giocato con rating)' });
      });
      var serie = a.filter(function (s) { return s && M[s.name] && Array.isArray(s.points) && s.points.length; }).map(function (s) {
        return {
          sito: 'lichess', ritmo: M[s.name], tipo: 'storico-servizio', provenienza: 'lichess /api/user/{nome}/rating-history',
          // [anno, mese da 0, giorno, rating]: data di CALENDARIO del servizio, nessuna reinterpretazione con il fuso del dispositivo
          punti: s.points.filter(function (q) { return Array.isArray(q) && q.length === 4; }).map(function (q) { return { data: q[0] + '-' + ('0' + (q[1] + 1)).slice(-2) + '-' + ('0' + q[2]).slice(-2), rating: q[3] }; })
        };
      });
      return { serieRicevute: a.length, serie: serie, ignorate: ignorate };
    }
    async function storicoRatingLichess(nome, o) { return (await storicoRatingLichessDettaglio(nome, o)).serie; }
    /* riga leggibile per rapporti e anteprima: mai vuota */
    function descriviStorico(d) {
      var usate = d.serie.map(function (x) { var p = x.punti, a = p[0], z = p[p.length - 1]; return x.ritmo + ': ' + p.length + ' punti, dal ' + a.data + ' (' + a.rating + ') al ' + z.data + ' (' + z.rating + ')'; });
      var ign = d.ignorate.map(function (x) { return x.nome + ' (' + x.punti + ', ' + x.motivo + ')'; });
      if (!d.serieRicevute) return 'Lichess non ha restituito nessuna serie per questo account (storico vuoto).';
      return (usate.length ? usate.join('; ') : 'Nessuna serie standard con punti') + ' · serie ricevute ' + d.serieRicevute + (ign.length ? ' · ignorate: ' + ign.join(', ') : '');
    }
    function liSorgente(g, nome) {
      var w = g.players && g.players.white || {}, b = g.players && g.players.black || {};
      var nomeDi = function (p) { return p.user ? p.user.name : (p.aiLevel ? 'Stockfish livello ' + p.aiLevel : null); };
      var res = g.winner === 'white' ? '1-0' : g.winner === 'black' ? '0-1' : LI_DRAW[g.status] || (g.status === 'outoftime' && !g.winner) || (g.status === 'timeout' && !g.winner) ? '1/2-1/2' : null;
      var tc = g.clock ? g.clock.initial + '+' + g.clock.increment : (g.speed === 'correspondence' ? '-' : null);
      return {
        source: 'lichess', sourceId: g.id, publicUrl: 'https://lichess.org/' + g.id, rawPgn: g.pgn, fetchedAt: ora(), identita: [nome],
        service: {
          result: res, status: g.status, timeClass: g.speed === 'correspondence' ? 'daily' : g.speed === 'ultraBullet' ? 'ultrabullet' : g.speed, timeControl: tc, rated: g.rated !== false,
          accuracy: (w.analysis && w.analysis.accuracy != null) || (b.analysis && b.analysis.accuracy != null) ? { w: w.analysis ? w.analysis.accuracy : null, b: b.analysis ? b.analysis.accuracy : null } : null,
          opening: g.opening ? { eco: g.opening.eco || null, name: g.opening.name || null } : null,
          players: { w: { name: nomeDi(w), rating: w.rating != null ? w.rating : null }, b: { name: nomeDi(b), rating: b.rating != null ? b.rating : null } },
          playedAtMs: g.createdAt, timeKind: 'inizio', variant: g.variant
        }
      };
    }
    /* un mese di calendario (Roma) da Lichess. Ritorna {mese, stato:'completo'|'parziale', sorgenti, popolazione, scartate, avvisi} */
    async function partiteLichessMese(nome, ym, o) {
      o = o || {}; nome = nomeValido('lichess', nome);
      var lim = o.perMese || 60, iv = U.intervalloMese(ym);
      var url = 'https://lichess.org/api/games/user/' + enc(nome) + '?since=' + iv.inizio + '&until=' + (iv.fine - 1) + '&max=' + (lim + 1) +
        '&perfType=' + LI_PERF + '&moves=true&pgnInJson=true&tags=true&opening=true&accuracy=true&evals=false&clocks=false&literate=false&ongoing=false&finished=true';
      var r;
      try { r = await R.richiesta(url, { ndjson: true, accept: 'application/x-ndjson', segnale: o.segnale, onAttesa: o.onAttesa }); }
      catch (e) { if (e.code === 'NON_TROVATO') throw U.errore('NOUSER', 'Account Lichess «' + nome + '» non trovato.'); throw e; }
      var out = { sito: 'lichess', mese: ym, stato: r.troncato || r.errori.length ? 'parziale' : 'completo', sorgenti: [], scartate: [], avvisi: [], politica: POLITICA, url: url };
      r.errori.forEach(function (x) { out.avvisi.push('Riga ' + x.riga + ': ' + x.msg); });
      var valide = [];
      r.righe.forEach(function (g) {
        if (!g || typeof g.id !== 'string' || typeof g.createdAt !== 'number') { out.scartate.push({ id: g && g.id || null, motivo: 'dati incompleti' }); out.stato = 'parziale'; return; }
        if (LI_SCARTA[g.status]) { out.scartate.push({ id: g.id, motivo: LI_SCARTA[g.status] }); return; }
        if (g.variant && g.variant !== 'standard') { out.scartate.push({ id: g.id, motivo: g.variant === 'fromPosition' ? 'partita da posizione' : 'variante ' + g.variant }); return; }
        if (g.createdAt < iv.inizio || g.createdAt >= iv.fine) { out.scartate.push({ id: g.id, motivo: 'fuori dal mese' }); return; }
        if (typeof g.pgn !== 'string' || !g.pgn.trim()) { out.scartate.push({ id: g.id, motivo: 'PGN assente nella risposta' }); out.stato = 'parziale'; return; }
        valide.push(g);
      });
      valide.sort(function (a, b) { return b.createdAt - a.createdAt || (a.id < b.id ? -1 : 1); });
      out.popolazione = { conteggio: valide.length > lim ? lim + 1 : valide.length, esatta: valide.length <= lim, nota: valide.length > lim ? 'più di ' + lim + ' partite nel mese (non contate oltre)' : null };
      valide.slice(0, lim).forEach(function (g) { out.sorgenti.push(liSorgente(g, nome)); });
      valide.slice(lim).forEach(function (g) { out.scartate.push({ id: g.id, motivo: 'oltre le ' + lim + ' più recenti del mese' }); });
      return out;
    }

    /* ---------------- Chess.com ---------------- */
    async function profiloChesscom(nome, o) {
      nome = nomeValido('chesscom', nome);
      var r;
      try { r = await R.richiesta('https://api.chess.com/pub/player/' + enc(nome), o); }
      catch (e) { if (e.code === 'NON_TROVATO') throw U.errore('NOUSER', 'Account Chess.com «' + nome + '» non trovato.'); throw e; }
      var p = r.dati; if (!p || !p.username) throw U.errore('RISPOSTA_INATTESA', 'Profilo Chess.com in formato inatteso.');
      if (p.status === 'closed' || p.status === 'closed:fair_play_violations') throw U.errore('NON_PUBBLICO', 'L\'account Chess.com «' + nome + '» non è disponibile.');
      // PRIVACY: come per Lichess, mai name (nome reale), location, country, avatar, url di terzi: solo id e username.
      return { sito: 'chesscom', id: String(p.player_id || p.username).toLowerCase(), nome: String(p.username) };
    }
    async function statsChesscom(nome, o) {
      nome = nomeValido('chesscom', nome);
      var s = (await R.richiesta('https://api.chess.com/pub/player/' + enc(nome) + '/stats', o)).dati || {};
      var M = { chess_daily: 'daily', chess_rapid: 'rapid', chess_blitz: 'blitz', chess_bullet: 'bullet' }, out = {};
      Object.keys(M).forEach(function (k) { var x = s[k]; if (x && x.last) out[M[k]] = { rating: x.last.rating, data: x.last.date ? U.dataRoma(x.last.date * 1000) : null, migliore: x.best ? x.best.rating : null, recordGlobale: x.record || null, fonte: 'chesscom-attuale', nota: 'Il record è quello di sempre, non del periodo caricato.' }; });
      return { sito: 'chesscom', ritmi: out };
    }
    async function archiviChesscom(nome, o) {
      nome = nomeValido('chesscom', nome);
      var r;
      try { r = await R.richiesta('https://api.chess.com/pub/player/' + enc(nome) + '/games/archives', o); }
      catch (e) { if (e.code === 'NON_TROVATO') throw U.errore('NOUSER', 'Account Chess.com «' + nome + '» non trovato.'); throw e; }
      var a = r.dati && r.dati.archives; if (!Array.isArray(a)) throw U.errore('RISPOSTA_INATTESA', 'Elenco archivi Chess.com in formato inatteso.');
      var mesi = {};
      a.forEach(function (u) { var m = /\/games\/(\d{4})\/(\d{2})$/.exec(u); if (m) mesi[m[1] + '-' + m[2]] = 'https://api.chess.com/pub/player/' + enc(nome) + '/games/' + m[1] + '/' + m[2]; });
      return mesi;   // chiave mese UTC (convenzione del servizio) → URL ricostruito sulla lista positiva
    }
    async function archivioMeseUTC(nome, ymUTC, url, o) {
      var k = 'cc:' + nome.toLowerCase() + ':' + ymUTC, adesso = ora(), corrente = U.meseUTC(adesso) === ymUTC;
      if (cache && !o.aggiorna) {
        var c = await cache.get(k);
        if (c && c.completo && (!corrente || adesso - c.t < TTL_CORRENTE)) return { games: c.games, daCache: true, scaricatoIl: c.t };
      }
      var r = await R.richiesta(url, { segnale: o.segnale, onAttesa: o.onAttesa });
      var g = r.dati && r.dati.games;
      if (!Array.isArray(g)) throw U.errore('RISPOSTA_INATTESA', 'Archivio mensile Chess.com in formato inatteso.');
      if (cache) await cache.set(k, { t: adesso, completo: true, games: g, cleanupClass: 1 });
      return { games: g, daCache: false, scaricatoIl: adesso };
    }
    function ccRisultato(g) {
      var w = g.white && g.white.result, b = g.black && g.black.result;
      if (w === 'win' && CC_SCONFITTA[b]) return '1-0';
      if (b === 'win' && CC_SCONFITTA[w]) return '0-1';
      if (CC_PATTA[w] && CC_PATTA[b]) return '1/2-1/2';
      return null;   // combinazione inattesa: sconosciuto, mai patta
    }
    function ccSorgente(g, nome) {
      var tag = function (t) { var m = (g.pgn || '').match(new RegExp('\\[' + t + ' "([^"]*)"\\]')); return m ? m[1] : null; };
      var ecoUrl = tag('ECOUrl') || g.eco || null, slug = ecoUrl ? ecoUrl.split('/').pop() : null;
      var nomeAp = slug ? decodeURIComponent(slug).replace(/-/g, ' ').replace(/\s+\d+\..*$/, '').trim() : null;
      return {
        source: 'chesscom', sourceId: Imp.idChesscomDaUrl(g.url) || ('uuid/' + g.uuid), publicUrl: g.url || null, rawPgn: g.pgn, fetchedAt: ora(), identita: [nome],
        service: {
          result: ccRisultato(g), status: (g.white && g.white.result) + '/' + (g.black && g.black.result), timeClass: g.time_class, timeControl: g.time_control || null, rated: g.rated !== false,
          accuracy: g.accuracies ? { w: g.accuracies.white != null ? g.accuracies.white : null, b: g.accuracies.black != null ? g.accuracies.black : null } : null,
          opening: nomeAp ? { eco: tag('ECO'), name: nomeAp } : null,
          players: { w: { name: g.white && g.white.username || null, rating: g.white && g.white.rating != null ? g.white.rating : null }, b: { name: g.black && g.black.username || null, rating: g.black && g.black.rating != null ? g.black.rating : null } },
          playedAtMs: g.end_time * 1000, timeKind: 'fine', variant: g.rules
        }
      };
    }
    /* un mese di calendario (Roma). Gli archivi Chess.com sono per mese UTC: si leggono il mese UTC uguale e il precedente
       (le prime ore del mese a Roma sono ancora nel mese UTC precedente) e si rifiltra localmente per data di fine. */
    async function partiteChesscomMese(nome, ym, o) {
      o = o || {}; nome = nomeValido('chesscom', nome);
      var lim = o.perMese || 60, iv = U.intervalloMese(ym), archivi = o.archivi || await archiviChesscom(nome, o);
      var necessari = [U.meseUTC(iv.inizio), U.meseUTC(iv.fine - 1)].filter(function (x, i, a) { return a.indexOf(x) === i; });
      var out = { sito: 'chesscom', mese: ym, stato: 'completo', sorgenti: [], scartate: [], avvisi: [], politica: POLITICA, archiviUsati: [] }, tutte = [];
      for (var i = 0; i < necessari.length; i++) {
        var m = necessari[i]; if (!archivi[m]) continue;   // mese senza partite: nessuna richiesta
        var a = await archivioMeseUTC(nome, m, archivi[m], o);
        out.archiviUsati.push({ meseUTC: m, daCache: a.daCache, scaricatoIl: a.scaricatoIl });
        a.games.forEach(function (g) { tutte.push(g); });
      }
      var valide = [];
      tutte.forEach(function (g) {
        if (!g || typeof g.end_time !== 'number' || !g.url) { out.scartate.push({ id: g && g.url || null, motivo: 'dati incompleti' }); return; }
        var t = g.end_time * 1000; if (t < iv.inizio || t >= iv.fine) return;   // appartiene a un altro mese di Roma
        if (g.rules && g.rules !== 'chess') { out.scartate.push({ id: g.url, motivo: 'variante ' + g.rules }); return; }
        if (typeof g.pgn !== 'string' || !g.pgn.trim()) { out.scartate.push({ id: g.url, motivo: 'PGN assente' }); out.stato = 'parziale'; return; }
        valide.push(g);
      });
      valide.sort(function (a, b) { return b.end_time - a.end_time || (a.url < b.url ? -1 : 1); });
      out.popolazione = { conteggio: valide.length, esatta: true, nota: null };
      valide.slice(0, lim).forEach(function (g) { out.sorgenti.push(ccSorgente(g, nome)); });
      valide.slice(lim).forEach(function (g) { out.scartate.push({ id: g.url, motivo: 'oltre le ' + lim + ' più recenti del mese' }); });
      return out;
    }

    /* ---------------- acquisizione per mesi con cursori ----------------
       cursori = {get(k), set(k,v)} (archivio meta). Un mese è «completo» solo dopo che onMese (import + commit) è riuscito
       e la risposta era completa. Il mese corrente si rilegge sempre; i mesi incompleti/in errore si rileggono interi
       (ripresa sovrapposta: i doppioni sono assorbiti dall'import idempotente). */
    async function acquisisci(sito, nome, o) {
      o = o || {};
      var mesi = U.ultimiMesi(o.ora || ora(), o.mesi || 12), corrente = mesi[0], rep = { sito: sito, nome: nome, politica: POLITICA, mesi: [] };
      var archivi = null;
      if (sito === 'chesscom') archivi = await archiviChesscom(nome, o);
      for (var i = 0; i < mesi.length; i++) {
        var ym = mesi[i], ck = 'cursore:' + sito + ':' + nome.toLowerCase() + ':' + ym;
        if (o.segnale && o.segnale.aborted) { rep.annullato = true; break; }
        var c = o.cursori ? await o.cursori.get(ck) : null;
        if (c && c.stato === 'completo' && ym !== corrente && !o.aggiorna) { rep.mesi.push({ mese: ym, stato: 'già completo', importate: c.importate, daCursore: true }); continue; }
        var r;
        try {
          r = sito === 'lichess' ? await partiteLichessMese(nome, ym, o) : await partiteChesscomMese(nome, ym, Object.assign({}, o, { archivi: archivi }));
        } catch (e) {
          if (e.code === 'ANNULLATO') { rep.annullato = true; break; }
          if (o.cursori) await o.cursori.set(ck, { stato: 'errore', codice: e.code, quando: ora() });
          rep.mesi.push({ mese: ym, stato: 'errore', codice: e.code, messaggio: e.message });
          if (e.code === 'NOUSER' || e.code === 'NON_PUBBLICO' || e.code === 'RETE' || e.code === 'RATE') { rep.interrotto = e.code; break; }
          continue;
        }
        var esitoImport = o.onMese ? await o.onMese(r) : null;   // il chiamante importa; se lancia, il cursore NON avanza
        var stato = r.stato === 'completo' ? 'completo' : 'parziale';
        if (o.cursori) await o.cursori.set(ck, { stato: stato, quando: ora(), importate: r.sorgenti.length, popolazione: r.popolazione, politica: POLITICA });
        rep.mesi.push({ mese: ym, stato: stato, importate: r.sorgenti.length, popolazione: r.popolazione, scartate: r.scartate.length, avvisi: r.avvisi, esitoImport: esitoImport });
      }
      return rep;
    }

    /* curva Chess.com ricostruita dalle partite scaricate: punti solo dove c'è una partita, buchi dichiarati */
    function curvaChesscomDaPartite(games, nomeUtente) {
      var me = String(nomeUtente || '').toLowerCase(), per = {};
      games.forEach(function (g) {
        if (!g.sourceRefs.some(function (s) { return s.source === 'chesscom'; }) || !g.userColor || g.playedAtMs == null) return;
        var r = g.players[g.userColor].rating; if (r == null) return;
        var k = g.timeClass || 'sconosciuto'; (per[k] = per[k] || []).push({ ms: g.playedAtMs, data: U.dataRoma(g.playedAtMs), rating: r, gameId: g.gameId });
      });
      return Object.keys(per).map(function (k) {
        var p = per[k].sort(function (a, b) { return a.ms - b.ms; });
        return { sito: 'chesscom', ritmo: k, tipo: 'ricostruita-da-partite', provenienza: 'rating delle partite scaricate (' + p.length + ')', campione: p.length, nota: 'Non è lo storico completo: mancano i giorni senza partite scaricate.', punti: p };
      });
    }

    return { profiloLichess: profiloLichess, storicoRatingLichess: storicoRatingLichess, storicoRatingLichessDettaglio: storicoRatingLichessDettaglio, descriviStorico: descriviStorico, partiteLichessMese: partiteLichessMese, profiloChesscom: profiloChesscom, statsChesscom: statsChesscom, archiviChesscom: archiviChesscom, partiteChesscomMese: partiteChesscomMese, acquisisci: acquisisci, curvaChesscomDaPartite: curvaChesscomDaPartite, POLITICA: POLITICA, _liSorgente: liSorgente, _ccSorgente: ccSorgente, _ccRisultato: ccRisultato };
  }
  return { crea: crea, POLITICA: POLITICA, VERSIONE: 'cnap-sorgenti-1' };
});
