/* Chess Node · Analisi profonda · FASE 4 · CNApTentativi — STORICO UNICO dei tentativi (A3-07): separato, immutabile, versionato.
   Codice originale Chess Node (09/11/2026).
   - un attemptId assegnato una volta; eventi solo AGGIUNTI (mai riscritti);
   - doppio «risolto» o ritorno dal background → un solo tentativo concluso (idempotente);
   - processo terminato con tentativo aperto → «interrotto», riprendibile con lo STESSO ID; ricominciare crea un tentativo nuovo;
   - esito riassuntivo con precedenza: soluzione mostrata > dopo errore > con aiuti > senza aiuti; «interrotto» se non concluso.
     I fatti restano separati: errorCount, hintLevels, solutionShown, solved, illegalInputs (chi sbaglia e poi usa un aiuto li conserva entrambi);
   - aiuto di 1° livello registrato ma NON conta come aiuto (regola attuale della biblioteca, stats.js);
   - nessun limite a 20: il vecchio limite di stats.js resta solo per il riepilogo legacy;
   - un successo successivo non cancella errori precedenti né il primo colpo storico. Tempo = tempo ATTIVO. */
(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api; else root.CNApTentativi = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  var VERSIONE = 'cnap-tentativi-1';
  var ESITI = { mostrata: 'soluzione mostrata', dopoErrore: 'risolto dopo errore', conAiuti: 'risolto con aiuti', senzaAiuti: 'risolto senza aiuti', interrotto: 'interrotto' };
  var EVENTI = ['mossa-giusta', 'errore', 'aiuto', 'mostra', 'arresa', 'illegale', 'non-obiettivo', 'verifica-alternativa', 'alternativa-valida', 'alternativa-incerta', 'pausa', 'ripresa', 'interrotto', 'fine'];

  function esito(t) {
    if (!t.endedAt) return ESITI.interrotto;
    if (t.solutionShown) return ESITI.mostrata;
    if (!t.solved) return ESITI.interrotto;
    if (t.errorCount > 0) return ESITI.dopoErrore;
    if (t.hintLevels.some(function (h) { return h >= 2; })) return ESITI.conAiuti;
    return ESITI.senzaAiuti;
  }

  function crea(d) {
    var DB = d.db, U = d.CNApUtil, ora = d.ora || function () { return Date.now(); };
    function err(c, m) { var e = new Error(m); e.code = c; return e; }
    async function leggi(id) { return DB.tx(['attempts'], 'readonly', function (t) { return t.get('attempts', id); }); }
    async function salva(a) { await DB.tx(['attempts'], 'readwrite', function (t) { return t.put('attempts', a); }); return a; }

    /* o = {exerciseId, sessionId, solutionVersion, validationVersion, difficulty:{level,version}, originPlacementId, attemptId?} */
    async function inizia(o) {
      if (o.attemptId) { var g = await leggi(o.attemptId); if (g) return g; }
      var t0 = ora(), id = o.attemptId || ('AT-' + U.hash(o.exerciseId + '|' + o.sessionId + '|' + t0 + '|' + Math.random()).slice(0, 12));
      var a = { attemptId: id, exerciseId: o.exerciseId, sessionId: o.sessionId || null, solutionVersion: o.solutionVersion, validationVersion: o.validationVersion || null,
        difficultyAtAttempt: o.difficulty || null, originPlacementId: o.originPlacementId || null, startedAt: t0, endedAt: null, activeMs: 0, outcome: ESITI.interrotto,
        solved: false, errorCount: 0, hintLevels: [], solutionShown: false, illegalInputs: 0, events: [], historicalSolution: false, schemaVersion: 1, versione: VERSIONE };
      // numero d'ordine di creazione: due tentativi nello stesso millisecondo restano nell'ordine vero (il primo colpo non si scambia)
      await DB.tx(['attempts', 'meta'], 'readwrite', async function (t) { var m = await t.get('meta', 'seqTentativi'); a.ordine = (m ? m.valore : 0) + 1; await t.put('meta', { key: 'seqTentativi', valore: a.ordine }); await t.put('attempts', a); });
      return a;
    }
    /* ev = {kind, elapsedActiveMs?, uci?, level?, info?} — append-only */
    async function evento(attemptId, ev) {
      if (EVENTI.indexOf(ev.kind) < 0) throw err('EVENTO', 'Evento sconosciuto: ' + ev.kind);
      var a = await leggi(attemptId); if (!a) throw err('TENTATIVO', 'Tentativo inesistente');
      if (a.endedAt && ev.kind !== 'fine') return a;   // dopo la fine non si aggiunge niente (doppio callback)
      a.events.push(Object.assign({ at: ora() }, ev));
      if (ev.elapsedActiveMs != null) a.activeMs = Math.max(a.activeMs, ev.elapsedActiveMs);
      if (ev.kind === 'errore') a.errorCount++;
      if (ev.kind === 'aiuto') a.hintLevels.push(ev.level || 1);
      if (ev.kind === 'mostra') a.solutionShown = true;
      if (ev.kind === 'illegale') a.illegalInputs++;
      if (ev.kind === 'ripresa') a.interrotto = false;
      if (ev.kind === 'interrotto') a.interrotto = true;
      a.outcome = esito(a);
      return salva(a);
    }
    /* conclusione idempotente: il secondo «solved» non crea niente e non cambia niente */
    async function concludi(attemptId, o) {
      o = o || {};
      var a = await leggi(attemptId); if (!a) throw err('TENTATIVO', 'Tentativo inesistente');
      if (a.endedAt) return Object.assign(a, { giaConcluso: true });
      a.endedAt = ora(); a.solved = !!o.solved && !a.solutionShown; a.viaAlternativa = !!o.viaAlternativa;
      if (o.activeMs != null) a.activeMs = Math.max(a.activeMs, o.activeMs);
      if (o.solutionShown) a.solutionShown = true;
      a.events.push({ at: a.endedAt, kind: 'fine', solved: a.solved });
      a.outcome = esito(a);
      return salva(a);
    }
    /* avvio dopo un riavvio: i tentativi aperti diventano «interrotti» (non successi), riprendibili con lo stesso ID */
    async function segnaInterrotti() {
      var tutti = await DB.tx(['attempts'], 'readonly', function (t) { return t.all('attempts'); }), n = 0;
      for (var i = 0; i < tutti.length; i++) if (!tutti[i].endedAt && !tutti[i].interrotto) { await evento(tutti[i].attemptId, { kind: 'interrotto', info: 'processo terminato o app chiusa' }); n++; }
      return n;
    }
    async function riprendi(attemptId) { return evento(attemptId, { kind: 'ripresa' }); }
    async function storico(exerciseId) {
      var l = await DB.tx(['attempts'], 'readonly', function (t) { return exerciseId ? t.byIndex('attempts', 'exerciseId', exerciseId) : t.all('attempts'); });
      return l.sort(function (a, b) { return a.startedAt - b.startedAt || (a.ordine || 0) - (b.ordine || 0) || (a.attemptId < b.attemptId ? -1 : 1); });
    }
    /* primo colpo storico: il primo tentativo CONCLUSO; mai riscritto da successi successivi */
    async function primoColpo(exerciseId) { var s = (await storico(exerciseId)).filter(function (a) { return a.endedAt; }); return s.length ? { attemptId: s[0].attemptId, outcome: s[0].outcome, perfetto: s[0].outcome === ESITI.senzaAiuti } : null; }
    /* nuova versione della soluzione: i vecchi tentativi restano riferiti alla loro versione (marcati, mai convertiti) */
    function marcaVersione(tentativi, solutionVersion) { return tentativi.map(function (a) { return Object.assign({}, a, { versionePrecedente: a.solutionVersion !== solutionVersion }); }); }
    /* il vecchio storico errori di stats.js (eh: n → [[ts, kind]], max 20) diventa un RIEPILOGO legacy, non tentativi inventati */
    function riepilogoLegacy(eh) { var out = {}; Object.keys(eh || {}).forEach(function (n) { out['library:' + n] = { eventi: (eh[n] || []).map(function (x) { return { at: x[0], kind: x[1] }; }), fonte: 'stats.js eh (max 20, legacy)' }; }); return out; }
    return { inizia: inizia, evento: evento, concludi: concludi, segnaInterrotti: segnaInterrotti, riprendi: riprendi, storico: storico, primoColpo: primoColpo, marcaVersione: marcaVersione, riepilogoLegacy: riepilogoLegacy, esito: esito };
  }
  return { crea: crea, ESITI: ESITI, EVENTI: EVENTI, esito: esito, VERSIONE: VERSIONE };
});
