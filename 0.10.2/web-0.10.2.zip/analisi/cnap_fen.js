/* Chess Node · Analisi profonda · FASE 1 · CNApFen — validazione completa di una FEN (A1-02 §6.2).
   Codice originale Chess Node (08/11/2026). Dipendenza facoltativa: chess.js (BSD-2) passato come parametro, solo per
   il controllo incrociato finale; i controlli qui sotto sono nostri e più severi del costruttore della libreria.
   Cosa controlla: 6 campi, disposizione 8×8, un Re per lato, pedoni non in 1ª/8ª, tratto, diritti d'arrocco coerenti con
   Re e Torri sulle case iniziali, en passant coerente (pedone appena spinto di due, case libere, contatore 0), contatori,
   Re adiacenti, lato che NON muove sotto scacco, più di due pezzi che danno scacco, materiale impossibile.
   NON prova la raggiungibilità storica: una FEN valida resta reachability "unknown" (regola maestro §6.2). */
(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api; else root.CNApFen = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  var START = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';
  var FILES = 'abcdefgh';

  function sq(r, f) { return FILES[f] + (8 - r); }

  function leggiDisposizione(pl, err) {
    var righe = pl.split('/');
    if (righe.length !== 8) { err('DISPOSIZIONE', 'La disposizione deve avere 8 traverse separate da «/» (trovate ' + righe.length + ').'); return null; }
    var b = [];
    for (var r = 0; r < 8; r++) {
      var riga = [], prevDigit = false;
      for (var i = 0; i < righe[r].length; i++) {
        var c = righe[r][i];
        if (/[1-8]/.test(c)) {
          if (prevDigit) { err('DISPOSIZIONE', 'Traversa ' + (8 - r) + ': due cifre consecutive («' + righe[r] + '»).'); return null; }
          for (var k = 0; k < +c; k++) riga.push(null);
          prevDigit = true;
        } else if (/[prnbqkPRNBQK]/.test(c)) { riga.push(c); prevDigit = false; }
        else { err('DISPOSIZIONE', 'Traversa ' + (8 - r) + ': carattere non valido «' + c + '».'); return null; }
      }
      if (riga.length !== 8) { err('DISPOSIZIONE', 'Traversa ' + (8 - r) + ': ' + riga.length + ' case invece di 8.'); return null; }
      b.push(riga);
    }
    return b;
  }

  /* quanti pezzi del colore `by` attaccano la casa (r,f) */
  function attaccanti(b, r, f, by) {
    var n = 0, w = by === 'w';
    var P = w ? 'P' : 'p', N = w ? 'N' : 'n', B = w ? 'B' : 'b', R = w ? 'R' : 'r', Q = w ? 'Q' : 'q', K = w ? 'K' : 'k';
    var at = function (rr, ff) { return rr >= 0 && rr < 8 && ff >= 0 && ff < 8 ? b[rr][ff] : undefined; };
    var pr = w ? r + 1 : r - 1;                       // il pedone bianco attacca verso traverse più alte (indice riga minore)
    if (at(pr, f - 1) === P) n++;
    if (at(pr, f + 1) === P) n++;
    [[1, 2], [2, 1], [-1, 2], [-2, 1], [1, -2], [2, -1], [-1, -2], [-2, -1]].forEach(function (d) { if (at(r + d[0], f + d[1]) === N) n++; });
    for (var dr = -1; dr <= 1; dr++) for (var df = -1; df <= 1; df++) if ((dr || df) && at(r + dr, f + df) === K) n++;
    [[1, 0], [-1, 0], [0, 1], [0, -1], [1, 1], [1, -1], [-1, 1], [-1, -1]].forEach(function (d) {
      var diag = d[0] && d[1], rr = r + d[0], ff = f + d[1];
      while (rr >= 0 && rr < 8 && ff >= 0 && ff < 8) {
        var p = b[rr][ff];
        if (p) { if (p === Q || p === (diag ? B : R)) n++; break; }
        rr += d[0]; ff += d[1];
      }
    });
    return n;
  }

  function trova(b, p) { for (var r = 0; r < 8; r++) for (var f = 0; f < 8; f++) if (b[r][f] === p) return { r: r, f: f }; return null; }

  /* opzioni: {Chess, completaCampi:false}  →  {ok, fen, errori[], avvisi[], variante, campiCompletati} */
  function valida(fen, o) {
    o = o || {};
    var errori = [], avvisi = [], variante = 'standard', completati = false;
    var err = function (code, msg) { errori.push({ code: code, msg: msg }); };
    var avv = function (code, msg) { avvisi.push({ code: code, msg: msg }); };
    if (typeof fen !== 'string' || !fen.trim()) { err('VUOTA', 'FEN assente.'); return { ok: false, fen: null, errori: errori, avvisi: avvisi, variante: variante }; }
    var campi = fen.trim().split(/\s+/);
    if (campi.length < 6) {
      if (o.completaCampi && campi.length >= 1) {
        var def = ['w', '-', '-', '0', '1'];
        while (campi.length < 6) campi.push(def[campi.length - 1]);
        completati = true;
        avv('CAMPI_COMPLETATI', 'La FEN non aveva tutti i 6 campi: tratto/arrocco/en passant/contatori completati con i valori predefiniti (da verificare).');
      } else err('CAMPI', 'Una FEN completa ha 6 campi; trovati ' + campi.length + '.');
    }
    if (campi.length > 6) err('CAMPI', 'Una FEN completa ha 6 campi; trovati ' + campi.length + '.');
    if (errori.length) return { ok: false, fen: null, errori: errori, avvisi: avvisi, variante: variante };
    var pl = campi[0], tratto = campi[1], arr = campi[2], ep = campi[3], hm = campi[4], fm = campi[5];
    var b = leggiDisposizione(pl, err);
    if (!/^[wb]$/.test(tratto)) err('TRATTO', 'Il tratto deve essere «w» o «b».');
    if (!/^\d+$/.test(hm)) err('CONTATORE', 'Contatore delle semimosse non valido («' + hm + '»).');
    if (!/^\d+$/.test(fm) || +fm < 1) err('CONTATORE', 'Numero di mossa non valido («' + fm + '»): deve essere almeno 1.');
    if (/^[A-Ha-h]+$/.test(arr) && !/^K?Q?k?q?$/.test(arr)) { variante = 'chess960'; err('VARIANTE_960', 'Diritti d\'arrocco in formato Chess960 («' + arr + '»): variante non supportata nel primo ambito.'); }
    else if (arr !== '-' && !/^K?Q?k?q?$/.test(arr)) err('ARROCCO', 'Campo arrocco non valido («' + arr + '»): usare «-» o le lettere KQkq in quest\'ordine.');
    if (ep !== '-' && !/^[a-h][36]$/.test(ep)) err('EN_PASSANT', 'Casa en passant non valida («' + ep + '»).');
    if (!b) return { ok: false, fen: null, errori: errori, avvisi: avvisi, variante: variante };

    // pezzi
    var cnt = {};
    for (var r = 0; r < 8; r++) for (var f = 0; f < 8; f++) { var p = b[r][f]; if (p) cnt[p] = (cnt[p] || 0) + 1; }
    if ((cnt.K || 0) !== 1) err('RE', 'Il Bianco deve avere esattamente un Re (trovati ' + (cnt.K || 0) + ').');
    if ((cnt.k || 0) !== 1) err('RE', 'Il Nero deve avere esattamente un Re (trovati ' + (cnt.k || 0) + ').');
    for (var f2 = 0; f2 < 8; f2++) {
      if (/[Pp]/.test(b[0][f2] || '')) err('PEDONE_BORDO', 'Pedone in ottava traversa (' + sq(0, f2) + ').');
      if (/[Pp]/.test(b[7][f2] || '')) err('PEDONE_BORDO', 'Pedone in prima traversa (' + sq(7, f2) + ').');
    }
    ['w', 'b'].forEach(function (c) {
      var w = c === 'w', pd = cnt[w ? 'P' : 'p'] || 0;
      var extra = Math.max(0, (cnt[w ? 'Q' : 'q'] || 0) - 1) + Math.max(0, (cnt[w ? 'R' : 'r'] || 0) - 2) + Math.max(0, (cnt[w ? 'B' : 'b'] || 0) - 2) + Math.max(0, (cnt[w ? 'N' : 'n'] || 0) - 2);
      if (pd > 8) err('MATERIALE', (w ? 'Bianco' : 'Nero') + ': più di 8 pedoni.');
      else if (extra > 8 - pd) err('MATERIALE', (w ? 'Bianco' : 'Nero') + ': troppi pezzi promossi rispetto ai pedoni mancanti (materiale impossibile).');
    });
    if (errori.length) return { ok: false, fen: null, errori: errori, avvisi: avvisi, variante: variante };

    var Kw = trova(b, 'K'), Kb = trova(b, 'k');
    if (Math.abs(Kw.r - Kb.r) <= 1 && Math.abs(Kw.f - Kb.f) <= 1) err('RE_ADIACENTI', 'I due Re sono su case adiacenti: posizione illegale.');
    var nonMuove = tratto === 'w' ? Kb : Kw, chiMuove = tratto === 'w' ? Kw : Kb;
    if (attaccanti(b, nonMuove.r, nonMuove.f, tratto) > 0) err('SCACCO_LATO_FERMO', 'Il Re del lato che non ha il tratto è sotto scacco: posizione illegale.');
    var nChk = attaccanti(b, chiMuove.r, chiMuove.f, tratto === 'w' ? 'b' : 'w');
    if (nChk > 2) err('SCACCO_TRIPLO', 'Il Re del lato al tratto riceve scacco da ' + nChk + ' pezzi: impossibile.');

    // arrocco coerente con Re e Torri sulle case iniziali
    if (arr !== '-' && variante === 'standard') {
      var need = { K: [[7, 4, 'K'], [7, 7, 'R']], Q: [[7, 4, 'K'], [7, 0, 'R']], k: [[0, 4, 'k'], [0, 7, 'r']], q: [[0, 4, 'k'], [0, 0, 'r']] };
      arr.split('').forEach(function (c) {
        if (!need[c].every(function (x) { return b[x[0]][x[1]] === x[2]; })) err('ARROCCO_INCOERENTE', 'Diritto d\'arrocco «' + c + '» senza Re e Torre sulle case iniziali.');
      });
    }
    // en passant: casa vuota, pedone appena spinto davanti, casa di partenza vuota, contatore semimosse 0
    if (ep !== '-' && /^[a-h][36]$/.test(ep)) {
      var ef = FILES.indexOf(ep[0]), er = 8 - +ep[1];
      var ok = tratto === 'w' ? ep[1] === '6' && b[er][ef] === null && b[er - 1][ef] === null && b[er + 1][ef] === 'p'
                              : ep[1] === '3' && b[er][ef] === null && b[er + 1][ef] === null && b[er - 1][ef] === 'P';
      if (!ok) err('EN_PASSANT_INCOERENTE', 'Casa en passant «' + ep + '» incoerente con la posizione e con il tratto.');
      else if (+hm !== 0) err('EN_PASSANT_INCOERENTE', 'Con una casa en passant il contatore delle semimosse deve essere 0 (una spinta di pedone lo azzera).');
    }
    if (+hm > 150) avv('CONTATORE_ALTO', 'Contatore semimosse oltre 150: la regola delle 75 mosse avrebbe già chiuso la partita.');

    var out = campi.join(' ');
    if (!errori.length && o.Chess) {
      try { new o.Chess(out); } catch (e) { err('LIBRERIA', 'La libreria di legalità rifiuta la FEN: ' + (e && e.message || e)); }
    }
    return { ok: !errori.length, fen: errori.length ? null : out, errori: errori, avvisi: avvisi, variante: variante, campiCompletati: completati };
  }

  /* chiave geometrica documentata (solo indici: disposizione+tratto+arrocco+ep). NON contiene contatori né storia:
     mai usarla per risultati teorici che dipendono da ripetizione o regola delle 50 mosse (A1-02 §6.2). */
  function chiaveGeometrica(fen) { return fen.split(' ').slice(0, 4).join(' '); }
  function tratto(fen) { return fen.split(' ')[1]; }
  function numeroMossa(fen) { return +fen.split(' ')[5]; }

  return { START: START, valida: valida, chiaveGeometrica: chiaveGeometrica, tratto: tratto, numeroMossa: numeroMossa, VERSIONE: 'cnap-fen-1' };
});
