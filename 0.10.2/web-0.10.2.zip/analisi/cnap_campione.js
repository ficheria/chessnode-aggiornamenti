/* Chess Node · Analisi profonda · FASE 1 · CNApCampione — scelta DETERMINISTICA delle partite per l'analisi automatica (DECISO Q04).
   Codice originale Chess Node (08/11/2026). Calcolo puro: stesso insieme di partite ⇒ stesso campione (anche dopo reimport).
   Regole: obiettivo ~15 al mese (obiettivo, non obbligo: mai riempire); Bullet/UltraBullet escluse; partite terminate prima della
   10ª mossa escluse; sconfitte recenti con priorità ma al massimo una quota (PROPOSTA Kiko-bot ~1/3, configurabile); equilibrio
   Bianco/Nero quando possibile; ritmi in proporzione alla loro presenza; partite già analizzate conservate (non ricalcolate).
   L'analisi manuale resta sempre possibile su qualsiasi partita: va marcata «fuori campione» negli aggregati. */
(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api; else root.CNApCampione = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  var POLITICA = 'campione-motore-q04-v1';
  var DEFAULT = { obiettivo: 15, quotaSconfitte: 1 / 3, ritmiEsclusi: ['bullet', 'ultrabullet'], minMossePiene: 10 };

  function h(s) { var a = 0x811c9dc5; for (var i = 0; i < s.length; i++) a = Math.imul(a ^ s.charCodeAt(i), 16777619) >>> 0; return a; }
  function ordine(a, b) { return (b.playedAtMs || 0) - (a.playedAtMs || 0) || h(a.gameId) - h(b.gameId) || (a.gameId < b.gameId ? -1 : 1); }
  function sconfitta(g) { return g.resultStatus === 'dichiarato' && g.userColor && g.result !== '1/2-1/2' && (g.result === '1-0') !== (g.userColor === 'w'); }

  /* games = partite di UN mese e di un ambito (es. 'self'); o = parametri (DEFAULT) */
  function seleziona(games, o) {
    o = Object.assign({}, DEFAULT, o || {});
    var rep = { politica: POLITICA, parametri: { obiettivo: o.obiettivo, quotaSconfitte: o.quotaSconfitte, ritmiEsclusi: o.ritmiEsclusi, minMossePiene: o.minMossePiene }, popolazione: games.length, escluse: [], idonee: 0, giaAnalizzate: 0, selezionate: [], sconfitteSelezionate: 0, perColore: { w: 0, b: 0 }, perRitmo: {} };
    var idonee = [];
    games.slice().sort(ordine).forEach(function (g) {
      var m = null;
      if (g.variant !== 'standard') m = 'variante non standard';
      else if (g.duplicateCandidateOf && g.duplicateCandidateOf.length) m = 'possibile doppione';
      else if (o.ritmiEsclusi.indexOf(g.timeClass) >= 0) m = 'ritmo ' + g.timeClass + ' escluso dall\'analisi automatica';
      else if (!g.timeClass) m = 'ritmo sconosciuto';
      else if ((g.fullMoves || 0) < o.minMossePiene) m = 'terminata prima della ' + o.minMossePiene + 'ª mossa';
      else if (!g.userColor) m = 'colore dell\'utente non identificato';
      if (m) rep.escluse.push({ gameId: g.gameId, motivo: m }); else idonee.push(g);
    });
    rep.idonee = idonee.length;
    rep.possibiliDoppioniEsclusi = rep.escluse.filter(function (x) { return x.motivo === 'possibile doppione'; }).length;
    var target = Math.min(o.obiettivo, idonee.length), maxSconf = Math.floor(o.obiettivo * o.quotaSconfitte + 1e-9);
    var scelte = [], preso = {};
    function prendi(g, motivo) { scelte.push({ gameId: g.gameId, motivo: motivo }); preso[g.gameId] = g; rep.perColore[g.userColor]++; rep.perRitmo[g.timeClass] = (rep.perRitmo[g.timeClass] || 0) + 1; if (sconfitta(g)) rep.sconfitteSelezionate++; }
    // 1) già analizzate con questa politica: si tengono (niente ricalcolo)
    idonee.forEach(function (g) { if (scelte.length < target && g.localAnalysisId && g.sampling && g.sampling.selectedForEngine) { prendi(g, 'già analizzata'); rep.giaAnalizzate++; } });
    // 1b) INTERPRETAZIONE da confermare: se le idonee non superano l'obiettivo non c'è nulla da scegliere → si analizzano tutte
    //     (Q04: «se nel mese ci sono 8 partite valide se ne analizzano 8»); la quota sconfitte serve solo quando si sceglie.
    if (idonee.length <= o.obiettivo) {
      idonee.forEach(function (g) { if (!preso[g.gameId]) prendi(g, 'tutte le idonee del mese (nessuna scelta necessaria)'); });
      rep.selezionate = scelte; rep.quotaApplicata = false;
      rep.nota = idonee.length < o.obiettivo ? 'Solo ' + idonee.length + ' partite idonee nel mese: analizzate tutte, nessun riempimento.' : null;
      return rep;
    }
    rep.quotaApplicata = true; rep.maxSconfitte = maxSconf;
    // 2) sconfitte più recenti fino alla quota
    idonee.forEach(function (g) { if (!preso[g.gameId] && sconfitta(g) && rep.sconfitteSelezionate < maxSconf && scelte.length < target) prendi(g, 'sconfitta recente (quota ' + maxSconf + ')'); });
    // 3) resto: ritmi in proporzione alla presenza tra le idonee, colori in equilibrio
    var pool = idonee.filter(function (g) { return !preso[g.gameId] && !sconfitta(g); });
    var classi = {}; idonee.forEach(function (g) { classi[g.timeClass] = (classi[g.timeClass] || 0) + 1; });
    var nomi = Object.keys(classi).sort(), quota = {};
    nomi.forEach(function (k) { quota[k] = target * classi[k] / idonee.length; });
    while (scelte.length < target && pool.length) {
      var best = null, bd = -Infinity;
      nomi.forEach(function (k) {
        if (!pool.some(function (g) { return g.timeClass === k; })) return;
        var def = quota[k] - (rep.perRitmo[k] || 0);
        if (def > bd + 1e-9) { bd = def; best = k; }
      });
      if (best === null) break;
      var col = rep.perColore.w <= rep.perColore.b ? 'w' : 'b';
      var cand = pool.filter(function (g) { return g.timeClass === best && g.userColor === col; })[0] || pool.filter(function (g) { return g.timeClass === best; })[0];
      prendi(cand, 'equilibrio ritmo/colore'); pool.splice(pool.indexOf(cand), 1);
    }
    idonee.forEach(function (g) { if (!preso[g.gameId]) rep.escluse.push({ gameId: g.gameId, motivo: sconfitta(g) && rep.sconfitteSelezionate >= maxSconf ? 'quota sconfitte raggiunta' : 'obiettivo mensile raggiunto' }); });
    rep.selezionate = scelte;
    rep.nota = target < o.obiettivo ? 'Solo ' + idonee.length + ' partite idonee nel mese: analizzate tutte, nessun riempimento.' : null;
    if (scelte.length < target) rep.nota = (rep.nota ? rep.nota + ' ' : '') + 'Selezionate ' + scelte.length + ' su ' + target + ': non ci sono abbastanza vittorie/patte senza superare la quota sconfitte.';
    return rep;
  }
  /* campionamento da salvare su ogni partita del mese (Game.sampling) */
  function marcature(games, rep, mese) {
    var sel = {}; rep.selezionate.forEach(function (s) { sel[s.gameId] = s.motivo; });
    var esc = {}; rep.escluse.forEach(function (s) { esc[s.gameId] = s.motivo; });
    var m = {};
    games.forEach(function (g) { m[g.gameId] = { month: mese, selectedForEngine: !!sel[g.gameId], motivo: sel[g.gameId] || esc[g.gameId] || null, policyVersion: POLITICA }; });
    return m;
  }
  return { seleziona: seleziona, marcature: marcature, DEFAULT: DEFAULT, POLITICA: POLITICA, VERSIONE: 'cnap-campione-1' };
});
