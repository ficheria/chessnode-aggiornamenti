/* Chess Node · Analisi profonda · FASE 1 · CNApUtil — utilità comuni (hash, JSON canonico, date Europe/Rome, errori).
   Codice originale Chess Node (Claude per Kiko, 08/11/2026). Nessuna dipendenza esterna.
   Nessun accesso a rete, archivio o DOM. Funziona in browser (globale CNApUtil) e in Node (module.exports). */
(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api; else root.CNApUtil = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  var ZONA = 'Europe/Rome';

  /* ---------- errori tipizzati: code stabile + messaggio leggibile in italiano ---------- */
  function errore(code, msg, extra) {
    var e = new Error(msg || code); e.code = code;
    if (extra) Object.keys(extra).forEach(function (k) { e[k] = extra[k]; });
    return e;
  }

  /* ---------- hash non crittografico (FNV-1a 2×32 bit) per identità e controlli d'integrità ----------
     Sincrono di proposito: va usato anche dentro transazioni IndexedDB, dove un await "esterno" chiuderebbe la transazione. */
  function fnv(s, seed) {
    var h = seed >>> 0;
    for (var i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619) >>> 0; }
    return h >>> 0;
  }
  function hash(s) {
    s = String(s);
    var a = fnv(s, 0x811c9dc5), b = fnv(s, 0x01000193 ^ 0x5bd1e995);
    return ('00000000' + a.toString(16)).slice(-8) + ('00000000' + b.toString(16)).slice(-8);
  }

  /* JSON con chiavi ordinate: stessa struttura → stessa stringa → stesso hash (backup, fingerprint). */
  function canon(v) {
    if (v === null || typeof v !== 'object') return JSON.stringify(v === undefined ? null : v);
    if (Array.isArray(v)) return '[' + v.map(canon).join(',') + ']';
    return '{' + Object.keys(v).sort().filter(function (k) { return v[k] !== undefined; })
      .map(function (k) { return JSON.stringify(k) + ':' + canon(v[k]); }).join(',') + '}';
  }
  function clone(v) { return v === undefined ? undefined : JSON.parse(JSON.stringify(v)); }

  /* ---------- date: il mese di calendario è quello di Europe/Rome (decisione Q04), con ora legale ---------- */
  var fmtCache = null;
  function fmt() {
    if (!fmtCache) fmtCache = new Intl.DateTimeFormat('en-GB', { timeZone: ZONA, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23' });
    return fmtCache;
  }
  function partiRoma(ms) {
    var o = {};
    fmt().formatToParts(new Date(ms)).forEach(function (p) { if (p.type !== 'literal') o[p.type] = +p.value; });
    if (o.hour === 24) o.hour = 0;
    return o;
  }
  function offsetRoma(ms) {   // minuti di differenza Roma − UTC in quell'istante (60 o 120)
    var p = partiRoma(ms);
    return Math.round((Date.UTC(p.year, p.month - 1, p.day, p.hour, p.minute, p.second) - Math.floor(ms / 1000) * 1000) / 60000);
  }
  /* istante UTC (ms) della mezzanotte locale di Roma del giorno indicato (mese 1–12) */
  function mezzanotteRoma(y, m, d) {
    var guess = Date.UTC(y, m - 1, d, 0, 0, 0);
    var t = guess - offsetRoma(guess) * 60000;
    t = guess - offsetRoma(t) * 60000;          // seconda passata: corregge i giorni di cambio ora
    return t;
  }
  function meseRoma(ms) { var p = partiRoma(ms); return p.year + '-' + ('0' + p.month).slice(-2); }
  function dataRoma(ms) { var p = partiRoma(ms); return p.year + '-' + ('0' + p.month).slice(-2) + '-' + ('0' + p.day).slice(-2); }
  function isoRoma(ms) {
    var p = partiRoma(ms), off = offsetRoma(ms), s = off >= 0 ? '+' : '-', a = Math.abs(off);
    var z = function (n) { return ('0' + n).slice(-2); };
    return p.year + '-' + z(p.month) + '-' + z(p.day) + 'T' + z(p.hour) + ':' + z(p.minute) + ':' + z(p.second) + s + z(Math.floor(a / 60)) + ':' + z(a % 60);
  }
  /* intervallo [inizio, fine) in ms UTC del mese "YYYY-MM" secondo Roma */
  function intervalloMese(ym) {
    var y = +ym.slice(0, 4), m = +ym.slice(5, 7);
    var ny = m === 12 ? y + 1 : y, nm = m === 12 ? 1 : m + 1;
    return { inizio: mezzanotteRoma(y, m, 1), fine: mezzanotteRoma(ny, nm, 1) };
  }
  function mesePrecedente(ym, n) {
    var y = +ym.slice(0, 4), m = +ym.slice(5, 7) - (n === undefined ? 1 : n);
    while (m < 1) { m += 12; y--; }
    return y + '-' + ('0' + m).slice(-2);
  }
  /* ultimi n mesi di calendario (Roma), dal più recente; il mese corrente è incluso */
  function ultimiMesi(oraMs, n) {
    var cur = meseRoma(oraMs), out = [];
    for (var i = 0; i < n; i++) out.push(mesePrecedente(cur, i));
    return out;
  }
  /* mese UTC "YYYY-MM" (convenzione degli archivi mensili di Chess.com) */
  function meseUTC(ms) { var d = new Date(ms); return d.getUTCFullYear() + '-' + ('0' + (d.getUTCMonth() + 1)).slice(-2); }

  /* stima prudente della dimensione in byte (UTF-16, come la contano molti browser) */
  function stimaByte(v) { return (typeof v === 'string' ? v.length : JSON.stringify(v === undefined ? null : v).length) * 2; }

  return {
    ZONA: ZONA, errore: errore, hash: hash, canon: canon, clone: clone,
    partiRoma: partiRoma, offsetRoma: offsetRoma, mezzanotteRoma: mezzanotteRoma, meseRoma: meseRoma, dataRoma: dataRoma,
    isoRoma: isoRoma, intervalloMese: intervalloMese, mesePrecedente: mesePrecedente, ultimiMesi: ultimiMesi, meseUTC: meseUTC,
    stimaByte: stimaByte, VERSIONE: 'cnap-util-1'
  };
});
