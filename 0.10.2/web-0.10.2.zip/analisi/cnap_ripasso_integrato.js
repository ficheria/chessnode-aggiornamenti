/* Chess Node · Analisi profonda · FASE 6 (rev. 2) · CNApRipassoIntegrato — la scelta del «Ripasso di oggi» con biblioteca e personali.
   Codice originale Chess Node (09/11/2026). Decisione di Kiko (09/11, 22:54):
   - finché l'app non ha il gancio window.__cnapApriPersonale, i personali NON compaiono nel ripasso di oggi e NON contano nel limite
     di 10: si filtrano PRIMA del taglio (lista, coda e numero sul pulsante = ciò che si apre davvero). Le loro scadenze e i risultati
     restano salvati: le chiavi p:… non si cancellano né si azzerano;
   - con il gancio: stesso limite di 10 al giorno, priorità agli scaduti da più tempo (l'ordine resta quello di stats.js);
     se quel giorno c'è biblioteca in scadenza, i personali occupano AL MASSIMO 5 posti (contando anche quelli già fatti oggi),
     gli altri restano alla biblioteca; senza biblioteca in scadenza i personali possono usare i posti rimasti, fino a 10.
   La STESSA funzione è copiata dentro app_patch/web/stats.js (che deve funzionare anche senza questo file); la prova controlla che
   le due diano sempre lo stesso risultato. */
(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api; else root.CNApRipassoIntegrato = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  var MAXDAY = 10, MAX_PERSONALI_CON_BIBLIOTECA = 5, POLICY = 'ripasso-integrato-fase6-rev2';
  function personale(k) { return typeof k === 'string' && /^p:/.test(k); }
  /* dovuti: chiavi già ORDINATE (scadenza più vecchia, poi più errori) — numeri per la biblioteca, 'p:…' per i personali;
     fatti: chiavi già ripassate oggi; apribile(k): il personale si può aprire? (gancio presente e esercizio allenabile) */
  function scegli(dovuti, fatti, apribile, o) {
    o = o || {};
    var max = o.max || MAXDAY, capP = o.maxPersonali != null ? o.maxPersonali : MAX_PERSONALI_CON_BIBLIOTECA;
    fatti = fatti || [];
    var gia = function (k) { return fatti.indexOf(k) >= 0 || fatti.indexOf(String(k)) >= 0 || (typeof k === 'string' && /^\d+$/.test(k) && fatti.indexOf(+k) >= 0); };
    var liberi = Math.max(0, max - fatti.length), fattiP = fatti.filter(personale).length;
    var lib = [], pers = [];
    dovuti.forEach(function (k) { if (gia(k)) return; if (personale(k)) { if (apribile(k)) pers.push(k); } else lib.push(k); });
    // biblioteca in scadenza OGGI = ancora da fare oppure già ripassata oggi (fatti contiene solo voci dovute: markDone/segnaFatto)
    var bibOggi = lib.length > 0 || fatti.length > fattiP;
    var quotaP = bibOggi ? Math.max(0, capP - fattiP) : liberi;
    var presiP = pers.slice(0, Math.min(quotaP, liberi)), presiL = lib.slice(0, liberi - presiP.length), scelti = {};
    presiP.concat(presiL).forEach(function (k) { scelti[String(k)] = 1; });
    return dovuti.filter(function (k) { return scelti[String(k)] && !gia(k); });
  }
  return { scegli: scegli, MAXDAY: MAXDAY, MAX_PERSONALI_CON_BIBLIOTECA: MAX_PERSONALI_CON_BIBLIOTECA, POLICY: POLICY };
});
