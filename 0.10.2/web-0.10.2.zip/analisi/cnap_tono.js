/* Chess Node · Analisi profonda · FASE 6 · CNApTono — controllo del tono delle schede «Studia un avversario», versione 2.
   Codice originale Chess Node (09/11/2026). È una RETE DI SICUREZZA: le frasi della scheda sono già scritte neutre (fase 5);
   questo controllo intercetta ciò che non deve mai comparire, anche se arrivasse da un testo nuovo o da un errore futuro.
   Correzioni rispetto alla fase 5 (lista semplice di parole):
   - confini di parola Unicode (lettere accentate comprese): «età», «città», «perché» ecc. ora scattano davvero;
   - famiglie di regole: giudizi sulla persona, età, luoghi, presenza online / «sta giocando», dati personali, tono da spia, promesse;
   - i nomi delle aperture dichiarati dal servizio («Vienna Game», «English Opening») si tolgono prima del controllo: non sono luoghi.
   Il tono deciso NON cambia: frasi di fatto in terza persona con il loro numero («Con il Nero ha giocato … in N partite»). */
(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api; else root.CNApTono = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  var VERSIONE = 'cnap-tono-2';
  var L = '(?<![\\p{L}\\p{N}])', R = '(?![\\p{L}\\p{N}])';   // confini di parola che conoscono le lettere accentate
  function w(s) { return new RegExp(L + '(?:' + s + ')' + R, 'iu'); }        // parola intera
  function p(s) { return new RegExp(L + '(?:' + s + ')', 'iu'); }            // inizio di parola (radici: aggressiv…)
  var CITTA = 'milano|roma|napoli|torino|palermo|genova|bologna|firenze|bari|catania|venezia|verona|messina|padova|trieste|brescia|parma|modena|reggio|ancona|pesaro|macerata|ascoli|fermo|urbino|pescara|perugia|cagliari|londra|parigi|berlino|madrid|barcellona|mosca|amsterdam|lisbona|varsavia|new york|los angeles|tokyo|pechino';
  var PAESI = 'italia|francia|germania|spagna|portogallo|inghilterra|regno unito|irlanda|russia|ucraina|polonia|olanda|belgio|svizzera|austria|grecia|turchia|stati uniti|america|canada|messico|brasile|argentina|india|cina|giappone|marche|lombardia|lazio|sicilia|sardegna|toscana|piemonte|veneto|campania|puglia';
  var REGOLE = [
    // giudizi sulla persona (positivi o negativi): non si giudica chi gioca, si descrivono le partite
    { c: 'persona', re: p('aggressiv|impulsiv|fragil|nervos|emotiv|impaurit|pauros|timid|insicur|arrogant|presuntuos|svogliat|sbadat|incapac|mediocr|scarsissim|scars[oaie]|pessim|psicolog|personalit|mentalit|temperament|caratter') },
    { c: 'persona', re: w('debole|deboli|ha paura|teme|si innervosisce|si spaventa|va in tilt|in tilt|tilt|crolla|panico|perde la testa|cede sotto pressione|si arrende facilmente') },
    { c: 'persona', re: w('gioca (?:male|bene|malissimo|benissimo|da principiante)|non sa (?:giocare|difendersi|attaccare|calcolare)') },
    { c: 'persona', re: w('è (?:un|una|il|la) (?:giocator[ea]|persona|tipo|principiante|campione|esperto|dilettante)') },
    // età
    { c: 'età', re: w('età|anni|anno di nascita|compleanno|giovane|giovanissim[oa]|anzian[oa]|vecchi[oa]|ragazzin[oa]|ragazz[oa]|bambin[oa]|adolescente|minorenne|maggiorenne|generazione') },
    { c: 'età', re: new RegExp(L + '\\d{1,3}\\s*(?:anni|enne)' + R, 'iu') },
    { c: 'età', re: w('nat[oa] (?:nel|il|l\'|in|a)') },
    // luoghi
    { c: 'luogo', re: w('vive (?:a|in|nel|nella|negli)|abita|risiede|residente|residenza|originari[oa]|proviene|trasferit[oa]|città|paese|nazione|nazionalità|bandiera|regione') },
    { c: 'luogo', re: w(CITTA) }, { c: 'luogo', re: w(PAESI) },
    // presenza in linea / partita in corso
    { c: 'presenza', re: w('sta giocando|in questo momento|adesso gioca|gioca ora|è online|online|offline|connesso|connessa|ultimo accesso|ultima connessione|visto di recente|visto l\'ultima volta|attivo ora|in partita ora|in diretta') },
    // dati personali (realName, location, bio e simili)
    { c: 'dati personali', re: w('realname|real name|nome reale|nome vero|cognome|location|bio|biografia|avatar|foto|immagine del profilo|e-mail|email|telefono|indirizzo|instagram|facebook|twitter|social') },
    // tono da spia
    { c: 'spia', re: p('spia|spiare|spion|sorvegli|dossier|pedin|tracciar|schedat') },
    { c: 'spia', re: new RegExp('d[\'’]occhio|' + L + 'osservarl[oa]' + R, 'iu') },
    // promesse di risultato
    { c: 'promessa', re: w('vincerai|batterai|lo batti|la batti|vittoria (?:sicura|garantita|assicurata|certa)|di sicuro|sicuramente|certamente|facile da battere|perde sempre|non vince mai|punto debole definitivo|debolezza definitiva') },
    { c: 'promessa', re: new RegExp('(?<!non )' + L + 'garanti(?:sc|t)', 'iu') }
  ];
  var ESCLUSI = { soggetto: 1, campioneDettaglio: 1, tono: 1, subjectId: 1, eco: 1, servizio: 1 };

  /* x = scheda (o qualunque struttura); o = {aperture: [nomi da togliere prima del controllo]} → [{categoria, testo, percorso, regola}] */
  function controlla(x, o) {
    o = o || {};
    var nomi = (o.aperture || []).concat(raccogliAperture(x)).filter(Boolean).sort(function (a, b) { return b.length - a.length; });
    var out = [];
    (function giu(v, path) {
      if (typeof v === 'string') {
        var t = v; nomi.forEach(function (n) { t = t.split(n).join(' '); });
        REGOLE.forEach(function (r) { if (r.re.test(t)) out.push({ categoria: r.c, testo: v, percorso: path, regola: String(r.re) }); });
        return;
      }
      if (v && typeof v === 'object') Object.keys(v).forEach(function (k) { if (!ESCLUSI[k]) giu(v[k], path + (Array.isArray(v) ? '[' + k + ']' : '.' + k)); });
    })(x, '');
    return out;
  }
  function raccogliAperture(x) {
    var a = []; if (x && x.aperture) ['bianco', 'nero'].forEach(function (c) { (x.aperture[c] || []).forEach(function (r) { if (r && r.nome) a.push(r.nome); }); }); return a;
  }
  /* rete di sicurezza: un testo che non passa non si mostra (sostituito da un avviso neutro), la scheda segnala il blocco */
  function proteggi(scheda) {
    var trovati = controlla(scheda), bloccati = {};
    trovati.forEach(function (f) { bloccati[f.percorso] = f; });
    function sost(v, path) {
      if (typeof v === 'string') return bloccati[path] ? 'Testo non mostrato: non supera il controllo del tono.' : v;
      if (v && typeof v === 'object') { var c = Array.isArray(v) ? [] : {}; Object.keys(v).forEach(function (k) { c[k] = ESCLUSI[k] ? v[k] : sost(v[k], path + (Array.isArray(v) ? '[' + k + ']' : '.' + k)); }); return c; }
      return v;
    }
    var out = sost(scheda, ''); out.tono = trovati; out.tonoVersione = VERSIONE; out.testiBloccati = Object.keys(bloccati).length;
    return out;
  }
  return { controlla: controlla, proteggi: proteggi, REGOLE: REGOLE, VERSIONE: VERSIONE };
});
