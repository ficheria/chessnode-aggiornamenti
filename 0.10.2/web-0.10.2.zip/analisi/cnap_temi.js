/* Chess Node · Analisi profonda · FASE 2 · CNApTemi — i sei temi iniziali (DECISO Q01) come OCCASIONI verificabili (A1-06 §10.3, A1-07).
   Codice originale Chess Node (08/11/2026). Regola d'oro: un predicato geometrico trova un CANDIDATO, non prova la tattica.
   Un tema è «sicuro» (certezza 1) solo se:
     (a) il predicato è vero dopo la mossa tematica nella posizione;
     (b) la mossa tematica è la PRIMA scelta della verifica profonda (multipv 3) — cioè il motore l'ha controllata contro tutte le difese;
     (c) la conseguenza è confermata sulla linea verificata: matto, oppure guadagno di almeno 2 punti-pedone a fine linea
         (dopo la risposta difensiva del motore, contando solo a fine scambio).
   Senza verifica profonda: certezza 2 («perdita di materiale» generica), non conteggiata nei denominatori del difetto.
   Esito per il giocatore che aveva il tratto: «preso» (ha giocato la mossa tematica), «mancato» (no, con perdita ≥ soglia Imprecisione),
   «altra buona» (no, ma senza perdita significativa: non è un errore del tema).
   Doppioni: la stessa occasione (stesso tema, stessa mossa tematica) su semimosse consecutive dello stesso lato conta una volta.
   Temi: pezzo_indifeso, forchetta, inchiodatura, infilata, matto_non_visto, scoperta. Altri temi: NON in V1. */
(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api; else root.CNApTemi = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  var VERSIONE = 'cnap-temi-2';   // 2: ripresa esclusa, inchiodatura relativa solo con un pezzo davanti, niente scoperta su arrocco, solo matto sulle linee di matto
  var VAL = { p: 1, n: 3, b: 3, r: 5, q: 9, k: 100 };
  var GUADAGNO_MIN = 2, MATTO_MAX = 10, PERDITA_MANCATO = 7;   // 7 = soglia Imprecisione (5) + margine (2) di cnap_classifica
  var NOMI = { pezzo_indifeso: 'Pezzo indifeso', forchetta: 'Forchetta', inchiodatura: 'Inchiodatura', infilata: 'Infilata', matto_non_visto: 'Matto non visto', scoperta: 'Attacco di scoperta' };
  var DIR = { r: [[1, 0], [-1, 0], [0, 1], [0, -1]], b: [[1, 1], [1, -1], [-1, 1], [-1, -1]] };
  DIR.q = DIR.r.concat(DIR.b);

  function sq2(s) { return { f: s.charCodeAt(0) - 97, r: +s[1] - 1 }; }
  function nome(f, r) { return String.fromCharCode(97 + f) + (r + 1); }
  function pezzo(c, s) { return c.get(s) || null; }
  /* case attaccate da un pezzo (raggi fermati dal primo pezzo) */
  function attacchi(c, s) {
    var p = pezzo(c, s); if (!p) return [];
    var o = sq2(s), out = [], t = p.type;
    if (t === 'p') { var dir = p.color === 'w' ? 1 : -1; [-1, 1].forEach(function (df) { var f = o.f + df, r = o.r + dir; if (f >= 0 && f < 8 && r >= 0 && r < 8) out.push(nome(f, r)); }); return out; }
    if (t === 'n') { [[1, 2], [2, 1], [-1, 2], [-2, 1], [1, -2], [2, -1], [-1, -2], [-2, -1]].forEach(function (d) { var f = o.f + d[0], r = o.r + d[1]; if (f >= 0 && f < 8 && r >= 0 && r < 8) out.push(nome(f, r)); }); return out; }
    if (t === 'k') { for (var a = -1; a <= 1; a++) for (var b = -1; b <= 1; b++) if (a || b) { var f2 = o.f + a, r2 = o.r + b; if (f2 >= 0 && f2 < 8 && r2 >= 0 && r2 < 8) out.push(nome(f2, r2)); } return out; }
    DIR[t].forEach(function (d) { var f = o.f + d[0], r = o.r + d[1]; while (f >= 0 && f < 8 && r >= 0 && r < 8) { var n = nome(f, r); out.push(n); if (c.get(n)) break; f += d[0]; r += d[1]; } });
    return out;
  }
  /* primi due pezzi lungo ogni raggio di un pezzo a lungo raggio */
  function raggi(c, s) {
    var p = pezzo(c, s); if (!p || !DIR[p.type]) return [];
    var o = sq2(s), out = [];
    DIR[p.type].forEach(function (d) {
      var f = o.f + d[0], r = o.r + d[1], trovati = [];
      while (f >= 0 && f < 8 && r >= 0 && r < 8 && trovati.length < 2) { var n = nome(f, r), q = c.get(n); if (q) trovati.push({ sq: n, p: q }); f += d[0]; r += d[1]; }
      out.push(trovati);
    });
    return out;
  }
  function difeso(c, s, colore) { return c.attackers(s, colore).length > 0; }
  function materiale(c, lato) { var t = 0; c.board().forEach(function (riga) { riga.forEach(function (x) { if (x && x.type !== 'k') t += (x.color === lato ? 1 : -1) * VAL[x.type]; }); }); return t; }

  /* predicati: posizione PRIMA (c0) e DOPO (c1) la mossa tematica m (verbose chess.js) */
  function predicati(c0, c1, m) {
    var noi = m.color, loro = noi === 'w' ? 'b' : 'w', out = {}, val = function (p) { return VAL[p.type]; };
    // pezzo indifeso: la mossa cattura un pezzo non difeso o di valore maggiore del catturante
    if (m.captured && m.captured !== 'k') { var dif = difeso(c0, m.to, loro); if (!dif || VAL[m.captured] > VAL[m.piece]) out.pezzo_indifeso = { bersaglio: m.to, pezzo: m.captured, difeso: dif }; }
    // forchetta (incluso attacco doppio): il pezzo mosso attacca ≥2 bersagli utili (Re, pezzo di valore maggiore, o non difeso)
    var bers = attacchi(c1, m.to).map(function (s) { return { sq: s, p: c1.get(s) }; }).filter(function (x) {
      return x.p && x.p.color === loro && (x.p.type === 'k' || VAL[x.p.type] > VAL[m.promotion || m.piece] || (!difeso(c1, x.sq, loro) && x.p.type !== 'p'));
    });
    if (bers.length >= 2) out.forchetta = { pezzo: m.promotion || m.piece, da: m.to, bersagli: bers.map(function (x) { return x.sq; }) };
    // inchiodatura e infilata create dal pezzo mosso (a lungo raggio)
    raggi(c1, m.to).forEach(function (t) {
      if (t.length < 2 || t[0].p.color !== loro || t[1].p.color !== loro) return;
      var a = t[0].p, b = t[1].p;
      if (a.type !== 'k' && (b.type === 'k' || (a.type !== 'p' && VAL[b.type] > VAL[a.type]))) out.inchiodatura = out.inchiodatura || { inchiodato: t[0].sq, dietro: t[1].sq, assoluta: b.type === 'k' };
      if ((a.type === 'k' || VAL[a.type] > VAL[b.type]) && b.type !== 'k') out.infilata = out.infilata || { davanti: t[0].sq, dietro: t[1].sq };
    });
    // scoperta: un NOSTRO pezzo a lungo raggio, diverso da quello mosso, ora attacca Re o pezzo ≥3 che prima non attaccava
    // (l'arrocco muove due pezzi: non è una scoperta)
    if (!/[kq]/.test(m.flags)) c1.board().forEach(function (riga) { riga.forEach(function (x) {
      if (!x || x.color !== noi || !DIR[x.type] || x.square === m.to) return;
      var prima = attacchi(c0, x.square), dopo = attacchi(c1, x.square);
      dopo.forEach(function (s) { var q = c1.get(s); if (q && q.color === loro && (q.type === 'k' || VAL[q.type] >= 3) && prima.indexOf(s) < 0) out.scoperta = out.scoperta || { pezzo: x.type, da: x.square, bersaglio: s, scacco: q.type === 'k' }; });
    }); });
    return out;
  }
  /* conseguenza sulla linea verificata (SAN): matto o guadagno ≥ GUADAGNO_MIN, contato a fine scambio */
  function conseguenza(Chess, fen, pvSan, lato, fenBase) {
    var c = new Chess(fen), base = materiale(fenBase ? new Chess(fenBase) : c, lato), g = null;
    for (var i = 0; i < pvSan.length; i++) {
      var m; try { m = c.move(pvSan[i]); } catch (e) { return null; }
      if (c.isCheckmate()) return { tipo: 'matto', semimosse: i + 1, lato: m.color === lato ? 'noi' : 'loro' };
      if (i % 2 === 1) g = materiale(c, lato) - base;   // si conta solo dopo la risposta dell'avversario (mai a metà di uno scambio a nostro favore)
    }
    return g == null ? null : { tipo: 'materiale', guadagno: g, semimosse: pvSan.length - (pvSan.length % 2) };
  }

  /* case su cui il lato `lato` cattura qualcosa lungo la linea */
  function catture(Chess, fen, pvSan, lato) {
    var c = new Chess(fen), out = [];
    for (var i = 0; i < pvSan.length; i++) { var m; try { m = c.move(pvSan[i]); } catch (e) { break; } if (m.captured && m.color === lato) out.push(m.to); }
    return out;
  }

  /* d = {gameId, fens, ucis, ids, cols, posizioni (positionResults), verifiche (rec.V), Chess} → {versione, occasioni[], riepilogo} */
  function rileva(d) {
    var Chess = d.Chess, occ = [], visti = {};
    for (var k = 0; k < d.ucis.length; k++) {
      var V = d.verifiche[k], pr = d.posizioni[k], lato = d.cols[k];
      var linea = V && V.linee && V.linee[0];
      if (!linea || !linea.pvSan || !linea.pvSan.length) continue;   // senza verifica profonda nessuna occasione conteggiabile
      var c0 = new Chess(d.fens[k]), c1 = new Chess(d.fens[k]), m;
      try { m = c1.move(linea.pvSan[0]); } catch (e) { continue; }
      var temi = {};
      if (linea.mate != null && linea.mate > 0 && linea.mate <= MATTO_MAX) temi.matto_non_visto = { matto: linea.mate };
      // RIPRESA: se l'avversario ha appena catturato, il guadagno si misura da PRIMA della sua cattura (riprendere un pezzo non è un tema)
      var ripresa = false; if (k > 0) { try { var cp = new Chess(d.fens[k - 1]); var mp = cp.move({ from: d.ucis[k - 1].slice(0, 2), to: d.ucis[k - 1].slice(2, 4), promotion: d.ucis[k - 1][4] }); ripresa = !!(mp && mp.captured); } catch (e) {} }
      var pred = predicati(c0, c1, m), cons = conseguenza(Chess, d.fens[k], linea.pvSan.slice(0, 8), lato, ripresa ? d.fens[k - 1] : null);
      if (ripresa && pred.pezzo_indifeso && m.to === d.ucis[k - 1].slice(2, 4)) delete pred.pezzo_indifeso;
      var confermato = cons && ((cons.tipo === 'matto' && cons.lato === 'noi') || (cons.tipo === 'materiale' && cons.guadagno >= GUADAGNO_MIN));
      // il bersaglio del tema deve davvero cadere nella linea verificata (o il tema dà matto): la geometria da sola non basta
      var presi = catture(Chess, d.fens[k], linea.pvSan.slice(0, 8), lato), cadde = function (sqs) { return sqs.some(function (s) { return presi.indexOf(s) >= 0; }); };
      var matto = cons && cons.tipo === 'matto' && cons.lato === 'noi';
      if (matto) pred = {};   // linea di matto: il tema è il matto; niente forchette/infilate «di contorno» (deviazione ecc. non sono in V1)
      if (confermato) Object.keys(pred).forEach(function (t) {
        var x = pred[t], ok = t === 'pezzo_indifeso' ? true
          : t === 'forchetta' ? matto || cadde(x.bersagli)
          : t === 'inchiodatura' ? matto || cadde([x.inchiodato, x.dietro])
          : t === 'infilata' ? matto || cadde([x.dietro])
          : t === 'scoperta' ? matto || cadde([x.bersaglio]) || x.scacco : false;
        if (ok) temi[t] = x;
      });
      Object.keys(temi).forEach(function (t) {
        var chiave = t + '|' + lato + '|' + linea.uci, prec = visti[chiave];
        if (prec != null && k - prec <= 2) { visti[chiave] = k; return; }   // stessa occasione ripetuta sulla semimossa successiva dello stesso lato
        visti[chiave] = k;
        var esito = d.ucis[k] === linea.uci ? 'preso' : (pr && pr.labelInfo && pr.labelInfo.loss >= PERDITA_MANCATO ? 'mancato' : 'altra buona');
        if (t === 'matto_non_visto' && esito === 'altra buona' && V.mG != null) esito = 'preso (matto mantenuto)';
        occ.push({ opportunityId: 'OP-' + d.gameId + '-' + k + '-' + t, tema: t, nome: NOMI[t], lato: lato, gameId: d.gameId, nodeId: d.ids[k], ply: k + 1,
          mossaTematica: linea.uci, mossaTematicaSan: linea.pvSan[0], giocata: d.ucis[k], esito: esito, gravita: pr ? pr.label : null, certezza: 1,
          prova: { predicato: temi[t], conseguenza: t === 'matto_non_visto' ? { tipo: 'matto', in: linea.mate } : cons, linea: linea.pvSan.slice(0, 8), profondita: V.profondita, multipv: V.linee.length },
          detectorVersion: VERSIONE });
      });
    }
    var rip = {}; occ.forEach(function (o) { var r = rip[o.tema] = rip[o.tema] || { occasioni: 0, prese: 0, mancate: 0 }; r.occasioni++; if (/^preso/.test(o.esito)) r.prese++; if (o.esito === 'mancato') r.mancate++; });
    return { versione: VERSIONE, occasioni: occ, riepilogo: rip };
  }

  return { rileva: rileva, predicati: predicati, conseguenza: conseguenza, attacchi: attacchi, NOMI: NOMI, VERSIONE: VERSIONE, GUADAGNO_MIN: GUADAGNO_MIN };
});
