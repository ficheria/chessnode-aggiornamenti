/* Chess Node · Analisi profonda · FASE 1 · CNApBackend — interfaccia di archiviazione comune (DECISO Q10).
   Due implementazioni con la STESSA interfaccia: IndexedDB (web e WebView Capacitor) e memoria (test, anteprima).
   Una futura SQLite deve solo rispettare questo contratto: tx(stores, mode, fn) atomica, con t.get/put/del/all/byIndex/count.
   Codice originale Chess Node (08/11/2026). Nessuna dipendenza.
   Regola importante per chi scrive fn: dentro una transazione usare SOLO await su operazioni t.*; niente fetch, timer o
   crypto.subtle (IndexedDB chiuderebbe la transazione). Tutti i calcoli si fanno prima, in staging. */
(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api; else root.CNApBackend = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';

  var DB_VERSION = 1;
  /* collezioni logiche (A1-04 §8) + diagnostica import, registro fusioni, copia legacy, cache ricostruibile, meta */
  var STORES = {
    games:            { key: 'gameId', idx: { playedAtMs: 'playedAtMs', monthRome: 'monthRome', scope: ['scopeRefs', true], archiveState: 'archiveState', contentKey: 'contentKey' } },
    gameSources:      { key: 'sourceRevKey', idx: { gameId: 'gameId', sourceKey: 'sourceKey' } },
    nodes:            { key: 'nodeId', idx: { gameId: 'gameId' } },
    analyses:         { key: 'analysisId', idx: { gameId: 'gameId', status: 'status' } },
    analysisJobs:     { key: 'jobId', idx: { status: 'status', gameId: 'gameId' } },
    profileSnapshots: { key: 'snapshotId', idx: { subjectId: 'subjectId' } },
    exerciseRefs:     { key: 'refId', idx: { gameId: 'gameId' } },
    diagnostics:      { key: 'diagId', idx: { batchId: 'batchId' } },
    mergeLog:         { key: 'mergeId', idx: { keptGameId: 'keptGameId' } },
    legacy:           { key: 'key', idx: {} },
    cache:            { key: 'key', idx: { cleanupClass: 'cleanupClass' } },
    meta:             { key: 'key', idx: {} }
  };

  function erroreSpazio(causa) { var e = new Error('Spazio di archiviazione esaurito: nessuna modifica salvata.'); e.code = 'SPAZIO'; e.causa = causa; return e; }
  function clone(v) { return v === undefined ? undefined : JSON.parse(JSON.stringify(v)); }
  function leggiPercorso(o, p) { return o == null ? undefined : o[p]; }

  /* ================= memoria (test/anteprima) — atomica con copia su scrittura, quota simulabile ================= */
  function memoria(o) {
    o = o || {};
    var dati = {}; Object.keys(STORES).forEach(function (s) { dati[s] = new Map(); });
    var quota = o.quotaByte || Infinity, guastoScrittura = null;
    function byteTotali(view) {
      var n = 0; Object.keys(STORES).forEach(function (s) { view(s).forEach(function (v) { n += JSON.stringify(v).length * 2; }); }); return n;
    }
    var api = {
      tipo: 'memoria',
      tx: async function (stores, mode, fn) {
        var mod = {};   // store → Map(key → valore|null)
        function vista(s) {
          var m = new Map(dati[s]); if (mod[s]) mod[s].forEach(function (v, k) { if (v === null) m.delete(k); else m.set(k, v); }); return m;
        }
        function chk(s) { if (stores.indexOf(s) < 0) throw new Error('Store «' + s + '» non incluso nella transazione'); }
        var t = {
          get: async function (s, k) { chk(s); var v = vista(s).get(k); return clone(v); },
          put: async function (s, v) { chk(s); if (mode !== 'readwrite') throw new Error('Transazione in sola lettura'); var k = leggiPercorso(v, STORES[s].key); if (k == null) throw new Error('Chiave mancante per ' + s); (mod[s] = mod[s] || new Map()).set(k, clone(v)); },
          del: async function (s, k) { chk(s); if (mode !== 'readwrite') throw new Error('Transazione in sola lettura'); (mod[s] = mod[s] || new Map()).set(k, null); },
          all: async function (s) { chk(s); return Array.from(vista(s).values()).map(clone); },
          byIndex: async function (s, idx, val) {
            chk(s); var def = STORES[s].idx[idx]; var path = Array.isArray(def) ? def[0] : def, multi = Array.isArray(def) && def[1];
            return Array.from(vista(s).values()).filter(function (v) { var x = leggiPercorso(v, path); return multi && Array.isArray(x) ? x.indexOf(val) >= 0 : x === val; }).map(clone);
          },
          count: async function (s) { chk(s); return vista(s).size; }
        };
        var r = await fn(t);
        if (mode === 'readwrite') {
          if (guastoScrittura) { var g = guastoScrittura; guastoScrittura = null; throw g; }
          if (quota !== Infinity) { var tot = byteTotali(vista); if (tot > quota) throw erroreSpazio('quota simulata ' + quota + ' byte superata (' + tot + ')'); }
          Object.keys(mod).forEach(function (s) { mod[s].forEach(function (v, k) { if (v === null) dati[s].delete(k); else dati[s].set(k, v); }); });
        }
        return r;
      },
      /* solo test: fa fallire la PROSSIMA transazione di scrittura al commit (simula crash/processo terminato) */
      _guastoAlProssimoCommit: function (e) { guastoScrittura = e || erroreSpazio('guasto simulato'); },
      _impostaQuota: function (q) { quota = q; },
      _dump: function () { var o2 = {}; Object.keys(dati).forEach(function (s) { o2[s] = Array.from(dati[s].values()).map(clone); }); return o2; },
      chiudi: async function () {}
    };
    return api;
  }

  /* ================= IndexedDB ================= */
  function indexedDB_(o) {
    o = o || {};
    var IDB = o.indexedDB || (typeof indexedDB !== 'undefined' ? indexedDB : null);
    if (!IDB) throw new Error('IndexedDB non disponibile in questo ambiente');
    var nome = o.nome || 'chessnodeplay-analisi', dbP = null;
    function apri() {
      if (dbP) return dbP;
      dbP = new Promise(function (res, rej) {
        var rq = IDB.open(nome, DB_VERSION);
        rq.onupgradeneeded = function () {
          var db = rq.result;
          Object.keys(STORES).forEach(function (s) {
            if (db.objectStoreNames.contains(s)) return;
            var os = db.createObjectStore(s, { keyPath: STORES[s].key });
            Object.keys(STORES[s].idx).forEach(function (i) { var d = STORES[s].idx[i]; os.createIndex(i, Array.isArray(d) ? d[0] : d, { multiEntry: Array.isArray(d) && !!d[1] }); });
          });
        };
        rq.onsuccess = function () { res(rq.result); };
        rq.onerror = function () { rej(rq.error); };
        rq.onblocked = function () { rej(new Error('Archivio bloccato da un\'altra scheda aperta')); };
      });
      return dbP;
    }
    function req(r) { return new Promise(function (res, rej) { r.onsuccess = function () { res(r.result); }; r.onerror = function (e) { e.preventDefault(); rej(r.error); }; }); }
    return {
      tipo: 'indexeddb', nome: nome,
      tx: async function (stores, mode, fn) {
        var db = await apri(), tr = db.transaction(stores, mode), finito;
        var fatto = new Promise(function (res, rej) {
          tr.oncomplete = function () { res(); };
          tr.onabort = function () { var e = tr.error; rej(e && e.name === 'QuotaExceededError' ? erroreSpazio(e.message) : (e || finito || new Error('Transazione annullata'))); };
          tr.onerror = function (ev) { /* gestito in onabort */ };
        });
        fatto.catch(function () {});
        var t = {
          get: function (s, k) { return req(tr.objectStore(s).get(k)); },
          put: function (s, v) { return req(tr.objectStore(s).put(v)); },
          del: function (s, k) { return req(tr.objectStore(s).delete(k)); },
          all: function (s) { return req(tr.objectStore(s).getAll()); },
          byIndex: function (s, i, v) { return req(tr.objectStore(s).index(i).getAll(v)); },
          count: function (s) { return req(tr.objectStore(s).count()); }
        };
        var r;
        try { r = await fn(t); }
        catch (e) { finito = e; try { tr.abort(); } catch (e2) {} try { await fatto; } catch (e3) { if (e3 && e3.code === 'SPAZIO') throw e3; } throw e; }
        await fatto;
        return r;
      },
      chiudi: async function () { if (dbP) { (await dbP).close(); dbP = null; } },
      elimina: async function () { if (dbP) { (await dbP).close(); dbP = null; } await new Promise(function (res, rej) { var r = IDB.deleteDatabase(nome); r.onsuccess = res; r.onerror = function () { rej(r.error); }; r.onblocked = res; }); }
    };
  }

  return { memoria: memoria, indexedDB: indexedDB_, STORES: STORES, DB_VERSION: DB_VERSION, VERSIONE: 'cnap-backend-1' };
});
