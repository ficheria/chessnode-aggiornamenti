/* Chess Node · Analisi profonda · FASE 4 · CNApCapitoli — ponte verso i capitoli ESISTENTI di Studia, senza inventare ID.
   Codice originale Chess Node (09/11/2026).
   Elenco di BOOK.chapters fornito da Kiko il 09/11/2026 19:39 (id — nome), usato così com'è:
     m1 Matto in una · m2 Matto in due · dbl Attacco doppio · disa Attacco di scoperta · disc Scacco di scoperta · dch Scacco doppio ·
     pin Inchiodatura · skew Infilata · defl Deviazione · decoy Sacrificio di adescamento · promo Promozione · fin Finali ·
     draw Tattiche di patta · mid Mediogioco · m3 Matto in tre · m4 Matto in quattro · def Difesa
   Regole di Kiko: forchetta = dbl, inchiodatura = pin; miss e cur NON sono capitoli; si collega SOLO con tema verificato;
   m3/m4 pronti ma solo con matto in 3/4 certificato (oggi la certificazione arriva al matto in 2); fin e mid con cautela
   (Finali seconda fase, Strategia/mid V2) → qui NON collegati. In più il collegamento si crea solo se l'ID è presente a runtime. */
(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api; else root.CNApCapitoli = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  var VERSIONE = 'cnap-capitoli-2';
  var CAPITOLI = { m1: 'Matto in una', m2: 'Matto in due', dbl: 'Attacco doppio', disa: 'Attacco di scoperta', disc: 'Scacco di scoperta', dch: 'Scacco doppio',
    pin: 'Inchiodatura', skew: 'Infilata', defl: 'Deviazione', decoy: 'Sacrificio di adescamento', promo: 'Promozione', fin: 'Finali',
    draw: 'Tattiche di patta', mid: 'Mediogioco', m3: 'Matto in tre', m4: 'Matto in quattro', def: 'Difesa' };
  /* tema verificato (CNApTemi v2 / CNApControlli) → capitolo */
  var MAPPA_TEMI = { forchetta: 'dbl', inchiodatura: 'pin', infilata: 'skew', difesa: 'def' };   // scoperta: disa o disc, vedi sotto
  var CENSIMENTO = {
    fonte: 'Elenco BOOK.chapters fornito da Kiko il 09/11/2026 (id e nome), più app.js:254 MATE_N per m1–m4',
    collegati: { m1: 'matto in 1 certificato', m2: 'matto in 2 certificato', m3: 'matto in 3 certificato (oggi mai: certificazione fino a 2)', m4: 'matto in 4 certificato (come m3)',
      dbl: 'tema forchetta verificato', pin: 'tema inchiodatura verificato', skew: 'tema infilata verificato',
      disa: 'tema attacco di scoperta verificato, senza scacco', disc: 'tema attacco di scoperta verificato CON scacco', def: 'esercizio di difesa con minaccia dimostrata' },
    nonCollegati: { dch: 'scacco doppio: nessun rilevatore verificato in V1', defl: 'deviazione: tema non in V1 (Q01)', decoy: 'adescamento: tema non in V1 (Q01)',
      promo: 'promozione: non è uno dei sei temi Q01; servirebbe una nuova approvazione', fin: 'Finali: seconda fase, collegamento solo con tema verificato (non ancora)',
      mid: 'Mediogioco/Strategia: V2', draw: 'tattiche di patta: obiettivo non previsto in V1', pezzo_indifeso: 'nessun capitolo corrispondente',
      geniale: '«Ritrova la tua mossa» non va nei capitoli (è la tua mossa, non un esercizio del capitolo)' },
    maiCapitoli: { miss: 'piazzamento, non è un capitolo', cur: 'curiosità, non è un capitolo' }
  };
  /* capitoliPresenti: ID davvero presenti a runtime (BOOK.chapters.map(c => c.id)); null = sconosciuto → nessun link */
  function collocazioni(ex, capitoliPresenti) {
    var out = [];
    if (!ex || (ex.validationStatus !== 'approved' && !ex._inApprovazione)) return out;
    if (!Array.isArray(capitoliPresenti) || ex.exerciseType === 'ritrova') return out;
    var ob = ex.objective || {}, tags = ex.themeTags || [], prove = ex.themeEvidence || {};
    function aggiungi(id, tema, motivo) {
      if (!CAPITOLI[id] || CENSIMENTO.maiCapitoli[id] || capitoliPresenti.indexOf(id) < 0) return;
      if (out.some(function (p) { return p.chapterId === id; })) return;
      out.push({ placementId: 'PL-' + ex.exerciseId + '-' + id, exerciseId: ex.exerciseId, kind: 'chapter', chapterId: id, verifiedTheme: tema, motivo: motivo });
    }
    if (ob.tipo === 'matto' && ob.esatto && ob.n >= 1 && ob.n <= 4 && ex.certification && ex.certification.certo && ex.certification.n === ob.n)
      aggiungi('m' + ob.n, 'matto_non_visto', 'matto in ' + ob.n + ' certificato contro ogni difesa');
    tags.forEach(function (t) {
      if (!prove[t]) return;   // tema senza prova registrata: nessun link
      if (t === 'scoperta') { var sc = prove[t].predicato && prove[t].predicato.scacco; aggiungi(sc ? 'disc' : 'disa', t, sc ? 'scoperta con scacco verificata' : 'attacco di scoperta verificato'); return; }
      if (t === 'difesa') { if (ex.threat && ex.threat.dimostrata) aggiungi('def', t, 'minaccia dimostrata e difesa verificata'); return; }
      if (MAPPA_TEMI[t]) aggiungi(MAPPA_TEMI[t], t, 'tema ' + t + ' verificato (predicato + bersaglio catturato nella linea)');
    });
    return out;
  }
  function spiega(tema) { return CENSIMENTO.nonCollegati[tema] || null; }
  return { collocazioni: collocazioni, spiega: spiega, CAPITOLI: CAPITOLI, MAPPA_TEMI: MAPPA_TEMI, CENSIMENTO: CENSIMENTO, VERSIONE: VERSIONE };
});
