/* Chess Node · Analisi profonda · FASE 4 · CNApRipasso — ADATTATORE del ripasso esistente 1·3·7 (stats.js), nessun secondo scheduler.
   Codice originale Chess Node (09/11/2026). Lavora sugli STESSI dati di stats.js ('chessnodeplay-stats-v1': d.rev, d.rd, d.lc) e con
   le STESSE regole (STEPS [1,3,7], MAXDAY 10, ordine «scadenza più vecchia, poi più sbagliati»), aggiungendo solo:
   - un risolutore di ID con namespace: «123» = biblioteca n.123 (come oggi), «p:P-…» = esercizio personale. Oggi stats.js fa
     Object.keys(d.rev).map(Number): un ID personale diventerebbe NaN e sparirebbe (A3-C01). Qui nessuna perdita;
   - giorni di calendario di Europe/Rome (somma di giorni sul calendario, non 24 h: ora legale indifferente);
   - limite di 10 al giorno CONDIVISO tra personali e biblioteca (limite, non obiettivo: se ce ne sono 3 se ne propongono 3);
   - nessuna penalità per i giorni saltati: chi è scaduto resta scaduto, senza moltiplicatori.
   La patch per stats.js (fase 6) è descritta in DIFFERENZE_PROPOSTE: sostituire queue() con risolvi(). Qui NON si tocca app/web. */
(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api; else root.CNApRipasso = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  var MAXDAY = 10, STEPS = [1, 3, 7], POLICY = 'legacy-1-3-7-adapter';
  function addDays(k, n) { var p = k.split('-'), t = Date.UTC(+p[0], +p[1] - 1, +p[2] + n); var d = new Date(t); return d.getUTCFullYear() + '-' + ('0' + (d.getUTCMonth() + 1)).slice(-2) + '-' + ('0' + d.getUTCDate()).slice(-2); }
  function daysBetween(a, b) { var pa = a.split('-'), pb = b.split('-'); return Math.round((Date.UTC(+pb[0], pb[1] - 1, +pb[2]) - Date.UTC(+pa[0], pa[1] - 1, +pa[2])) / 86400000); }
  /* chiave del ripasso ↔ exerciseId */
  function chiave(exerciseId) { var m = /^library:(\d+)$/.exec(exerciseId); return m ? m[1] : 'p:' + exerciseId; }
  function risolvi(k) {
    k = String(k);
    if (/^\d+$/.test(k)) return { chiave: k, fonte: 'biblioteca', exerciseId: 'library:' + k, n: +k };
    if (/^p:.+/.test(k)) return { chiave: k, fonte: 'personale', exerciseId: k.slice(2) };
    return null;   // chiave sconosciuta: ignorata ma NON cancellata
  }
  function cmpChiave(a, b) { var na = /^\d+$/.test(a), nb = /^\d+$/.test(b); if (na && nb) return +a - +b; if (na !== nb) return na ? -1 : 1; return a < b ? -1 : a > b ? 1 : 0; }

  /* d = {dati: () => oggetto stats (d.rev, d.rd, d.lc), oggi: () => 'YYYY-MM-DD' (Roma), esiste: (exerciseId) => bool, salva?: () => void} */
  function crea(o) {
    function D() { var x = o.dati(); x.rev = x.rev || {}; x.rd = x.rd || { day: '', done: [] }; x.rcons = x.rcons || {}; return x; }
    function oggi() { return o.oggi(); }
    function rday() { var x = D(), k = oggi(); if (!x.rd || x.rd.day !== k) x.rd = { day: k, done: [] }; return x.rd; }
    function coda() { return Object.keys(D().rev).map(risolvi).filter(function (r) { return r && (!o.esiste || o.esiste(r.exerciseId)); }); }
    function dovuti() {
      var x = D(), k = oggi();
      return coda().filter(function (r) { return x.rev[r.chiave].due <= k; }).sort(function (a, b) {
        var ra = x.rev[a.chiave], rb = x.rev[b.chiave];
        return (ra.due < rb.due ? -1 : ra.due > rb.due ? 1 : 0) || ((rb.w || 0) - (ra.w || 0)) || cmpChiave(a.chiave, b.chiave);
      });
    }
    function diOggi() { var r = rday(), resto = Math.max(0, MAXDAY - r.done.length); return dovuti().filter(function (x) { return r.done.map(String).indexOf(String(x.chiave)) < 0 && r.done.indexOf(+x.chiave) < 0; }).slice(0, resto); }
    function isDue(exerciseId) { var r = D().rev[chiave(exerciseId)]; return !!(r && r.due <= oggi()); }
    function segnaFatto(k) { var r = rday(), v = /^\d+$/.test(k) ? +k : k; if (r.done.indexOf(v) < 0) r.done.push(v); }
    /* esito di un tentativo concluso (stesse regole di stats.js: fail = errore, 2° aiuto, soluzione vista, resa) */
    function registra(exerciseId, t) {
      var x = D(), k = chiave(exerciseId), dovuto = isDue(exerciseId), out;
      var perfetto = t.solved && !t.solutionShown && !t.errorCount && !t.hintLevels.some(function (h) { return h >= 2; });
      var fallito = t.solutionShown || t.errorCount > 0 || t.hintLevels.some(function (h) { return h >= 2; }) || t.arreso;
      if (fallito) {
        var r = x.rev[k] || (x.rev[k] = { s: 0, due: '', w: 0 });
        r.s = 0; r.w = (r.w || 0) + 1; r.due = addDays(oggi(), STEPS[0]); r.lastAttemptId = t.attemptId;
        if (dovuto) segnaFatto(k);
        delete x.rcons[k];
        out = { stato: 'da ripassare', fra: STEPS[0], tappa: 0 };
      } else if (perfetto && x.rev[k] && dovuto) {
        var e = x.rev[k]; segnaFatto(k); e.s++; e.lastAttemptId = t.attemptId;
        if (e.s >= STEPS.length) { delete x.rev[k]; x.lc = (x.lc || 0) + 1; x.rcons[k] = oggi(); out = { stato: 'consolidato', uscito: true }; }
        else { e.due = addDays(oggi(), STEPS[e.s]); out = { stato: 'da ripassare', fra: STEPS[e.s], tappa: e.s }; }
      } else out = { stato: x.rev[k] ? 'da ripassare' : 'invariato' };   // saltato senza errore o non dovuto: nessun cambiamento
      if (o.salva) o.salva();
      return out;
    }
    function stato(exerciseId) { var x = D(), k = chiave(exerciseId); if (x.rev[k]) return { inRipasso: true, due: x.rev[k].due, tappa: x.rev[k].s, dovuto: x.rev[k].due <= oggi(), errori: x.rev[k].w || 0 }; return { inRipasso: false, consolidato: !!x.rcons[k] }; }
    function quando(exerciseId) { var x = D(), r = x.rev[chiave(exerciseId)]; if (!r) return ''; var dd = daysBetween(oggi(), r.due); if (dd <= 0) return diOggi().some(function (y) { return y.exerciseId === exerciseId; }) ? 'oggi' : 'domani'; return dd === 1 ? 'domani' : 'fra ' + dd + ' g'; }
    /* rapporto di migrazione: quante voci, quali scadenze, prima e dopo il risolutore */
    function rapportoMigrazione() {
      var x = D(), chiavi = Object.keys(x.rev), legacy = chiavi.map(Number).filter(function (n) { return !isNaN(n); });
      return { vociTotali: chiavi.length, vistiDaStatsJsOggi: legacy.length, vistiDallAdattatore: coda().length, persiConMapNumber: chiavi.length - legacy.length,
        scadenze: chiavi.reduce(function (m, k) { m[k] = x.rev[k].due; return m; }, {}), policyVersion: POLICY };
    }
    return { coda: coda, dovuti: dovuti, diOggi: diOggi, isDue: isDue, registra: registra, stato: stato, quando: quando, rapportoMigrazione: rapportoMigrazione, chiave: chiave, risolvi: risolvi, MAXDAY: MAXDAY, STEPS: STEPS, POLICY: POLICY };
  }
  return { crea: crea, chiave: chiave, risolvi: risolvi, addDays: addDays, daysBetween: daysBetween, MAXDAY: MAXDAY, STEPS: STEPS, POLICY: POLICY };
});
