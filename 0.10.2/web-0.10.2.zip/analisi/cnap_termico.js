/* Chess Node · Analisi profonda · FASE 2 · CNApTermico — stato termico del dispositivo (DECISO Q10) → scheduler.
   Codice originale Chess Node (08/11/2026). Sul telefono legge il plugin nativo «ChessNodeThermal» (nativo/android, da compilare
   nell'APK solo dopo approvazione); sul web o su Android < 10 (API 29): «non disponibile», nessuna stima inventata.
   Mappa PowerManager.THERMAL_STATUS_*: NONE→normale, LIGHT→leggero, MODERATE→moderato, SEVERE→severo, CRITICAL/EMERGENCY/SHUTDOWN→critico. */
(function (root, factory) {
  'use strict';
  var api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api; else root.CNApTermico = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  var MAPPA = { 0: 'normale', 1: 'leggero', 2: 'moderato', 3: 'severo', 4: 'critico', 5: 'critico', 6: 'critico' };
  var AVVISI = { severo: 'Il telefono si sta scaldando: analisi in pausa finché non si raffredda. I risultati completati sono salvati.', critico: 'Il telefono è molto caldo: nessuna nuova analisi finché non si raffredda.' };
  function daCodice(c) { return MAPPA.hasOwnProperty(c) ? MAPPA[c] : 'non disponibile'; }
  /* collega plugin → scheduler; o.onAvviso(testo|null) per il messaggio FUORI dalla scacchiera */
  async function collega(plugin, scheduler, o) {
    o = o || {};
    var stato = 'non disponibile';
    function applica(c) { stato = daCodice(c); scheduler.termico(stato); if (o.onAvviso) o.onAvviso(AVVISI[stato] || null); return stato; }
    if (!plugin || typeof plugin.getStatus !== 'function') { scheduler.termico('non disponibile'); return { stato: function () { return stato; }, disponibile: false }; }
    try {
      var r = await plugin.getStatus();
      if (!r || r.supported === false) { scheduler.termico('non disponibile'); return { stato: function () { return stato; }, disponibile: false }; }
      applica(r.status);
      if (plugin.addListener) await plugin.addListener('thermalStatusChange', function (e) { applica(e && e.status); });
    } catch (e) { scheduler.termico('non disponibile'); return { stato: function () { return stato; }, disponibile: false, errore: String(e && e.message || e) }; }
    return { stato: function () { return stato; }, disponibile: true };
  }
  return { collega: collega, daCodice: daCodice, AVVISI: AVVISI, VERSIONE: 'cnap-termico-1' };
});
