/* Impostazioni > Suoni > "Musica di avvio" (predefinito: attiva). Salvata in prefs.introMusic.
   Con i Suoni spenti la musica di avvio non suona comunque: la casella resta com'è ma si disattiva con una nota. */
(function(){
  var A = window.__app, cb = document.getElementById('introMusic'), nota = document.getElementById('introMusicNota'), so = document.getElementById('soundOn');
  if (!A || !A.prefs || !cb) return;
  function sync(){ var off = A.prefs.sound === false; cb.checked = A.prefs.introMusic !== false; cb.disabled = off; if (nota) nota.hidden = !off; }
  cb.addEventListener('change', function(){ A.prefs.introMusic = cb.checked; A.savePrefs(); });
  if (so) so.addEventListener('change', sync);
  var sb = document.getElementById('soundBtn'); if (sb) sb.addEventListener('click', function(){ setTimeout(sync, 0); });
  sync();
})();
