/* Finestra "Condividi" (solo versione moderna): schede PGN, Immagine, GIF, con il marchio Chess Node.
   Tutto offline: il PNG lo disegna app.js (renderPNG), la GIF la codifica gifenc (lib/gifenc.js, MIT). */
(function(){
  'use strict';
  var A = window.__app;
  if (!A || !document.documentElement.classList.contains('moderna') || !document.getElementById('board')) return;
  var L = window.LUCIDE || {};
  var ICON = {
    copy: '<rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/>',
    download: L.download, x: L.x, share: L['share-2'], check: L.check
  };
  function svg(n, s){ return ICON[n] ? '<svg viewBox="0 0 24 24" width="' + (s || 20) + '" height="' + (s || 20) + '" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' + ICON[n] + '</svg>' : ''; }
  function esc(s){ return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;'); }
  function touch(){ return !!(window.matchMedia && window.matchMedia('(pointer: coarse)').matches); }

  // ---------- PGN ----------
  var IT = {K:'R', Q:'D', R:'T', B:'A', N:'C'};
  function itSan(san){ return san.replace(/^[KQRBN]/, function(c){ return IT[c]; }).replace(/=([QRBN])/, function(m, c){ return '=' + IT[c]; }); }
  function bare(s){ return String(s).replace(/[+#!?]/g, ''); }
  function book(e){ return e.__book || e.sol || []; }
  function clean(t){ return String(t == null ? '' : t).replace(/<[^>]+>/g, '').replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/[{}]/g, '').replace(/\s+/g, ' ').trim(); }
  function hdr(k, v){ return '[' + k + ' "' + String(v).replace(/\\/g, '\\\\').replace(/"/g, '\\"') + '"]'; }
  function exLab(e){ return e.c === 'pz' && e.pz ? 'Puzzle ' + e.pz.id : 'Esercizio ' + e.n; }   // 14-11: Puzzle Random con il suo nome
  function exFile(e){ return e.c === 'pz' && e.pz ? 'chessnode_puzzle_' + e.pz.id : 'chessnode_esercizio_' + e.n; }
  function chName(e){ var c = A.chById && A.chById[e.c]; return c ? c.name : ''; }
  // linea del libro in notazione inglese (quella che leggono Lichess e gli altri programmi)
  function line(e){
    var g = new Chess(e.fen), out = [], b = book(e);
    for (var i = 0; i < b.length; i++){
      var u = b[i][0], before = g.fen(), mv = null;
      try { mv = g.move({from:u.slice(0,2), to:u.slice(2,4), promotion:u[4] || undefined}); } catch(err){ mv = null; }
      if (!mv) break;
      out.push({san:mv.san, it:b[i][1] || itSan(mv.san), before:before, from:mv.from, to:mv.to});
    }
    return {moves:out, g:g};
  }
  // "Alternativa Stockfish" (difesa.js, in notazione italiana) -> mossa legale in notazione inglese
  function altSan(fen, it){
    try { var g = new Chess(fen), ms = g.moves(); for (var i = 0; i < ms.length; i++) if (bare(itSan(ms[i])) === bare(it)) return ms[i]; } catch(err){}
    return null;
  }
  function alts(e, L){
    var D = window.DIFESA || {}, r = {};
    (D[e.n] || []).forEach(function(x){ var m = L.moves[x.ply]; if (!m || bare(m.it) !== bare(x.libro)) return; var s = altSan(m.before, x.alt); if (s) r[x.ply] = s; });
    return r;
  }
  function resultOf(g){
    if (g.isCheckmate()) return g.turn() === 'w' ? '0-1' : '1-0';
    if (g.isStalemate() || g.isInsufficientMaterial() || g.isThreefoldRepetition()) return '1/2-1/2';
    return '*';
  }
  function placeText(e){ var N = {P:'pedone', N:'Cavallo', B:'Alfiere', R:'Torre', Q:'Donna'}; return e.place ? ' Soluzione: ' + (N[e.place[0]] || e.place[0]) + ' in ' + e.place[1] + '.' : ''; }
  function buildPGN(withC){
    var e = A.state.ex, Ln = line(e), now = new Date(), res = resultOf(Ln.g);
    var date = now.getFullYear() + '.' + ('0' + (now.getMonth() + 1)).slice(-2) + '.' + ('0' + now.getDate()).slice(-2);
    var H = [hdr('Event', 'Chess Node – ' + exLab(e)), hdr('Site', 'Chess Node'), hdr('Date', date), hdr('Round', String(e.n)),
      hdr('White', '?'), hdr('Black', '?'), hdr('Result', res), hdr('Capitolo', chName(e)), hdr('Annotator', 'Chess Node'),
      hdr('SetUp', '1'), hdr('FEN', e.fen)];
    var task = clean(A.taskText ? A.taskText(e) : '') , parts = [];
    if (withC && !Ln.moves.length){ var c = clean(task + placeText(e) + ' ' + (e.txt || '')); if (c) H.push(hdr('Comment', c)); }
    if (withC && Ln.moves.length && task) parts.push('{' + task + '}');
    var fin = withC && e.txt && clean(e.txt) ? '{' + clean(e.txt) + '}' : '';
    var V = withC ? alts(e, Ln) : {}, f = e.fen.split(' '), white = f[1] !== 'b', num = parseInt(f[5], 10) || 1, needNum = true;
    Ln.moves.forEach(function(m, i){
      parts.push(white ? num + '. ' + m.san : (needNum ? num + '... ' + m.san : m.san));
      needNum = false;
      // il commento finale va subito dopo l'ultima mossa (prima di un'eventuale variante): chess.js non accetta {..} dopo ")" in fondo
      if (i === Ln.moves.length - 1 && fin) parts.push(fin);
      if (V[i]) { parts.push('(' + (white ? num + '. ' : num + '... ') + V[i] + ' {Alternativa Stockfish})'); needNum = true; }
      if (!white) num++;
      white = !white;
    });
    parts.push(res);
    var body = '', ln = '';
    parts.join(' ').split(' ').forEach(function(w){ if (ln && (ln + ' ' + w).length > 79){ body += ln + '\n'; ln = w; } else ln = ln ? ln + ' ' + w : w; });
    return H.join('\n') + '\n\n' + body + ln + '\n';
  }

  /* ---------- 14-11 stampo: condividere QUALSIASI scacchiera (analisi, scacchiera libera, partite coi bot) ----------
     CNShare.open(tab, src) con src = {fen0, sans:[...SAN inglesi], titolo, sub, nome (base del file), orient 'w'|'b',
     ply (mossa mostrata, default = ultima), tags:{White, Black, Result, Event, Date}}. Senza src: esercizio/puzzle come prima. */
  var SRC = null;
  function srcLine(S){
    var g = new Chess(S.fen0 || undefined), out = [];
    (S.sans || []).forEach(function(san){ var b = g.fen(), mv = null; try { mv = g.move(san); } catch(err){ mv = null; } if (mv) out.push({san:mv.san, it:itSan(mv.san), before:b, from:mv.from, to:mv.to}); });
    return {moves:out, g:g};
  }
  function srcNow(S){   // posizione mostrata (ply) e ultima mossa
    var L = srcLine(S), n = S.ply == null ? L.moves.length : Math.max(0, Math.min(L.moves.length, S.ply)), g = new Chess(S.fen0 || undefined);
    for (var i = 0; i < n; i++) g.move(L.moves[i].san);
    return {g:g, lm:n ? {from:L.moves[n - 1].from, to:L.moves[n - 1].to} : null};
  }
  function srcPGN(S){
    var L = srcLine(S), now = new Date(), T = S.tags || {}, res = T.Result || resultOf(L.g);
    var date = T.Date || (now.getFullYear() + '.' + ('0' + (now.getMonth() + 1)).slice(-2) + '.' + ('0' + now.getDate()).slice(-2));
    var start = S.fen0 && S.fen0 !== new Chess().fen() ? S.fen0 : null;
    var H = [hdr('Event', T.Event || ('Chess Node – ' + (S.titolo || 'Analisi'))), hdr('Site', 'Chess Node'), hdr('Date', date),
      hdr('White', T.White || '?'), hdr('Black', T.Black || '?'), hdr('Result', res), hdr('Annotator', 'Chess Node')];
    if (start){ H.push(hdr('SetUp', '1')); H.push(hdr('FEN', start)); }
    var f = (start || new Chess().fen()).split(' '), white = f[1] !== 'b', num = parseInt(f[5], 10) || 1, parts = [], first = true;
    L.moves.forEach(function(m){ parts.push(white ? num + '. ' + m.san : (first ? num + '... ' + m.san : m.san)); first = false; if (!white) num++; white = !white; });
    parts.push(res);
    var body = '', ln = '';
    parts.join(' ').split(' ').forEach(function(w){ if (ln && (ln + ' ' + w).length > 79){ body += ln + '\n'; ln = w; } else ln = ln ? ln + ' ' + w : w; });
    return H.join('\n') + '\n\n' + body + ln + '\n';
  }
  function srcFrames(S){
    var L = srcLine(S), g = new Chess(S.fen0 || undefined), f = g.fen().split(' '), white = f[1] !== 'b', num = parseInt(f[5], 10) || 1, o = S.orient || 'w';
    var out = [{g:new Chess(g.fen()), lm:null, sub:S.sub || 'Posizione iniziale', d:1200, orient:o}];
    L.moves.forEach(function(m, i){
      g.move(m.san); var lab = (white ? num + '.' : num + '...') + m.it; if (!white) num++; white = !white;
      out.push({g:new Chess(g.fen()), lm:{from:m.from, to:m.to}, sub:lab + (g.isCheckmate() ? '  · matto' : ''), d:i === L.moves.length - 1 ? 3000 : 700, orient:o});
    });
    if (out.length > 121) out = [out[0]].concat(out.slice(out.length - 120));   // GIF leggera: al massimo le ultime 120 semimosse
    return out;
  }
  function srcEx(S, g){ return {n:0, c:'__stampo', fen:g.fen(), task:''}; }

  // ---------- GIF della soluzione ----------
  var LOGO_H = 56, GW = 480;
  function logoBand(ctx, w, label, sub){
    ctx.fillStyle = '#0B1F3A'; ctx.fillRect(0, 0, w, LOGO_H);
    var F = 'system-ui, "Segoe UI", Roboto, Arial, sans-serif', x = 14, y = LOGO_H / 2;
    ctx.fillStyle = '#165B27'; ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(x, y - 14, 28, 28, 7); else ctx.rect(x, y - 14, 28, 28); ctx.fill();
    ctx.fillStyle = '#fff'; ctx.font = '800 12px ' + F; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText('CN', x + 14, y + 1);
    ctx.textAlign = 'left'; ctx.font = '700 20px ' + F; x += 38;
    ctx.fillStyle = '#fff'; ctx.fillText('Chess', x, y + 1); x += ctx.measureText('Chess ').width;
    ctx.fillStyle = '#34A252'; ctx.fillText('Node', x, y + 1);
    ctx.textAlign = 'right'; ctx.fillStyle = '#BFD0E8'; ctx.font = '600 14px ' + F; ctx.fillText(label, w - 14, y - 9);
    ctx.fillStyle = '#679CD4'; ctx.font = '500 13px ' + F; ctx.fillText(sub, w - 14, y + 11, w - 200);
    ctx.textAlign = 'left';
  }
  function frames(e){
    var Ln = line(e), out = [], orient = A.state.orient || e.fen.split(' ')[1], side = e.fen.split(' ')[1] === 'w' ? 'il Bianco' : 'il Nero';
    out.push({g:new Chess(e.fen), lm:null, sub:'Muove ' + side, d:1500});
    if (Ln.moves.length){
      var g = new Chess(e.fen), f = e.fen.split(' '), white = f[1] !== 'b', num = parseInt(f[5], 10) || 1;
      Ln.moves.forEach(function(m, i){
        g.move(m.san);
        var lab = (white ? num + '.' : num + '...') + m.it;
        if (!white) num++; white = !white;
        out.push({g:new Chess(g.fen()), lm:{from:m.from, to:m.to}, sub:lab + (g.isCheckmate() ? '  · matto' : ''), d:i === Ln.moves.length - 1 ? 3000 : 1000});
      });
    } else if (e.place){
      // il pezzo da mettere: quello che dà matto (di solito del colore che non muove)
      var t = e.place[0].toLowerCase(), sq = e.place[1], opp = e.fen.split(' ')[1] === 'w' ? 'b' : 'w', opts = {};
      ['w', 'b'].forEach(function(c){ var g2 = new Chess(e.fen); try { if (g2.put({type:t, color:c}, sq)) opts[c] = g2; } catch(err){} });
      var pick = (opts[opp] && opts[opp].isCheckmate()) ? opts[opp] : (opts.w && opts.w.isCheckmate()) ? opts.w : (opts.b && opts.b.isCheckmate()) ? opts.b : (opts[opp] || null);
      if (pick) out.push({g:pick, lm:{from:sq, to:sq}, sub:'Pezzo in ' + sq, d:3000});
    }
    out.forEach(function(x){ x.orient = orient; });
    return out;
  }
  function makeGIF(e, onProg, S){
    if (!window.gifenc && window.cnLoadScript) return window.cnLoadScript('lib/gifenc.js').then(function(){ if (!window.gifenc) throw new Error('codificatore GIF mancante'); return makeGIF(e, onProg, S); });
    var G = window.gifenc; if (!G) return Promise.reject(new Error('codificatore GIF mancante'));
    var F = S ? srcFrames(S) : frames(e), enc = G.GIFEncoder(), cv = document.createElement('canvas'); cv.width = GW; cv.height = GW + LOGO_H;
    var ctx = cv.getContext('2d'), i = 0, saved = {lm:null};
    function next(){
      if (i >= F.length){ enc.finish(); return Promise.resolve(new Blob([enc.bytes()], {type:'image/gif'})); }
      var fr = F[i];
      return Promise.resolve(A.renderPNG(S ? {g:fr.g, ex:srcEx(S, fr.g), orient:fr.orient, lm:fr.lm, raw:true, cap:S.titolo || 'Chess Node', sub:fr.sub} : {g:fr.g, ex:e, orient:fr.orient, lm:fr.lm, raw:true})).then(function(r){
        var src = r.canvas, cap = src.height - src.width;
        logoBand(ctx, GW, S ? (S.etichetta || 'Analisi') : exLab(e), fr.sub);
        ctx.imageSmoothingQuality = 'high';
        ctx.drawImage(src, 0, cap, src.width, src.width, 0, LOGO_H, GW, GW);
        var data = ctx.getImageData(0, 0, cv.width, cv.height).data;
        var pal = G.quantize(data, 128), idx = G.applyPalette(data, pal);
        enc.writeFrame(idx, cv.width, cv.height, {palette:pal, delay:fr.d, repeat:0});
        i++; if (onProg) onProg(i / F.length);
        return new Promise(function(res){ setTimeout(res, 0); }).then(next);  // lascia respirare la pagina
      });
    }
    return next().then(function(b){ b.frames = F.length; return b; });
  }

  // ---------- consegna: condividi sul telefono, scarica sul computer ----------
  function download(blob, name){
    if (A.download) return A.download(blob, name);
    var u = URL.createObjectURL(blob), a = document.createElement('a'); a.href = u; a.download = name; document.body.appendChild(a); a.click(); a.remove(); setTimeout(function(){ URL.revokeObjectURL(u); }, 4000);
  }
  function deliver(blob, name, type, title){
    // nell'APK (android.js): salva il file e apre la condivisione di Android (Capacitor Filesystem + Share)
    if (typeof window.__cnNativeShare === 'function')
      return Promise.resolve(window.__cnNativeShare(blob, name, type, title)).catch(function(err){ if (!err || !/cancel/i.test(String(err.message || err))) toast('Non riesco a condividere'); });
    var file = null; try { file = new File([blob], name, {type:type}); } catch(err){}
    var can = false; try { can = !!(file && navigator.canShare && navigator.share && navigator.canShare({files:[file]})); } catch(err){}
    if ((touch() || (A.isNativeApp && A.isNativeApp())) && can)
      return navigator.share({files:[file], title:title}).catch(function(err){ if (!err || err.name !== 'AbortError') download(blob, name); });
    download(blob, name);
  }

  // ---------- finestra ----------
  var root = document.createElement('div');
  root.id = 'cnShare'; root.className = 'cns'; root.hidden = true;
  root.innerHTML =
    '<div class="cns-scrim"></div>' +
    '<div class="cns-card" role="dialog" aria-modal="true" aria-labelledby="cnsTitle" tabindex="-1">' +
      '<div class="cns-grab"></div>' +
      '<div class="cns-head"><h2 id="cnsTitle">Condividi</h2><button type="button" class="cns-x" aria-label="Chiudi">' + svg('x', 22) + '</button></div>' +
      '<div class="cns-tabs" role="tablist">' +
        '<button type="button" role="tab" data-t="pgn" aria-selected="true">PGN</button>' +
        '<button type="button" role="tab" data-t="img" aria-selected="false">Immagine</button>' +
        '<button type="button" role="tab" data-t="gif" aria-selected="false">GIF</button>' +
      '</div>' +
      '<div class="cns-body">' +
        '<section class="cns-pane" data-p="pgn">' +
          '<label class="cns-lab" for="cnsFen">FEN</label>' +
          '<div class="cns-field"><input id="cnsFen" readonly spellcheck="false"><button type="button" class="cns-copy" data-c="fen" aria-label="Copia FEN" title="Copia FEN">' + svg('copy', 20) + '</button></div>' +
          '<div class="cns-row"><label class="cns-lab" for="cnsPgn">PGN</label>' +
            '<label class="cns-chk"><input type="checkbox" id="cnsCom"><span>Con commenti</span></label></div>' +
          '<div class="cns-field cns-ta"><textarea id="cnsPgn" readonly spellcheck="false" rows="9"></textarea><button type="button" class="cns-copy" data-c="pgn" aria-label="Copia PGN" title="Copia PGN">' + svg('copy', 20) + '</button></div>' +
        '</section>' +
        '<section class="cns-pane" data-p="img" hidden><div class="cns-prev"><img id="cnsImg" alt="Anteprima dell\'immagine della posizione"><div class="cns-wait">Preparo l\'immagine…</div></div></section>' +
        '<section class="cns-pane" data-p="gif" hidden><div class="cns-prev"><img id="cnsGif" alt="GIF animata della soluzione"><div class="cns-wait"><span>Creo la GIF…</span><i class="cns-bar"><b></b></i></div></div><p class="cns-note"></p></section>' +
      '</div>' +
      '<div class="cns-foot"><button type="button" class="cns-dl">' + svg('download', 22) + '<span>Scarica</span></button></div>' +
      '<div class="cns-toast" role="status" aria-live="polite"></div>' +
    '</div>';
  document.body.appendChild(root);
  var card = root.querySelector('.cns-card'), $q = function(s){ return root.querySelector(s); };
  var cur = 'pgn', exN = null, img = null, gif = null, gifJob = null, lastFocus = null, urls = [];
  function url(b){ var u = URL.createObjectURL(b); urls.push(u); return u; }
  function freeUrls(){ urls.forEach(function(u){ URL.revokeObjectURL(u); }); urls = []; }

  function toast(t){ var el = $q('.cns-toast'); el.textContent = t; el.classList.add('on'); clearTimeout(toast.t); toast.t = setTimeout(function(){ el.classList.remove('on'); }, 1400); }
  function copy(text){
    function legacy(){ var ta = document.createElement('textarea'); ta.value = text; ta.setAttribute('readonly', ''); ta.style.cssText = 'position:fixed;left:-9999px;top:0'; card.appendChild(ta); ta.select(); var ok = false; try { ok = document.execCommand('copy'); } catch(err){} ta.remove(); toast(ok ? 'Copiato' : 'Non riesco a copiare'); }
    if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(text).then(function(){ toast('Copiato'); }, legacy); else legacy();
  }
  function fillPGN(){
    if (SRC){ $q('#cnsFen').value = srcNow(SRC).g.fen(); $q('#cnsPgn').value = srcPGN(SRC); return; }
    $q('#cnsFen').value = A.state.ex.fen; $q('#cnsPgn').value = buildPGN($q('#cnsCom').checked); }
  function dlState(){
    var b = $q('.cns-dl'), ready = cur === 'pgn' || (cur === 'img' && img) || (cur === 'gif' && gif);
    b.disabled = !ready;
  }
  function loadImg(){
    if (img) return;
    var ex = exN;
    var N = SRC ? srcNow(SRC) : null;
    (N ? A.renderPNG({g:N.g, ex:srcEx(SRC, N.g), orient:SRC.orient || 'w', lm:N.lm, cap:SRC.titolo || 'Chess Node', sub:SRC.sub || ''}) : A.renderPNG()).then(function(r){ if (ex !== exN) return; img = r.blob; $q('#cnsImg').src = url(img); $q('[data-p=img]').classList.add('ready'); dlState(); })
      .catch(function(err){ $q('[data-p=img] .cns-wait').textContent = 'Non sono riuscito a creare l\'immagine.'; });
  }
  function loadGif(){
    if (gif || gifJob) return;
    var ex = exN, e = A.state.ex, bar = $q('.cns-bar b'), pane = $q('[data-p=gif]');
    bar.style.width = '0%';
    gifJob = makeGIF(e, function(p){ bar.style.width = Math.round(p * 100) + '%'; }, SRC).then(function(b){
      gifJob = null; if (ex !== exN) return;
      gif = b; $q('#cnsGif').src = url(b); pane.classList.add('ready');
      $q('.cns-note').textContent = (b.frames > 1 ? (b.frames - 1) + (b.frames === 2 ? ' mossa' : ' mosse') + (SRC ? '' : ' della soluzione') + ' · ' : '') + Math.max(1, Math.round(b.size / 1024)) + ' KB';
      dlState();
    }).catch(function(err){ gifJob = null; $q('[data-p=gif] .cns-wait').textContent = 'Non sono riuscito a creare la GIF.'; });
  }
  function tab(t){
    cur = t;
    root.querySelectorAll('.cns-tabs [role=tab]').forEach(function(b){ b.setAttribute('aria-selected', b.dataset.t === t ? 'true' : 'false'); });
    root.querySelectorAll('.cns-pane').forEach(function(p){ p.hidden = p.dataset.p !== t; });
    if (t === 'img') loadImg(); else if (t === 'gif') loadGif();
    dlState();
  }
  function open(t, src){
    SRC = src && typeof src === 'object' ? src : null;
    if (!SRC && (!A.state || !A.state.ex)) return;
    var n = SRC ? 'src:' + (SRC.nome || '') + ':' + (SRC.fen0 || '') + ':' + (SRC.sans || []).join(' ') : A.state.ex.n;
    $q('.cns-chk').hidden = !!SRC;
    $q('#cnsGif').alt = SRC ? 'GIF animata della partita' : 'GIF animata della soluzione';
    // ogni apertura riparte dalla posizione attuale (l'immagine segue mosse, frecce e colori)
    freeUrls(); img = null; if (exN !== n){ gif = null; $q('[data-p=gif]').classList.remove('ready'); $q('#cnsGif').removeAttribute('src'); $q('.cns-note').textContent = ''; }
    exN = n; $q('[data-p=img]').classList.remove('ready'); $q('#cnsImg').removeAttribute('src');
    if (gif) $q('#cnsGif').src = url(gif);
    fillPGN();
    lastFocus = document.activeElement; root.hidden = false; document.documentElement.classList.add('cns-open');
    tab(t || cur); requestAnimationFrame(function(){ root.classList.add('in'); card.focus({preventScroll:true}); });
  }
  function close(){
    if (root.hidden) return;
    root.classList.remove('in'); root.hidden = true; document.documentElement.classList.remove('cns-open');
    if (lastFocus && lastFocus.focus) try { lastFocus.focus({preventScroll:true}); } catch(err){}
  }
  function dl(){
    var e = SRC ? null : A.state.ex;
    var base = SRC ? (SRC.nome || 'chessnode_analisi') : exFile(e), ttl = 'Chess Node – ' + (SRC ? (SRC.titolo || 'Analisi') : exLab(e));
    if (cur === 'pgn'){
      var txt = $q('#cnsPgn').value, name = base + (!SRC && $q('#cnsCom').checked ? '_commenti' : '') + '.pgn';
      // nell'APK lo scaricamento di un file non funziona: se non c'è la condivisione, copio il PGN negli appunti
      if (typeof window.__cnNativeShare !== 'function' && A.isNativeApp && A.isNativeApp() && !(navigator.canShare && navigator.share)){ copy(txt); return; }
      return deliver(new Blob([txt], {type:'application/x-chess-pgn'}), name, 'application/x-chess-pgn', ttl);
    }
    if (cur === 'img' && img) return deliver(img, base + '.png', 'image/png', ttl);
    if (cur === 'gif' && gif) return deliver(gif, base + '.gif', 'image/gif', ttl);
  }
  root.addEventListener('click', function(ev){
    var t = ev.target;
    if (t.classList.contains('cns-scrim') || t.closest('.cns-x')){ close(); return; }
    var tb = t.closest('.cns-tabs [role=tab]'); if (tb){ tab(tb.dataset.t); return; }
    var c = t.closest('.cns-copy'); if (c){ copy(c.dataset.c === 'fen' ? $q('#cnsFen').value : $q('#cnsPgn').value); return; }
    if (t.closest('.cns-dl')) dl();
  });
  $q('#cnsCom').addEventListener('change', fillPGN);
  root.addEventListener('keydown', function(ev){
    ev.stopPropagation();   // le scorciatoie della scacchiera (frecce, F) restano ferme mentre la finestra è aperta
    if (ev.key === 'Escape'){ ev.preventDefault(); close(); }
    else if ((ev.key === 'ArrowRight' || ev.key === 'ArrowLeft') && ev.target.closest && ev.target.closest('.cns-tabs')){
      var order = ['pgn', 'img', 'gif'], i = order.indexOf(cur) + (ev.key === 'ArrowRight' ? 1 : -1); i = (i + 3) % 3;
      tab(order[i]); $q('.cns-tabs [data-t=' + order[i] + ']').focus();
    }
  });
  window.CNShare = {open:open, close:close, buildPGN:buildPGN, makeGIF:function(){ return makeGIF(A.state.ex); }, isOpen:function(){ return !root.hidden; }};
})();
