/* Chess Node — spiega_soluzione.js (CNSpiegaSol)
 * Copyright (c) 2026 Kiko (Chess Node). Tutti i diritti riservati.
 * Codice proprietario di Kiko, scritto per Chess Node: NON è software libero, non si copia né si ridistribuisce.
 * Usa solo chess.js (BSD-2-Clause, libreria separata in lib/). Nessun codice AGPL/GPL/NC.
 * Base: modulo cn_spiega.js (31/10/2026), corretto per Chess Node (sezione K della LISTA).
 * Nome globale: window.CNSpiegaSol (window.CNSpiega resta quello di spiega_errori.js).
 */
/* Modulo — spiega in italiano PERCHE' una mossa funziona, guardando solo la posizione.
 * Nessun dato esterno: usa solo chess.js (attackers, moves, ...). Funziona su qualsiasi FEN.
 *
 * Browser:  <script src="lib/chess.min.js"></script><script src="cn_spiega.js"></script>
 *   CNSpiega.explainMove(fen, "g4f6")                    -> { tags:[...], text:"Cf6+ è una forchetta: ..." }
 *   CNSpiega.explainLine(fen, ["g4f6","g8h8","d7h7"])    -> { text:"1.Cf6+ ... Poi 2.Txh7#: ...", tags:[...] }
 *       (mosse in UCI; la prima e' di chi risolve, poi alternate; opzionale {res:"mate|win|draw", evalCp:N})
 * Node:     const CNSpiega = require("./cn_spiega.js")(Chess);
 *
 * Cosa riconosce: matto (corridoio, affogato, arabo, scala, Donna protetta, scacco doppio, di scoperta)
 *   e per ogni mossa: forchetta, inchiodatura (creata, sfruttata, o che impedisce una presa), infilata,
 *   attacco/scacco di scoperta, scacco doppio, promozione/sottopromozione, cattura libera, sacrificio,
 *   minaccia di matto; su una linea: adescamento del Re o di un pezzo, deviazione del difensore.
 *
 * LIMITI (importante per l'analisi delle partite):
 *  - Descrive cosa FA la mossa, non se e' BUONA: per giudicare usa la valutazione del motore.
 *    Il tag "sac" in una partita puo' essere uno svarione: mostralo come "sacrificio" solo se il
 *    motore dice che la mossa e' valida.
 *  - Le mosse "quiete" (posizionali) non hanno un tema tattico: explainMove ritorna text:"".
 */
(function (root) {
  "use strict";
  function build(Chess) {
    var VAL = { p: 1, n: 3, b: 3, r: 5, q: 9, k: 0 };
    var FILES = "abcdefgh";
    var NM = {
      p: { det: "il pedone", ind: "un pedone", da: "dal pedone", di: "del pedone", pl: "pedoni", sda: "dal suo pedone", spl: "dai suoi pedoni", g: "m" },
      n: { det: "il Cavallo", ind: "un Cavallo", da: "dal Cavallo", di: "del Cavallo", pl: "Cavalli", sda: "dal suo Cavallo", spl: "dai suoi Cavalli", g: "m" },
      b: { det: "l'Alfiere", ind: "un Alfiere", da: "dall'Alfiere", di: "dell'Alfiere", pl: "Alfieri", sda: "dal suo Alfiere", spl: "dai suoi Alfieri", g: "m" },
      r: { det: "la Torre", ind: "una Torre", da: "dalla Torre", di: "della Torre", pl: "Torri", sda: "dalla sua Torre", spl: "dalle sue Torri", g: "f" },
      q: { det: "la Donna", ind: "una Donna", da: "dalla Donna", di: "della Donna", pl: "Donne", sda: "dalla sua Donna", spl: "dalle sue Donne", g: "f" },
      k: { det: "il Re", ind: "un Re", da: "dal Re", di: "del Re", pl: "Re", sda: "dal suo Re", spl: "dai suoi Re", g: "m" }
    };
    var COL = { w: "Bianco", b: "Nero" };
    var DIRS = { b: [[1, 1], [1, -1], [-1, 1], [-1, -1]], r: [[1, 0], [-1, 0], [0, 1], [0, -1]] };
    DIRS.q = DIRS.b.concat(DIRS.r);

    // ---------- utilita' ----------
    var opp = function (c) { return c === "w" ? "b" : "w"; };
    var sqF = function (s) { return s.charCodeAt(0) - 97; };
    var sqR = function (s) { return +s[1] - 1; };
    var mk = function (f, r) { return f < 0 || f > 7 || r < 0 || r > 7 ? null : FILES[f] + (r + 1); };
    var cap = function (s) { return s.charAt(0).toUpperCase() + s.slice(1); };
    var lista = function (a) { if (a.length < 2) return a.join(""); var l = String(a[a.length - 1]); return a.slice(0, -1).join(", ") + (/^[eE]/.test(l) ? " ed " : " e ") + l; };
    var cadj = function (t, c) { return c === "w" ? (NM[t].g === "f" ? "bianca" : "bianco") : (NM[t].g === "f" ? "nera" : "nero"); };
    var pz = function (t, c) { return NM[t].det + " " + cadj(t, c); };
    var at = function (t, s) { return NM[t].det + " in " + s; };
    var daP = function (t, c) { return t === "k" ? "dal Re " + cadj("k", c) : NM[t].da; };
    var att = function (g, sq, c) { try { return g.attackers(sq, c); } catch (e) { return []; } };
    var ksq = function (g, c) { var f = g.findPiece({ type: "k", color: c }); return f && f[0]; };
    var pcs = function (g, c) {
      var out = [];
      g.board().forEach(function (row) { row.forEach(function (p) { if (p && p.color === c) out.push(p); }); });
      return out;
    };
    var adjSq = function (s) {
      var out = [];
      for (var df = -1; df <= 1; df++) for (var dr = -1; dr <= 1; dr++) {
        if (!df && !dr) continue;
        var x = mk(sqF(s) + df, sqR(s) + dr); if (x) out.push(x);
      }
      return out;
    };
    var between = function (a, b) {
      var df = sqF(b) - sqF(a), dr = sqR(b) - sqR(a);
      if (!(df === 0 || dr === 0 || Math.abs(df) === Math.abs(dr)) || (!df && !dr)) return null;
      var sf = Math.sign(df), sr = Math.sign(dr), out = [], f = sqF(a) + sf, r = sqR(a) + sr;
      while (mk(f, r) && mk(f, r) !== b) { out.push(mk(f, r)); f += sf; r += sr; }
      return out;
    };
    var sanIt = function (san) {
      var map = { K: "R", Q: "D", R: "T", B: "A", N: "C" };
      return san.replace(/^[KQRBN]/, function (m) { return map[m]; }).replace(/=([QRBN])/, function (_, m) { return "=" + map[m]; });
    };
    // sicura = nessuno la puo' prendere con guadagno
    var isSafe = function (g, sq, c) {
      var p = g.get(sq); if (!p) return true;
      var enemy = att(g, sq, opp(c)); if (!enemy.length) return true;
      var defended = att(g, sq, c).length > 0;
      if (enemy.every(function (s) { return g.get(s).type === "k"; })) return defended;
      var minAtk = Math.min.apply(null, enemy.map(function (s) { var t = g.get(s).type; return t === "k" ? 99 : VAL[t]; }));
      return defended && minAtk >= VAL[p.type];
    };

    // ---------- matto: perche' il Re non scappa ----------
    function mateInfo(g, mv) {
      var us = mv.color, them = opp(us), K = ksq(g, them);
      var checkers = att(g, K, us);
      var ctx = new Chess(g.fen()); ctx.remove(K);        // raggi "attraverso" il Re
      var adj = adjSq(K), blocked = [], ctrl = [], prot = [];
      adj.forEach(function (s) {
        var p = g.get(s);
        if (p && p.color === them) { blocked.push({ sq: s, t: p.type }); return; }
        var a = att(ctx, s, us);
        if (p && p.color === us) { if (a.length) prot.push({ sq: s, t: p.type, by: a }); }
        else if (a.length) ctrl.push({ sq: s, by: a });
      });
      var map = {};
      ctrl.forEach(function (c) { c.by.forEach(function (a) { (map[a] = map[a] || []).push(c.sq); }); });
      var left = ctrl.map(function (c) { return c.sq; }), groups = [];
      while (left.length) {
        var best = null, bs = -1;
        Object.keys(map).forEach(function (a) {
          var n = map[a].filter(function (s) { return left.indexOf(s) >= 0; }).length;
          var sc = n * 10 + VAL[ctx.get(a).type];
          if (sc > bs && n > 0) { bs = sc; best = a; }
        });
        if (!best) break;
        var cov = map[best].filter(function (s) { return left.indexOf(s) >= 0; }).sort();
        groups.push({ from: best, t: ctx.get(best).type, sq: cov });
        left = left.filter(function (s) { return cov.indexOf(s) < 0; });
      }
      var parts = [];
      groups.forEach(function (gr) {
        var dup = groups.filter(function (o) { return o.t === gr.t; }).length > 1;
        parts.push(lista(gr.sq) + (gr.sq.length > 1 ? " sono controllate " : " è controllata ") + daP(gr.t, us) + (dup ? " in " + gr.from : ""));
      });
      var byType = {};
      blocked.forEach(function (b) { (byType[b.t] = byType[b.t] || []).push(b.sq); });
      Object.keys(byType).forEach(function (t) {
        var s = byType[t].sort();
        parts.push(lista(s) + (s.length > 1 ? " sono occupate " + NM[t].spl : " è occupata " + NM[t].sda));
      });
      prot.filter(function (p) { return checkers.indexOf(p.sq) >= 0; }).forEach(function (p) {
        var protT = g.get(p.by[0]) ? g.get(p.by[0]).type : ctx.get(p.by[0]).type;
        parts.push(at(p.t, p.sq) + (NM[p.t].g === "f" ? " è protetta " : " è protetto ") + daP(protT, us) + " e il Re non può prenderl" + (NM[p.t].g === "f" ? "a" : "o"));
      });
      var body = parts.join(", ");
      var base = "il Re " + cadj("k", them) + " non ha case di fuga: " + body;
      var ch = checkers.map(function (s) { return { sq: s, t: g.get(s).type }; });
      var dbl = ch.length >= 2, disc = checkers.indexOf(mv.to) < 0, c0 = ch[0];
      var backRank = (them === "b" ? "8" : "1") === K[1];
      var name = null, text = null;
      var fwd = adj.filter(function (s) { return sqR(s) - sqR(K) === (them === "b" ? -1 : 1); });
      var fwdBlocked = fwd.length && fwd.every(function (s) { var p = g.get(s); return p && p.color === them; });
      if (!dbl && c0.t === "n" && blocked.length === adj.length) {
        name = "matto affogato";
        text = "Matto affogato: il Re " + cadj("k", them) + " è circondato dai suoi stessi pezzi e il Cavallo in " + c0.sq + " dà scacco senza che nessuno possa prenderlo.";
      } else if (!dbl && backRank && (c0.t === "r" || c0.t === "q") && c0.sq[1] === K[1] && fwdBlocked) {
        name = "matto del corridoio";
        var allP = fwd.every(function (s) { return g.get(s).type === "p"; });
        text = "Matto del corridoio: " + NM[c0.t].det + " dà scacco lungo l'ultima traversa e il Re " + cadj("k", them) + " è chiuso dai suoi stessi " + (allP ? "pedoni" : "pezzi") + " in " + lista(fwd.sort()) + ".";
      } else if (!dbl && c0.t === "r" && ["a1", "a8", "h1", "h8"].indexOf(K) >= 0 && adjSq(K).indexOf(c0.sq) >= 0 &&
        att(g, c0.sq, us).some(function (s) { return g.get(s).type === "n"; })) {
        var nsq = att(g, c0.sq, us).filter(function (s) { return g.get(s).type === "n"; })[0];
        name = "matto arabo";
        text = "Matto arabo: la Torre in " + c0.sq + " dà scacco ed è protetta dal Cavallo in " + nsq + "; il Re " + cadj("k", them) + " è chiuso nell'angolo e non può prenderla.";
      } else if (dbl) {
        name = "scacco doppio";
        text = "Matto con scacco doppio: nessun pezzo può parare due scacchi insieme, il Re deve muoversi ma " + parts.join(", ") + ".";
      } else if (disc) {
        name = "matto di scoperta";
        text = "Matto di scoperta: spostando " + NM[mv.piece].det + " da " + mv.from + " si apre la linea " + NM[c0.t].di + " in " + c0.sq + ", che dà scacco; " + base + ".";
      } else if (c0.t === "q" && adjSq(K).indexOf(c0.sq) >= 0 && prot.some(function (p) { return p.sq === c0.sq; })) {
        name = "matto con la Donna protetta";
        text = "Matto con la Donna protetta: " + body + ".";
      } else {
        // scala: due pezzi lineari (T/D) sull'ultima linea e su quella accanto
        var edge = K[0] === "a" || K[0] === "h" || K[1] === "1" || K[1] === "8";
        var lin = (c0.t === "r" || c0.t === "q") && edge && ((K[1] === c0.sq[1] && (K[1] === "1" || K[1] === "8")) || (K[0] === c0.sq[0] && (K[0] === "a" || K[0] === "h")));
        var inner = adj.filter(function (s) { return (K[1] === "1" || K[1] === "8") && K[1] === c0.sq[1] ? s[1] !== K[1] : s[0] !== K[0]; });
        var other = groups.filter(function (gr) { return (gr.t === "r" || gr.t === "q") && gr.from !== c0.sq && inner.every(function (s) { return gr.sq.indexOf(s) >= 0; }); })[0];
        if (lin && other && inner.length >= 2) {
          name = "matto della scala";
          text = "Matto della scala: " + NM[c0.t].det + " in " + c0.sq + " dà scacco sull'ultima linea e " + NM[other.t].det + " in " + other.from + " controlla tutta la linea accanto (" + lista(inner.sort()) + ").";
        } else {
          text = cap(base) + ".";
        }
      }
      return { name: name, text: text, base: base, checkers: ch };
    }

    // ---------- fatti su una mossa (non matto) ----------
    function lineTargets(g2, sq, type, us) {
      var out = [], ds = DIRS[type]; if (!ds) return out;
      ds.forEach(function (d) {
        var f = sqF(sq) + d[0], r = sqR(sq) + d[1], first = null, second = null;
        while (mk(f, r)) {
          var s = mk(f, r), p = g2.get(s);
          if (p) {
            if (!first) { first = { sq: s, t: p.type, c: p.color }; if (p.color === us) break; }
            else { second = { sq: s, t: p.type, c: p.color }; break; }
          }
          f += d[0]; r += d[1];
        }
        if (first && second && first.c !== us && second.c !== us) out.push({ first: first, second: second });
      });
      return out;
    }

    function moveFacts(g, mv, g2) {
      var us = mv.color, them = opp(us), to = mv.to, from = mv.from;
      var F = { us: us, them: them, mv: mv, tags: [], san: sanIt(mv.san) };
      F.movedType = mv.promotion || mv.piece;
      F.check = g2.isCheck(); F.mate = g2.isCheckmate(); F.stalemate = g2.isStalemate();
      var K = ksq(g2, them);
      F.checkers = F.check ? att(g2, K, us) : [];
      if (F.checkers.length >= 2) F.tags.push({ k: "dblcheck", pri: 9 });
      var legalCaps = g2.moves({ verbose: true }).filter(function (m) { return m.to === to; });
      var safeGeo = isSafe(g2, to, us), safe;
      if (!legalCaps.length) safe = true;
      else {
        var defTo = att(g2, to, us).length > 0;
        var minA = Math.min.apply(null, legalCaps.map(function (m) { return m.piece === "k" ? 99 : VAL[m.piece]; }));
        safe = defTo && minA >= VAL[F.movedType];
      }

      // promozione
      if (mv.promotion) F.tags.push({ k: "promo", to: mv.promotion, under: mv.promotion !== "q", pri: 6 });

      // scacco di scoperta / attacco di scoperta
      pcs(g2, us).forEach(function (s) {
        if (s.square === to || !DIRS[s.type]) return;
        pcs(g2, them).forEach(function (e) {
          if (!(e.type === "k" || VAL[e.type] >= 3)) return;
          if (!att(g2, e.square, us).includes(s.square) || att(g, e.square, us).includes(s.square)) return;
          var bt = between(s.square, e.square); if (!bt || bt.indexOf(from) < 0) return;
          F.tags.push({ k: e.type === "k" ? "disccheck" : "disc", slider: s, target: e, pri: e.type === "k" ? 9 : 8 });
        });
      });

      // forchetta
      var mvv = VAL[F.movedType], targets = [];
      pcs(g2, them).forEach(function (p) {
        if (!att(g2, p.square, us).includes(to)) return;
        if (p.type === "k") { targets.push(p); return; }
        var defended = att(g2, p.square, them).length > 0;
        if (VAL[p.type] > mvv || (!defended && VAL[p.type] >= 3)) targets.push(p);
      });
      var forkOk = !legalCaps.length || (att(g2, to, us).length > 0 && legalCaps.every(function (m) { return m.piece !== "k" && VAL[m.piece] > VAL[F.movedType]; }));
      if (targets.length >= 2 && forkOk && F.movedType !== "k") F.tags.push({ k: "fork", targets: targets, pri: 8 });
      else if (targets.length === 1 && targets[0].type !== "k" && safe && VAL[targets[0].type] > mvv && VAL[targets[0].type] >= 5) {
        F.tags.push({ k: "att", target: targets[0], pri: 3 });
      }

      // inchiodatura / infilata creata dal pezzo mosso
      if (DIRS[F.movedType] && (safe || F.check)) {
        lineTargets(g2, to, F.movedType, us).forEach(function (lt) {
          var a = lt.first, b = lt.second;
          if (a.t !== "k" && b.t === "k") F.tags.push({ k: "pin", sub: "new", a: a, b: b, abs: true, pri: 7 });
          else if (a.t === "k" && VAL[b.t] >= 3 && (att(g2, b.sq, them).length === 0 || VAL[b.t] > VAL[F.movedType])) F.tags.push({ k: "skewer", a: a, b: b, pri: 7 });
          else if (a.t !== "k" && b.t !== "k" && VAL[b.t] > VAL[a.t] && VAL[b.t] >= 5) F.tags.push({ k: "pin", sub: "new", a: a, b: b, abs: false, pri: 7 });
          else if (a.t !== "k" && b.t !== "k" && VAL[a.t] >= 5 && VAL[a.t] > VAL[b.t] && (att(g2, b.sq, them).length === 0 || VAL[b.t] > VAL[F.movedType])) F.tags.push({ k: "skewer", a: a, b: b, pri: 7 });
        });
      }

      // inchiodature GIA' presenti sulla scacchiera, sfruttate dalla mossa
      pcs(g, us).forEach(function (sl) {
        if (!DIRS[sl.type] || sl.square === from) return;
        lineTargets(g, sl.square, sl.type, us).forEach(function (lt) {
          var a = lt.first, b = lt.second;
          var abs = a.t !== "k" && b.t === "k", rel = a.t !== "k" && b.t !== "k" && VAL[b.t] > VAL[a.t] && VAL[b.t] >= 5;
          if (!abs && !rel) return;
          if (to === a.sq) F.tags.push({ k: "pin", sub: "cap", a: a, b: b, abs: abs, pri: 7 });
          else if (att(g2, a.sq, us).includes(to) && !att(g, a.sq, us).includes(from)) F.tags.push({ k: "pin", sub: "att", a: a, b: b, abs: abs, pri: 7 });
        });
      });
      // la mossa funziona perche' un difensore e' inchiodato e non puo' catturare
      if (!safeGeo && safe && !F.mate) {
        var pinnedDef = att(g2, to, them).filter(function (sq) {
          var pc = g2.get(sq); if (!pc || pc.type === "k") return false;
          var K2 = ksq(g2, them), c2 = new Chess(g2.fen()); c2.remove(sq);
          return att(c2, K2, us).length > att(g2, K2, us).length;
        });
        if (pinnedDef.length) F.tags.push({ k: "pin", sub: "def", pinned: { t: g2.get(pinnedDef[0]).type, sq: pinnedDef[0] }, pri: 8 });
      }

      // cattura
      if (mv.captured) {
        var enemyAtk = att(g2, to, them).filter(function (s) { return g2.get(s).type !== "k" || att(g2, to, us).length === 0; });
        var undefended = !att(g, to, them).some(function (s) { return s !== from; }) ;
        F.tags.push({ k: "cap", captured: mv.captured, free: enemyAtk.length === 0, undefended: undefended, pri: enemyAtk.length === 0 ? 5 : 3 });
      }

      // sacrificio (la mossa mette un pezzo dove si perde con perdita netta >=2)
      if (!safe) {
        var loss = VAL[F.movedType] - (mv.captured ? VAL[mv.captured] : 0);
        if (loss >= 2) F.tags.push({ k: "sac", piece: F.movedType, loss: loss, pri: 6 });
      }

      // minaccia di matto in una
      if (!F.check && !F.mate) {
        var fen = g2.fen().split(" "); fen[1] = us; fen[3] = "-";
        try {
          var c = new Chess(fen.join(" ")), ms = c.moves({ verbose: true });
          for (var i = 0; i < ms.length; i++) { c.move(ms[i]); var m = c.isCheckmate(); c.undo(); if (m) { F.tags.push({ k: "mthreat", move: sanIt(ms[i].san), pri: 4 }); break; } }
        } catch (e) { }
      }
      if (F.check && !F.tags.some(function (t) { return t.k === "dblcheck" || t.k === "disccheck"; })) F.tags.push({ k: "check", pri: 2 });
      F.tags.sort(function (a, b) { return b.pri - a.pri; });
      return F;
    }

    // frase breve per una mossa data (usa il tag piu' importante)
    function clause(F, tag) {
      var mv = F.mv, T = tag || F.tags[0];
      var P = at(F.movedType, mv.to);
      if (!T) return "";
      switch (T.k) {
        case "dblcheck": return "è uno scacco doppio: il Re può solo spostarsi";
        case "disccheck": return "è uno scacco di scoperta: spostando " + NM[mv.piece].det + " da " + mv.from + " si apre la linea " + NM[T.slider.type].di + " in " + T.slider.square + ", che attacca il Re";
        case "disc": return "è un attacco di scoperta: spostando " + NM[mv.piece].det + " da " + mv.from + " si apre la linea " + NM[T.slider.type].di + " in " + T.slider.square + ", che attacca " + at(T.target.type, T.target.square);
        case "fork": return "è una forchetta: " + P + " attacca insieme " + lista(T.targets.map(function (t) { return at(t.type, t.square); }));
        case "pin":
          var tgt = T.sub === "def" ? null : (T.abs ? "al Re" : "contro " + at(T.b.t, T.b.sq));
          if (T.sub === "def") return "funziona perché " + at(T.pinned.t, T.pinned.sq) + " è inchiodat" + (NM[T.pinned.t].g === "f" ? "a" : "o") + " e non può catturare";
          if (T.sub === "cap") return "cattura " + at(T.a.t, T.a.sq) + ", che era inchiodat" + (NM[T.a.t].g === "f" ? "a" : "o") + " " + tgt;
          if (T.sub === "att") return "attacca " + at(T.a.t, T.a.sq) + ", inchiodat" + (NM[T.a.t].g === "f" ? "a" : "o") + " " + tgt + ": non può scappare";
          return "inchioda " + at(T.a.t, T.a.sq) + " " + tgt;
        case "skewer": return T.a.t === "k" ? "dà scacco in infilata: quando il Re si sposta cade " + at(T.b.t, T.b.sq) : "è un'infilata: se " + at(T.a.t, T.a.sq) + " si sposta, cade " + at(T.b.t, T.b.sq);
        case "promo": return T.under ? "promuove a " + NM[T.to].ind.replace(/^un[a]? /, "") + " (sottopromozione)" : "promuove il pedone a Donna";
        case "sac": return "sacrifica " + NM[T.piece].det;
        case "cap": return "cattura " + NM[T.captured].det + " in " + mv.to + (T.free ? (T.undefended ? ", che era indifes" + (NM[T.captured].g === "f" ? "a" : "o") + ", " : ", ") + "senza che l'avversario possa riprendere" : "");
        case "mthreat": return "minaccia matto in una con " + T.move;
        case "att": return "attacca " + at(T.target.type, T.target.square);
        case "check": return "dà scacco";
      }
      return "";
    }

    function bestTag(F) { return F.tags[0] || null; }

    // ---------- linea completa (soluzione di un puzzle) ----------
    function simulate(fen, ucis) {
      var g = new Chess(fen), steps = [];
      ucis.forEach(function (u, i) {
        var before = new Chess(g.fen());
        var mv = g.move({ from: u.slice(0, 2), to: u.slice(2, 4), promotion: u[4] });
        if (!mv) throw new Error("mossa illegale " + u);
        var after = new Chess(g.fen());
        steps.push({ mv: mv, before: before, after: after, ours: i % 2 === 0, facts: i % 2 === 0 ? moveFacts(before, mv, after) : null });
      });
      return steps;
    }
    function numSan(steps, i) {
      var us = steps[0].mv.color;
      return (Math.floor(i / 2) + 1) + (us === "b" ? "..." : ".") + (steps[i].facts ? steps[i].facts.san : sanIt(steps[i].mv.san));
    }
    function takesPhr(R, ourType) {
      var g = NM[ourType].g === "f" ? "la" : "lo", forced = R.before.moves().length === 1;
      return forced ? "è costrett" + (NM[R.mv.piece].g === "f" ? "a" : "o") + " a prender" + g + " in " + R.mv.to : g + " prende in " + R.mv.to;
    }
    function gainedList(st, us) {
      var cnt = {}, num = ["", "", "due", "tre", "quattro", "cinque", "sei"];
      st.forEach(function (x) { if (x.mv.captured && x.mv.color === us) cnt[x.mv.captured] = (cnt[x.mv.captured] || 0) + 1; });
      var parts = [];
      ["q", "r", "b", "n", "p"].forEach(function (t) {
        if (!cnt[t]) return;
        parts.push(cnt[t] === 1 ? (t === "q" ? "la Donna" : NM[t].ind) : (num[cnt[t]] || cnt[t]) + " " + NM[t].pl);
      });
      return lista(parts);
    }

    function explainLine(fen, ucis, opts) {
      opts = opts || {};
      var st = simulate(fen, ucis), us = st[0].mv.color, them = opp(us);
      var last = st[st.length - 1], lastOurs = st.filter(function (s) { return s.ours; }).pop();
      var gain = 0, loss = 0, promos = [];
      st.forEach(function (s) {
        if (s.mv.captured) { if (s.mv.color === us) gain += VAL[s.mv.captured]; else loss += VAL[s.mv.captured]; }
        if (s.mv.promotion && s.mv.color === us) promos.push(s.mv.promotion);
      });
      var net = gain - loss;
      var res = last.after.isCheckmate() ? "mate" : (last.after.isStalemate() || last.after.isInsufficientMaterial() ? "draw" : (opts.res || "win"));
      var out = { res: res, tags: [], text: "" };
      var first = st[0].facts;
      var forced = st.length > 1 ? st[0].after.moves().length === 1 : false;

      // deviazione / adescamento: A (nostra), R (risposta), B (nostra)
      var dd = null;
      for (var i = 0; i + 2 < st.length && !dd; i += 2) {
        var A = st[i], R = st[i + 1], B = st[i + 2], Af = A.facts;
        var forcing = Af.check || Af.tags.some(function (t) { return t.k === "sac"; }) || !!R.mv.captured;
        if (R.mv.piece === "k" && R.mv.captured && (B.facts.check || B.after.isCheckmate() || B.facts.tags.some(function (t) { return t.k === "fork"; }))) {
          dd = { k: "decoy", sub: "king", i: i, A: A, R: R, B: B };
        } else if (R.mv.piece !== "k" && R.mv.captured && B.mv.to === R.mv.to && B.mv.captured && VAL[R.mv.piece] > VAL[Af.movedType]) {
          dd = { k: "decoy", sub: "cap", i: i, A: A, R: R, B: B };
        } else if (forcing && B.mv.captured && B.mv.to !== R.mv.to &&
          att(R.before, B.mv.to, them).indexOf(R.mv.from) >= 0 && att(R.after, B.mv.to, them).indexOf(R.mv.to) < 0) {
          dd = { k: "defl", i: i, A: A, R: R, B: B };
        }
      }

      out.all = [];
      st.forEach(function (s) { if (s.ours) s.facts.tags.forEach(function (t) { if (out.all.indexOf(t.k) < 0) out.all.push(t.k); }); });
      if (dd) out.all.push(dd.k);

      if (res === "mate") {
        var mi = mateInfo(last.after, last.mv);
        out.tags.push("mate:" + (mi.name || "generico"));
        var mateTxt = mi.text;
        if (st.length === 1) { out.text = mateTxt; return out; }
        var n = lastOurs ? st.filter(function (s) { return s.ours; }).length : 1;
        var T = bestTag(first);
        var s1 = numSan(st, 0) + " ";
        var cl = dd && dd.i === 0 && dd.sub === "king" ? null : (T && ["dblcheck", "disccheck", "fork", "sac", "promo", "check"].indexOf(T.k) >= 0 ? clause(first, T) : null);
        if (dd && dd.i === 0 && dd.k === "decoy" && dd.sub === "king") s1 += "sacrifica " + NM[dd.A.facts.movedType].det + ": il Re " + cadj("k", them) + " " + takesPhr(dd.R, dd.A.facts.movedType);
        else if (cl) s1 += cl;
        else s1 += first.check ? "dà scacco" : "prepara il matto";
        if (dd && dd.i === 0 && dd.sub === "king") { /* gia' spiegato: il Re e' costretto a prendere */ }
        else if (forced) s1 += ", e il " + COL[them] + " ha una sola risposta (" + sanIt(st[1].mv.san) + ")";
        else if (!(dd && dd.i === 0 && dd.sub === "king")) s1 += "; per il " + COL[them] + " non c'è difesa";
        out.text = cap(s1) + ". Poi " + numSan(st, st.length - 1) + ": " + (mi.name ? mi.text.charAt(0).toLowerCase() + mi.text.slice(1) : mi.text.charAt(0).toLowerCase() + mi.text.slice(1));
        out.tags.push("matto in " + n);
        return out;
      }

      // win / draw: scegli i due temi piu' forti nei nostri passi
      var cands = [];
      st.forEach(function (s, i) { if (s.ours) s.facts.tags.forEach(function (t) { if (t.k !== "check" || true) cands.push({ i: i, t: t, pri: t.pri }); }); });
      if (dd) cands.push({ i: dd.i, t: { k: dd.k, dd: dd }, pri: 9 });
      cands.sort(function (a, b) { return b.pri - a.pri || a.i - b.i; });
      var chosen = [];
      cands.forEach(function (c) {
        if (chosen.length >= 2) return;
        if (chosen.some(function (o) { return o.i === c.i || o.t.k === c.t.k || (o.t.dd && c.i === o.t.dd.i + 2) || (c.t.dd && o.i === c.t.dd.i + 2); })) return;
        chosen.push(c);
      });
      chosen.sort(function (a, b) { return a.i - b.i; });
      var phr = chosen.map(function (c, idx) {
        var s = st[c.i], t = c.t, F = s.facts, p = numSan(st, c.i) + " ";
        if (t.k === "decoy" && t.dd.sub === "king") return p + "sacrifica " + NM[F.movedType].det + ": il Re " + cadj("k", them) + " " + takesPhr(t.dd.R, F.movedType) + " e dopo " + numSan(st, t.dd.i + 2) + (t.dd.B.after.isCheck() ? " arriva uno scacco decisivo" : " il " + COL[them] + " perde materiale");
        if (t.k === "decoy") return p + "sacrifica " + NM[F.movedType].det + ": " + NM[t.dd.R.mv.piece].det + " " + cadj(t.dd.R.mv.piece, them) + " " + takesPhr(t.dd.R, F.movedType) + " e dopo " + numSan(st, t.dd.i + 2) + " viene catturat" + (NM[t.dd.R.mv.piece].g === "f" ? "a" : "o");
        if (t.k === "defl") return p + "costringe " + NM[t.dd.R.mv.piece].det + " a lasciare la difesa di " + t.dd.B.mv.to + ": dopo " + numSan(st, t.dd.i + 2) + " si cattura " + NM[t.dd.B.mv.captured].det;
        var extra = F.tags.filter(function (x) { return x.k === "pin" && x.sub === "def" && x !== t; })[0];
        return p + clause(F, t) + (extra ? "; " + clause(F, extra) : "");
      });
      var txt = "";
      if (phr.length) txt = cap(phr[0]) + (phr.length > 1 ? "; poi " + phr[1].replace(/^(\d+\.)/, "$1") : "") + ".";
      else txt = "Mossa chiave: " + numSan(st, 0) + ".";
      var outcome;
      if (res === "draw") {
        outcome = last.after.isStalemate() ? "Finisce in stallo: il Re " + cadj("k", them) + " non è sotto scacco ma non ha mosse legali, quindi è patta." : (last.after.isInsufficientMaterial() ? "Restano pezzi insufficienti per dare matto: è patta." : "Così il " + COL[us] + " salva la partita (patta).");
      } else if (promos.length && net <= 0) outcome = "Il pedone arriva in promozione e il " + COL[us] + " ottiene una posizione vincente.";
      else if (net > 0 && loss === 0) outcome = "Alla fine il " + COL[us] + " vince " + gainedList(st, us) + (promos.length ? " e promuove un pedone" : "") + ".";
      else if (net > 0) outcome = "Dopo gli scambi il " + COL[us] + " resta in vantaggio" + (promos.length ? " e promuove un pedone" : "") + ".";
      else {
        out.generic = true;
        outcome = "Alla fine il " + COL[us] + " ottiene una posizione migliore.";
      }
      out.text = txt + " " + outcome;
      out.tags = chosen.map(function (c) { return c.t.k; });
      out.net = net;
      return out;
    }
    // ======================================================================
    // explainSol: testo BREVE e VERIFICABILE per la soluzione di un esercizio
    // (Chess Node, 31/10). Ritorna { text, claims:[...], fallback:"motivo"|null }.
    // Regola di Kiko: nel dubbio un commento generico è meglio di uno sbagliato.
    // Se non trova un tema certo e realizzato nella linea -> fallback (si usa il testo vecchio).
    // opts: { res, chapter, mateName (nome del matto dal testo vecchio), oldOutcome (frase finale vecchia), max }
    // ======================================================================
    var WANT = { dbl: ["fork"], disa: ["disc", "disccheck"], disc: ["disccheck"], dch: ["dblcheck"], pin: ["pin"], skew: ["skewer"], defl: ["defl"], decoy: ["decoy"], promo: ["promo"] };
    var NUMW = ["", "", "due", "tre", "quattro", "cinque", "sei", "sette", "otto"];
    function fixG(s) {
      return s.replace(/\b(di|a|da|in|su) (il|lo|la|l'|i|gli|le) /g, function (m, p, a) {
        var P = { di: "de", a: "a", da: "da", "in": "ne", su: "su" }[p], A = { il: "l", lo: "llo", la: "lla", "l'": "ll'", i: "i", gli: "gli", le: "lle" }[a];
        return P + (a === "i" ? (p === "in" ? "i" : "i") : A) + (a === "l'" ? "" : " ");
      }).replace(/\be (e[a-h1-8]|e\b|è)/g, "ed $1").replace(/ {2,}/g, " ").replace(/\s+([,.;:])/g, "$1");
    }
    function matWords(cnt, def) {
      var parts = [];
      ["q", "r", "b", "n", "p"].forEach(function (t) {
        var n = cnt[t] || 0; if (n <= 0) return;
        parts.push(n === 1 ? (def && t === "q" ? "la Donna" : NM[t].ind) : (NUMW[n] || n) + " " + NM[t].pl);
      });
      return lista(parts);
    }
    function explainSol(fen, ucis, opts) {
      opts = opts || {};
      var MAX = opts.max || 160;
      var st = simulate(fen, ucis), us = st[0].mv.color, them = opp(us);
      var f = fen.split(" "), n0 = +f[5] || 1, blk = f[1] === "b";
      var US = "il " + COL[us], THEM = "il " + COL[them], KT = "il Re " + cadj("k", them);
      var last = st[st.length - 1], mate = last.after.isCheckmate();
      var claims = [];
      function sanOf(i) { return st[i].facts ? st[i].facts.san : sanIt(st[i].mv.san); }
      function lab(i) { var pa = i + (blk ? 1 : 0), num = n0 + Math.floor(pa / 2); return num + (pa % 2 === 0 ? "." : "…") + sanOf(i); }
      function seq(a, b) { // come la riga delle mosse sotto la scacchiera
        var out = [];
        for (var i = a; i <= b; i++) { var pa = i + (blk ? 1 : 0); if (pa % 2 === 0 || i === a) out.push(lab(i)); else out.push(sanOf(i)); }
        return out.join(" ");
      }
      function capLater(i, sq, t) { // una nostra mossa successiva cattura il pezzo t in sq
        for (var j = i + 2; j < st.length; j += 2) if (st[j].mv.to === sq && st[j].mv.captured === t) return j;
        return -1;
      }
      function fem(t) { return NM[t].g === "f"; }
      // ---- candidati (solo fatti realizzati nella linea) ----
      var cands = [];
      st.forEach(function (s, i) {
        if (!s.ours) return;
        var F = s.facts, mvT = F.movedType;
        F.tags.forEach(function (T) {
          var c = null;
          switch (T.k) {
            case "dblcheck": c = { k: "dblcheck", ply: i, checkers: F.checkers.slice(), text: "è uno scacco doppio", textL: "è uno scacco doppio: " + KT + " può solo spostarsi", pri: 9 }; break;
            case "disccheck": c = { k: "disccheck", ply: i, slider: T.slider.square, sT: T.slider.type, from: s.mv.from, text: "è uno scacco di scoperta", textL: "è uno scacco di scoperta: si apre la linea " + NM[T.slider.type].di + " in " + T.slider.square, pri: 9 }; break;
            case "disc":
              var j = capLater(i, T.target.square, T.target.type);
              if (j < 0 && !mate) break;
              c = { k: "disc", ply: i, slider: T.slider.square, sT: T.slider.type, target: T.target.square, tT: T.target.type, from: s.mv.from, realized: j,
                text: "è un attacco di scoperta su " + at(T.target.type, T.target.square),
                textL: "è un attacco di scoperta: si apre la linea " + NM[T.slider.type].di + " in " + T.slider.square + " contro " + at(T.target.type, T.target.square), pri: 8 }; break;
            case "fork":
              var real = -1;
              T.targets.forEach(function (tg) { if (tg.type !== "k" && real < 0) real = capLater(i, tg.square, tg.type); });
              if (real < 0 && !mate) break;
              var tl = T.targets.map(function (t) { return t.type === "k" ? KT : at(t.type, t.square); });
              c = { k: "fork", ply: i, sq: s.mv.to, pT: mvT, targets: T.targets.map(function (t) { return { sq: t.square, t: t.type }; }), realized: real,
                text: "è una forchetta su " + lista(tl), textL: "è una forchetta: " + at(mvT, s.mv.to) + " attacca insieme " + lista(tl), pri: 8 }; break;
            case "pin":
              if (T.sub === "def") { c = { k: "pindef", ply: i, pinned: T.pinned.sq, pT: T.pinned.t, to: s.mv.to, text: "funziona perché " + at(T.pinned.t, T.pinned.sq) + " è inchiodat" + (fem(T.pinned.t) ? "a" : "o") + " e non può catturare", pri: 7 }; c.textL = c.text; break; }
              var tgt = T.abs ? "al Re" : "contro " + at(T.b.t, T.b.sq);
              var slider = T.sub === "new" ? s.mv.to : null;
              if (T.sub === "cap" && VAL[T.a.t] < 3) break;
              if (T.sub === "cap") { c = { k: "pincap", ply: i, a: T.a.sq, aT: T.a.t, b: T.b.sq, bT: T.b.t, text: "cattura " + at(T.a.t, T.a.sq) + ", inchiodat" + (fem(T.a.t) ? "a" : "o") + " " + tgt, pri: 7 }; c.textL = c.text; break; }
              var ra = capLater(i, T.a.sq, T.a.t), rb = capLater(i, T.b.sq, T.b.t);
              if (ra < 0 && rb < 0 && !mate) break;
              if (T.sub === "att") c = { k: "pinatt", ply: i, a: T.a.sq, aT: T.a.t, b: T.b.sq, bT: T.b.t, to: s.mv.to, text: "attacca " + at(T.a.t, T.a.sq) + ", inchiodat" + (fem(T.a.t) ? "a" : "o") + " " + tgt, pri: 7 };
              else c = { k: "pin", ply: i, sq: s.mv.to, pT: mvT, a: T.a.sq, aT: T.a.t, b: T.b.sq, bT: T.b.t, text: "inchioda " + at(T.a.t, T.a.sq) + " " + tgt, pri: 7 };
              c.textL = c.text; break;
            case "skewer":
              var rs = capLater(i, T.b.sq, T.b.t);
              if (rs < 0) break;
              c = { k: "skewer", ply: i, sq: s.mv.to, pT: mvT, a: T.a.sq, aT: T.a.t, b: T.b.sq, bT: T.b.t, realized: rs,
                text: T.a.t === "k" ? "è un'infilata: quando " + KT + " si sposta, cade " + at(T.b.t, T.b.sq) : "è un'infilata: se " + at(T.a.t, T.a.sq) + " si sposta, cade " + at(T.b.t, T.b.sq), pri: 8 };
              c.textL = c.text; break;
            case "promo": c = { k: "promo", ply: i, to: s.mv.to, pT: T.to, text: T.under ? "promuove a " + NM[T.to].det.replace(/^(il |la |l')/, "") + " (sottopromozione)" : "promuove il pedone a Donna", pri: 6 }; c.textL = c.text; break;
            case "sac":
              var R = st[i + 1];
              if (!R || R.mv.to !== s.mv.to || !R.mv.captured) break;
              if (VAL[mvT] - (s.mv.captured ? VAL[s.mv.captured] : 0) < 2) break;
              if (!isSafe(s.before, s.mv.from, us)) break; // era gia' in presa: non e' un sacrificio
              c = { k: "sac", ply: i, sq: s.mv.to, pT: mvT, text: "sacrifica " + NM[mvT].det, pri: 6 }; c.textL = c.text; break;
            case "cap":
              if (!T.free || VAL[T.captured] < 3) break;
              if (i > 0 && st[i - 1].mv.to === s.mv.to) break; // e' solo una ripresa (scambio), non un guadagno
              c = { k: "capfree", ply: i, sq: s.mv.to, cT: T.captured, text: "cattura " + at(T.captured, s.mv.to) + (fem(T.captured) ? " e nessuno può riprenderla" : " e nessuno può riprenderlo"), pri: 5 }; c.textL = c.text; break;
            case "mthreat": c = { k: "mthreat", ply: i, move: T.move, text: "minaccia matto con " + T.move, pri: 4 }; c.textL = c.text; break;
          }
          if (c) cands.push(c);
        });
      });
      // adescamento / deviazione (A nostra, R risposta, B nostra)
      for (var i = 0; i + 2 < st.length; i += 2) {
        var A = st[i], R = st[i + 1], B = st[i + 2], Af = A.facts, AT = Af.movedType;
        var lossA = isSafe(A.before, A.mv.from, us) && !A.mv.promotion ? VAL[AT] - (A.mv.captured ? VAL[A.mv.captured] : 0) : 0;
        if (R.mv.piece === "k" && R.mv.captured && R.mv.to === A.mv.to && lossA >= 1 && (B.after.isCheck() || B.facts.tags.some(function (t) { return t.k === "fork"; }))) {
          var forcedK = R.before.moves().length === 1;
          cands.push({ k: "decoy", sub: "king", ply: i, sq: A.mv.to, pT: AT, forced: forcedK, pri: 9,
            text: "sacrifica " + NM[AT].det + ": " + KT + (forcedK ? " è costretto a prender" + (fem(AT) ? "la" : "lo") : " l" + (fem(AT) ? "a" : "o") + " prende in " + A.mv.to) });
        } else if (R.mv.piece !== "k" && R.mv.captured && R.mv.to === A.mv.to && B.mv.to === R.mv.to && B.mv.captured && VAL[R.mv.piece] > VAL[AT] && lossA >= 1) {
          cands.push({ k: "decoy", sub: "cap", ply: i, sq: A.mv.to, pT: AT, rT: R.mv.piece, pri: 8,
            text: "sacrifica " + NM[AT].det + " per attirare " + pz(R.mv.piece, them) + " in " + A.mv.to });
        } else if ((Af.check || !!R.mv.captured) && B.mv.captured && B.mv.to !== R.mv.to &&
          att(R.before, B.mv.to, them).indexOf(R.mv.from) >= 0 && att(R.after, B.mv.to, them).indexOf(R.mv.to) < 0 &&
          att(R.after, B.mv.to, them).length === 0) {
          cands.push({ k: "defl", ply: i, rFrom: R.mv.from, rT: R.mv.piece, target: B.mv.to, bply: i + 2, pri: 8,
            text: "costringe " + pz(R.mv.piece, them) + " a lasciare la difesa di " + B.mv.to });
        }
      }
      cands.forEach(function (c) { if (!c.textL) c.textL = c.text; });
      var want = WANT[opts.chapter] || [];
      function key(c) { return c.k === "pindef" || c.k === "pincap" || c.k === "pinatt" ? "pin" : c.k; }
      cands.forEach(function (c) { c.score = c.pri + (want.indexOf(key(c)) >= 0 ? 20 : 0) - c.ply * 0.1; });
      cands.sort(function (a, b) { return b.score - a.score; });
      var res = mate ? "mate" : (opts.res || "win");

      function pick(cands2) { // primo testo che sta nel limite
        for (var k = 0; k < cands2.length; k++) { var t = fixG(cands2[k]); if (t.length <= MAX && (t.match(/[.!?](\s|$)/g) || []).length <= 2) return t; }
        return null;
      }
      function forcedReply(i) { return st[i + 1] && st[i].after.moves().length === 1; }

      // --------------------------- MATTO ---------------------------
      if (mate) {
        var mi = mateInfo(last.after, last.mv), nm = opts.mateName || null;
        var nameSrc = nm ? "old" : (mi.name && mi.name !== "matto con la Donna protetta" ? "cn" : null);
        var mname = nm || (nameSrc ? (mi.name === "scacco doppio" ? "matto con scacco doppio" : mi.name) : null);
        claims.push({ k: "mate", ply: st.length - 1, name: mname, nameSrc: nameSrc, cnName: mi.name, checkers: mi.checkers });
        var Kq = ksq(last.after, them), c0 = mi.checkers[0];
        var whyL = [], whyS = [];
        if (mi.name === "matto affogato") { whyL.push(KT + " è chiuso dai suoi pezzi e il Cavallo dà scacco"); }
        else if (mi.name === "matto del corridoio") { whyL.push(KT + " è chiuso dai suoi pezzi sulla traversa davanti"); }
        else if (mi.name === "matto arabo") { whyL.push("la Torre è protetta dal Cavallo e " + KT + " è chiuso nell'angolo"); }
        else if (mi.name === "matto con la Donna protetta") {
          var pb = att(last.after, c0.sq, us).filter(function (s) { return s !== c0.sq; })[0];
          var pbT = pb ? last.after.get(pb).type : null;
          if (pbT) { whyL.push("la Donna in " + c0.sq + " è protetta " + daP(pbT, us) + " e " + KT + " non può prenderla"); claims.push({ k: "qprot", ply: st.length - 1, q: c0.sq, by: pb, byT: pbT }); }
        }
        else if (mi.name === "scacco doppio") whyL.push("due pezzi danno scacco insieme e " + KT + " non ha case libere");
        else if (mi.name === "matto di scoperta") whyL.push("si apre la linea " + NM[c0.t].di + " in " + c0.sq + " e " + KT + " non ha case libere");
        whyS.push(KT + " non ha case di fuga");
        var whys = whyL.concat(whyS);
        var tx = [];
        if (st.length === 1) {
          var head = "Con " + lab(0) + " " + US + " dà matto";
          whys.forEach(function (w) { if (mname) tx.push(head + ": è il " + mname + ". " + cap(w) + "."); else tx.push(head + ". " + cap(w) + "."); });
          if (mname) tx.push(head + ": è il " + mname + ".");
          var t1 = pick(tx); if (!t1) return { text: "", claims: claims, fallback: "lunghezza" };
          return { text: t1, claims: claims, fallback: null };
        }
        // matto in N: frase 1 = la mossa chiave (tema del capitolo prima), frase 2 = il resto fino al matto
        var main = null;
        cands.forEach(function (c) { if (!main && (want.indexOf(key(c)) >= 0)) main = c; });
        if (!main) cands.forEach(function (c) { if (!main && c.ply === 0 && ["dblcheck", "disccheck", "fork", "sac", "decoy", "promo", "pin", "pincap", "mthreat", "skewer", "defl"].indexOf(c.k) >= 0) main = c; });
        var mp = main ? main.ply : 0;
        if (main) claims.push(main);
        var s1v = [];
        var pre = mp > 0 ? "Dopo " + seq(0, mp - 1) + ", " : "";
        var cl = main ? [main.textL, main.text] : [st[0].facts.check ? "dà scacco" : "prepara il matto"];
        if (!main && st[0].facts.check) claims.push({ k: "check", ply: 0 });
        var fr = forcedReply(mp) && !(main && main.k === "decoy" && main.sub === "king");
        if (fr) claims.push({ k: "forced", ply: mp });
        var nxt = fr ? mp + 2 : mp + 1;
        var endTail = mname ? [": è il " + mname, ": " + whys[0], ""] : whys.map(function (w) { return ": " + w; }).concat([""]);
        var tails = [];
        endTail.forEach(function (et) {
          var after = nxt <= st.length - 1 ? seq(nxt, st.length - 1) : "";
          if (nxt === st.length - 1) tails.push(cap((et ? lab(st.length - 1) + " è matto" + et.replace(/^: è il /, ", il ") : "Poi " + lab(st.length - 1) + " è matto")) + ".");
          else tails.push("Poi " + after + et + ".");
        });
        if (mp === st.length - 1) {
          cl.forEach(function (c) {
            var s0 = cap(pre + lab(mp) + " " + c.replace(/:.*$/, "") + " ed è matto") + ".";
            (mname ? ["È il " + mname + ".", ""] : whys.map(function (w) { return cap(w) + "."; }).concat([""])).forEach(function (t) { s1v.push((s0 + " " + t).trim()); });
          });
        } else cl.forEach(function (c) {
          var s1 = cap(pre + lab(mp) + " " + c + (fr ? (/ e |:/.test(c) ? "; " : " e ") + THEM + " ha una sola risposta, " + lab(mp + 1) : "")) + ".";
          tails.forEach(function (t) { s1v.push(s1 + " " + t); });
        });
        var t2 = pick(s1v);
        if (!t2) return { text: "", claims: claims, fallback: "lunghezza" };
        return { text: t2, claims: claims, fallback: null };
      }

      // --------------------------- VINCE / PATTA ---------------------------
      var main2 = cands[0] || null;
      if (!main2) return { text: "", claims: claims, fallback: "nessun tema certo" };
      claims.push(main2);
      // esito: materiale (solo se certo) altrimenti frase finale vecchia
      var gain = {}, lost = {}, prom = 0;
      st.forEach(function (s) {
        if (s.mv.captured) { var o = s.mv.color === us ? gain : lost; o[s.mv.captured] = (o[s.mv.captured] || 0) + 1; }
        if (s.mv.promotion && s.mv.color === us) prom++;
      });
      ["q", "r", "b", "n", "p"].forEach(function (t) { var m = Math.min(gain[t] || 0, lost[t] || 0); if (m) { gain[t] -= m; lost[t] -= m; } });
      // Alfiere e Cavallo si equivalgono
      [["b", "n"], ["n", "b"]].forEach(function (pr) { var m = Math.min(gain[pr[0]] || 0, lost[pr[1]] || 0); if (m) { gain[pr[0]] -= m; lost[pr[1]] -= m; } });
      var gm = (gain.b || 0) + (gain.n || 0), lm2 = (lost.b || 0) + (lost.n || 0);
      var sum = function (o) { return Object.keys(o).reduce(function (a, t) { return a + VAL[t] * o[t]; }, 0); };
      var net = sum(gain) - sum(lost);
      var worst = 0;
      last.after.moves({ verbose: true }).forEach(function (m) {
        if (!m.captured) return;
        var g3 = new Chess(last.after.fen()); g3.move(m);
        var def = att(g3, m.to, us).length > 0;
        var w = VAL[m.captured] - (def ? (m.piece === "k" ? 99 : VAL[m.piece]) : 0);
        if (m.promotion) w += 8;
        if (w > worst) worst = w;
      });
      var outs = [];
      var certain = res === "win" && !prom && net >= 1 && worst <= 0 && last.mv.color === us;
      if (res === "draw" && last.after.isStalemate()) { outs.push("Finisce in stallo: è patta."); claims.push({ k: "stalemate", ply: st.length - 1 }); }
      else if (res === "draw" && last.after.isInsufficientMaterial()) { outs.push("Restano pezzi insufficienti per il matto: è patta."); claims.push({ k: "insuff", ply: st.length - 1 }); }
      else if (certain && gm >= 0 && lm2 >= 0) {
        var gw = matWords(gain, true), lw = matWords(lost, false);
        if (gw) {
          outs.push("Alla fine " + US + " vince " + gw + (lw ? " per " + lw : "") + ".");
          claims.push({ k: "material", gain: gain, lost: lost, net: net, worst: worst });
        }
      }
      if (opts.oldOutcome) outs.push(opts.oldOutcome);
      if (!outs.length) return { text: "", claims: claims, fallback: "esito incerto" };
      var pre2 = main2.ply > 0 ? "Dopo " + seq(0, main2.ply - 1) + ", " : "";
      var base2 = main2.k === "decoy" || main2.k === "defl" ? lab(main2.ply) + " " : lab(main2.ply) + " ";
      var vs = [];
      [main2.textL, main2.text].forEach(function (c) { outs.forEach(function (o) { vs.push(cap(pre2 + base2 + c) + ". " + o); }); });
      if (main2.ply > 0) [main2.textL, main2.text].forEach(function (c) { outs.forEach(function (o) { vs.push(cap(lab(main2.ply) + " " + c) + ". " + o); }); });
      var t3 = pick(vs);
      if (!t3) return { text: "", claims: claims, fallback: "lunghezza" };
      return { text: t3, claims: claims, fallback: null };
    }

    function cadjSafe(c) { return c === "w" ? "bianco" : "nero"; }

    // ---------- singola mossa (per analisi partite) ----------
    function explainMove(fen, uci) {
      var before = new Chess(fen), g = new Chess(fen);
      var mv = g.move({ from: uci.slice(0, 2), to: uci.slice(2, 4), promotion: uci[4] });
      if (!mv) return null;
      var after = new Chess(g.fen());
      if (after.isCheckmate()) { var mi = mateInfo(after, mv); return { tags: ["mate"], text: mi.text }; }
      var F = moveFacts(before, mv, after), T = bestTag(F);
      if (!T) return { tags: [], text: "" };
      return { tags: F.tags.map(function (t) { return t.k; }), text: F.san + " " + clause(F, T) + "." };
    }

    return { explainMove: explainMove, explainLine: explainLine, explainSol: explainSol, simulate: simulate, mateInfo: mateInfo, moveFacts: moveFacts, sanIt: sanIt, fixG: fixG };
  }

  if (typeof module === "object" && module.exports) module.exports = build;
  else { root.CNSpiegaSol = root.Chess ? build(root.Chess) : { init: function (C) { root.CNSpiegaSol = build(C); } }; }
})(typeof window !== "undefined" ? window : globalThis);
